//! Kernel Bypass & Stream I/O engine using io_uring SQPOLL and fixed buffers.

use std::alloc::{alloc_zeroed, dealloc, Layout};
use std::fmt;
use std::io;
use std::os::raw::{c_int, c_uint, c_void};
use std::ptr::{self, NonNull};
use std::sync::atomic::{AtomicU32, Ordering};
use thiserror::Error;

#[derive(Error, Debug)]
pub enum IoUringError {
    #[error("io_uring_setup syscall failed: {0}")]
    SetupFailed(io::Error),
    #[error("io_uring_enter syscall failed: {0}")]
    EnterFailed(io::Error),
    #[error("io_uring_register syscall failed: {0}")]
    RegisterFailed(io::Error),
    #[error("mmap ring buffer failed: {0}")]
    MmapFailed(io::Error),
    #[error("Submission queue is full (capacity: {0})")]
    SubmissionQueueFull(u32),
    #[error("Buffer pool exhausted")]
    BufferPoolExhausted,
    #[error("CPU core pinning failed for core {core}: {source}")]
    CorePinFailed { core: usize, source: io::Error },
    #[error("Invalid ring configuration: {0}")]
    InvalidConfig(String),
}

#[cfg(target_arch = "x86_64")]
const SYS_IO_URING_SETUP: i64 = 425;
#[cfg(target_arch = "x86_64")]
const SYS_IO_URING_ENTER: i64 = 426;
#[cfg(target_arch = "x86_64")]
const SYS_IO_URING_REGISTER: i64 = 427;
#[cfg(not(target_arch = "x86_64"))]
const SYS_IO_URING_SETUP: i64 = 425;
#[cfg(not(target_arch = "x86_64"))]
const SYS_IO_URING_ENTER: i64 = 426;
#[cfg(not(target_arch = "x86_64"))]
const SYS_IO_URING_REGISTER: i64 = 427;

pub const IORING_SETUP_SQPOLL: u32 = 1 << 1;
pub const IORING_SETUP_SQ_AFF: u32 = 1 << 2;
pub const IORING_SETUP_CQSIZE: u32 = 1 << 3;
pub const IORING_SETUP_CLAMP: u32 = 1 << 4;
pub const IORING_SETUP_ATTACH_WQ: u32 = 1 << 5;

pub const IORING_OP_NOP: u8 = 0;
pub const IORING_OP_READV: u8 = 1;
pub const IORING_OP_WRITEV: u8 = 2;
pub const IORING_OP_READ_FIXED: u8 = 4;
pub const IORING_OP_WRITE_FIXED: u8 = 5;
pub const IORING_OP_POLL_ADD: u8 = 6;
pub const IORING_OP_POLL_REMOVE: u8 = 7;
pub const IORING_OP_SENDMSG: u8 = 9;
pub const IORING_OP_RECVMSG: u8 = 10;
pub const IORING_OP_ACCEPT: u8 = 13;
pub const IORING_ACCEPT_MULTISHOT: u16 = 1 << 0;
pub const IORING_CQE_F_MORE: u32 = 1 << 1;
pub const IORING_OP_CONNECT: u8 = 16;
pub const IORING_OP_CLOSE: u8 = 19;
pub const IORING_OP_READ: u8 = 22;
pub const IORING_OP_WRITE: u8 = 23;
pub const IORING_OP_SPLICE: u8 = 30;

pub const IORING_REGISTER_BUFFERS: u32 = 0;
pub const IORING_UNREGISTER_BUFFERS: u32 = 1;
pub const IORING_REGISTER_FILES: u32 = 2;
pub const IORING_UNREGISTER_FILES: u32 = 3;

pub const IORING_ENTER_GETEVENTS: u32 = 1 << 0;
pub const IORING_ENTER_SQ_WAKEUP: u32 = 1 << 1;
pub const IORING_ENTER_SQ_WAIT: u32 = 1 << 2;
pub const IORING_SQ_NEED_WAKEUP: u32 = 1 << 0;

pub const IORING_OFF_SQ_RING: u64 = 0;
pub const IORING_OFF_CQ_RING: u64 = 0x8000000;
pub const IORING_OFF_SQES: u64 = 0x10000000;

#[repr(C)]
#[derive(Debug, Clone, Copy, Default)]
pub struct io_sqring_offsets {
    pub head: u32,
    pub tail: u32,
    pub ring_mask: u32,
    pub ring_entries: u32,
    pub flags: u32,
    pub dropped: u32,
    pub array: u32,
    pub resv1: u32,
    pub resv2: u64,
}

#[repr(C)]
#[derive(Debug, Clone, Copy, Default)]
pub struct io_cqring_offsets {
    pub head: u32,
    pub tail: u32,
    pub ring_mask: u32,
    pub ring_entries: u32,
    pub overflow: u32,
    pub cqes: u32,
    pub flags: u32,
    pub resv1: u32,
    pub resv2: u64,
}

#[repr(C)]
#[derive(Debug, Clone, Copy, Default)]
pub struct io_uring_params {
    pub sq_entries: u32,
    pub cq_entries: u32,
    pub flags: u32,
    pub sq_thread_cpu: u32,
    pub sq_thread_idle: u32,
    pub features: u32,
    pub wq_fd: u32,
    pub resv: [u32; 3],
    pub sq_off: io_sqring_offsets,
    pub cq_off: io_cqring_offsets,
}

#[repr(C)]
#[derive(Clone, Copy)]
pub struct io_uring_sqe {
    pub opcode: u8,
    pub flags: u8,
    pub ioprio: u16,
    pub fd: i32,
    pub off: u64,
    pub addr: u64,
    pub len: u32,
    pub rw_flags: u32,
    pub user_data: u64,
    pub buf_index: u16,
    pub personality: u16,
    pub splice_fd_in: i32,
    pub addr3_or_pad: [u64; 2],
}

impl Default for io_uring_sqe {
    fn default() -> Self {
        unsafe { std::mem::zeroed() }
    }
}

impl fmt::Debug for io_uring_sqe {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("io_uring_sqe")
            .field("opcode", &self.opcode)
            .field("fd", &self.fd)
            .field("len", &self.len)
            .field("user_data", &self.user_data)
            .finish()
    }
}

#[repr(C)]
#[derive(Debug, Clone, Copy, Default)]
pub struct io_uring_cqe {
    pub user_data: u64,
    pub res: i32,
    pub flags: u32,
}

pub unsafe fn sys_io_uring_setup(entries: u32, params: *mut io_uring_params) -> c_int {
    unsafe { libc::syscall(SYS_IO_URING_SETUP, entries as c_uint, params) as c_int }
}

pub unsafe fn sys_io_uring_enter(
    fd: c_int,
    to_submit: u32,
    min_complete: u32,
    flags: u32,
    sig: *const libc::sigset_t,
) -> c_int {
    unsafe {
        libc::syscall(
            SYS_IO_URING_ENTER,
            fd,
            to_submit as c_uint,
            min_complete as c_uint,
            flags as c_uint,
            sig,
            std::mem::size_of::<libc::sigset_t>(),
        ) as c_int
    }
}

pub unsafe fn sys_io_uring_register(
    fd: c_int,
    opcode: u32,
    arg: *const c_void,
    nr_args: u32,
) -> c_int {
    unsafe {
        libc::syscall(
            SYS_IO_URING_REGISTER,
            fd,
            opcode as c_uint,
            arg,
            nr_args as c_uint,
        ) as c_int
    }
}

pub fn pin_to_core(core_id: usize) -> Result<(), IoUringError> {
    #[cfg(target_os = "linux")]
    {
        let mut set: libc::cpu_set_t = unsafe { std::mem::zeroed() };
        let ret = unsafe {
            libc::CPU_SET(core_id, &mut set);
            libc::sched_setaffinity(0, std::mem::size_of::<libc::cpu_set_t>(), &set)
        };
        if ret != 0 {
            return Err(IoUringError::CorePinFailed {
                core: core_id,
                source: io::Error::last_os_error(),
            });
        }
        Ok(())
    }
    #[cfg(not(target_os = "linux"))]
    {
        let _ = core_id;
        Ok(())
    }
}

#[inline(always)]
pub fn cpu_pause() {
    #[cfg(target_arch = "x86_64")]
    unsafe {
        core::arch::x86_64::_mm_pause();
    }
    #[cfg(not(target_arch = "x86_64"))]
    {
        core::hint::spin_loop();
    }
}

#[derive(Debug, Clone, Copy)]
pub struct AdaptiveBackoff {
    spin_limit: u32,
    current_spin: u32,
}

impl AdaptiveBackoff {
    pub const fn new(spin_limit: u32) -> Self {
        Self {
            spin_limit,
            current_spin: 0,
        }
    }

    #[inline(always)]
    pub fn spin(&mut self) {
        if self.current_spin < self.spin_limit {
            cpu_pause();
            self.current_spin += 1;
        } else {
            std::thread::yield_now();
        }
    }

    #[inline(always)]
    pub fn reset(&mut self) {
        self.current_spin = 0;
    }
}

pub struct FixedBufferPool {
    memory: NonNull<u8>,
    buffer_size: usize,
    num_buffers: usize,
    free_indices: Vec<u16>,
    iovecs: Vec<libc::iovec>,
    layout: Layout,
    bitmap: Vec<u64>,
}

unsafe impl Send for FixedBufferPool {}
unsafe impl Sync for FixedBufferPool {}

impl FixedBufferPool {
    pub fn new(num_buffers: usize, buffer_size: usize) -> Result<Self, IoUringError> {
        if num_buffers == 0 || buffer_size == 0 || num_buffers > 65535 {
            return Err(IoUringError::InvalidConfig(
                "Invalid fixed buffer pool dimensions".to_string(),
            ));
        }
        if buffer_size % 64 != 0 {
            return Err(IoUringError::InvalidConfig(format!(
                "buffer_size {buffer_size} must be a multiple of 64"
            )));
        }

        let total_size = num_buffers
            .checked_mul(buffer_size)
            .ok_or_else(|| IoUringError::InvalidConfig("Buffer pool size overflow".to_string()))?;
        let layout = Layout::from_size_align(total_size, 4096).map_err(|_| {
            IoUringError::InvalidConfig("Invalid page alignment layout".to_string())
        })?;

        let raw = unsafe { alloc_zeroed(layout) };
        let memory = NonNull::new(raw).ok_or_else(|| {
            IoUringError::MmapFailed(io::Error::new(
                io::ErrorKind::OutOfMemory,
                "Fixed buffer allocation failed",
            ))
        })?;

        let mut free_indices = Vec::with_capacity(num_buffers);
        let mut iovecs = Vec::with_capacity(num_buffers);
        for i in 0..num_buffers {
            free_indices.push(i as u16);
            let buf_ptr = unsafe { memory.as_ptr().add(i * buffer_size) };
            iovecs.push(libc::iovec {
                iov_base: buf_ptr as *mut c_void,
                iov_len: buffer_size,
            });
        }

        let words = (num_buffers + 63) / 64;
        Ok(Self {
            memory,
            buffer_size,
            num_buffers,
            free_indices,
            iovecs,
            layout,
            bitmap: vec![0u64; words],
        })
    }

    #[inline(always)]
    pub fn buffer_size(&self) -> usize {
        self.buffer_size
    }

    #[inline(always)]
    pub fn num_buffers(&self) -> usize {
        self.num_buffers
    }

    #[inline(always)]
    pub fn available_buffers(&self) -> usize {
        self.free_indices.len()
    }

    pub fn acquire(&mut self) -> Result<u16, IoUringError> {
        let idx = self.free_indices.pop().ok_or(IoUringError::BufferPoolExhausted)?;
        let word = (idx as usize) / 64;
        let bit = (idx as usize) % 64;
        self.bitmap[word] |= 1u64 << bit;
        Ok(idx)
    }

    pub fn release(&mut self, index: u16) {
        if (index as usize) >= self.num_buffers {
            return;
        }
        let word = (index as usize) / 64;
        let bit = (index as usize) % 64;
        let mask = 1u64 << bit;

        if (self.bitmap[word] & mask) == 0 {
            return;
        }

        self.bitmap[word] &= !mask;
        self.free_indices.push(index);
    }

    #[inline]
    pub fn get_slice(&self, index: u16) -> &[u8] {
        assert!(
            (index as usize) < self.num_buffers,
            "FixedBufferPool::get_slice: index out of bounds"
        );
        let offset = (index as usize) * self.buffer_size;
        unsafe { std::slice::from_raw_parts(self.memory.as_ptr().add(offset), self.buffer_size) }
    }

    #[inline]
    pub fn get_slice_mut(&mut self, index: u16) -> &mut [u8] {
        assert!(
            (index as usize) < self.num_buffers,
            "FixedBufferPool::get_slice_mut: index out of bounds"
        );
        let offset = (index as usize) * self.buffer_size;
        unsafe { std::slice::from_raw_parts_mut(self.memory.as_ptr().add(offset), self.buffer_size) }
    }

    pub fn register(&self, ring_fd: i32) -> Result<(), IoUringError> {
        if ring_fd < 0 {
            return Ok(());
        }
        let ret = unsafe {
            sys_io_uring_register(
                ring_fd,
                IORING_REGISTER_BUFFERS,
                self.iovecs.as_ptr() as *const c_void,
                self.iovecs.len() as u32,
            )
        };
        if ret < 0 {
            let err = io::Error::last_os_error();
            if matches!(err.raw_os_error(), Some(libc::EPERM) | Some(libc::ENOSYS) | Some(libc::EOPNOTSUPP)) {
                return Ok(());
            }
            return Err(IoUringError::RegisterFailed(err));
        }
        Ok(())
    }
}

impl Drop for FixedBufferPool {
    fn drop(&mut self) {
        unsafe {
            dealloc(self.memory.as_ptr(), self.layout);
        }
    }
}

#[derive(Debug, Clone, Copy)]
pub struct CqeEvent {
    pub user_data: u64,
    pub result: i32,
    pub flags: u32,
}

#[derive(Debug, Clone)]
pub struct IoUringConfig {
    pub entries: u32,
    pub sqpoll_cpu: Option<u32>,
    pub sqpoll_idle_ms: u32,
    pub fixed_buffer_count: usize,
    pub fixed_buffer_size: usize,
}

impl Default for IoUringConfig {
    fn default() -> Self {
        Self {
            entries: 1024,
            sqpoll_cpu: None,
            sqpoll_idle_ms: 2000,
            fixed_buffer_count: 512,
            fixed_buffer_size: 16384,
        }
    }
}

enum RingBackend {
    Kernel {
        ring_fd: i32,
        sq_khead: *const AtomicU32,
        sq_ktail: *mut AtomicU32,
        sq_kflags: *const AtomicU32,
        sq_ring_mask: u32,
        sqes: *mut io_uring_sqe,
        sq_array: *mut u32,
        sq_ring_size: usize,
        sq_mmap_ptr: *mut c_void,
        sqes_mmap_ptr: *mut c_void,
        sqes_size: usize,
        cq_khead: *mut AtomicU32,
        cq_ktail: *const AtomicU32,
        cqes: *const io_uring_cqe,
        cq_ring_mask: u32,
        cq_ring_size: usize,
        cq_mmap_ptr: *mut c_void,
    },
    Simulated {
        sq_queue: Vec<io_uring_sqe>,
        cq_queue: Vec<io_uring_cqe>,
        capacity: u32,
    },
}

unsafe impl Send for RingBackend {}
unsafe impl Sync for RingBackend {}

pub struct IoUringDriver {
    #[allow(dead_code)]
    config: IoUringConfig,
    backend: RingBackend,
    fixed_buffers: FixedBufferPool,
    pending_sqes: Vec<io_uring_sqe>,
}

impl IoUringDriver {
    pub fn new(config: IoUringConfig) -> Result<Self, IoUringError> {
        let fixed_buffers =
            FixedBufferPool::new(config.fixed_buffer_count, config.fixed_buffer_size)?;
        let backend = match Self::setup_kernel_sqpoll(&config) {
            Ok(k) => k,
            Err(_) => RingBackend::Simulated {
                sq_queue: Vec::with_capacity(config.entries as usize),
                cq_queue: Vec::with_capacity(config.entries as usize * 2),
                capacity: config.entries,
            },
        };
        let driver = Self {
            config,
            backend,
            fixed_buffers,
            pending_sqes: Vec::with_capacity(128),
        };
        if let RingBackend::Kernel { ring_fd, .. } = &driver.backend {
            let _ = driver.fixed_buffers.register(*ring_fd);
        }
        Ok(driver)
    }

    fn setup_kernel_sqpoll(config: &IoUringConfig) -> Result<RingBackend, IoUringError> {
        if cfg!(miri) {
            return Err(IoUringError::SetupFailed(std::io::Error::new(
                std::io::ErrorKind::Unsupported,
                "miri stub",
            )));
        }
        let mut p: io_uring_params = unsafe { std::mem::zeroed() };
        p.flags = IORING_SETUP_SQPOLL;
        p.sq_thread_idle = config.sqpoll_idle_ms;
        if let Some(cpu) = config.sqpoll_cpu {
            p.flags |= IORING_SETUP_SQ_AFF;
            p.sq_thread_cpu = cpu;
        }

        let ring_fd = unsafe { sys_io_uring_setup(config.entries, &mut p) };
        if ring_fd < 0 {
            return Err(IoUringError::SetupFailed(io::Error::last_os_error()));
        }

        let sq_ring_size =
            (p.sq_off.array as usize) + (p.sq_entries as usize) * std::mem::size_of::<u32>();
        let cq_ring_size = (p.cq_off.cqes as usize)
            + (p.cq_entries as usize) * std::mem::size_of::<io_uring_cqe>();

        let sq_mmap_ptr = unsafe {
            libc::mmap(
                ptr::null_mut(),
                sq_ring_size,
                libc::PROT_READ | libc::PROT_WRITE,
                libc::MAP_SHARED | libc::MAP_POPULATE,
                ring_fd,
                IORING_OFF_SQ_RING as libc::off_t,
            )
        };
        if sq_mmap_ptr == libc::MAP_FAILED {
            unsafe { libc::close(ring_fd) };
            return Err(IoUringError::MmapFailed(io::Error::last_os_error()));
        }

        let cq_mmap_ptr = unsafe {
            libc::mmap(
                ptr::null_mut(),
                cq_ring_size,
                libc::PROT_READ | libc::PROT_WRITE,
                libc::MAP_SHARED | libc::MAP_POPULATE,
                ring_fd,
                IORING_OFF_CQ_RING as libc::off_t,
            )
        };
        if cq_mmap_ptr == libc::MAP_FAILED {
            unsafe {
                libc::munmap(sq_mmap_ptr, sq_ring_size);
                libc::close(ring_fd);
            }
            return Err(IoUringError::MmapFailed(io::Error::last_os_error()));
        }

        let sqes_size = (p.sq_entries as usize) * std::mem::size_of::<io_uring_sqe>();
        let sqes_mmap_ptr = unsafe {
            libc::mmap(
                ptr::null_mut(),
                sqes_size,
                libc::PROT_READ | libc::PROT_WRITE,
                libc::MAP_SHARED | libc::MAP_POPULATE,
                ring_fd,
                IORING_OFF_SQES as libc::off_t,
            )
        };
        if sqes_mmap_ptr == libc::MAP_FAILED {
            unsafe {
                libc::munmap(cq_mmap_ptr, cq_ring_size);
                libc::munmap(sq_mmap_ptr, sq_ring_size);
                libc::close(ring_fd);
            }
            return Err(IoUringError::MmapFailed(io::Error::last_os_error()));
        }

        let sq_base = sq_mmap_ptr as *mut u8;
        let cq_base = cq_mmap_ptr as *mut u8;

        unsafe {
            Ok(RingBackend::Kernel {
                ring_fd,
                sq_khead: sq_base.add(p.sq_off.head as usize) as *const AtomicU32,
                sq_ktail: sq_base.add(p.sq_off.tail as usize) as *mut AtomicU32,
                sq_kflags: sq_base.add(p.sq_off.flags as usize) as *const AtomicU32,
                sq_ring_mask: *(sq_base.add(p.sq_off.ring_mask as usize) as *const u32),
                sqes: sqes_mmap_ptr as *mut io_uring_sqe,
                sq_array: sq_base.add(p.sq_off.array as usize) as *mut u32,
                sq_ring_size,
                sq_mmap_ptr,
                sqes_mmap_ptr,
                sqes_size,
                cq_khead: cq_base.add(p.cq_off.head as usize) as *mut AtomicU32,
                cq_ktail: cq_base.add(p.cq_off.tail as usize) as *const AtomicU32,
                cqes: cq_base.add(p.cq_off.cqes as usize) as *const io_uring_cqe,
                cq_ring_mask: *(cq_base.add(p.cq_off.ring_mask as usize) as *const u32),
                cq_ring_size,
                cq_mmap_ptr,
            })
        }
    }

    #[inline(always)]
    pub fn is_kernel(&self) -> bool {
        matches!(self.backend, RingBackend::Kernel { .. })
    }

    #[inline]
    pub fn buffer_pool(&mut self) -> &mut FixedBufferPool {
        &mut self.fixed_buffers
    }

    pub fn submit_read_fixed(
        &mut self,
        fd: i32,
        buf_idx: u16,
        len: u32,
        offset: u64,
        user_data: u64,
    ) -> Result<(), IoUringError> {
        let slice = self.fixed_buffers.get_slice(buf_idx);
        let buf_size = self.fixed_buffers.buffer_size() as u32;
        let effective_len = if len == 0 { buf_size } else { len.min(buf_size) };
        let sqe = io_uring_sqe {
            opcode: IORING_OP_READ_FIXED,
            fd,
            addr: slice.as_ptr() as u64,
            len: effective_len,
            off: offset,
            buf_index: buf_idx,
            user_data,
            ..Default::default()
        };
        self.pending_sqes.push(sqe);
        Ok(())
    }

    pub fn submit_write_fixed(
        &mut self,
        fd: i32,
        buf_idx: u16,
        len: u32,
        offset: u64,
        user_data: u64,
    ) -> Result<(), IoUringError> {
        let slice = self.fixed_buffers.get_slice(buf_idx);
        let sqe = io_uring_sqe {
            opcode: IORING_OP_WRITE_FIXED,
            fd,
            addr: slice.as_ptr() as u64,
            len: len.min(self.fixed_buffers.buffer_size() as u32),
            off: offset,
            buf_index: buf_idx,
            user_data,
            ..Default::default()
        };
        self.pending_sqes.push(sqe);
        Ok(())
    }

    pub fn submit_connect(
        &mut self,
        fd: i32,
        addr: *const libc::sockaddr,
        addrlen: libc::socklen_t,
        user_data: u64,
    ) -> Result<(), IoUringError> {
        let sqe = io_uring_sqe {
            opcode: IORING_OP_CONNECT,
            fd,
            addr: addr as u64,
            off: addrlen as u64,
            user_data,
            ..Default::default()
        };
        self.pending_sqes.push(sqe);
        Ok(())
    }

    pub fn submit_poll_add(
        &mut self,
        fd: i32,
        poll_mask: u32,
        user_data: u64,
    ) -> Result<(), IoUringError> {
        let sqe = io_uring_sqe {
            opcode: IORING_OP_POLL_ADD,
            fd,
            rw_flags: poll_mask,
            user_data,
            ..Default::default()
        };
        self.pending_sqes.push(sqe);
        Ok(())
    }

    pub fn submit_accept_multishot(&mut self, listen_fd: i32, user_data: u64) -> Result<(), IoUringError> {
        let sqe = io_uring_sqe {
            opcode: IORING_OP_ACCEPT,
            fd: listen_fd,
            ioprio: IORING_ACCEPT_MULTISHOT,
            rw_flags: (libc::SOCK_NONBLOCK | libc::SOCK_CLOEXEC) as u32,
            user_data,
            ..Default::default()
        };
        self.pending_sqes.push(sqe);
        Ok(())
    }

    pub fn submit_close(&mut self, fd: i32, user_data: u64) -> Result<(), IoUringError> {
        let sqe = io_uring_sqe {
            opcode: IORING_OP_CLOSE,
            fd,
            user_data,
            ..Default::default()
        };
        self.pending_sqes.push(sqe);
        Ok(())
    }

    pub fn flush_submissions(&mut self) -> Result<u32, IoUringError> {
        if self.pending_sqes.is_empty() {
            return Ok(0);
        }
        let submitted = match &mut self.backend {
            RingBackend::Kernel {
                ring_fd,
                sq_khead,
                sq_ktail,
                sq_kflags,
                sq_ring_mask,
                sqes,
                sq_array,
                ..
            } => {
                let head = unsafe { (*(*sq_khead)).load(Ordering::Acquire) };
                let mut tail = unsafe { (*(*sq_ktail)).load(Ordering::Relaxed) };
                let ring_entries = sq_ring_mask.wrapping_add(1);
                let occupied = tail.wrapping_sub(head);
                let free = ring_entries.wrapping_sub(occupied);
                let to_submit = (self.pending_sqes.len() as u32).min(free);
                if to_submit == 0 {
                    return Ok(0);
                }
                for sqe in self.pending_sqes.drain(..to_submit as usize) {
                    let index = tail & *sq_ring_mask;
                    unsafe {
                        *sqes.add(index as usize) = sqe;
                        *sq_array.add(index as usize) = index;
                    }
                    tail = tail.wrapping_add(1);
                }
                unsafe {
                    (*(*sq_ktail)).store(tail, Ordering::Release);
                }
                std::sync::atomic::fence(Ordering::SeqCst);
                let flags = unsafe { (*(*sq_kflags)).load(Ordering::Acquire) };
                if (flags & IORING_SQ_NEED_WAKEUP) != 0 {
                    unsafe {
                        let _ = sys_io_uring_enter(*ring_fd, to_submit, 0, IORING_ENTER_SQ_WAKEUP, ptr::null());
                    }
                }
                to_submit
            }
            RingBackend::Simulated { sq_queue, cq_queue, capacity } => {
                let free = (*capacity as usize).saturating_sub(sq_queue.len());
                let to_submit = self.pending_sqes.len().min(free);
                if to_submit == 0 {
                    return Ok(0);
                }
                let mut count = 0;
                for sqe in self.pending_sqes.drain(..to_submit) {
                    cq_queue.push(io_uring_cqe {
                        user_data: sqe.user_data,
                        res: 0,
                        flags: 0,
                    });
                    count += 1;
                }
                count
            }
        };
        Ok(submitted)
    }

    pub fn reap_completions<F>(&mut self, mut handler: F) -> usize
    where
        F: FnMut(CqeEvent),
    {
        const BATCH_REAP_MAX: usize = 64;
        match &mut self.backend {
            RingBackend::Kernel {
                cq_khead,
                cq_ktail,
                cqes,
                cq_ring_mask,
                ..
            } => {
                let head_start = unsafe { (*(*cq_khead)).load(Ordering::Relaxed) };
                let tail = unsafe { (*(*cq_ktail)).load(Ordering::Acquire) };
                let available = tail.wrapping_sub(head_start) as usize;
                if available == 0 {
                    return 0;
                }
                let batch = available.min(BATCH_REAP_MAX);
                let mut processed = 0u32;

                for i in 0..batch {
                    let idx = head_start.wrapping_add(i as u32) & *cq_ring_mask;
                    let cqe = unsafe { *cqes.add(idx as usize) };
                    let event = CqeEvent {
                        user_data: cqe.user_data,
                        result: cqe.res,
                        flags: cqe.flags,
                    };
                    handler(event);
                    processed += 1;
                    unsafe {
                        (*(*cq_khead)).store(head_start.wrapping_add(processed), Ordering::Release);
                    }
                }
                processed as usize
            }
            RingBackend::Simulated { cq_queue, .. } => {
                let count = cq_queue.len();
                for cqe in cq_queue.drain(..) {
                    handler(CqeEvent {
                        user_data: cqe.user_data,
                        result: cqe.res,
                        flags: cqe.flags,
                    });
                }
                count
            }
        }
    }
}

impl Drop for IoUringDriver {
    fn drop(&mut self) {
        if let RingBackend::Kernel {
            ring_fd,
            sq_mmap_ptr,
            sq_ring_size,
            cq_mmap_ptr,
            cq_ring_size,
            sqes_mmap_ptr,
            sqes_size,
            ..
        } = self.backend
        {
            unsafe {
                libc::munmap(sqes_mmap_ptr, sqes_size);
                libc::munmap(cq_mmap_ptr, cq_ring_size);
                libc::munmap(sq_mmap_ptr, sq_ring_size);
                libc::close(ring_fd);
            }
        }
    }
}
