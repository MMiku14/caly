//! Universal socket address resolver and union representation for Linux ABI syscalls.

use std::net::{IpAddr, SocketAddr};

/// Union wrapping IPv4, IPv6, and generic storage sockaddr types for C ABI safety.
#[repr(C)]
#[derive(Clone, Copy)]
pub union GenericSockAddr {
    pub v4: libc::sockaddr_in,
    pub v6: libc::sockaddr_in6,
    pub storage: libc::sockaddr_storage,
}

impl Default for GenericSockAddr {
    #[inline]
    fn default() -> Self {
        // SAFETY: `zeroed` produces a valid all-zero value for the C-FFI POD type.
        unsafe { std::mem::zeroed() }
    }
}

impl AsRef<libc::sockaddr> for GenericSockAddr {
    fn as_ref(&self) -> &libc::sockaddr {
        // SAFETY: union 起始地址可合法转 sockaddr。
        unsafe { &*(&self.storage as *const _ as *const libc::sockaddr) }
    }
}

impl GenericSockAddr {
    /// Constructs a `GenericSockAddr` and its byte length from a Rust `SocketAddr`.
    pub fn from_socket_addr(addr: SocketAddr) -> (Self, libc::socklen_t) {
        match addr {
            SocketAddr::V4(v4) => {
                let mut sin: libc::sockaddr_in = unsafe { std::mem::zeroed() };
                sin.sin_family = libc::AF_INET as libc::sa_family_t;
                sin.sin_port = v4.port().to_be();
                sin.sin_addr = libc::in_addr {
                    s_addr: u32::from_ne_bytes(v4.ip().octets()),
                };
                (
                    Self { v4: sin },
                    std::mem::size_of::<libc::sockaddr_in>() as libc::socklen_t,
                )
            }
            SocketAddr::V6(v6) => {
                let mut sin6: libc::sockaddr_in6 = unsafe { std::mem::zeroed() };
                sin6.sin6_family = libc::AF_INET6 as libc::sa_family_t;
                sin6.sin6_port = v6.port().to_be();
                sin6.sin6_flowinfo = v6.flowinfo();
                sin6.sin6_addr = libc::in6_addr {
                    s6_addr: v6.ip().octets(),
                };
                sin6.sin6_scope_id = v6.scope_id();
                (
                    Self { v6: sin6 },
                    std::mem::size_of::<libc::sockaddr_in6>() as libc::socklen_t,
                )
            }
        }
    }

    /// Resolves target string (e.g. "1.2.3.4:80", "[::1]:443", "example.com:443")
    /// utilizing speculative DNS resolution if available, with synchronous fallback.
    ///
    /// Returns `Some((GenericSockAddr, socklen, af_domain))` or `None` on unresolvable target.
    pub fn resolve_target_with_speculative(
        target: &str,
        speculative_ip: Option<IpAddr>,
    ) -> Option<(Self, libc::socklen_t, i32)> {
        // 1. Direct SocketAddr string parse ("192.168.1.1:8080" or "[::1]:8080")
        if let Ok(sa) = target.parse::<SocketAddr>() {
            let domain = match sa {
                SocketAddr::V4(_) => libc::AF_INET,
                SocketAddr::V6(_) => libc::AF_INET6,
            };
            let (gsa, len) = Self::from_socket_addr(sa);
            return Some((gsa, len, domain));
        }

        // 2. Parse host and port parts
        let (host, port) = Self::split_host_port(target)?;

        // 3. Direct IP literal in host part
        if let Ok(ip) = host.parse::<IpAddr>() {
            let sa = SocketAddr::new(ip, port);
            let domain = match ip {
                IpAddr::V4(_) => libc::AF_INET,
                IpAddr::V6(_) => libc::AF_INET6,
            };
            let (gsa, len) = Self::from_socket_addr(sa);
            return Some((gsa, len, domain));
        }

        // 4. Use speculative IP from DNS pipeline if provided
        if let Some(ip) = speculative_ip {
            let sa = SocketAddr::new(ip, port);
            let domain = match ip {
                IpAddr::V4(_) => libc::AF_INET,
                IpAddr::V6(_) => libc::AF_INET6,
            };
            let (gsa, len) = Self::from_socket_addr(sa);
            return Some((gsa, len, domain));
        }

        // 5. Blocking DNS must never run on the reactor thread. The
        //    speculative DNS pipeline is responsible for resolution; if
        //    it has no answer, signal failure so the caller can queue a
        //    background query instead of blocking.
        None
    }

    /// Returns a raw pointer suitable for passing to `libc::connect` or `io_uring_prep_connect`.
    #[inline(always)]
    pub fn as_ptr(&self) -> *const libc::sockaddr {
        unsafe { &self.storage as *const _ as *const libc::sockaddr }
    }

    /// Splits a target string like "host:port" or "[ipv6]:port" into (host, port).
    fn split_host_port(target: &str) -> Option<(&str, u16)> {
        if let Some(rest) = target.strip_prefix('[') {
            let (host, rest) = rest.split_once(']')?;
            let port = rest.strip_prefix(':')?.parse::<u16>().ok()?;
            Some((host, port))
        } else {
            let (host, port) = target.rsplit_once(':')?;
            Some((host, port.parse::<u16>().ok()?))
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::net::Ipv4Addr;

    #[test]
    fn test_generic_sockaddr_v4() {
        let sa: SocketAddr = "127.0.0.1:8080".parse().unwrap();
        let (gsa, len) = GenericSockAddr::from_socket_addr(sa);
        assert_eq!(
            len,
            std::mem::size_of::<libc::sockaddr_in>() as libc::socklen_t
        );
        unsafe {
            assert_eq!(gsa.v4.sin_family, libc::AF_INET as libc::sa_family_t);
            assert_eq!(u16::from_be(gsa.v4.sin_port), 8080);
        }
    }

    #[test]
    fn test_generic_sockaddr_v6() {
        let sa: SocketAddr = "[::1]:9090".parse().unwrap();
        let (gsa, len) = GenericSockAddr::from_socket_addr(sa);
        assert_eq!(
            len,
            std::mem::size_of::<libc::sockaddr_in6>() as libc::socklen_t
        );
        unsafe {
            assert_eq!(gsa.v6.sin6_family, libc::AF_INET6 as libc::sa_family_t);
            assert_eq!(u16::from_be(gsa.v6.sin6_port), 9090);
        }
    }

    #[test]
    fn test_resolve_target_with_speculative() {
        let target = "caly.internal:8443";
        let spec_ip = Some(IpAddr::V4(Ipv4Addr::new(10, 0, 1, 5)));
        let (gsa, len, domain) =
            GenericSockAddr::resolve_target_with_speculative(target, spec_ip).unwrap();
        assert_eq!(domain, libc::AF_INET);
        assert_eq!(
            len,
            std::mem::size_of::<libc::sockaddr_in>() as libc::socklen_t
        );
        unsafe {
            assert_eq!(u16::from_be(gsa.v4.sin_port), 8443);
            let octets = gsa.v4.sin_addr.s_addr.to_ne_bytes();
            assert_eq!(octets, [10, 0, 1, 5]);
        }
    }
}
