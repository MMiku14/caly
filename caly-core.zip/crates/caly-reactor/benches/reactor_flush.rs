//! Criterion benchmarks for the reactor outbound-queue primitives.
//!
//! Two groups:
//!   * `pending_chunk/partial_write` —— `PendingChunk::advance(1)` vs
//!     `Vec::drain(..1)` on a 16 KiB buffer. `advance` is O(1) pointer
//!     bump; `drain` is O(n) memmove per call. This is the core reason
//!     `PendingChunk` exists.
//!   * `pending_chunk/queue_cycle` —— push N chunks and drain them
//!     completely; the total bytes touched is the same across both
//!     implementations, so this captures the amortised cost including
//!     allocations.
//!
//! NOTE: the `drain` reference implementation uses `Vec<u8>` directly
//! (not `VecDeque<Vec<u8>>`) to isolate the memmove cost. The reactor
//! previously stored `VecDeque<Vec<u8>>`; the drain overhead is
//! identical, only the outer container differs.

use criterion::{black_box, criterion_group, criterion_main, BenchmarkId, Criterion, Throughput};
use std::collections::VecDeque;

use caly_reactor::reactor::PendingChunk;

/// Reference: the old `Vec<u8>` + `drain(..1)` partial-write pattern.
/// Each call shifts the entire remaining tail left by one byte.
fn legacy_consume_one_byte(remaining: &mut usize, buf: &mut Vec<u8>) {
    buf.drain(..1);
    *remaining = buf.len();
}

/// New: `PendingChunk::advance(1)` — O(1) pointer bump, no memmove.
fn new_consume_one_byte(chunk: &mut PendingChunk) {
    chunk.advance(1);
}

fn bench_partial_write(c: &mut Criterion) {
    let mut group = c.benchmark_group("pending_chunk/partial_write");
    // Throughput measured in "bytes consumed", i.e. one per iteration.
    group.throughput(Throughput::Elements(1));

    for &chunk_size in &[1024usize, 4096, 16384, 65536] {
        // `legacy` and `new` operate on their own copies; we rebuild the
        // initial state each iteration because both mutate in place.

        group.bench_with_input(
            BenchmarkId::new("legacy_drain", chunk_size),
            &chunk_size,
            |b, &size| {
                b.iter_batched(
                    || vec![0u8; size],
                    |mut buf| {
                        // Consume 1 byte (worst case: full 16 KiB tail shift).
                        let mut remaining = buf.len();
                        legacy_consume_one_byte(&mut remaining, &mut buf);
                        black_box(remaining)
                    },
                    criterion::BatchSize::SmallInput,
                );
            },
        );

        group.bench_with_input(
            BenchmarkId::new("new_advance", chunk_size),
            &chunk_size,
            |b, &size| {
                b.iter_batched(
                    || PendingChunk::new(vec![0u8; size]),
                    |mut chunk| {
                        new_consume_one_byte(&mut chunk);
                        black_box(chunk.len())
                    },
                    criterion::BatchSize::SmallInput,
                );
            },
        );
    }
    group.finish();
}

fn bench_queue_cycle(c: &mut Criterion) {
    // Simulate: N chunks of 16 KiB pushed into a queue, then fully
    // flushed. Compare the legacy `VecDeque<Vec<u8>>` + `drain` path
    // against `VecDeque<PendingChunk>` + `advance`.
    //
    // We do NOT call the reactor's `ConnectionState::flush_queue`
    // directly (it needs a real socket fd); we replicate its body.

    const CHUNK_SIZE: usize = 16384;
    const CHUNKS: usize = 64; // 1 MiB total

    let mut group = c.benchmark_group("pending_chunk/queue_cycle");
    group.throughput(Throughput::Bytes((CHUNK_SIZE * CHUNKS) as u64));

    group.bench_function("legacy_vec_deque", |b| {
        b.iter(|| {
            let mut q: VecDeque<Vec<u8>> = VecDeque::with_capacity(CHUNKS);
            for _ in 0..CHUNKS {
                q.push_back(vec![0xAAu8; CHUNK_SIZE]);
            }
            // Drain 1 byte at a time (like a slow peer).
            let mut total_drained = 0usize;
            while let Some(front) = q.front_mut() {
                front.drain(..1);
                total_drained += 1;
                if front.is_empty() {
                    q.pop_front();
                }
            }
            black_box(total_drained)
        })
    });

    group.bench_function("new_pending_chunk", |b| {
        b.iter(|| {
            let mut q: VecDeque<PendingChunk> = VecDeque::with_capacity(CHUNKS);
            for _ in 0..CHUNKS {
                q.push_back(PendingChunk::new(vec![0xAAu8; CHUNK_SIZE]));
            }
            let mut total_drained = 0usize;
            while let Some(front) = q.front_mut() {
                front.advance(1);
                total_drained += 1;
                if front.is_empty() {
                    q.pop_front();
                }
            }
            black_box(total_drained)
        })
    });

    group.finish();
}

fn bench_push_only(c: &mut Criterion) {
    // Pure push throughput — isolates allocation + container cost from
    // the drain/advance asymmetry.
    const CHUNK_SIZE: usize = 16384;
    const CHUNKS: usize = 64;

    let mut group = c.benchmark_group("pending_chunk/push_only");
    group.throughput(Throughput::Bytes((CHUNK_SIZE * CHUNKS) as u64));

    group.bench_function("legacy_vec_deque", |b| {
        b.iter(|| {
            let mut q: VecDeque<Vec<u8>> = VecDeque::with_capacity(CHUNKS);
            for _ in 0..CHUNKS {
                q.push_back(vec![0xAAu8; CHUNK_SIZE]);
            }
            black_box(q.len())
        })
    });

    group.bench_function("new_pending_chunk", |b| {
        b.iter(|| {
            let mut q: VecDeque<PendingChunk> = VecDeque::with_capacity(CHUNKS);
            for _ in 0..CHUNKS {
                q.push_back(PendingChunk::new(vec![0xAAu8; CHUNK_SIZE]));
            }
            black_box(q.len())
        })
    });

    group.finish();
}

criterion_group!(
    benches,
    bench_partial_write,
    bench_queue_cycle,
    bench_push_only,
);
criterion_main!(benches);
