//! Deterministic HugeTLB Partitioning and Subsystem Memory Isolation.
//!
//! ## Architectural Note on Modern LLC / L3 Microarchitectures:
//! On modern Intel (Sandy Bridge through Emerald Rapids) and AMD (Zen 1 through Zen 5)
//! processors, the Last-Level Cache (L3/LLC) is divided into multiple independent slices
//! interconnected by high-speed ring or 2D-mesh buses. The hardware mapping from physical
//! addresses to cache sets and slices uses proprietary, non-linear multi-bit XOR hashing
//! functions designed by chipmakers to distribute memory evenly across slices.
//! Furthermore, in unprivileged userspace, `/proc/self/pagemap` physical Page Frame Numbers
//! (PFNs) are zeroed out by the kernel unless the process possesses `CAP_SYS_ADMIN`.
//!
//! Consequently, naive linear modulo formulas (`(PhysAddr >> 6) % CacheSets`) do not
//! guarantee single-set affinity on modern multi-slice CPUs.
//!
//! ## Deterministic Isolation Guarantees in `ColoredMemoryPool`:
//! Rather than relying on ungrounded set-coloring assumptions, `ColoredMemoryPool` enforces:
//! 1. **1GB / 2MB HugeTLB Alignment**: Zero TLB miss penalties, eliminating hardware page table walks.
//! 2. **Strict 64-Byte Cache-Line Alignment**: Enforces that all buffers, descriptors, and queue
//!    pointers never straddle cache lines, eliminating False Sharing across CPU cores.
//! 3. **Non-Overlapping Contiguous Extents**: Partitions the HugeTLB pool into disjoint,
//!    dedicated extents for `RxRing`, `TxRing`, `RouteTable`, and `SessionArena`.

use crate::error::{MemoryError, Result};
use crate::hugetlb::{HugePageMemory, HugePageSize};
use std::ops::Range;
use std::sync::Arc;

/// Subsystem partition target for cache coloring and memory isolation.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum ColorPartition {
    /// Network Ingress RX ring buffers.
    RxRing,
    /// Network Egress TX ring buffers.
    TxRing,
    /// Fast-path routing table & FIB lookup data structures.
    RouteTable,
    /// Flow tracking and connection session arena.
    SessionArena,
}

impl ColorPartition {
    /// Return human-readable label.
    pub const fn as_str(&self) -> &'static str {
        match self {
            Self::RxRing => "RxRing",
            Self::TxRing => "TxRing",
            Self::RouteTable => "RouteTable",
            Self::SessionArena => "SessionArena",
        }
    }
}

/// Configuration parameters for hardware L3 cache topology.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct CacheColoringConfig {
    /// Width of a CPU cache line in bytes (typically 64).
    pub cache_line_size: usize,
    /// Total number of sets in L3 cache (e.g., 8192, 16384, 32768).
    pub l3_cache_sets: usize,
    /// Number of L3 cache slices across CPU cores.
    pub slice_count: usize,
}

impl Default for CacheColoringConfig {
    #[inline]
    fn default() -> Self {
        Self::default_server()
    }
}

impl CacheColoringConfig {
    /// Create a new cache configuration.
    pub const fn new(cache_line_size: usize, l3_cache_sets: usize, slice_count: usize) -> Self {
        assert!(cache_line_size > 0 && cache_line_size.is_power_of_two());
        assert!(l3_cache_sets > 0);
        assert!(slice_count > 0);
        Self {
            cache_line_size,
            l3_cache_sets,
            slice_count,
        }
    }

    /// Standard baseline hardware profile (64-byte line, 16,384 sets, 8 slices).
    pub const fn standard_hardware() -> Self {
        Self {
            cache_line_size: 64,
            l3_cache_sets: 16384,
            slice_count: 8,
        }
    }

    /// Compatibility alias for baseline hardware profile.
    #[inline(always)]
    pub const fn default_server() -> Self {
        Self::standard_hardware()
    }

    /// Computes the theoretical idealized cache set index (for modeling single-slice caches).
    #[inline(always)]
    pub fn set_index(&self, phys_addr: usize) -> usize {
        let shift = self.cache_line_size.trailing_zeros();
        (phys_addr >> shift) % self.l3_cache_sets
    }

    /// Alias for `set_index`.
    #[inline(always)]
    pub fn color_of(&self, phys_addr: usize) -> usize {
        self.set_index(phys_addr)
    }

    /// Stride in bytes across sets.
    #[inline(always)]
    pub fn stride_bytes(&self) -> usize {
        self.l3_cache_sets * self.cache_line_size
    }
}

/// Non-overlapping cache set / extent assignment across system subsystems.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct PartitionScheme {
    /// Range assigned to Ingress RX rings.
    pub rx_sets: Range<usize>,
    /// Range assigned to Egress TX rings.
    pub tx_sets: Range<usize>,
    /// Range assigned to Routing tables.
    pub route_sets: Range<usize>,
    /// Range assigned to Session arena.
    pub session_sets: Range<usize>,
}

impl PartitionScheme {
    /// Create a 4-way balanced partition scheme dividing sets equally across 4 subsystems.
    pub fn balanced(total_sets: usize) -> Self {
        let quarter = total_sets / 4;
        Self {
            rx_sets: 0..quarter,
            tx_sets: quarter..(2 * quarter),
            route_sets: (2 * quarter)..(3 * quarter),
            session_sets: (3 * quarter)..total_sets,
        }
    }

    /// Retrieve the set range assigned to a specific subsystem partition.
    pub fn get_range(&self, partition: ColorPartition) -> Range<usize> {
        match partition {
            ColorPartition::RxRing => self.rx_sets.clone(),
            ColorPartition::TxRing => self.tx_sets.clone(),
            ColorPartition::RouteTable => self.route_sets.clone(),
            ColorPartition::SessionArena => self.session_sets.clone(),
        }
    }

    /// Check if an index belongs to a specific partition.
    pub fn contains(&self, partition: ColorPartition, set_idx: usize) -> bool {
        self.get_range(partition).contains(&set_idx)
    }
}

/// A contiguous slice of memory specifically allocated for a target subsystem.
pub struct ColoredBlock {
    ptr: *mut u8,
    len: usize,
    partition: ColorPartition,
    start_offset: usize,
    end_offset: usize,
    /// Keeps the backing HugePageMemory alive as long as any block derived
    /// from it exists. Without this field, `ColoredBlock` would dangle the
    /// moment its parent pool is dropped, even though the block is `Send`
    /// and `Sync` and may have been moved to another thread.
    _owner: Arc<HugePageMemory>,
}

// SAFETY: `ColoredBlock` holds a raw pointer into a `HugePageMemory`
// that is kept alive by `_owner: Arc<HugePageMemory>`. Moving the
// block across threads does not affect the lifetime of that
// allocation, so `Send` is sound.
unsafe impl Send for ColoredBlock {}
// SAFETY: `&ColoredBlock` exposes only read-only views
// (`as_slice` / `ptr`); mutation requires `&mut ColoredBlock`.
unsafe impl Sync for ColoredBlock {}

impl ColoredBlock {
    /// Usable pointer to block start.
    #[inline(always)]
    pub fn ptr(&self) -> *mut u8 {
        self.ptr
    }

    /// Length in bytes.
    #[inline(always)]
    pub fn len(&self) -> usize {
        self.len
    }

    /// Check if block is empty.
    #[inline(always)]
    pub fn is_empty(&self) -> bool {
        self.len == 0
    }

    /// Assigned subsystem partition.
    #[inline(always)]
    pub fn partition(&self) -> ColorPartition {
        self.partition
    }

    /// Range of offsets within partition occupied by this block.
    #[inline(always)]
    pub fn set_range(&self) -> Range<usize> {
        self.start_offset..self.end_offset
    }

    /// View as immutable byte slice.
    #[inline(always)]
    pub fn as_slice(&self) -> &[u8] {
        // SAFETY: `ptr`/`len` describe a valid, initialized, non-aliased mutable slice.
        unsafe { std::slice::from_raw_parts(self.ptr, self.len) }
    }

    /// View as mutable byte slice.
    #[inline(always)]
    pub fn as_mut_slice(&mut self) -> &mut [u8] {
        // SAFETY: `ptr`/`len` describe a valid, initialized, non-aliased mutable slice.
        unsafe { std::slice::from_raw_parts_mut(self.ptr, self.len) }
    }
}

/// Dedicated contiguous memory extent for a subsystem partition.
#[derive(Debug, Clone, Copy)]
struct SubsystemExtent {
    offset_start: usize,
    capacity: usize,
    allocated: usize,
}

impl SubsystemExtent {
    fn new(offset_start: usize, capacity: usize) -> Self {
        Self {
            offset_start,
            capacity,
            allocated: 0,
        }
    }

    fn allocate(&mut self, bytes: usize, align: usize) -> Option<usize> {
        let current = self.offset_start + self.allocated;
        let aligned = (current + align - 1) & !(align - 1);
        let needed = (aligned - self.offset_start) + bytes;
        if needed <= self.capacity {
            self.allocated = needed;
            Some(aligned)
        } else {
            None
        }
    }

    fn contains_addr(&self, base_addr: usize, addr: usize) -> bool {
        let start = base_addr + self.offset_start;
        let end = start + self.capacity;
        addr >= start && addr < end
    }
}

/// Deterministic Partitioned memory allocator managing HugeTLB backing memory for subsystems.
///
/// Ensures clean `munmap` in `Drop` by managing the underlying `HugePageMemory`.
pub struct ColoredMemoryPool {
    /// Underlying mapped hugepage memory buffer. Wrapped in `Arc` so that
    /// every [`ColoredBlock`] can hold a reference and keep the mapping
    /// alive across pool drop.
    memory: Arc<HugePageMemory>,
    /// Hardware cache configuration.
    config: CacheColoringConfig,
    /// Partition scheme mapping sets to subsystems.
    scheme: PartitionScheme,
    /// Extents per subsystem partition.
    rx_extent: SubsystemExtent,
    tx_extent: SubsystemExtent,
    route_extent: SubsystemExtent,
    session_extent: SubsystemExtent,
}

impl ColoredMemoryPool {
    /// Allocate a new partitioned memory pool backed by HugeTLB memory.
    pub fn new(
        config: CacheColoringConfig,
        page_size: HugePageSize,
        total_size: usize,
    ) -> Result<Self> {
        let memory = Arc::new(HugePageMemory::allocate(total_size, page_size)?);
        let scheme = PartitionScheme::balanced(config.l3_cache_sets);
        let quarter = total_size / 4;

        Ok(Self {
            memory,
            config,
            scheme,
            rx_extent: SubsystemExtent::new(0, quarter),
            tx_extent: SubsystemExtent::new(quarter, quarter),
            route_extent: SubsystemExtent::new(2 * quarter, quarter),
            session_extent: SubsystemExtent::new(3 * quarter, total_size - 3 * quarter),
        })
    }

    /// Custom constructor with user-defined partition scheme.
    pub fn with_scheme(
        config: CacheColoringConfig,
        scheme: PartitionScheme,
        page_size: HugePageSize,
        total_size: usize,
    ) -> Result<Self> {
        let memory = Arc::new(HugePageMemory::allocate(total_size, page_size)?);
        let quarter = total_size / 4;

        Ok(Self {
            memory,
            config,
            scheme,
            rx_extent: SubsystemExtent::new(0, quarter),
            tx_extent: SubsystemExtent::new(quarter, quarter),
            route_extent: SubsystemExtent::new(2 * quarter, quarter),
            session_extent: SubsystemExtent::new(3 * quarter, total_size - 3 * quarter),
        })
    }

    /// Access the cache configuration.
    pub fn config(&self) -> &CacheColoringConfig {
        &self.config
    }

    /// Access the partition scheme.
    pub fn scheme(&self) -> &PartitionScheme {
        &self.scheme
    }

    /// Base physical address of the allocated pool.
    pub fn base_phys_addr(&self) -> usize {
        self.memory.as_ptr() as usize
    }

    /// Raw pointer to the start of the memory pool.
    pub fn as_ptr(&self) -> *const u8 {
        self.memory.as_ptr()
    }

    /// Total mapped size in bytes.
    pub fn total_size(&self) -> usize {
        self.memory.len()
    }

    /// Check if underlying memory is real HugeTLB.
    pub fn is_hugetlb(&self) -> bool {
        self.memory.is_hugetlb()
    }

    /// Allocate a memory block strictly isolated for the given partition.
    ///
    /// Every block is guaranteed 64-byte cache-line aligned and resides inside
    /// a dedicated, non-overlapping contiguous HugeTLB extent.
    pub fn allocate_partition(
        &mut self,
        partition: ColorPartition,
        requested_bytes: usize,
    ) -> Result<ColoredBlock> {
        if requested_bytes == 0 {
            return Err(MemoryError::AllocationFailure(
                "cannot allocate 0 bytes".into(),
            ));
        }

        let line_size = self.config.cache_line_size;
        let extent = match partition {
            ColorPartition::RxRing => &mut self.rx_extent,
            ColorPartition::TxRing => &mut self.tx_extent,
            ColorPartition::RouteTable => &mut self.route_extent,
            ColorPartition::SessionArena => &mut self.session_extent,
        };

        let offset = extent.allocate(requested_bytes, line_size).ok_or_else(|| {
            MemoryError::OutOfMemory {
                requested: requested_bytes,
                available: extent.capacity.saturating_sub(extent.allocated),
            }
        })?;

        // SAFETY: `offset` was produced by `SubsystemExtent::allocate`, which
        // guarantees it lies within `[0, self.memory.len())`. `as_ptr()` is
        // used (rather than `as_mut_ptr`) because the field is now
        // `Arc<HugePageMemory>`; both return the same underlying pointer.
        let block_ptr = unsafe { self.memory.as_ptr().add(offset) as *mut u8 };

        Ok(ColoredBlock {
            ptr: block_ptr,
            len: requested_bytes,
            partition,
            start_offset: offset,
            end_offset: offset + requested_bytes,
            _owner: self.memory.clone(),
        })
    }

    /// Verify whether a virtual address lands inside the partition's designated HugeTLB extent.
    pub fn verify_address_in_partition(&self, partition: ColorPartition, addr: usize) -> bool {
        let base = self.memory.as_ptr() as usize;
        match partition {
            ColorPartition::RxRing => self.rx_extent.contains_addr(base, addr),
            ColorPartition::TxRing => self.tx_extent.contains_addr(base, addr),
            ColorPartition::RouteTable => self.route_extent.contains_addr(base, addr),
            ColorPartition::SessionArena => self.session_extent.contains_addr(base, addr),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    #[cfg_attr(miri, ignore)]
    fn test_set_index_calculation() {
        let config = CacheColoringConfig::new(64, 8192, 8);
        assert_eq!(config.set_index(0), 0);
        assert_eq!(config.set_index(64), 1);
        assert_eq!(config.set_index(524288), 0);
        let phys_addr = 0x1234560;
        let expected = (phys_addr >> 6) % 8192;
        assert_eq!(config.set_index(phys_addr), expected);
    }

    #[test]
    #[cfg_attr(miri, ignore)]
    fn test_partitioned_allocator_stride_alignment() {
        let config = CacheColoringConfig::new(64, 8192, 8);
        let mut pool = ColoredMemoryPool::new(config, HugePageSize::Standard4KiB, 4 * 1024 * 1024)
            .expect("create colored memory pool");

        let rx_block = pool
            .allocate_partition(ColorPartition::RxRing, 1024)
            .unwrap();
        assert_eq!(rx_block.partition(), ColorPartition::RxRing);
        assert_eq!(rx_block.len(), 1024);

        let tx_block = pool
            .allocate_partition(ColorPartition::TxRing, 2048)
            .unwrap();
        assert_eq!(tx_block.partition(), ColorPartition::TxRing);
        assert_eq!(tx_block.len(), 2048);

        assert!(pool.verify_address_in_partition(ColorPartition::RxRing, rx_block.ptr() as usize));
        assert!(pool.verify_address_in_partition(ColorPartition::TxRing, tx_block.ptr() as usize));
    }

    /// `ColoredBlock` must keep the underlying HugePageMemory alive after
    /// the pool is dropped. Without the `Arc<HugePageMemory>` reference,
    /// `block.as_slice()` would be a use-after-free.
    #[test]
    fn test_colored_block_outlives_pool() {
        let block = {
            let mut pool = ColoredMemoryPool::new(
                CacheColoringConfig::new(64, 8192, 8),
                HugePageSize::Standard4KiB,
                4 * 1024 * 1024,
            )
            .expect("pool");

            let b = pool
                .allocate_partition(ColorPartition::RxRing, 128)
                .unwrap();
            // Write a distinctive pattern so we can verify the memory is
            // still intact after the pool is dropped.
            unsafe {
                let p = b.ptr();
                for i in 0..128 {
                    *p.add(i) = (i & 0xFF) as u8;
                }
            }
            b
            // pool dropped here; only the `Arc` inside `block` keeps the
            // HugePageMemory alive.
        };

        let slice = block.as_slice();
        assert_eq!(slice.len(), 128);
        for (i, &b) in slice.iter().enumerate() {
            assert_eq!(
                b,
                (i & 0xFF) as u8,
                "byte {i} was corrupted after pool drop"
            );
        }
    }
}
