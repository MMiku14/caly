// `workspace-hack` is a cargo-hakari synthetic crate that unifies
// feature resolution across the workspace. It is intentionally
// never `use`d by any source file, so the standard
// `unused_crate_dependencies` lint does not apply here.
#![allow(unused_crate_dependencies)]
//! # `caly-memory`
//!
//! High-performance, zero-copy memory management, HugeTLB allocation, L3 cache coloring,
//! algebraic zero-runtime-cost aliasing, and lock-free ring buffers for the Caly network proxy kernel.
//!
//! ## Specification REV 4.0 Submodules:
//! - [`arena`]: Thread-safe `HugePageArena` managing partitioned cache-colored memory pools.
//! - [`frame`]: 64-byte cache-line aligned network frame descriptor (`IngressFrameDesc`).
//! - [`hugetlb`]: 1GB/2MB HugeTLB page allocator with transparent fallback to anonymous mmap and clean `munmap`.
//! - [`page_coloring`]: L3 cache set index calculation (`(PhysicalAddress >> 6) % CacheSets`)
//!   and partition allocator for RX ring, TX ring, Route table, and Session arena.
//! - [`ghost_cell`]: Algebraic borrow token system (`CoreToken`, `BrandedCell`, `enter_core_reactor`)
//!   for zero-runtime-cost mutable aliasing.
//! - [`ring`]: Fixed-size, zero-allocation lock-free SPSC ring buffer (`StaticRingBuffer`)
//!   with Kani formal verification harness.
//! - [`tsc`]: Hardware CPU Time Stamp Counter (`read_tsc`, `read_cpu_tsc`) and frequency calibration (`TscClock`).

#![deny(unsafe_op_in_unsafe_fn)]
#![warn(clippy::undocumented_unsafe_blocks)]
#![warn(clippy::multiple_unsafe_ops_per_block)]
#![deny(missing_docs)]
#![warn(rust_2018_idioms)]
#![allow(unexpected_cfgs)]

pub mod arena;
pub mod error;
pub mod frame;
pub mod ghost_cell;
pub mod hugetlb;
pub mod page_coloring;
pub mod ring;
pub mod tsc;

/// Shared test-support helpers. Currently only used to centralize proptest
/// configuration so that Miri (which does not support `getcwd` under
/// isolation) does not trip proptest's built-in file-based failure
/// persistence.
#[cfg(test)]
pub(crate) mod test_support {
    /// Returns a `proptest` config with `cases` case budget.
    ///
    /// Under Miri we additionally:
    /// * disable `FileFailurePersistence` (avoids `getcwd` and file IO), and
    /// * clamp the case count to a small value (the interpreter is ~100x
    ///   slower than native, and proptest cases dominate the runtime).
    pub(crate) fn proptest_config(cases: u32) -> proptest::test_runner::Config {
        let mut cfg = proptest::test_runner::Config::default();
        cfg.cases = cases;
        #[cfg(miri)]
        {
            cfg.failure_persistence = None;
            cfg.cases = cfg.cases.min(16);
        }
        cfg
    }
}

// Re-exports for convenient public crate consumption
pub use arena::HugePageArena;
pub use error::{MemoryError, Result};
pub use frame::{flags, IngressFrameDesc};
pub use ghost_cell::{enter_core_reactor, BrandedCell, CoreToken, InvariantLifetime};
pub use hugetlb::{HugePageMemory, HugePageSize, HugeTlbAllocator};
pub use page_coloring::{
    CacheColoringConfig, ColorPartition, ColoredBlock, ColoredMemoryPool, PartitionScheme,
};
pub use ring::{Consumer, Producer, StaticRingBuffer};
pub use tsc::{
    estimate_tsc_frequency_hz, read_cpu_tsc, read_cpu_tsc_serialized, read_tsc,
    tsc_cycles_to_nanos, TscClock,
};

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    #[cfg_attr(miri, ignore)]
    fn test_caly_memory_end_to_end_pipeline() {
        // 1. Initialize TSC Clock
        let clock = TscClock::from_frequency_hz(2_500_000_000);
        let start_tsc = clock.now();
        assert!(read_tsc() >= start_tsc);

        // 2. Initialize Cache Coloring and Pool
        let coloring_cfg = CacheColoringConfig::default_server();
        let mut pool =
            ColoredMemoryPool::new(coloring_cfg, HugePageSize::Standard4KiB, 4 * 1024 * 1024)
                .expect("create colored pool");

        let rx_mem = pool
            .allocate_partition(ColorPartition::RxRing, 4096)
            .expect("rx alloc");
        assert_eq!(rx_mem.partition(), ColorPartition::RxRing);

        // 3. Initialize HugePage Arena
        let arena = HugePageArena::new(2 * 1024 * 1024).expect("arena alloc");
        let tx_mem = arena
            .allocate_partition(ColorPartition::TxRing, 4096)
            .expect("tx alloc");
        assert_eq!(tx_mem.partition(), ColorPartition::TxRing);

        // 4. Ingress Frame Descriptor Check
        let mut desc = IngressFrameDesc::empty();
        desc.rx_timestamp_tsc = read_tsc();
        desc.data_len = 1460;
        desc.peer_port = 443;
        assert_eq!(desc.data_len, 1460);

        // 5. Zero-runtime cost algebraic borrow verification
        enter_core_reactor(|mut token| {
            let cell = BrandedCell::new(desc);
            {
                let desc_mut = cell.borrow_mut(&mut token);
                desc_mut.flags |= flags::FLAG_DIRECT_FLOW;
            }
            let desc_ref = cell.borrow(&token);
            assert_eq!(
                desc_ref.flags & flags::FLAG_DIRECT_FLOW,
                flags::FLAG_DIRECT_FLOW
            );
        });

        // 6. Ring Buffer Execution
        // `StaticRingBuffer` exposes `push` / `pop` (both take `&self`);
        // there is no `try_push` / `try_pop` variant on the type.
        let ring = StaticRingBuffer::<u64, 16>::new();
        assert!(ring.push(0xDEADBEEF).is_ok());
        assert_eq!(ring.pop(), Some(0xDEADBEEF));

        let elapsed = clock.elapsed_ns(start_tsc);
        println!("Pipeline executed in {elapsed} ns");
    }
}
