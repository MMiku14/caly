//! Cache-line aligned network frame descriptor.
//!
//! Specification REV 4.0:
//! - Exactly 64 bytes (`#[repr(C, align(64))]`), matching modern L1/L2/L3 cache line width.
//! - Eliminates false sharing when processed concurrently or passed across ring buffers.
//! - Holds timestamps, packet boundaries, 5-tuple / flow identifiers, and compact IP addresses.

use std::net::{Ipv4Addr, Ipv6Addr, SocketAddr, SocketAddrV4, SocketAddrV6};
use std::ops::Range;

/// Common flag masks for `IngressFrameDesc::flags`.
pub mod flags {
    /// Indicates the frame carries an IPv4 payload.
    pub const FLAG_IPV4: u32 = 1 << 0;
    /// Indicates the frame carries an IPv6 payload.
    pub const FLAG_IPV6: u32 = 1 << 1;
    /// Indicates TCP protocol.
    pub const FLAG_TCP: u32 = 1 << 2;
    /// Indicates UDP protocol.
    pub const FLAG_UDP: u32 = 1 << 3;
    /// TCP SYN control bit.
    pub const FLAG_SYN: u32 = 1 << 4;
    /// TCP FIN control bit.
    pub const FLAG_FIN: u32 = 1 << 5;
    /// TCP RST control bit.
    pub const FLAG_RST: u32 = 1 << 6;
    /// TCP ACK control bit.
    pub const FLAG_ACK: u32 = 1 << 7;
    /// Hardware/NIC checksum validated.
    pub const FLAG_CSUM_VALID: u32 = 1 << 8;
    /// Frame marked as dropped by pipeline filter.
    pub const FLAG_DROPPED: u32 = 1 << 9;
    /// Frame has been routed / lookup succeeded.
    pub const FLAG_ROUTED: u32 = 1 << 10;
    /// Frame marked for direct in-kernel bypass flow.
    pub const FLAG_DIRECT_FLOW: u32 = 1 << 11;
}

/// Cache-line aligned 64-byte descriptor for ingress and egress network packets.
///
/// Designed to fit precisely within a single 64-byte cache line to prevent split-line access
/// and cache invalidation storms during high-throughput packet classification.
#[repr(C, align(64))]
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct IngressFrameDesc {
    /// Ingress hardware or TSC timestamp when packet arrived at NIC / ring.
    pub rx_timestamp_tsc: u64,
    /// Byte offset within the memory buffer where packet payload begins.
    pub data_offset: u32,
    /// Length of packet payload in bytes.
    pub data_len: u32,
    /// Protocol and operational status bitflags.
    pub flags: u32,
    /// Precomputed 32-bit Toeplitz or Murmur3 flow hash for RSS/flow steering.
    pub flow_hash: u32,
    /// Opaque 64-bit session or routing table token.
    pub flow_token: u64,
    /// Remote peer IP address: Compact IPv6 or IPv4-mapped IPv6 (RFC 4291).
    pub peer_addr: [u8; 16],
    /// Remote peer layer-4 port (host byte order).
    pub peer_port: u16,
    /// Padding to enforce strict 64-byte total structure size.
    pub _pad: [u8; 14],
}

// Compile-time static assertions ensuring exact 64-byte size and 64-byte alignment.
// Static assertions for size and alignment
const _: () = assert!(std::mem::size_of::<IngressFrameDesc>() == 64);
const _: () = assert!(std::mem::align_of::<IngressFrameDesc>() == 64);

impl Default for IngressFrameDesc {
    #[inline]
    fn default() -> Self {
        Self {
            rx_timestamp_tsc: 0,
            data_offset: 0,
            data_len: 0,
            flags: 0,
            flow_hash: 0,
            flow_token: 0,
            peer_addr: [0u8; 16],
            peer_port: 0,
            _pad: [0u8; 14],
        }
    }
}

impl IngressFrameDesc {
    /// Creates an empty, zero-initialized frame descriptor.
    #[inline(always)]
    pub const fn empty() -> Self {
        Self {
            rx_timestamp_tsc: 0,
            data_offset: 0,
            data_len: 0,
            flags: 0,
            flow_hash: 0,
            flow_token: 0,
            peer_addr: [0u8; 16],
            peer_port: 0,
            _pad: [0u8; 14],
        }
    }

    /// Create a zero-initialized descriptor with given timestamp and buffer geometry.
    #[inline]
    pub const fn new(rx_timestamp_tsc: u64, data_offset: u32, data_len: u32) -> Self {
        Self {
            rx_timestamp_tsc,
            data_offset,
            data_len,
            flags: 0,
            flow_hash: 0,
            flow_token: 0,
            peer_addr: [0u8; 16],
            peer_port: 0,
            _pad: [0u8; 14],
        }
    }

    /// Getter: RX arrival TSC timestamp.
    #[inline(always)]
    pub fn rx_timestamp_tsc(&self) -> u64 {
        self.rx_timestamp_tsc
    }

    /// Setter: RX arrival TSC timestamp.
    #[inline(always)]
    pub fn set_rx_timestamp_tsc(&mut self, tsc: u64) {
        self.rx_timestamp_tsc = tsc;
    }

    /// Getter: Payload data offset.
    #[inline(always)]
    pub fn data_offset(&self) -> u32 {
        self.data_offset
    }

    /// Setter: Payload data offset.
    #[inline(always)]
    pub fn set_data_offset(&mut self, offset: u32) {
        self.data_offset = offset;
    }

    /// Getter: Payload data length.
    #[inline(always)]
    pub fn data_len(&self) -> u32 {
        self.data_len
    }

    /// Setter: Payload data length.
    #[inline(always)]
    pub fn set_data_len(&mut self, len: u32) {
        self.data_len = len;
    }

    /// Returns the byte range of the packet payload.
    #[inline]
    pub fn payload_range(&self) -> Range<usize> {
        let start = self.data_offset as usize;
        let end = start.saturating_add(self.data_len as usize);
        start..end
    }

    /// Getter: Bitflags.
    #[inline(always)]
    pub fn flags(&self) -> u32 {
        self.flags
    }

    /// Setter: Bitflags.
    #[inline(always)]
    pub fn set_flags(&mut self, flags: u32) {
        self.flags = flags;
    }

    /// Test if a flag bit is active.
    #[inline(always)]
    pub fn has_flag(&self, flag: u32) -> bool {
        (self.flags & flag) == flag
    }

    /// Set a flag bit.
    #[inline(always)]
    pub fn set_flag(&mut self, flag: u32) {
        self.flags |= flag;
    }

    /// Clear a flag bit.
    #[inline(always)]
    pub fn clear_flag(&mut self, flag: u32) {
        self.flags &= !flag;
    }

    /// Getter: Flow hash.
    #[inline(always)]
    pub fn flow_hash(&self) -> u32 {
        self.flow_hash
    }

    /// Setter: Flow hash.
    #[inline(always)]
    pub fn set_flow_hash(&mut self, hash: u32) {
        self.flow_hash = hash;
    }

    /// Getter: Flow token.
    #[inline(always)]
    pub fn flow_token(&self) -> u64 {
        self.flow_token
    }

    /// Setter: Flow token.
    #[inline(always)]
    pub fn set_flow_token(&mut self, token: u64) {
        self.flow_token = token;
    }

    /// Getter: Peer address bytes.
    #[inline(always)]
    pub fn peer_addr(&self) -> [u8; 16] {
        self.peer_addr
    }

    /// Setter: Peer address bytes.
    #[inline(always)]
    pub fn set_peer_addr(&mut self, addr: [u8; 16]) {
        self.peer_addr = addr;
    }

    /// Getter: Peer port.
    #[inline(always)]
    pub fn peer_port(&self) -> u16 {
        self.peer_port
    }

    /// Setter: Peer port.
    #[inline(always)]
    pub fn set_peer_port(&mut self, port: u16) {
        self.peer_port = port;
    }

    /// Check whether the peer address is an IPv4 address.
    ///
    /// Evaluates to `true` iff the wire format written by [`Self::set_ipv4`]
    /// is present: bytes `0..10` are zero, bytes `10..12` are `0xff`.
    ///
    /// The invariant `self.is_ipv4() == self.get_ipv4().is_some()` always
    /// holds. The `FLAG_IPV4` bit is informational; the address layout is
    /// authoritative. (An earlier version of this method also returned
    /// `true` when `FLAG_IPV4` was set but the address bytes were *not*
    /// IPv4-mapped, which made `is_ipv4()` and `get_ipv4()` disagree.)
    #[inline]
    pub fn is_ipv4(&self) -> bool {
        // IPv4-mapped IPv6 check: bytes 0..10 zero, bytes 10..11 == 0xff.
        self.peer_addr[0..10] == [0u8; 10]
            && self.peer_addr[10] == 0xff
            && self.peer_addr[11] == 0xff
    }

    /// Retrieve the peer address as an IPv4 address if applicable.
    #[inline]
    pub fn get_ipv4(&self) -> Option<Ipv4Addr> {
        if self.is_ipv4() {
            Some(Ipv4Addr::new(
                self.peer_addr[12],
                self.peer_addr[13],
                self.peer_addr[14],
                self.peer_addr[15],
            ))
        } else {
            None
        }
    }

    /// Retrieve the peer address as an IPv6 address.
    #[inline]
    pub fn get_ipv6(&self) -> Ipv6Addr {
        Ipv6Addr::from(self.peer_addr)
    }

    /// Store an IPv4 address into `peer_addr` using standard IPv4-mapped IPv6 format.
    #[inline]
    pub fn set_ipv4(&mut self, addr: Ipv4Addr) {
        self.set_flag(flags::FLAG_IPV4);
        self.clear_flag(flags::FLAG_IPV6);
        let octets = addr.octets();
        self.peer_addr = [
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0xff, 0xff, octets[0], octets[1], octets[2], octets[3],
        ];
    }

    /// Store an IPv6 address into `peer_addr`.
    #[inline]
    pub fn set_ipv6(&mut self, addr: Ipv6Addr) {
        self.set_flag(flags::FLAG_IPV6);
        self.clear_flag(flags::FLAG_IPV4);
        self.peer_addr = addr.octets();
    }

    /// Convert peer address and port into a standard `SocketAddr`.
    #[inline]
    pub fn peer_socket_addr(&self) -> SocketAddr {
        if let Some(v4) = self.get_ipv4() {
            SocketAddr::V4(SocketAddrV4::new(v4, self.peer_port))
        } else {
            SocketAddr::V6(SocketAddrV6::new(self.get_ipv6(), self.peer_port, 0, 0))
        }
    }

    /// Assign peer socket address.
    #[inline]
    pub fn set_peer_socket_addr(&mut self, addr: SocketAddr) {
        match addr {
            SocketAddr::V4(v4) => {
                self.set_ipv4(*v4.ip());
                self.set_peer_port(v4.port());
            }
            SocketAddr::V6(v6) => {
                self.set_ipv6(*v6.ip());
                self.set_peer_port(v6.port());
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_ingress_frame_desc_size_and_alignment() {
        assert_eq!(std::mem::size_of::<IngressFrameDesc>(), 64);
        assert_eq!(std::mem::align_of::<IngressFrameDesc>(), 64);
    }

    #[test]
    fn test_ipv4_mapped_address_handling() {
        let mut desc = IngressFrameDesc::new(12345, 64, 1400);
        assert_eq!(desc.rx_timestamp_tsc(), 12345);
        assert_eq!(desc.data_offset(), 64);
        assert_eq!(desc.data_len(), 1400);
        assert_eq!(desc.payload_range(), 64..1464);

        let ip4 = Ipv4Addr::new(192, 168, 1, 100);
        desc.set_ipv4(ip4);
        desc.set_peer_port(8080);

        assert!(desc.is_ipv4());
        assert_eq!(desc.get_ipv4(), Some(ip4));
        assert_eq!(
            desc.peer_socket_addr(),
            SocketAddr::V4(SocketAddrV4::new(ip4, 8080))
        );
    }

    #[test]
    fn test_ipv6_address_handling() {
        let mut desc = IngressFrameDesc::default();
        let ip6: Ipv6Addr = "2001:db8::ff00:42:8329".parse().unwrap();
        desc.set_ipv6(ip6);
        desc.set_peer_port(443);

        assert!(!desc.is_ipv4());
        assert_eq!(desc.get_ipv4(), None);
        assert_eq!(desc.get_ipv6(), ip6);
        assert_eq!(
            desc.peer_socket_addr(),
            SocketAddr::V6(SocketAddrV6::new(ip6, 443, 0, 0))
        );
    }

    #[test]
    fn test_flags_and_flow_identifiers() {
        let mut desc = IngressFrameDesc::default();
        desc.set_flag(flags::FLAG_TCP | flags::FLAG_SYN);
        assert!(desc.has_flag(flags::FLAG_TCP));
        assert!(desc.has_flag(flags::FLAG_SYN));
        assert!(!desc.has_flag(flags::FLAG_FIN));

        desc.clear_flag(flags::FLAG_SYN);
        assert!(!desc.has_flag(flags::FLAG_SYN));

        desc.set_flow_hash(0xdeadbeef);
        desc.set_flow_token(0xfeedfacecafebeef);
        assert_eq!(desc.flow_hash(), 0xdeadbeef);
        assert_eq!(desc.flow_token(), 0xfeedfacecafebeef);
    }

    #[test]
    fn test_frame_is_ipv4_matches_get_ipv4() {
        // The invariant `is_ipv4() == get_ipv4().is_some()` must hold for
        // every state reachable through the public API.
        let mut desc = IngressFrameDesc::default();
        assert_eq!(desc.is_ipv4(), desc.get_ipv4().is_some());

        desc.set_ipv4(Ipv4Addr::new(203, 0, 113, 5));
        assert!(desc.is_ipv4());
        assert_eq!(desc.get_ipv4(), Some(Ipv4Addr::new(203, 0, 113, 5)));
        assert_eq!(desc.is_ipv4(), desc.get_ipv4().is_some());

        let mut desc6 = IngressFrameDesc::default();
        desc6.set_ipv6("2001:db8::1".parse().unwrap());
        assert!(!desc6.is_ipv4());
        assert_eq!(desc6.get_ipv4(), None);
        assert_eq!(desc6.is_ipv4(), desc6.get_ipv4().is_some());
    }

    #[test]
    fn test_frame_set_ipv4_clears_ipv6_flag_and_vice_versa() {
        let mut desc = IngressFrameDesc::default();

        desc.set_ipv4(Ipv4Addr::new(1, 2, 3, 4));
        assert!(desc.has_flag(flags::FLAG_IPV4));
        assert!(!desc.has_flag(flags::FLAG_IPV6));

        desc.set_ipv6("::1".parse().unwrap());
        assert!(!desc.has_flag(flags::FLAG_IPV4));
        assert!(desc.has_flag(flags::FLAG_IPV6));
        assert!(!desc.is_ipv4());

        desc.set_ipv4(Ipv4Addr::new(5, 6, 7, 8));
        assert!(desc.has_flag(flags::FLAG_IPV4));
        assert!(!desc.has_flag(flags::FLAG_IPV6));
    }
}
