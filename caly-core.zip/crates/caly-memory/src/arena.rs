//! Thread-safe HugePage Arena with Cache-Coloring partitioning.
//!
//! Specification REV 4.0:
//! - Implements thread-safe `HugePageArena` wrapping `ColoredMemoryPool`.
//! - Provides partitioned block allocation eliminating cross-partition L3 set eviction.

use crate::error::MemoryError;
use crate::hugetlb::HugePageSize;
use crate::page_coloring::{CacheColoringConfig, ColorPartition, ColoredBlock, ColoredMemoryPool};
use std::sync::Mutex;

/// Thread-safe HugePage Arena wrapping a cache-colored memory pool.
pub struct HugePageArena {
    pool: Mutex<ColoredMemoryPool>,
}

impl HugePageArena {
    /// Allocate a new HugePage arena with the specified total capacity in bytes.
    ///
    /// Automatically requests 2MB hugepages with transparent fallback to standard pages
    /// if hugepages are unconfigured or restricted by the operating system environment.
    pub fn new(total_bytes: usize) -> Result<Self, MemoryError> {
        let config = CacheColoringConfig::default_server();
        // Request 2MB hugepages with graceful fallback
        let pool = ColoredMemoryPool::new(config, HugePageSize::TwoMegabytes, total_bytes)?;
        Ok(Self {
            pool: Mutex::new(pool),
        })
    }

    /// Allocate a block of memory strictly colored for the target subsystem partition.
    pub fn allocate_partition(
        &self,
        partition: ColorPartition,
        bytes: usize,
    ) -> Result<ColoredBlock, MemoryError> {
        let mut pool = self
            .pool
            .lock()
            .map_err(|e| MemoryError::AllocationFailure(format!("Mutex poisoned: {e}")))?;
        pool.allocate_partition(partition, bytes)
    }

    /// Total mapped arena capacity in bytes.
    pub fn capacity(&self) -> usize {
        let pool = self.pool.lock().unwrap();
        pool.total_size()
    }

    /// Check if underlying memory is backed by real HugeTLB.
    pub fn is_hugetlb(&self) -> bool {
        let pool = self.pool.lock().unwrap();
        pool.is_hugetlb()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    #[cfg_attr(miri, ignore)]
    fn test_hugepage_arena_allocation() {
        let arena = HugePageArena::new(2 * 1024 * 1024).expect("arena creation");
        assert!(arena.capacity() >= 2 * 1024 * 1024);

        let rx_block = arena
            .allocate_partition(ColorPartition::RxRing, 4096)
            .unwrap();
        assert_eq!(rx_block.len(), 4096);
        assert_eq!(rx_block.partition(), ColorPartition::RxRing);

        let tx_block = arena
            .allocate_partition(ColorPartition::TxRing, 4096)
            .unwrap();
        assert_eq!(tx_block.len(), 4096);
        assert_eq!(tx_block.partition(), ColorPartition::TxRing);

        assert_ne!(rx_block.ptr(), tx_block.ptr());
    }
}
