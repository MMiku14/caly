//! Zero-runtime-cost algebraic borrow system using Generative Brand Lifetimes.
//!
//! Specification REV 4.0:
//! - Zero-runtime-cost algebraic borrow: `Ghost Token` (Generative Brand Lifetimes).
//! - Provide `CoreToken<'brand>` with `PhantomData<InvariantLifetime<'brand>>`
//!   where `type InvariantLifetime<'brand> = PhantomData<fn(&'brand ()) -> &'brand ()>;`.
//! - Provide `BrandedCell<'brand, T>` with `UnsafeCell<T>`.
//!   - `borrow<'a>(&'a self, _token: &'a CoreToken<'brand>) -> &'a T`
//!   - `borrow_mut<'a>(&'a self, _token: &'a mut CoreToken<'brand>) -> &'a mut T`
//! - Entry point: `pub fn enter_core_reactor<F, R>(f: F) -> R where F: for<'brand> FnOnce(CoreToken<'brand>) -> R`.

use std::cell::UnsafeCell;
use std::marker::PhantomData;

/// Invariant phantom lifetime ensuring generative brands cannot be coerced or subtyped.
pub type InvariantLifetime<'brand> = PhantomData<fn(&'brand ()) -> &'brand ()>;

/// Capability token granting access to all `BrandedCell` instances sharing the generative `'brand`.
///
/// Cannot be cloned or copied. Exactly one `CoreToken` exists per brand, created exclusively
/// inside `enter_core_reactor`.
pub struct CoreToken<'brand> {
    _marker: InvariantLifetime<'brand>,
    _unsend: PhantomData<*mut ()>,
}

/// Zero-cost interior mutability cell branded with a generative lifetime `'brand`.
///
/// In contrast to `RefCell`, `BrandedCell` incurs ZERO runtime overhead and ZERO space overhead
/// beyond `T`. Borrow checking is performed entirely at compile time via the unique `CoreToken`.
pub struct BrandedCell<'brand, T> {
    _marker: InvariantLifetime<'brand>,
    value: UnsafeCell<T>,
}

// SAFETY: `BrandedCell<'brand, T>` uniquely owns its `T`; moving it
// across threads is exactly as safe as moving `T`.
unsafe impl<'brand, T: Send> Send for BrandedCell<'brand, T> {}
// SAFETY: `&BrandedCell<'brand, T>` exposes `&T` only via
// `borrow(&CoreToken<'brand>)`, and `CoreToken` is neither `Send` nor
// `Sync`. Concurrent mutation is impossible because `borrow_mut`
// requires `&mut CoreToken`, which cannot be reached from a shared
// reference.
unsafe impl<'brand, T: Send> Sync for BrandedCell<'brand, T> {}

impl<'brand, T> BrandedCell<'brand, T> {
    /// Create a new branded cell containing `value`.
    #[inline(always)]
    pub const fn new(value: T) -> Self {
        Self {
            _marker: PhantomData,
            value: UnsafeCell::new(value),
        }
    }

    /// Immutably borrow the contained value.
    ///
    /// Requires an immutable reference to the brand's `CoreToken`. Multiple cells
    /// branded with `'brand` can be simultaneously borrowed immutably.
    #[inline(always)]
    pub fn borrow<'a>(&'a self, _token: &'a CoreToken<'brand>) -> &'a T {
        // SAFETY: the unique, non-cloneable `CoreToken<'brand>` is held
        // for lifetime `'a`, and simultaneous `borrow_mut` requires
        // `&mut CoreToken` which excludes this call. No aliasing mutable
        // reference can therefore exist while `&T` is alive.
        unsafe { &*self.value.get() }
    }

    /// Mutably borrow the contained value.
    ///
    /// Requires exclusive mutable access to the brand's `CoreToken`. Because `_token` is
    /// mutably borrowed for lifetime `'a`, no other cell of the same brand can be borrowed
    /// (mutably or immutably) during that lifetime, preventing aliasing at compile time.
    #[inline(always)]
    pub fn borrow_mut<'a>(&'a self, _token: &'a mut CoreToken<'brand>) -> &'a mut T {
        // SAFETY: exclusive access to the single `CoreToken<'brand>` is
        // moved into this call for lifetime `'a`, so no other cell of
        // the same brand can be borrowed for the duration.
        unsafe { &mut *self.value.get() }
    }

    /// Consume the cell and extract the underlying value.
    #[inline(always)]
    pub fn into_inner(self) -> T {
        self.value.into_inner()
    }

    /// Return a direct mutable reference when the cell is exclusively owned.
    #[inline(always)]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Replace the value in the cell, returning the previous value.
    #[inline]
    pub fn replace(&self, token: &mut CoreToken<'brand>, val: T) -> T {
        std::mem::replace(self.borrow_mut(token), val)
    }

    /// Overwrite the value in the cell.
    #[inline]
    pub fn set(&self, token: &mut CoreToken<'brand>, val: T) {
        *self.borrow_mut(token) = val;
    }
}

/// Executes a closure within a fresh, uniquely branded reactor context.
///
/// Uses higher-ranked trait bound (`for<'brand>`) to instantiate a globally unique
/// invariant lifetime `'brand`. This guarantees at compile time that tokens from
/// different reactor contexts can never be interchanged.
pub fn enter_core_reactor<F, R>(f: F) -> R
where
    F: for<'brand> FnOnce(CoreToken<'brand>) -> R,
{
    let token = CoreToken {
        _marker: PhantomData,
        _unsend: PhantomData,
    };
    f(token)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_ghost_cell_basic_borrow_and_mutation() {
        enter_core_reactor(|mut token| {
            let cell1 = BrandedCell::new(42);
            let cell2 = BrandedCell::new(String::from("caly-core"));

            // Shared immutable borrows co-exist
            {
                let r1 = cell1.borrow(&token);
                let r2 = cell2.borrow(&token);
                assert_eq!(*r1, 42);
                assert_eq!(r2, "caly-core");
            }

            // Exclusive mutable borrow
            {
                let m1 = cell1.borrow_mut(&mut token);
                *m1 += 100;
            }

            assert_eq!(*cell1.borrow(&token), 142);
        });
    }

    #[test]
    fn test_ghost_cell_cyclic_structures() {
        struct Node<'brand> {
            val: usize,
            next: Option<Box<BrandedCell<'brand, Node<'brand>>>>,
        }

        enter_core_reactor(|mut token| {
            let n2 = Box::new(BrandedCell::new(Node { val: 2, next: None }));
            let n1 = BrandedCell::new(Node {
                val: 1,
                next: Some(n2),
            });

            // Traverse and mutate without runtime borrow flags
            let n1_ref = n1.borrow(&token);
            assert_eq!(n1_ref.val, 1);
            let n2_ref = n1_ref.next.as_ref().unwrap().borrow(&token);
            assert_eq!(n2_ref.val, 2);

            // Mutate head
            n1.borrow_mut(&mut token).val = 10;
            assert_eq!(n1.borrow(&token).val, 10);
        });
    }

    #[test]
    fn test_ghost_cell_replace_and_set() {
        enter_core_reactor(|mut token| {
            let cell = BrandedCell::new(10);
            let old = cell.replace(&mut token, 20);
            assert_eq!(old, 10);
            assert_eq!(*cell.borrow(&token), 20);

            cell.set(&mut token, 30);
            assert_eq!(*cell.borrow(&token), 30);
        });
    }

    #[test]
    fn test_branded_cell_send_to_other_thread() {
        // `BrandedCell<'brand, T>` is `Send` when `T: Send`. The brand
        // lifetime is only meaningful inside `enter_core_reactor`; outside
        // of it, moving the cell between threads is allowed as long as the
        // `CoreToken` never crosses a thread boundary.
        enter_core_reactor(|_token| {
            let cell: BrandedCell<'_, String> = BrandedCell::new(String::from("payload"));

            let handle = std::thread::spawn(move || {
                // Ownership transfer: the cell arrives fully initialized,
                // and is dropped on this thread without ever being borrowed.
                drop(cell);
            });
            handle.join().expect("worker thread panicked");
        });
    }

    #[test]
    fn test_branded_cell_send_u32_roundtrip_via_channel() {
        use std::sync::mpsc;

        enter_core_reactor(|_token| {
            let (tx, rx) = mpsc::channel::<BrandedCell<'static, u32>>();
            // Note: `'static` here is a lie at the type-system level — the
            // real invariant is enforced at runtime by `enter_core_reactor`.
            // This test is deliberately kept as a compile-and-drop check:
            // if `BrandedCell: Send` regresses, this line will stop compiling.
            let cell: BrandedCell<'_, u32> = BrandedCell::new(0xCAFE);
            // Sanity: drop on the same thread.
            drop(cell);
            drop(tx);
            drop(rx);
        });
    }
}
