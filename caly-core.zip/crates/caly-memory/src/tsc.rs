//! Hardware Time Stamp Counter (TSC) timer and frequency calibration.
//!
//! Specification REV 4.0:
//! - Hardware TSC timer: `read_cpu_tsc()` using `_rdtsc()` on x86_64 or fallback cycle counter.
//! - Inline alias `read_tsc()` for sub-cycle latency queries.
//! - Frequency calibration helper (`TscClock`) and helper functions:
//!   - `estimate_tsc_frequency_hz()`
//!   - `tsc_cycles_to_nanos()`
//! - Sub-nanosecond precision timing for ingress frame timestamps and pipeline latency profiling.

use std::time::{Duration, Instant};
/// Read the raw CPU Time Stamp Counter (TSC).
///
/// On x86_64, directly executes the `_rdtsc` compiler intrinsic for minimal overhead (typically 15-25 cycles).
/// On AArch64, queries the virtual cycle counter `cntvct_el0`.
/// On other architectures, falls back to a high-resolution monotonic timer.
///
/// Under Miri, `_rdtsc` / `cntvct_el0` / `Instant::now` are unavailable, so we
/// return a monotonically-increasing pseudo-counter. This keeps pure-logic tests
/// (which use TSC only for ordering / measuring) executable under Miri without
/// changing production behavior.
#[inline(always)]
pub fn read_cpu_tsc() -> u64 {
    #[cfg(miri)]
    {
        use std::sync::atomic::{AtomicU64, Ordering};
        static MIRI_TSC: AtomicU64 = AtomicU64::new(0);
        MIRI_TSC.fetch_add(1, Ordering::Relaxed)
    }
    #[cfg(all(not(miri), target_arch = "x86_64"))]
    // SAFETY: `_rdtsc` is unconditionally available on x86_64; it reads
    // the timestamp counter and has no side effects.
    unsafe {
        core::arch::x86_64::_rdtsc()
    }
    #[cfg(all(not(miri), target_arch = "x86"))]
    unsafe {
        core::arch::x86::_rdtsc()
    }
    #[cfg(all(not(miri), target_arch = "aarch64"))]
    unsafe {
        let val: u64;
        core::arch::asm!("mrs {}, cntvct_el0", out(reg) val, options(nomem, nostack));
        val
    }
    #[cfg(all(
        not(miri),
        not(any(target_arch = "x86_64", target_arch = "x86", target_arch = "aarch64"))
    ))]
    {
        use std::sync::atomic::{AtomicU64, Ordering};
        static START: std::sync::OnceLock<Instant> = std::sync::OnceLock::new();
        let start = START.get_or_init(Instant::now);
        start.elapsed().as_nanos() as u64
    }
}

/// Read the raw CPU Time Stamp Counter (TSC).
///
/// An inline zero-overhead alias for [`read_cpu_tsc`].
#[inline(always)]
pub fn read_tsc() -> u64 {
    read_cpu_tsc()
}

/// Read the CPU Time Stamp Counter with serialization to prevent out-of-order execution.
///
/// Uses `__rdtscp` or `_mm_lfence` on x86_64.
#[inline(always)]
pub fn read_cpu_tsc_serialized() -> u64 {
    #[cfg(target_arch = "x86_64")]
    // SAFETY: `__rdtscp` is available on all x86_64 CPUs that support
    // the RDTSCP feature (detected via the compiler target); `aux` is
    // a stack local written by the instruction.
    unsafe {
        let mut aux: u32 = 0;
        core::arch::x86_64::__rdtscp(&mut aux)
    }
    #[cfg(not(target_arch = "x86_64"))]
    {
        read_cpu_tsc()
    }
}

/// Estimate the CPU TSC frequency in Hertz over a brief sampling window (5 ms).
///
/// The result is cached after the first call: TSC frequency is fixed on a
/// given machine, so a single calibration is sufficient and avoids paying
/// the 5 ms spin-loop cost on every call site (e.g. `DrainController::drain`
/// would otherwise block for 5 ms per invocation).
pub fn estimate_tsc_frequency_hz() -> u64 {
    use std::sync::OnceLock;
    static CACHED_FREQ_HZ: OnceLock<u64> = OnceLock::new();
    *CACHED_FREQ_HZ.get_or_init(|| TscClock::calibrate(Duration::from_millis(5)).frequency_hz())
}

/// Convert TSC elapsed cycles into nanoseconds given the clock frequency in Hertz.
#[inline(always)]
pub fn tsc_cycles_to_nanos(cycles: u64, freq_hz: u64) -> u64 {
    if freq_hz == 0 {
        return 0;
    }
    ((cycles as u128 * 1_000_000_000) / (freq_hz as u128)) as u64
}

/// TSC Frequency calibration and timestamp converter.
///
/// Provides conversion between raw TSC cycle ticks and physical time units (nanoseconds, microseconds).
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct TscClock {
    /// Measured or configured clock frequency in Hertz (cycles per second).
    frequency_hz: u64,
    /// Nanoseconds per TSC cycle.
    ns_per_cycle: f64,
}

impl Default for TscClock {
    #[inline]
    fn default() -> Self {
        // Fast non-spinning default nominal frequency (2.5 GHz standard server profile)
        Self::from_frequency_hz(2_500_000_000)
    }
}

impl TscClock {
    /// Construct a `TscClock` with an explicitly known frequency in Hertz.
    pub const fn from_frequency_hz(frequency_hz: u64) -> Self {
        assert!(frequency_hz > 0, "TSC frequency must be strictly positive");
        Self {
            frequency_hz,
            ns_per_cycle: 1_000_000_000.0 / (frequency_hz as f64),
        }
    }

    /// Calibrate TSC frequency against the system monotonic clock over `sample_duration`.
    pub fn calibrate(sample_duration: Duration) -> Self {
        let start_instant = Instant::now();
        let start_tsc = read_cpu_tsc();

        // Spin-wait until calibration sample duration has elapsed
        while start_instant.elapsed() < sample_duration {
            core::hint::spin_loop();
        }

        let elapsed_time = start_instant.elapsed();
        let end_tsc = read_cpu_tsc();
        let elapsed_cycles = end_tsc.saturating_sub(start_tsc);

        let elapsed_secs = elapsed_time.as_secs_f64();
        let frequency_hz = if elapsed_secs > 0.0 && elapsed_cycles > 0 {
            (elapsed_cycles as f64 / elapsed_secs) as u64
        } else {
            // Nominal 2.5 GHz fallback
            2_500_000_000
        };

        Self::from_frequency_hz(frequency_hz.max(1_000_000))
    }

    /// Configured or calibrated frequency in Hertz.
    #[inline(always)]
    pub fn frequency_hz(&self) -> u64 {
        self.frequency_hz
    }

    /// Read current TSC cycle count.
    #[inline(always)]
    pub fn now(&self) -> u64 {
        read_cpu_tsc()
    }

    /// Convert TSC cycle duration to nanoseconds without floating point inaccuracy.
    #[inline(always)]
    pub fn cycles_to_ns(&self, cycles: u64) -> u64 {
        tsc_cycles_to_nanos(cycles, self.frequency_hz)
    }

    /// Convert TSC cycle duration to microseconds.
    #[inline(always)]
    pub fn cycles_to_us(&self, cycles: u64) -> u64 {
        ((cycles as u128 * 1_000_000) / (self.frequency_hz as u128)) as u64
    }

    /// Convert nanoseconds to TSC cycles.
    #[inline(always)]
    pub fn ns_to_cycles(&self, ns: u64) -> u64 {
        ((ns as u128 * self.frequency_hz as u128) / 1_000_000_000) as u64
    }

    /// Elapsed cycles from `start_tsc` to now.
    #[inline(always)]
    pub fn elapsed_cycles(&self, start_tsc: u64) -> u64 {
        read_cpu_tsc().saturating_sub(start_tsc)
    }

    /// Elapsed nanoseconds from `start_tsc` to now.
    #[inline(always)]
    pub fn elapsed_ns(&self, start_tsc: u64) -> u64 {
        self.cycles_to_ns(self.elapsed_cycles(start_tsc))
    }

    /// Elapsed microseconds from `start_tsc` to now.
    #[inline(always)]
    pub fn elapsed_us(&self, start_tsc: u64) -> u64 {
        self.cycles_to_us(self.elapsed_cycles(start_tsc))
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    #[cfg_attr(miri, ignore)]
    fn test_tsc_monotonicity() {
        let t1 = read_cpu_tsc();
        let t2 = read_tsc();
        assert!(t2 >= t1);
    }

    #[test]
    fn test_tsc_clock_math() {
        // Test with 2 GHz clock
        let clock = TscClock::from_frequency_hz(2_000_000_000);
        assert_eq!(clock.frequency_hz(), 2_000_000_000);

        // 2,000,000,000 cycles = 1,000,000,000 ns
        assert_eq!(clock.cycles_to_ns(2_000_000_000), 1_000_000_000);
        assert_eq!(clock.cycles_to_us(2_000_000_000), 1_000_000);
        assert_eq!(clock.ns_to_cycles(1_000_000_000), 2_000_000_000);
        assert_eq!(
            tsc_cycles_to_nanos(2_000_000_000, 2_000_000_000),
            1_000_000_000
        );
    }

    #[test]
    #[cfg_attr(miri, ignore)]
    fn test_estimate_tsc_frequency() {
        let freq = estimate_tsc_frequency_hz();
        assert!(freq > 1_000_000);
    }
}
