//! Error types for the caly-memory crate.

use thiserror::Error;

/// Core errors occurring during memory allocation, coloring, or ring operations.
#[derive(Error, Debug)]
pub enum MemoryError {
    /// Memory mapping syscall failed.
    #[error("mmap allocation failed: {0}")]
    MmapFailed(#[from] std::io::Error),

    /// System error during munmap.
    #[error("munmap deallocation failed with errno: {0}")]
    MunmapFailed(i32),

    /// Requested capacity is invalid (e.g. not a power of two or zero).
    #[error("invalid capacity {capacity}: {reason}")]
    InvalidCapacity {
        /// Capacity that was requested.
        capacity: usize,
        /// Reason for rejection.
        reason: &'static str,
    },

    /// The memory pool or partition has exhausted its available capacity.
    #[error("out of memory: requested {requested} bytes, but only {available} bytes available")]
    OutOfMemory {
        /// Requested byte count.
        requested: usize,
        /// Available remaining capacity.
        available: usize,
    },

    /// Ring buffer is completely full.
    #[error("ring buffer is full")]
    RingFull,

    /// Ring buffer is empty.
    #[error("ring buffer is empty")]
    RingEmpty,

    /// Memory alignment requirement violated.
    #[error(
        "invalid alignment {requested} bytes: must be at least {minimum} bytes and a power of two"
    )]
    InvalidAlignment {
        /// Requested alignment.
        requested: usize,
        /// Minimum required alignment.
        minimum: usize,
    },

    /// Cache coloring configuration or partition constraint violated.
    #[error("cache coloring error: {0}")]
    ColoringError(String),

    /// HugeTLB requested page size is unsupported or unavailable.
    #[error("HugeTLB requested page size is unsupported or unavailable")]
    HugePageUnsupported,

    /// General allocation failure.
    #[error("memory allocation failure: {0}")]
    AllocationFailure(String),
}

/// Convenience result alias for memory operations.
pub type Result<T> = std::result::Result<T, MemoryError>;
