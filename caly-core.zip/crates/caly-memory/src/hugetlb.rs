//! HugeTLB Page Allocator with Linux mmap and transparent anonymous fallback.
//!
//! Specification REV 4.0:
//! - Allocates 2MB or 1GB pages via `mmap` with `MAP_HUGETLB | MAP_POPULATE`.
//! - Provides automatic fallback to standard aligned anonymous memory for test environments
//!   or containers where HugeTLB is not mounted.
//! - Implements clean `munmap` in `Drop`.
//! - Provides physical address resolution via `/proc/self/pagemap`.

use crate::error::{MemoryError, Result};
use std::fs::File;
use std::io::{Read, Seek, SeekFrom};
use std::ops::{Deref, DerefMut};

/// Supported memory page sizes for HugeTLB allocation.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum HugePageSize {
    /// Standard operating system page (typically 4 KiB).
    Standard4KiB,
    /// 2 MiB Huge Page (2,097,152 bytes).
    TwoMegabytes,
    /// 1 GiB Huge Page (1,073,741,824 bytes).
    OneGigabyte,
}

impl HugePageSize {
    /// Ergonomic alias for 2 MiB hugepage.
    #[allow(non_upper_case_globals)]
    pub const Huge2MiB: HugePageSize = HugePageSize::TwoMegabytes;
    /// Ergonomic alias for 1 GiB hugepage.
    #[allow(non_upper_case_globals)]
    pub const Huge1GiB: HugePageSize = HugePageSize::OneGigabyte;

    /// Return the page size in bytes.
    #[inline(always)]
    pub const fn size_bytes(&self) -> usize {
        match self {
            Self::Standard4KiB => 4 * 1024,
            Self::TwoMegabytes => 2 * 1024 * 1024,
            Self::OneGigabyte => 1024 * 1024 * 1024,
        }
    }

    /// Return the Linux mmap `MAP_HUGE_SHIFT` exponent if applicable.
    #[inline(always)]
    pub const fn huge_shift(&self) -> Option<u32> {
        match self {
            Self::Standard4KiB => None,
            Self::TwoMegabytes => Some(21),
            Self::OneGigabyte => Some(30),
        }
    }
}

/// A contiguous, page-aligned memory buffer allocated via HugeTLB or aligned anonymous mmap.
///
/// Ensures clean `munmap` upon dropping, completely preventing kernel memory leaks.
pub struct HugePageMemory {
    /// Pointer to the usable aligned memory buffer.
    ptr: *mut u8,
    /// Usable length of the memory buffer in bytes.
    len: usize,
    /// Raw base pointer returned by `libc::mmap` (may differ from `ptr` if alignment padding was added).
    raw_ptr: *mut u8,
    /// Total bytes mapped by `libc::mmap`.
    raw_len: usize,
    /// Page size requested during allocation.
    page_size: HugePageSize,
    /// True if allocation was backed by real HugeTLB pages.
    is_hugetlb: bool,
}

// SAFETY: `HugePageMemory` uniquely owns its mapped region; the raw
// pointers are never aliased by any other Rust value, so moving it
// across threads is safe.
unsafe impl Send for HugePageMemory {}
// SAFETY: `&HugePageMemory` exposes only read-only views; mutation
// requires `&mut self`, which the borrow checker serializes.
unsafe impl Sync for HugePageMemory {}

impl HugePageMemory {
    /// Allocate memory buffer with the specified size and page size.
    ///
    /// Attempts `mmap` with `MAP_HUGETLB | MAP_POPULATE`. If HugeTLB pages are unavailable
    /// or insufficient privileges exist (common in containerized CI environments),
    /// transparently falls back to aligned anonymous memory.
    pub fn allocate(size: usize, page_size: HugePageSize) -> Result<Self> {
        if size == 0 {
            return Err(MemoryError::AllocationFailure(
                "cannot allocate 0 bytes".into(),
            ));
        }

        let page_bytes = page_size.size_bytes();

        // Guard the round-up arithmetic: for very large `size`, `size + page_bytes - 1`
        // would wrap around and produce a tiny aligned size, silently mapping
        // far less than the caller asked for.
        let aligned_size = size.checked_add(page_bytes - 1).ok_or_else(|| {
            MemoryError::AllocationFailure(format!(
                "size {size} + alignment {page_bytes} overflows usize"
            ))
        })? & !(page_bytes - 1);

        // First attempt: HugeTLB mmap if supported on target OS.
        // Under Miri this branch is skipped; the fallback below uses
        // MAP_PRIVATE | MAP_ANONYMOUS, which Miri fully supports.
        #[cfg(all(target_os = "linux", not(miri)))]
        if let Some(shift) = page_size.huge_shift() {
            let huge_flag = (shift as libc::c_int) << 26;
            let flags = libc::MAP_PRIVATE
                | libc::MAP_ANONYMOUS
                | libc::MAP_HUGETLB
                | huge_flag
                | libc::MAP_POPULATE;

            // SAFETY: `mmap` with a null hint and MAP_ANONYMOUS returns
            // a fresh, unaliased mapping; flags and protection bits are
            // well-formed. The mapping is owned by this function until
            // it is returned inside `Self`.
            let mmap_res = unsafe {
                libc::mmap(
                    std::ptr::null_mut(),
                    aligned_size,
                    libc::PROT_READ | libc::PROT_WRITE,
                    flags,
                    -1,
                    0,
                )
            };

            if mmap_res != libc::MAP_FAILED {
                let ptr = mmap_res as *mut u8;
                return Ok(Self {
                    ptr,
                    len: aligned_size,
                    raw_ptr: ptr,
                    raw_len: aligned_size,
                    page_size,
                    is_hugetlb: true,
                });
            }
        }

        // Fallback: Standard anonymous mmap with manual alignment to page_bytes
        // Extra page is needed for manual re-alignment when we fall back to
        // anonymous pages. Adding `page_bytes` can also overflow, so use
        // checked arithmetic here as well.
        let total_to_map = if page_bytes > 4096 {
            aligned_size.checked_add(page_bytes).ok_or_else(|| {
                MemoryError::AllocationFailure("aligned_size + page_bytes overflows usize".into())
            })?
        } else {
            aligned_size
        };

        let flags = libc::MAP_PRIVATE | libc::MAP_ANONYMOUS;
        // SAFETY: fallback path — same contract as the HugeTLB `mmap`
        // above; the resulting region is fresh and owned by this
        // function.
        let mmap_res = unsafe {
            libc::mmap(
                std::ptr::null_mut(),
                total_to_map,
                libc::PROT_READ | libc::PROT_WRITE,
                flags,
                -1,
                0,
            )
        };

        if mmap_res == libc::MAP_FAILED {
            return Err(MemoryError::MmapFailed(std::io::Error::last_os_error()));
        }

        let raw_ptr = mmap_res as *mut u8;
        let raw_addr = raw_ptr as usize;
        let misalign = raw_addr & (page_bytes - 1);
        let offset = if misalign == 0 {
            0
        } else {
            page_bytes - misalign
        };

        // Advance the original pointer by `offset` bytes; this preserves
        // provenance, whereas `aligned_addr as *mut u8` would expose the
        // address and produce a provenance-erased pointer.
        // SAFETY: `offset < page_bytes <= total_to_map`, so the
        // resulting pointer stays inside the same allocation.
        let ptr = unsafe { raw_ptr.add(offset) };

        Ok(Self {
            ptr,
            len: aligned_size,
            raw_ptr,
            raw_len: total_to_map,
            page_size,
            is_hugetlb: false,
        })
    }

    /// Usable pointer to beginning of memory region.
    #[inline(always)]
    pub fn as_ptr(&self) -> *const u8 {
        self.ptr
    }

    /// Mutable pointer to beginning of memory region.
    #[inline(always)]
    pub fn as_mut_ptr(&mut self) -> *mut u8 {
        self.ptr
    }

    /// Length of the usable memory buffer in bytes.
    #[inline(always)]
    pub fn len(&self) -> usize {
        self.len
    }

    /// Check if the buffer is empty.
    #[inline(always)]
    pub fn is_empty(&self) -> bool {
        self.len == 0
    }

    /// Returns whether this buffer is backed by hardware HugeTLB pages.
    #[inline(always)]
    pub fn is_hugetlb(&self) -> bool {
        self.is_hugetlb
    }

    /// The page size configuration for this allocation.
    #[inline(always)]
    pub fn page_size(&self) -> HugePageSize {
        self.page_size
    }

    /// View memory buffer as an immutable byte slice.
    #[inline(always)]
    pub fn as_slice(&self) -> &[u8] {
        // SAFETY: `ptr`/`len` describe a valid, initialized, non-aliased mutable slice.
        unsafe { std::slice::from_raw_parts(self.ptr, self.len) }
    }

    /// View memory buffer as a mutable byte slice.
    #[inline(always)]
    pub fn as_mut_slice(&mut self) -> &mut [u8] {
        // SAFETY: `ptr`/`len` describe a valid, initialized, non-aliased mutable slice.
        unsafe { std::slice::from_raw_parts_mut(self.ptr, self.len) }
    }

    /// Query the physical address of a virtual address within this memory region.
    ///
    /// Reads `/proc/self/pagemap` on Linux. Three outcomes are possible:
    ///
    /// 1. **Success** — the kernel provides a valid PFN; the real physical
    ///    address is returned. This requires `CAP_SYS_ADMIN` (or being root)
    ///    in most kernel configurations.
    /// 2. **Fallback** — `/proc/self/pagemap` is inaccessible or the PFN is
    ///    censored (returned as zero). The virtual address is returned so
    ///    that downstream cache-set modelling can still operate on *some*
    ///    monotonic value; callers that need to *distinguish* real physical
    ///    addresses from virtual ones should compare the result against the
    ///    input address (`result == virt_addr` implies fallback).
    /// 3. **Out-of-range** — `virt_addr` is outside `[self.as_ptr(), self.as_ptr() + self.len())`;
    ///    `None` is returned.
    ///
    /// The fallback behaviour is a design compromise: cache-coloring code
    /// that runs in unprivileged containers would otherwise be unusable.
    pub fn virt_to_phys(&self, virt_addr: usize) -> Option<usize> {
        let base = self.ptr as usize;
        if virt_addr < base || virt_addr >= base + self.len {
            return None;
        }

        #[cfg(target_os = "linux")]
        {
            const PAGE_SHIFT: usize = 12; // 4096 bytes
            const PAGEMAP_ENTRY_BYTES: usize = 8;
            let page_index = virt_addr >> PAGE_SHIFT;
            let offset = (page_index * PAGEMAP_ENTRY_BYTES) as u64;

            if let Ok(mut file) = File::open("/proc/self/pagemap") {
                if file.seek(SeekFrom::Start(offset)).is_ok() {
                    let mut entry = [0u8; 8];
                    if file.read_exact(&mut entry).is_ok() {
                        let data = u64::from_ne_bytes(entry);
                        // Bit 63: page present in RAM.
                        let present = (data & (1 << 63)) != 0;
                        // Bit 61: page has been swapped out. The PFN
                        // field is only meaningful while the page is
                        // resident; on a swapped entry it is stale, and
                        // returning it would hand the caller a physical
                        // address into unrelated memory. Fall through to
                        // the virtual-address fallback below, which
                        // preserves the "monotone key" contract this
                        // method documents.
                        let swapped = (data & (1 << 61)) != 0;
                        if present && !swapped {
                            // PFN occupies bits 0..54.
                            let pfn = data & 0x007f_ffff_ffff_ffff;
                            let phys = ((pfn as usize) << PAGE_SHIFT) | (virt_addr & 0xfff);
                            return Some(phys);
                        }
                    }
                }
            }
        }

        // Transparent fallback: return virtual address for cache set calculations in tests
        Some(virt_addr)
    }
}

impl Deref for HugePageMemory {
    type Target = [u8];

    #[inline(always)]
    fn deref(&self) -> &Self::Target {
        self.as_slice()
    }
}

impl DerefMut for HugePageMemory {
    #[inline(always)]
    fn deref_mut(&mut self) -> &mut Self::Target {
        self.as_mut_slice()
    }
}

impl AsRef<[u8]> for HugePageMemory {
    #[inline(always)]
    fn as_ref(&self) -> &[u8] {
        self.as_slice()
    }
}

impl AsMut<[u8]> for HugePageMemory {
    #[inline(always)]
    fn as_mut(&mut self) -> &mut [u8] {
        self.as_mut_slice()
    }
}

impl Drop for HugePageMemory {
    fn drop(&mut self) {
        if !self.raw_ptr.is_null() && self.raw_len > 0 {
            // SAFETY: `raw_ptr`/`raw_len` were produced by `libc::mmap`
            // in `allocate` and are unmapped exactly once here.
            let res = unsafe { libc::munmap(self.raw_ptr as *mut libc::c_void, self.raw_len) };
            if res != 0 {
                #[cfg(debug_assertions)]
                eprintln!(
                    "HugePageMemory: munmap failed with error: {}",
                    std::io::Error::last_os_error()
                );
            }
        }
    }
}

/// Helper allocator interface for HugeTLB memory pools.
#[derive(Debug, Default, Clone, Copy)]
pub struct HugeTlbAllocator;

impl HugeTlbAllocator {
    /// Allocate memory sized as an integral number of 2MB huge pages.
    pub fn allocate_2mb(num_pages: usize) -> Result<HugePageMemory> {
        let size = num_pages
            .checked_mul(HugePageSize::TwoMegabytes.size_bytes())
            .ok_or_else(|| {
                MemoryError::AllocationFailure("integer overflow in 2MB allocation size".into())
            })?;
        HugePageMemory::allocate(size, HugePageSize::TwoMegabytes)
    }

    /// Allocate memory sized as an integral number of 1GB huge pages.
    pub fn allocate_1gb(num_pages: usize) -> Result<HugePageMemory> {
        let size = num_pages
            .checked_mul(HugePageSize::OneGigabyte.size_bytes())
            .ok_or_else(|| {
                MemoryError::AllocationFailure("integer overflow in 1GB allocation size".into())
            })?;
        HugePageMemory::allocate(size, HugePageSize::OneGigabyte)
    }

    /// Allocate general memory with custom size and target hugepage class.
    pub fn allocate(size: usize, page_size: HugePageSize) -> Result<HugePageMemory> {
        HugePageMemory::allocate(size, page_size)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    #[cfg_attr(miri, ignore)]
    fn test_hugetlb_allocation_and_drop() {
        let mut mem = HugePageMemory::allocate(1024 * 1024, HugePageSize::Standard4KiB)
            .expect("mmap allocation");
        assert!(mem.len() >= 1024 * 1024);
        assert!(!mem.as_ptr().is_null());

        // Test memory write/read.
        // Cache the length in a local first: `mem[mem.len() - 1] = ...` would
        // require an immutable borrow (for `len()`) inside the same expression
        // that performs an `IndexMut` on `mem`, which is rejected by borrowck (E0502).
        let last = mem.len() - 1;
        mem[0] = 0xAA;
        mem[last] = 0x55;
        assert_eq!(mem[0], 0xAA);
        assert_eq!(mem[last], 0x55);
        // Verified drop calls munmap cleanly
    }

    #[test]
    #[cfg_attr(miri, ignore)]
    fn test_2mb_allocator_fallback() {
        let mem = HugeTlbAllocator::allocate_2mb(1).expect("fallback or hugetlb allocate 2MB");
        assert_eq!(mem.len(), 2 * 1024 * 1024);
        assert_eq!(mem.as_ptr() as usize % 4096, 0);
    }

    #[test]
    #[cfg_attr(miri, ignore)]
    fn test_virt_to_phys() {
        let mem = HugePageMemory::allocate(4096, HugePageSize::Standard4KiB).unwrap();
        let virt = mem.as_ptr() as usize;
        let phys = mem.virt_to_phys(virt);
        assert!(phys.is_some());
    }

    /// A resident page must never produce a physical address of exactly
    /// zero: PFN 0 is the real-mode IVT and is never handed out by the
    /// page allocator. If the swapped-bit handling regresses (bit 61 is
    /// misread as "not present" or the present/swap check is inverted),
    /// the fallback path returns the virtual address instead — which is
    /// never zero for a real mapping — so a zero result is the canonical
    /// signature of the earlier bug.
    #[test]
    #[cfg_attr(miri, ignore)]
    fn test_virt_to_phys_never_returns_zero_for_a_live_mapping() {
        let mem = HugePageMemory::allocate(8192, HugePageSize::Standard4KiB).unwrap();
        let virt = mem.as_ptr() as usize;
        assert_ne!(virt, 0, "mmap never returns the null address");

        match mem.virt_to_phys(virt) {
            Some(phys) => assert_ne!(
                phys, 0,
                "physical address 0 is impossible for a live mapping; \
                 this indicates a swapped-bit handling regression",
            ),
            // The fallback path documented on `virt_to_phys` returns
            // `Some(virt_addr)`; a `None` here means the range check is
            // broken.
            None => panic!("virt_to_phys returned None for an in-range address"),
        }
    }

    #[test]
    fn test_hugetlb_rejects_overflow_sizes() {
        // `usize::MAX` would previously wrap during alignment rounding and
        // silently return a tiny buffer. It must now be rejected with Err.
        let r = HugePageMemory::allocate(usize::MAX, HugePageSize::TwoMegabytes);
        assert!(r.is_err(), "usize::MAX must be rejected");

        let r = HugePageMemory::allocate(usize::MAX - 100, HugePageSize::OneGigabyte);
        assert!(r.is_err(), "near-usize::MAX must be rejected");
    }
}
