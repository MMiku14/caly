//! Zero-allocation lock-free SPSC Static Ring Buffer.
//!
//! Specification REV 4.0:
//! - `StaticRingBuffer<T, const CAP: usize>`: Fixed-size zero-allocation ring buffer.
//! - Power-of-two capacity optimization with bitmask.
//! - Head and tail pointers with lock-free semantics for SPSC (Single Producer Single Consumer)
//!   or branded single-core use.
//! - Cache-line padded head/tail pointers to eliminate false sharing.
//! - Kani formal verification proof harness under `#[cfg(kani)]`.

use crossbeam_utils::CachePadded;
use std::cell::UnsafeCell;
use std::mem::MaybeUninit;
use std::sync::atomic::{AtomicUsize, Ordering};

/// Fixed-size, zero-allocation lock-free Single Producer Single Consumer (SPSC) ring buffer.
///
/// Capacity `CAP` must be a non-zero power of two.
pub struct StaticRingBuffer<T, const CAP: usize> {
    /// Zero-allocation inline ring storage buffer.
    buffer: [UnsafeCell<MaybeUninit<T>>; CAP],
    /// Consumer read cursor (cache-line padded to eliminate false sharing).
    head: CachePadded<AtomicUsize>,
    /// Producer write cursor (cache-line padded to eliminate false sharing).
    tail: CachePadded<AtomicUsize>,
}

// SAFETY: `StaticRingBuffer` stores `T` behind `UnsafeCell` but
// synchronizes all accesses through `head` / `tail` atomics with
// `Acquire`/`Release` semantics. `T: Send` is the only trait bound
// required to move the buffer across threads.
unsafe impl<T: Send, const CAP: usize> Send for StaticRingBuffer<T, CAP> {}
// SAFETY: shared references only provide `push`/`pop`/`len`, which
// are designed for cross-thread SPSC use (single producer, single
// consumer). Concurrent use from more than one producer or consumer
// is a caller responsibility, not a property of this type.
unsafe impl<T: Send, const CAP: usize> Sync for StaticRingBuffer<T, CAP> {}

impl<T, const CAP: usize> Default for StaticRingBuffer<T, CAP> {
    #[inline]
    fn default() -> Self {
        Self::new()
    }
}

impl<T, const CAP: usize> StaticRingBuffer<T, CAP> {
    /// Bitmask for fast modulo wrapping.
    const MASK: usize = CAP - 1;

    /// Create a new empty ring buffer.
    ///
    /// # Panics
    /// Panics at runtime if `CAP` is zero or not a power of two.
    pub fn new() -> Self {
        assert!(CAP > 0, "Ring buffer capacity must be greater than zero");
        assert!(
            (CAP & (CAP - 1)) == 0,
            "Ring buffer capacity must be a power of two"
        );

        Self {
            // `const { ... }` inline-const guarantees the expression is
            // evaluated at compile time and does not require `unsafe`.
            // No `MaybeUninit::assume_init` is involved: the elements are
            // simply constructed as `UnsafeCell<MaybeUninit<T>>` values,
            // and `MaybeUninit::uninit()` is a safe, valid value on its own.
            buffer: [const { UnsafeCell::new(MaybeUninit::uninit()) }; CAP],
            head: CachePadded::new(AtomicUsize::new(0)),
            tail: CachePadded::new(AtomicUsize::new(0)),
        }
    }

    /// Return buffer capacity.
    #[inline(always)]
    pub const fn capacity(&self) -> usize {
        CAP
    }

    /// Number of items currently enqueued in the ring buffer.
    ///
    /// # Consistency
    ///
    /// `head` and `tail` are read via two independent `Acquire` loads;
    /// the pair is **not** an atomic snapshot. In a correct SPSC
    /// pairing:
    ///
    /// * The **producer** reads its own `tail` (which it just stored)
    ///   and observes `head` at or before its true value, so
    ///   `tail - head` is an **over-estimate**. `push`'s fullness check
    ///   therefore fails safe: it may refuse a push that would still
    ///   fit, but it will never overflow.
    /// * The **consumer** reads its own `head` and observes `tail` at
    ///   or before its true value, so `tail - head` is an
    ///   **under-estimate**. `pop`'s emptiness check therefore fails
    ///   safe: it may return `None` while an item is still in flight,
    ///   but it will never read an uninitialized slot.
    ///
    /// A third-party observer (neither producer nor consumer) has no
    /// such guarantee: it may observe `head` and `tail` from different
    /// points in time, producing a value outside `[0, CAP]`. Callers
    /// that need a consistent reading from a third thread must add
    /// their own synchronization.
    #[inline]
    pub fn len(&self) -> usize {
        let head = self.head.load(Ordering::Acquire);
        let tail = self.tail.load(Ordering::Acquire);
        tail.wrapping_sub(head)
    }

    /// Check if the ring buffer contains no items.
    #[inline]
    pub fn is_empty(&self) -> bool {
        let head = self.head.load(Ordering::Acquire);
        let tail = self.tail.load(Ordering::Acquire);
        head == tail
    }

    /// Check if the ring buffer is completely full.
    #[inline]
    pub fn is_full(&self) -> bool {
        self.len() >= CAP
    }

    /// Remaining available capacity.
    #[inline]
    pub fn remaining(&self) -> usize {
        CAP.saturating_sub(self.len())
    }

    /// Writes `item` into the slot at `slot`.
    ///
    /// # Safety
    ///
    /// * `slot` must be `< CAP` (guaranteed by `& Self::MASK`).
    /// * The slot must currently be uninitialized — i.e. it is the
    ///   producer's next write position, not yet visible to the consumer.
    /// * No other thread may concurrently access this slot.
    #[inline(always)]
    unsafe fn write_slot(&self, slot: usize, item: T) {
        // SAFETY: `slot < CAP` by the caller's contract; `self.buffer[slot]`
        // is `UnsafeCell<MaybeUninit<T>>`, and `.get()` gives a valid mutable
        // pointer to the inner `MaybeUninit<T>`. Writing a fresh `T` via
        // `MaybeUninit::write` is always sound (it does not drop the old
        // contents, matching the "uninitialized slot" precondition).
        unsafe {
            (*self.buffer[slot].get()).write(item);
        }
    }

    /// Reads (moves out) the value from the slot at `slot`.
    ///
    /// # Safety
    ///
    /// * `slot` must be `< CAP`.
    /// * The slot must currently hold an initialized `T` — i.e. it was
    ///   written by the producer and has not yet been consumed.
    /// * No other thread may concurrently access this slot.
    #[inline(always)]
    unsafe fn read_slot(&self, slot: usize) -> T {
        // SAFETY: `slot < CAP` by the caller's contract; `get()`
        // returns a valid pointer to the `UnsafeCell`'s `MaybeUninit<T>`.
        let cell = unsafe { &*self.buffer[slot].get() };
        // SAFETY: the slot was published by the producer via a `Release`
        // store on `tail`, and this consumer has observed that store via
        // an `Acquire` load, so the `MaybeUninit<T>` is initialized.
        // `assume_init_read` moves the value out without touching the
        // (now logically empty) slot.
        unsafe { cell.assume_init_read() }
    }

    /// Enqueue an item into the ring buffer (Producer).
    ///
    /// Returns `Err(item)` if the ring buffer is full.
    #[inline]
    pub fn push(&self, item: T) -> std::result::Result<(), T> {
        let tail = self.tail.load(Ordering::Relaxed);
        let head = self.head.load(Ordering::Acquire);

        if tail.wrapping_sub(head) >= CAP {
            return Err(item);
        }

        let slot = tail & Self::MASK;
        // SAFETY: `slot = tail & MASK < CAP`; producer-exclusive access is
        // guaranteed by the SPSC contract (only one writer thread).
        unsafe {
            self.write_slot(slot, item);
        }

        self.tail.store(tail.wrapping_add(1), Ordering::Release);
        Ok(())
    }

    /// Dequeue an item from the ring buffer (Consumer).
    ///
    /// Returns `None` if the ring buffer is empty.
    #[inline]
    pub fn pop(&self) -> Option<T> {
        let head = self.head.load(Ordering::Relaxed);
        let tail = self.tail.load(Ordering::Acquire);

        if head == tail {
            return None;
        }

        let slot = head & Self::MASK;
        // SAFETY: `slot = head & MASK < CAP`; the slot at the consumer's
        // read cursor has been published by the producer and not yet
        // consumed. SPSC contract guarantees exclusive consumer access.
        let item = unsafe { self.read_slot(slot) };

        self.head.store(head.wrapping_add(1), Ordering::Release);
        Some(item)
    }

    /// Push a batch of items from an iterator, returning count of items successfully pushed.
    pub fn push_batch<I>(&self, iter: I) -> usize
    where
        I: IntoIterator<Item = T>,
    {
        let mut count = 0;
        for item in iter {
            if self.push(item).is_err() {
                break;
            }
            count += 1;
        }
        count
    }

    /// Pop up to `max` items from the ring buffer into a `Vec`.
    pub fn pop_batch(&self, max: usize) -> Vec<T> {
        let mut items = Vec::with_capacity(max.min(self.len()));
        for _ in 0..max {
            if let Some(item) = self.pop() {
                items.push(item);
            } else {
                break;
            }
        }
        items
    }

    /// Split the buffer into dedicated Single Producer and Single Consumer handles.
    pub fn split(&mut self) -> (Producer<'_, T, CAP>, Consumer<'_, T, CAP>) {
        (Producer { ring: self }, Consumer { ring: self })
    }
}

impl<T, const CAP: usize> Drop for StaticRingBuffer<T, CAP> {
    fn drop(&mut self) {
        let mut head = self.head.load(Ordering::Relaxed);
        let tail = self.tail.load(Ordering::Relaxed);

        while head != tail {
            let slot = head & Self::MASK;
            // SAFETY: `slot = head & MASK < CAP`; the slot is known to
            // hold an initialized `T` because `head != tail` guarantees
            // the producer has published it.
            let cell = unsafe { &mut *self.buffer[slot].get() };
            // SAFETY: dropping the value in place is the final use of
            // this slot; `head` is advanced immediately after.
            unsafe { std::ptr::drop_in_place(cell.as_mut_ptr()) };
            head = head.wrapping_add(1);
        }
    }
}

/// Producer handle for `StaticRingBuffer`.
pub struct Producer<'a, T, const CAP: usize> {
    ring: &'a StaticRingBuffer<T, CAP>,
}

// SAFETY: `Producer` is a thin `&StaticRingBuffer` wrapper; the
// underlying buffer is `Send` when `T: Send`.
unsafe impl<'a, T: Send, const CAP: usize> Send for Producer<'a, T, CAP> {}

impl<'a, T, const CAP: usize> Producer<'a, T, CAP> {
    /// Enqueue an item.
    #[inline(always)]
    pub fn push(&self, item: T) -> std::result::Result<(), T> {
        self.ring.push(item)
    }

    /// Check if full.
    #[inline(always)]
    pub fn is_full(&self) -> bool {
        self.ring.is_full()
    }

    /// Remaining slots.
    #[inline(always)]
    pub fn remaining(&self) -> usize {
        self.ring.remaining()
    }
}

/// Consumer handle for `StaticRingBuffer`.
pub struct Consumer<'a, T, const CAP: usize> {
    ring: &'a StaticRingBuffer<T, CAP>,
}

// SAFETY: same as `Producer`: `&StaticRingBuffer` is `Send` when
// `T: Send`.
unsafe impl<'a, T: Send, const CAP: usize> Send for Consumer<'a, T, CAP> {}

impl<'a, T, const CAP: usize> Consumer<'a, T, CAP> {
    /// Dequeue an item.
    #[inline(always)]
    pub fn pop(&self) -> Option<T> {
        self.ring.pop()
    }

    /// Check if empty.
    #[inline(always)]
    pub fn is_empty(&self) -> bool {
        self.ring.is_empty()
    }

    /// Current queue length.
    #[inline(always)]
    pub fn len(&self) -> usize {
        self.ring.len()
    }
}

// -------------------------------------------------------------------------------------------------
// Kani Formal Verification Proof Harness
// -------------------------------------------------------------------------------------------------
#[cfg(kani)]
mod kani_proofs {
    use super::*;

    /// Formally verify strict First-In First-Out (FIFO) ordering invariant.
    #[kani::proof]
    fn verify_ring_buffer_fifo() {
        let ring: StaticRingBuffer<u32, 4> = StaticRingBuffer::new();
        let val1: u32 = kani::any();
        let val2: u32 = kani::any();

        assert!(ring.push(val1).is_ok());
        assert!(ring.push(val2).is_ok());

        assert_eq!(ring.pop(), Some(val1));
        assert_eq!(ring.pop(), Some(val2));
        assert_eq!(ring.pop(), None);
    }

    /// Formally verify capacity bounds and overflow prevention.
    #[kani::proof]
    fn verify_ring_buffer_capacity_bounds() {
        let ring: StaticRingBuffer<u8, 2> = StaticRingBuffer::new();
        assert!(ring.is_empty());
        assert!(!ring.is_full());

        assert!(ring.push(1).is_ok());
        assert_eq!(ring.len(), 1);

        assert!(ring.push(2).is_ok());
        assert!(ring.is_full());
        assert_eq!(ring.len(), 2);

        // Third push must fail with error
        assert!(ring.push(3).is_err());

        assert_eq!(ring.pop(), Some(1));
        assert!(!ring.is_full());
        assert!(ring.push(3).is_ok());

        assert_eq!(ring.pop(), Some(2));
        assert_eq!(ring.pop(), Some(3));
        assert_eq!(ring.pop(), None);
        assert!(ring.is_empty());
    }

    /// Formally verify wrapping arithmetic safety near integer boundaries.
    #[kani::proof]
    fn verify_ring_buffer_wrapping_arithmetic() {
        let ring: StaticRingBuffer<u16, 2> = StaticRingBuffer::new();
        ring.head.store(usize::MAX - 1, Ordering::Relaxed);
        ring.tail.store(usize::MAX - 1, Ordering::Relaxed);

        let v: u16 = kani::any();
        assert!(ring.push(v).is_ok());
        assert_eq!(ring.pop(), Some(v));
        assert!(ring.is_empty());
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_ring_buffer_fifo_order() {
        let ring: StaticRingBuffer<i32, 4> = StaticRingBuffer::new();
        assert_eq!(ring.capacity(), 4);
        assert!(ring.is_empty());

        assert!(ring.push(10).is_ok());
        assert!(ring.push(20).is_ok());
        assert!(ring.push(30).is_ok());
        assert!(ring.push(40).is_ok());
        assert!(ring.is_full());
        assert!(ring.push(50).is_err());

        assert_eq!(ring.pop(), Some(10));
        assert_eq!(ring.pop(), Some(20));
        assert!(ring.push(50).is_ok());

        assert_eq!(ring.pop(), Some(30));
        assert_eq!(ring.pop(), Some(40));
        assert_eq!(ring.pop(), Some(50));
        assert_eq!(ring.pop(), None);
        assert!(ring.is_empty());
    }

    #[test]
    fn test_ring_buffer_split_handles() {
        let mut ring: StaticRingBuffer<String, 8> = StaticRingBuffer::new();
        let (producer, consumer) = ring.split();

        assert!(producer.push("frame1".to_string()).is_ok());
        assert!(producer.push("frame2".to_string()).is_ok());

        assert_eq!(consumer.pop(), Some("frame1".to_string()));
        assert_eq!(consumer.pop(), Some("frame2".to_string()));
        assert_eq!(consumer.pop(), None);
    }

    #[test]
    fn test_batch_operations() {
        let ring: StaticRingBuffer<u64, 16> = StaticRingBuffer::new();
        let count = ring.push_batch(0..10);
        assert_eq!(count, 10);
        assert_eq!(ring.len(), 10);

        let popped = ring.pop_batch(5);
        assert_eq!(popped, vec![0, 1, 2, 3, 4]);
        assert_eq!(ring.len(), 5);

        let popped_remaining = ring.pop_batch(10);
        assert_eq!(popped_remaining, vec![5, 6, 7, 8, 9]);
        assert!(ring.is_empty());
    }

    /// Multi-threaded SPSC stress test: one producer pushing 0..N, one
    /// consumer popping; verify strict FIFO ordering across the barrier.
    ///
    /// Skipped under Miri because the interpreter's overhead makes the
    /// 10k-iteration spin loop take minutes. The single-threaded tests
    /// already exercise the same `MaybeUninit` / atomic code paths.
    #[test]
    #[cfg_attr(miri, ignore)]
    fn test_ring_buffer_concurrent_spsc() {
        use std::hint::spin_loop;
        use std::sync::Arc;
        use std::thread;

        const N: u64 = 10_000;
        let ring: Arc<StaticRingBuffer<u64, 1024>> = Arc::new(StaticRingBuffer::new());

        let producer = {
            let ring = ring.clone();
            thread::spawn(move || {
                let mut i = 0u64;
                while i < N {
                    if ring.push(i).is_ok() {
                        i += 1;
                    } else {
                        spin_loop();
                    }
                }
            })
        };

        let consumer = {
            let ring = ring.clone();
            thread::spawn(move || {
                let mut received = Vec::with_capacity(N as usize);
                while received.len() < N as usize {
                    if let Some(v) = ring.pop() {
                        received.push(v);
                    } else {
                        spin_loop();
                    }
                }
                received
            })
        };

        producer.join().expect("producer thread panicked");
        let received = consumer.join().expect("consumer thread panicked");

        assert_eq!(received.len(), N as usize);
        for (i, v) in received.iter().enumerate() {
            assert_eq!(*v, i as u64, "FIFO violated at index {i}");
        }
    }

    /// Concurrent observer: a third thread hammering `len()` /
    /// `is_empty()` / `remaining()` while a producer/consumer pair
    /// races. The observer must never panic or trigger UB — but its
    /// `len()` result is **not** required to lie in `[0, CAP]`.
    ///
    /// As documented on `len()`, a third-party observer reads `head`
    /// and `tail` non-atomically and can see them from different points
    /// in time. Only the producer and the consumer have enough local
    /// state to interpret `(head, tail)` safely, and their use is
    /// covered by `test_ring_buffer_concurrent_spsc`.
    #[test]
    #[cfg_attr(miri, ignore)]
    fn test_ring_buffer_concurrent_observers() {
        use std::hint::spin_loop;
        use std::sync::atomic::{AtomicBool, Ordering};
        use std::sync::Arc;
        use std::thread;

        let ring: Arc<StaticRingBuffer<u32, 256>> = Arc::new(StaticRingBuffer::new());
        let started = Arc::new(AtomicBool::new(false));
        let done = Arc::new(AtomicBool::new(false));

        let observer = {
            let ring = ring.clone();
            let started = started.clone();
            let done = done.clone();
            thread::spawn(move || {
                // Signal *before* entering the loop: `spawn` only enqueues
                // the closure with the OS, so without this barrier the main
                // thread could finish its work and set `done = true` before
                // the observer thread is ever scheduled, leaving
                // `iterations == 0` and the assertion below flaky.
                started.store(true, Ordering::Release);

                let mut iterations: u64 = 0;
                while !done.load(Ordering::Acquire) {
                    // None of these calls may panic or produce UB,
                    // regardless of the value returned (a third-party
                    // observer is allowed to see `(head, tail)` from
                    // different points in time; see `len()` docs).
                    let _ = ring.len();
                    let _ = ring.is_empty();
                    let _ = ring.is_full();
                    let _ = ring.remaining();
                    iterations = iterations.wrapping_add(1);
                    spin_loop();
                }
                iterations
            })
        };

        // Wait until the observer thread has actually started running.
        while !started.load(Ordering::Acquire) {
            spin_loop();
        }

        // Producer / consumer pair — the only legitimate users of
        // `push` / `pop`. Drive 5 000 round-trips while the observer
        // races on `len()` / `is_*()` / `remaining()`.
        for i in 0..5_000u32 {
            while ring.push(i).is_err() {
                spin_loop();
            }
            while ring.pop().is_some() {}
        }

        done.store(true, Ordering::Release);
        let iters = observer.join().expect("observer thread panicked");
        assert!(
            iters > 0,
            "observer must have made progress; the `started` barrier \
             should make this deterministic",
        );
    }

    /// `push_batch` must stop at the first rejected element and report
    /// the count that actually fit, without losing the rejected item.
    #[test]
    fn test_push_batch_respects_capacity() {
        let ring: StaticRingBuffer<u32, 4> = StaticRingBuffer::new();
        // Try to push 10 items into a capacity-4 ring: only 4 fit.
        let pushed = ring.push_batch(0..10);
        assert_eq!(pushed, 4);
        assert!(ring.is_full());
        // Drain and verify FIFO.
        let drained = ring.pop_batch(4);
        assert_eq!(drained, vec![0, 1, 2, 3]);
        assert!(ring.is_empty());

        // Reusable after drain.
        let pushed = ring.push_batch(100..110);
        assert_eq!(pushed, 4);
        let drained = ring.pop_batch(10);
        assert_eq!(drained, vec![100, 101, 102, 103]);
    }

    /// `pop_batch` on an empty ring returns an empty `Vec` immediately,
    /// without spinning or panicking.
    #[test]
    fn test_pop_batch_on_empty_ring() {
        let ring: StaticRingBuffer<u32, 4> = StaticRingBuffer::new();
        let drained = ring.pop_batch(10);
        assert!(drained.is_empty());
    }

    /// `remaining() + len() == CAP` must hold whenever both are read
    /// from a single consistent snapshot. In the single-threaded case
    /// this is trivially true; the test guards against a future
    /// refactor of `remaining()` that breaks the invariant.
    #[test]
    fn test_remaining_plus_len_equals_capacity() {
        let ring: StaticRingBuffer<u32, 8> = StaticRingBuffer::new();
        assert_eq!(ring.remaining() + ring.len(), 8);

        ring.push(1).unwrap();
        ring.push(2).unwrap();
        assert_eq!(ring.remaining() + ring.len(), 8);

        ring.pop().unwrap();
        assert_eq!(ring.remaining() + ring.len(), 8);

        // Fill to capacity.
        for i in 0..7u32 {
            ring.push(100 + i).unwrap();
        }
        assert_eq!(ring.remaining() + ring.len(), 8);
        assert_eq!(ring.remaining(), 0);
    }

    #[test]
    fn test_ring_buffer_capacity_one() {
        let ring: StaticRingBuffer<u8, 1> = StaticRingBuffer::new();
        assert_eq!(ring.capacity(), 1);
        assert!(ring.is_empty());

        // Exactly one slot.
        assert!(ring.push(0xAB).is_ok());
        assert!(ring.is_full());
        assert!(ring.push(0xCD).is_err(), "second push must fail");

        assert_eq!(ring.pop(), Some(0xAB));
        assert!(ring.is_empty());
        assert_eq!(ring.pop(), None);

        // Reusable after drain.
        assert!(ring.push(0xEF).is_ok());
        assert_eq!(ring.pop(), Some(0xEF));
    }

    #[test]
    fn test_ring_buffer_capacity_two_full_empty_cycles() {
        let ring: StaticRingBuffer<u32, 2> = StaticRingBuffer::new();

        for cycle in 0..100u32 {
            assert!(ring.is_empty());
            assert!(ring.push(cycle).is_ok());
            assert!(ring.push(cycle + 1).is_ok());
            assert!(ring.is_full());
            assert!(ring.push(cycle + 2).is_err());

            assert_eq!(ring.pop(), Some(cycle));
            assert_eq!(ring.pop(), Some(cycle + 1));
            assert_eq!(ring.pop(), None);
        }
    }

    /// Property: any sequence of pushes and pops on a SPSC ring preserves
    /// FIFO order for the elements that were successfully pushed.
    #[cfg(test)]
    mod proptests {
        use super::*;
        use proptest::prelude::*;

        #[derive(Debug, Clone)]
        enum Op {
            Push(u32),
            Pop,
        }

        fn arb_op() -> impl Strategy<Value = Op> {
            prop_oneof![
                3 => any::<u32>().prop_map(Op::Push),
                1 => Just(Op::Pop),
            ]
        }

        proptest! {
            #![proptest_config(crate::test_support::proptest_config(512))]

            #[test]
            fn prop_spsc_preserves_fifo(
                ops in prop::collection::vec(arb_op(), 0..128),
            ) {
                let ring: StaticRingBuffer<u32, 8> = StaticRingBuffer::new();
                let mut pushed = std::collections::VecDeque::<u32>::new();

                for op in ops {
                    match op {
                        Op::Push(v) => {
                            match ring.push(v) {
                                Ok(()) => pushed.push_back(v),
                                Err(_) => {
                                    // Ring full: verify `len` matches.
                                    prop_assert_eq!(ring.len(), pushed.len());
                                }
                            }
                        }
                        Op::Pop => {
                            let expected = pushed.pop_front();
                            prop_assert_eq!(ring.pop(), expected);
                        }
                    }
                }

                // Drain; ordering must match.
                while let Some(expected) = pushed.pop_front() {
                    prop_assert_eq!(ring.pop(), Some(expected));
                }
                prop_assert_eq!(ring.pop(), None);
            }
        }
    }
}
