//! Minimal SOCKS5 proxy demonstrating `caly-transducer` on real sockets.
//!
//! This is a **reference implementation**, not the production daemon. It
//! exists to prove that the protocol parsing layer (`caly-transducer`)
//! composes correctly with real `std::net` sockets, with **no** io_uring,
//! AF_XDP, or eBPF in the loop.
//!
//! # Usage
//!
//! ```text
//! cargo run --release --example socks5_minimal -p caly-transducer -- \
//!     --listen 127.0.0.1:1080
//! ```
//!
//! Then, from another shell:
//!
//! ```text
//! curl --socks5-hostname 127.0.0.1:1080 http://example.com/
//! ```
//!
//! # Design notes
//!
//! * One OS thread per connection. This matches the "thread-per-connection"
//!   baseline that every production proxy starts from, and keeps the code
//!   short enough to audit.
//! * The SOCKS5 success reply for `CONNECT` is sent **after** the upstream
//!   socket is established, so a failed dial returns the correct RFC 1928
//!   status code (`0x05` = connection refused) instead of a bogus success.
//! * Bidirectional relay uses two `io::copy` threads and propagates
//!   `shutdown(Write)` on EOF, avoiding the classic half-close deadlock.

use std::io::{self, Read, Write};
use std::net::{Shutdown, TcpListener, TcpStream};
use std::os::unix::io::AsRawFd;
use std::sync::atomic::{AtomicBool, AtomicU64, Ordering};
use std::thread;

/// Worker thread stack. The default 2 MiB is cloned on every
/// `thread::spawn`; for a connection handler that only touches a few
/// KiB, 64 KiB keeps the spawn cost low.
const WORKER_STACK_BYTES: usize = 64 * 1024;

use caly_transducer::{ProtocolTransducer, TransducerOutput};

/// Read buffer size for the handshake loop. Relay-phase I/O uses `io::copy`
/// with its own internal buffer, so this only affects handshake latency.
const BUF_SIZE: usize = 16 * 1024;

/// SOCKS5 reply status codes (RFC 1928 §6) used when the upstream dial fails.
const SOCKS5_REP_GENERAL_FAILURE: u8 = 0x01;
const SOCKS5_REP_CONN_REFUSED: u8 = 0x05;

static CONN_ID: AtomicU64 = AtomicU64::new(1);

/// Set to `true` by `--quiet`. Under sustained load the four `eprintln!`
/// calls per connection (`client`, `dialing`, `established`, `relay
/// closed`) serialize every worker on the global `stderr` lock and can
/// become the dominant cost. `--quiet` turns them off.
static QUIET: AtomicBool = AtomicBool::new(false);

/// Log a per-connection message unless `--quiet` is set.
macro_rules! log_conn {
    ($($arg:tt)*) => {
        if !QUIET.load(Ordering::Relaxed) {
            eprintln!($($arg)*);
        }
    };
}

fn main() -> io::Result<()> {
    let mut listen = String::from("127.0.0.1:1080");
    let mut backlog: i32 = 8192;

    let args: Vec<String> = std::env::args().collect();
    let mut i = 1;
    while i < args.len() {
        match args[i].as_str() {
            "--listen" | "-l" if i + 1 < args.len() => {
                listen = args[i + 1].clone();
                i += 2;
            }
            "--backlog" if i + 1 < args.len() => {
                backlog = args[i + 1]
                    .parse()
                    .map_err(|e| io::Error::new(io::ErrorKind::InvalidInput, format!("bad --backlog: {e}")))?;
                i += 2;
            }
            "--quiet" | "-q" => {
                QUIET.store(true, Ordering::Relaxed);
                i += 1;
            }
            "--help" | "-h" => {
                eprintln!("usage: socks5_minimal [--listen <addr:port>] [--backlog <N>] [--quiet]");
                eprintln!("       default: 127.0.0.1:1080");
                return Ok(());
            }
            other => {
                eprintln!("[socks5] unknown argument: {other}");
                std::process::exit(2);
            }
        }
    }

    let listener = TcpListener::bind(&listen)?;
    // Override the std-imposed backlog of 128. The default is the
    // binding constraint when accept + spawn cannot keep up with the
    // connect rate (SYN queue overflows and clients see a 1 s TCP
    // retransmit that dominates the p99 tail).
    unsafe {
        libc::listen(listener.as_raw_fd(), backlog);
    }
    eprintln!("[socks5] listening on {listen} (backlog={backlog})");
    eprintln!("[socks5] try: curl --socks5-hostname {listen} http://example.com/");

    for client in listener.incoming() {
        let client = match client {
            Ok(c) => c,
            Err(e) => {
                log_conn!("[socks5] accept error: {e}");
                continue;
            }
        };

        let id = CONN_ID.fetch_add(1, Ordering::Relaxed);
        thread::Builder::new()
            .stack_size(WORKER_STACK_BYTES)
            .spawn(move || {
                if let Err(e) = handle_client(id, client) {
                    log_conn!("[socks5] conn#{id}: {e}");
                }
            })
            .expect("spawn worker thread");
    }

    Ok(())
}

fn handle_client(id: u64, mut client: TcpStream) -> io::Result<()> {
    let peer = client
        .peer_addr()
        .map(|a| a.to_string())
        .unwrap_or_else(|_| "?".into());
    log_conn!("[socks5] conn#{id}: client {peer}");

    client.set_nodelay(true)?;

    let mut transducer = ProtocolTransducer::new();
    let mut buf = [0u8; BUF_SIZE];

    loop {
        let n = match client.read(&mut buf) {
            Ok(0) => {
                log_conn!("[socks5] conn#{id}: client closed during handshake");
                return Ok(());
            }
            Ok(n) => n,
            Err(e) => {
                log_conn!("[socks5] conn#{id}: read error: {e}");
                return Ok(());
            }
        };

        let out = match transducer.consume(&buf[..n]) {
            Ok(o) => o,
            Err(e) => {
                log_conn!("[socks5] conn#{id}: transducer error: {e}");
                return Ok(());
            }
        };

        match out {
            // ── Handshake in progress ────────────────────────────────────
            TransducerOutput::Continue => {
                if !transducer.is_established() {
                    // Greeting phase: the transducer has just emitted the
                    // method-selection reply (`[0x05, 0x00]`). Send it now.
                    if let Some(reply) = transducer.take_client_reply() {
                        client.write_all(&reply)?;
                        client.flush()?;
                    }
                    continue;
                }

                // CONNECT was accepted but no trailing payload arrived in
                // the same read. Dial upstream and relay.
                return connect_and_relay(id, client, &mut transducer, &[]);
            }

            // ── Handshake done, plus the client's first payload ─────────
            TransducerOutput::ProxyForward(payload) => {
                return connect_and_relay(id, client, &mut transducer, &payload);
            }

            // ── Unrecognised protocol: close ─────────────────────────────
            TransducerOutput::DirectForward => {
                log_conn!("[socks5] conn#{id}: unrecognised protocol, closing");
                return Ok(());
            }

            // ── Fatal ────────────────────────────────────────────────────
            TransducerOutput::Terminate => {
                log_conn!("[socks5] conn#{id}: transducer requested termination");
                return Ok(());
            }
        }
    }
}

/// Dial the target host from the transducer's decision, send the SOCKS5
/// success reply, forward any buffered payload, and enter the relay loop.
fn connect_and_relay(
    id: u64,
    mut client: TcpStream,
    transducer: &mut ProtocolTransducer,
    initial_payload: &[u8],
) -> io::Result<()> {
    let target = match transducer.target_address() {
        Some(t) => t.to_string(),
        None => {
            log_conn!("[socks5] conn#{id}: no target address, aborting");
            let _ = client.write_all(&socks5_reply(SOCKS5_REP_GENERAL_FAILURE));
            return Ok(());
        }
    };
    log_conn!("[socks5] conn#{id}: dialing upstream {target}");

    let mut upstream = match TcpStream::connect(&target) {
        Ok(u) => u,
        Err(e) => {
            log_conn!("[socks5] conn#{id}: connect to {target} failed: {e}");
            let _ = client.write_all(&socks5_reply(SOCKS5_REP_CONN_REFUSED));
            return Ok(());
        }
    };
    upstream.set_nodelay(true)?;
    log_conn!("[socks5] conn#{id}: upstream {target} established");

    // Successful dial — now (and only now) tell the client.
    if let Some(reply) = transducer.take_client_reply() {
        client.write_all(&reply)?;
    } else {
        // Fall back to a synthetic BND.ADDR=0.0.0.0 BND.PORT=0 success reply.
        client.write_all(&socks5_reply(0x00))?;
    }
    client.flush()?;

    // Forward whatever the client sent after the CONNECT request.
    if !initial_payload.is_empty() {
        upstream.write_all(initial_payload)?;
        upstream.flush()?;
    }

    relay_bidirectional(id, client, upstream)
}

/// Build a 10-byte SOCKS5 reply with an IPv4 `0.0.0.0:0` bound address.
fn socks5_reply(rep: u8) -> [u8; 10] {
    [0x05, rep, 0x00, 0x01, 0, 0, 0, 0, 0, 0]
}

fn relay_bidirectional(id: u64, client: TcpStream, upstream: TcpStream) -> io::Result<()> {
    let client_read = client.try_clone()?;
    let upstream_write = upstream.try_clone()?;

    // client → upstream on a worker thread.
    let c2u = thread::Builder::new()
        .stack_size(WORKER_STACK_BYTES)
        .spawn(move || {
            let mut c = client_read;
            let mut u = upstream_write;
            let n = io::copy(&mut c, &mut u).unwrap_or(0);
            // Propagate EOF as a half-close so the other direction can finish.
            let _ = u.shutdown(Shutdown::Write);
            n
        })
        .expect("spawn relay thread");

    // upstream → client on the current thread.
    let u2c_n = {
        let mut c = client;
        let mut u = upstream;
        let n = io::copy(&mut u, &mut c).unwrap_or(0);
        let _ = c.shutdown(Shutdown::Write);
        n
    };

    let c2u_n = c2u.join().unwrap_or(0);
    log_conn!("[socks5] conn#{id}: relay closed, c→u {c2u_n}B, u→c {u2c_n}B");
    Ok(())
}
