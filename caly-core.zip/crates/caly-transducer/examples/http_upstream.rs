//! Minimal multi-threaded HTTP/1.1 upstream for load testing.
//!
//! Replaces `python -m http.server` / `ThreadingHTTPServer` when
//! measuring `caly-transducer` end-to-end throughput: CPython
//! serializes every request handler behind the GIL, capping loopback
//! throughput at ~800 req/s regardless of thread count.
//!
//! Usage:
//!     cargo run --release --example http_upstream -p caly-transducer -- \
//!         --listen 127.0.0.1:18080 --backlog 8192

use std::io::{self, Read, Write};
use std::net::{TcpListener, TcpStream};
use std::os::unix::io::AsRawFd;
use std::sync::atomic::{AtomicU64, Ordering};
use std::thread;

const BODY: &[u8] = b"caly-real-traffic-ok\n";
const MAX_HEADER_BYTES: usize = 16 * 1024;
/// Worker thread stack. 2 MiB (Rust default) is cloned on every
/// `thread::spawn`; for a request handler that touches at most a few KiB
/// of stack, 64 KiB is plenty and much cheaper to clone.
const WORKER_STACK_BYTES: usize = 64 * 1024;

static CONN_ID: AtomicU64 = AtomicU64::new(1);

fn main() -> io::Result<()> {
    let mut listen = String::from("127.0.0.1:18080");
    let mut backlog: i32 = 8192;

    let args: Vec<String> = std::env::args().collect();
    let mut i = 1;
    while i < args.len() {
        match args[i].as_str() {
            "--listen" | "-l" if i + 1 < args.len() => {
                listen = args[i + 1].clone();
                i += 2;
            }
            "--backlog" if i + 1 < args.len() => {
                backlog = args[i + 1]
                    .parse()
                    .map_err(|e| io::Error::new(io::ErrorKind::InvalidInput, format!("bad --backlog: {e}")))?;
                i += 2;
            }
            "--help" | "-h" => {
                eprintln!("usage: http_upstream [--listen <addr:port>] [--backlog <N>]");
                return Ok(());
            }
            other => {
                eprintln!("[upstream] unknown argument: {other}");
                std::process::exit(2);
            }
        }
    }

    let listener = TcpListener::bind(&listen)?;
    // Override the std-imposed backlog of 128. `listen(2)` is idempotent
    // on Linux — calling it again updates the backlog.
    unsafe {
        libc::listen(listener.as_raw_fd(), backlog);
    }
    eprintln!("[upstream] listening on {listen} (backlog={backlog})");

    for client in listener.incoming() {
        let client = match client {
            Ok(c) => c,
            Err(e) => {
                eprintln!("[upstream] accept error: {e}");
                continue;
            }
        };
        let id = CONN_ID.fetch_add(1, Ordering::Relaxed);
        thread::Builder::new()
            .stack_size(WORKER_STACK_BYTES)
            .spawn(move || {
                if let Err(e) = handle(id, client) {
                    if e.kind() != io::ErrorKind::ConnectionReset
                        && e.kind() != io::ErrorKind::BrokenPipe
                        && e.kind() != io::ErrorKind::UnexpectedEof
                    {
                        eprintln!("[upstream] conn#{id}: {e}");
                    }
                }
            })
            .expect("spawn worker thread");
    }
    Ok(())
}

fn handle(_id: u64, mut s: TcpStream) -> io::Result<()> {
    s.set_nodelay(true)?;
    // `buf` must be sized to `MAX_HEADER_BYTES`, not 4 KiB: `head_len`
    // accumulates across reads within one request, and `buf[head_len..]`
    // would panic once `head_len` exceeded the array size.
    let mut buf = [0u8; MAX_HEADER_BYTES];

    loop {
        let mut head_len = 0usize;
        let head_end = loop {
            let n = s.read(&mut buf[head_len..])?;
            if n == 0 {
                return Ok(()); // peer closed
            }
            head_len += n;
            if let Some(pos) = find_header_end(&buf[..head_len]) {
                break pos;
            }
            if head_len >= MAX_HEADER_BYTES {
                return Ok(()); // defensive: refuse oversized heads
            }
        };

        let close_requested = contains_ascii_ci(&buf[..head_end], b"connection: close");

        let response = format!(
            "HTTP/1.1 200 OK\r\n\
             Content-Type: text/plain\r\n\
             Content-Length: {}\r\n\
             Connection: {}\r\n\
             \r\n",
            BODY.len(),
            if close_requested { "close" } else { "keep-alive" }
        );
        s.write_all(response.as_bytes())?;
        s.write_all(BODY)?;
        s.flush()?;

        if close_requested {
            return Ok(());
        }
    }
}

fn find_header_end(buf: &[u8]) -> Option<usize> {
    let n = buf.len();
    let mut i = 0;
    while i < n {
        if i + 4 <= n && &buf[i..i + 4] == b"\r\n\r\n" {
            return Some(i + 4);
        }
        if i + 2 <= n && &buf[i..i + 2] == b"\n\n" {
            return Some(i + 2);
        }
        i += 1;
    }
    None
}

fn contains_ascii_ci(haystack: &[u8], needle: &[u8]) -> bool {
    if needle.is_empty() || haystack.len() < needle.len() {
        return false;
    }
    haystack.windows(needle.len()).any(|w| {
        w.iter()
            .zip(needle.iter())
            .all(|(a, b)| a.to_ascii_lowercase() == b.to_ascii_lowercase())
    })
}
