//! In-process protocol parsing throughput benchmark.
//!
//! **CPU-only**: no sockets, no syscalls, no kernel. Measures exactly
//! what the data plane does per new flow — parse a SOCKS5 greeting +
//! CONNECT, or an HTTP CONNECT request.
//!
//! End-to-end benchmarks that go through `socks5_minimal` measure that
//! *example* (thread-per-connection, blocking IO, ~15 syscalls per
//! request), not the parsing layer. This benchmark is the honest
//! answer to "how fast is `caly-transducer`?".
//!
//! Run:
//!     cargo bench -p caly-transducer --bench protocol_parse

use caly_transducer::{
    parse_client_greeting, parse_client_request, parse_connect_request,
    ProtocolTransducer, TransducerOutput,
};
use criterion::{
    black_box, criterion_group, criterion_main, BenchmarkId, Criterion,
    Throughput,
};

fn bench_socks5_handshake(c: &mut Criterion) {
    let greeting: [u8; 3] = [0x05, 0x01, 0x00];
    let connect: [u8; 10] = [0x05, 0x01, 0x00, 0x01, 127, 0, 0, 1, 0x1F, 0x90];

    let mut group = c.benchmark_group("protocol_parse/socks5");
    group.throughput(Throughput::Elements(1));

    // Pure parser: greeting + request as standalone calls.
    group.bench_function("parsers_only", |b| {
        b.iter(|| {
            let (_, g) = parse_client_greeting(black_box(&greeting)).unwrap();
            assert!(g.supports_no_auth());
            let (_, r) = parse_client_request(black_box(&connect)).unwrap();
            assert_eq!(r.target.port, 8080);
        })
    });

    // Stateful transducer: full handshake through `ProtocolTransducer`.
    group.bench_function("full_transducer", |b| {
        b.iter(|| {
            let mut pt = ProtocolTransducer::new();
            let out1 = pt.consume(black_box(&greeting)).unwrap();
            assert!(matches!(out1, TransducerOutput::Continue));
            let _ = pt.take_client_reply();
            let out2 = pt.consume(black_box(&connect)).unwrap();
            assert!(matches!(out2, TransducerOutput::Continue));
            let _ = pt.take_client_reply();
            assert!(pt.is_established());
        })
    });

    group.finish();
}

fn bench_http_connect(c: &mut Criterion) {
    let req = b"CONNECT example.com:443 HTTP/1.1\r\nHost: example.com:443\r\n\r\n";

    let mut group = c.benchmark_group("protocol_parse/http_connect");
    group.throughput(Throughput::Bytes(req.len() as u64));

    group.bench_function("parser_only", |b| {
        b.iter(|| {
            let (_, r) = parse_connect_request(black_box(req)).unwrap();
            assert_eq!(r.port, 443);
        })
    });

    group.bench_function("full_transducer", |b| {
        b.iter(|| {
            let mut pt = ProtocolTransducer::new();
            let out = pt.consume(black_box(req)).unwrap();
            assert!(matches!(out, TransducerOutput::Continue));
            let _ = pt.take_client_reply();
            assert!(pt.is_established());
        })
    });

    group.finish();
}

fn bench_greeting_throughput(c: &mut Criterion) {
    // Sweep buffer sizes at the parser level to surface cache effects.
    let mut group = c.benchmark_group("protocol_parse/greeting_sweep");

    for &sz in &[10usize, 64, 256, 1024, 4096] {
        let mut buf = vec![0u8; sz];
        if sz >= 3 {
            buf[0] = 0x05;
            buf[1] = 0x01;
            buf[2] = 0x00;
        }
        group.throughput(Throughput::Bytes(sz as u64));
        group.bench_with_input(BenchmarkId::from_parameter(sz), &buf, |b, buf| {
            b.iter(|| {
                let _ = parse_client_greeting(black_box(&buf[..]));
            })
        });
    }
    group.finish();
}

criterion_group!(
    benches,
    bench_socks5_handshake,
    bench_http_connect,
    bench_greeting_throughput,
);
criterion_main!(benches);
