//! Sans-I/O HTTP CONNECT proxy parser with zero heap allocation.
//!
//! Compliant with RFC 9110 (HTTP Semantics, Section 9.3.6: CONNECT).

use core::str;
use thiserror::Error;

/// Maximum number of headers stored without heap allocation.
pub const MAX_HEADERS: usize = 32;

/// Standard HTTP 200 Connection Established response.
pub const HTTP_200_RESPONSE: &[u8] = b"HTTP/1.1 200 Connection Established\r\n\r\n";

/// HTTP 400 Bad Request response.
pub const HTTP_400_RESPONSE: &[u8] = b"HTTP/1.1 400 Bad Request\r\n\r\n";

/// HTTP 405 Method Not Allowed response.
pub const HTTP_405_RESPONSE: &[u8] = b"HTTP/1.1 405 Method Not Allowed\r\n\r\n";

/// HTTP 502 Bad Gateway response.
pub const HTTP_502_RESPONSE: &[u8] = b"HTTP/1.1 502 Bad Gateway\r\n\r\n";

/// Parsed HTTP header key-value pair borrowed directly from the input buffer.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct HttpHeader<'a> {
    pub name: &'a str,
    pub value: &'a str,
}

/// Zero-allocation representation of an HTTP CONNECT request.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct HttpConnectRequest<'a> {
    /// Target host name or IP address (e.g. "example.com", "1.2.3.4", or "2001:db8::1").
    pub host: &'a str,
    /// Destination port (defaults to 443 if omitted in request line).
    pub port: u16,
    /// HTTP protocol version string (e.g. "HTTP/1.1").
    pub http_version: &'a str,
    /// Complete target authority string from the request line (e.g. "example.com:443" or "[::1]:8080").
    pub raw_target: &'a str,
    headers: [Option<HttpHeader<'a>>; MAX_HEADERS],
    header_count: usize,
}

impl<'a> HttpConnectRequest<'a> {
    /// Returns a slice of the parsed HTTP headers.
    pub fn headers(&self) -> &[Option<HttpHeader<'a>>] {
        &self.headers[..self.header_count]
    }

    /// Finds a header value by case-insensitive name match.
    pub fn get_header(&self, name: &str) -> Option<&'a str> {
        for h in self.headers[..self.header_count].iter().flatten() {
            if h.name.eq_ignore_ascii_case(name) {
                return Some(h.value);
            }
        }
        None
    }

    /// Iterator over active parsed headers.
    pub fn iter_headers(&self) -> impl Iterator<Item = HttpHeader<'a>> + '_ {
        self.headers[..self.header_count]
            .iter()
            .filter_map(|&opt| opt)
    }

    /// Returns the number of parsed headers.
    #[inline]
    pub fn header_count(&self) -> usize {
        self.header_count
    }
}

/// Convenience constructors for HTTP CONNECT responses.
pub struct HttpConnectResponse;

impl HttpConnectResponse {
    /// Standard HTTP 200 Connection Established response bytes.
    #[inline]
    pub fn connection_established() -> &'static [u8] {
        HTTP_200_RESPONSE
    }

    /// Standard HTTP 400 Bad Request response bytes.
    #[inline]
    pub fn bad_request() -> &'static [u8] {
        HTTP_400_RESPONSE
    }

    /// Standard HTTP 405 Method Not Allowed response bytes.
    #[inline]
    pub fn method_not_allowed() -> &'static [u8] {
        HTTP_405_RESPONSE
    }

    /// Standard HTTP 502 Bad Gateway response bytes.
    #[inline]
    pub fn bad_gateway() -> &'static [u8] {
        HTTP_502_RESPONSE
    }
}

/// Errors occurring during HTTP CONNECT parsing.
#[derive(Debug, Error, PartialEq, Eq, Clone)]
pub enum HttpConnectError {
    /// Request is incomplete (missing CRLF CRLF header delimiter).
    #[error("Incomplete HTTP request: awaiting header delimiter")]
    Incomplete,

    /// Request contains invalid UTF-8 encoding.
    #[error("Invalid UTF-8 encoding in HTTP request")]
    InvalidEncoding,

    /// Request line is malformed.
    #[error("Malformed HTTP request line")]
    MalformedRequestLine,

    /// Method is not CONNECT.
    #[error("Unsupported HTTP method: expected CONNECT, got {0}")]
    InvalidMethod(String),

    /// Target host/port specification is invalid.
    #[error("Invalid target host/port specification: {0}")]
    InvalidTarget(String),

    /// Port number cannot be parsed.
    #[error("Invalid port number: {0}")]
    InvalidPort(String),

    /// Malformed header syntax.
    #[error("Malformed header: {0}")]
    MalformedHeader(String),
}

/// Parses an HTTP CONNECT proxy request from a byte slice with zero heap allocation.
///
/// Returns (consumed_bytes, HttpConnectRequest).
pub fn parse_connect_request(
    buf: &[u8],
) -> Result<(usize, HttpConnectRequest<'_>), HttpConnectError> {
    // 1. Locate the end of the HTTP headers (\r\n\r\n or \n\n).
    let (header_bytes_len, delimiter_len) = find_header_end(buf)?;
    let total_consumed = header_bytes_len + delimiter_len;

    let header_str =
        str::from_utf8(&buf[..header_bytes_len]).map_err(|_| HttpConnectError::InvalidEncoding)?;

    // 2. Parse the request line and headers.
    let mut lines = header_str.split('\n');
    let request_line = lines.next().ok_or(HttpConnectError::MalformedRequestLine)?;
    let request_line = request_line.trim_end_matches('\r').trim();

    let mut parts = request_line.split_ascii_whitespace();
    let method = parts.next().ok_or(HttpConnectError::MalformedRequestLine)?;
    let target = parts.next().ok_or(HttpConnectError::MalformedRequestLine)?;
    let version = parts.next().ok_or(HttpConnectError::MalformedRequestLine)?;

    if !method.eq_ignore_ascii_case("CONNECT") {
        return Err(HttpConnectError::InvalidMethod(method.into()));
    }

    // 3. Parse target into (host, port).
    let (host, port) = parse_authority(target)?;

    // 4. Parse headers without heap allocation.
    let mut headers = [None; MAX_HEADERS];
    let mut header_count = 0;

    for line in lines {
        let line = line.trim_end_matches('\r').trim();
        if line.is_empty() {
            continue;
        }

        if let Some(colon_idx) = line.find(':') {
            let name = line[..colon_idx].trim();
            let value = line[colon_idx + 1..].trim();
            if header_count < MAX_HEADERS {
                headers[header_count] = Some(HttpHeader { name, value });
                header_count += 1;
            }
        } else {
            return Err(HttpConnectError::MalformedHeader(line.into()));
        }
    }

    Ok((
        total_consumed,
        HttpConnectRequest {
            host,
            port,
            http_version: version,
            raw_target: target,
            headers,
            header_count,
        },
    ))
}

/// Locates the end of HTTP headers: either \r\n\r\n (4 bytes) or \n\n (2 bytes).
fn find_header_end(buf: &[u8]) -> Result<(usize, usize), HttpConnectError> {
    for i in 0..buf.len() {
        if buf[i..].starts_with(b"\r\n\r\n") {
            return Ok((i, 4));
        }
        if buf[i..].starts_with(b"\n\n") {
            return Ok((i, 2));
        }
    }
    Err(HttpConnectError::Incomplete)
}

/// Parses authority string host:port or [ipv6]:port.
fn parse_authority(target: &str) -> Result<(&str, u16), HttpConnectError> {
    let (host, port) = if target.starts_with('[') {
        let close_bracket = target
            .find(']')
            .ok_or_else(|| HttpConnectError::InvalidTarget(target.into()))?;
        let host = &target[1..close_bracket];
        let remainder = &target[close_bracket + 1..];

        if remainder.is_empty() {
            (host, 443)
        } else if let Some(port_str) = remainder.strip_prefix(':') {
            let port = port_str
                .parse::<u16>()
                .map_err(|e| HttpConnectError::InvalidPort(e.to_string()))?;
            (host, port)
        } else {
            return Err(HttpConnectError::InvalidTarget(target.into()));
        }
    } else if target.contains(':') {
        // Non-bracketed. RFC 9110 §4.2.1 requires IPv6 literals to be
        // wrapped in `[...]`; a target that carries more than one colon
        // (e.g. `2001:db8::1`) is a bare IPv6 address and must be
        // rejected outright. Splitting it on the final `:` would treat
        // the last hextet as a port number and silently dial the wrong
        // endpoint.
        if target.bytes().filter(|&b| b == b':').count() > 1 {
            return Err(HttpConnectError::InvalidTarget(target.into()));
        }
        let colon_idx = target
            .find(':')
            .expect("contains(':') guarantees at least one colon");
        let host = &target[..colon_idx];
        let port_str = &target[colon_idx + 1..];
        let port = port_str
            .parse::<u16>()
            .map_err(|e| HttpConnectError::InvalidPort(e.to_string()))?;
        (host, port)
    } else {
        (target, 443)
    };

    // RFC 9110 §4.2: the authority must contain a non-empty host component.
    // Accepting `:443` would let downstream code dial an unspecified address
    // (0.0.0.0 / ::/ whatever the OS chooses), which is not the intent of
    // HTTP CONNECT and is generally a sign of a malformed or malicious
    // request.
    if host.is_empty() {
        return Err(HttpConnectError::InvalidTarget(target.into()));
    }

    Ok((host, port))
}

#[cfg(test)]
mod tests {
    use super::*;

    /// Max header count is enforced, extra headers are silently dropped
    /// (this is intentional DoS hardening). We check the count is exactly
    /// `MAX_HEADERS` and no panic occurs on overflow.
    #[test]
    fn test_http_connect_max_headers_saturates_safely() {
        let mut raw = Vec::new();
        raw.extend_from_slice(b"CONNECT example.com:443 HTTP/1.1\r\n");
        for i in 0..(MAX_HEADERS + 32) {
            raw.extend_from_slice(format!("X-Filler-{i}: v\r\n").as_bytes());
        }
        raw.extend_from_slice(b"\r\n");

        let (_, req) = parse_connect_request(&raw).expect("parse");
        assert_eq!(
            req.header_count(),
            MAX_HEADERS,
            "extra headers must be silently dropped, not stored or panic",
        );
    }

    #[test]
    fn test_http_connect_rejects_empty_host() {
        // Bare port with empty host — malformed.
        let raw = b"CONNECT :443 HTTP/1.1\r\nHost: :443\r\n\r\n";
        assert!(matches!(
            parse_connect_request(raw),
            Err(HttpConnectError::InvalidTarget(_)),
        ));

        // IPv6 form with empty brackets.
        let raw6 = b"CONNECT []:443 HTTP/1.1\r\nHost: []:443\r\n\r\n";
        assert!(matches!(
            parse_connect_request(raw6),
            Err(HttpConnectError::InvalidTarget(_)),
        ));
    }

    /// Bare (un-bracketed) IPv6 targets must be rejected, not split on
    /// the final `:`. RFC 9110 §4.2.1 requires the `[..]` form; the
    /// naive `rfind(':')` used before this fix produced `host =
    /// "2001:db8:"`, `port = 1`, silently dialing the wrong endpoint.
    #[test]
    fn test_http_connect_rejects_bare_ipv6_target() {
        for target in [
            "CONNECT 2001:db8::1 HTTP/1.1\r\n\r\n",
            "CONNECT 2001:db8::1:443 HTTP/1.1\r\n\r\n",
            "CONNECT fe80::1 HTTP/1.1\r\n\r\n",
        ] {
            match parse_connect_request(target.as_bytes()) {
                Err(HttpConnectError::InvalidTarget(_)) => {}
                other => panic!(
                    "expected InvalidTarget for {target:?}, got {other:?}",
                ),
            }
        }

        // The bracketed form must continue to be accepted.
        let (_, req) =
            parse_connect_request(b"CONNECT [2001:db8::1]:443 HTTP/1.1\r\n\r\n")
                .expect("bracketed IPv6 must parse");
        assert_eq!(req.host, "2001:db8::1");
        assert_eq!(req.port, 443);

        // A single-colon `host:port` must still be split correctly.
        let (_, req) =
            parse_connect_request(b"CONNECT example.com:8443 HTTP/1.1\r\n\r\n")
                .expect("host:port must parse");
        assert_eq!(req.host, "example.com");
        assert_eq!(req.port, 8443);
    }

    #[test]
    fn test_http_connect_accepts_normal_authority() {
        // Sanity: normal host:port still works.
        let raw = b"CONNECT example.com:443 HTTP/1.1\r\n\r\n";
        let (_, req) = parse_connect_request(raw).expect("parse");
        assert_eq!(req.host, "example.com");
        assert_eq!(req.port, 443);

        // Default port for bare hostname.
        let raw = b"CONNECT example.com HTTP/1.1\r\n\r\n";
        let (_, req) = parse_connect_request(raw).expect("parse");
        assert_eq!(req.host, "example.com");
        assert_eq!(req.port, 443);
    }
}
