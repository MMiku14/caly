//! Sans-I/O QUIC Initial Packet detector, header parser, and CRYPTO SNI extractor.
//!
//! Compliant with RFC 9000 (QUIC Transport) and RFC 9001 (Using TLS for QUIC).

use crate::tls_sniffer::{self, TlsSniffError};
use thiserror::Error;

/// Long Packet Type mask and value for Initial Packet.
pub const QUIC_LONG_PACKET_TYPE_INITIAL: u8 = 0x00;

/// Frame type for CRYPTO frame (RFC 9000 Section 19.6).
pub const QUIC_FRAME_TYPE_CRYPTO: u8 = 0x06;

/// Frame type for PADDING frame.
pub const QUIC_FRAME_TYPE_PADDING: u8 = 0x00;

/// Parsed QUIC Initial Packet Header.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct QuicInitialHeader<'a> {
    /// QUIC Version (e.g. 0x00000001 for QUIC v1, or 0x6b3343cf for QUIC v2).
    pub version: u32,
    /// Destination Connection ID (DCID).
    pub dcid: &'a [u8],
    /// Source Connection ID (SCID).
    pub scid: &'a [u8],
    /// Token associated with the Initial packet.
    pub token: &'a [u8],
    /// Packet payload slice starting after the Length varint.
    pub payload: &'a [u8],
}

/// Parsed QUIC CRYPTO frame.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct QuicCryptoFrame<'a> {
    /// Stream offset of the crypto data.
    pub offset: u64,
    /// Raw crypto data (contains TLS 1.3 handshake bytes).
    pub data: &'a [u8],
}

/// Errors occurring during QUIC parsing and SNI sniffing.
#[derive(Debug, Error, PartialEq, Eq, Clone)]
pub enum QuicSniffError {
    /// Packet is incomplete; more bytes needed.
    #[error("Incomplete QUIC packet: need {needed} additional bytes")]
    Incomplete { needed: usize },

    /// Not a QUIC Long Header packet (header form bit 7 is not set).
    #[error("Not a QUIC Long Header packet (first byte: {0:#04x})")]
    NotLongHeader(u8),

    /// Fixed bit (bit 6) is not 1.
    #[error("QUIC fixed bit is not set (first byte: {0:#04x})")]
    FixedBitNotSet(u8),

    /// Packet type is not Initial.
    #[error("Not a QUIC Initial packet (type: {0:#04x})")]
    NotInitialPacket(u8),

    /// Packet is a Version Negotiation packet (version is 0).
    #[error("Version Negotiation packet encountered")]
    VersionNegotiation,

    /// DCID or SCID length exceeds RFC 9000 maximum (20 bytes for version 1).
    #[error("Connection ID length {0} exceeds maximum allowed")]
    InvalidConnectionIdLength(usize),

    /// Variable-length integer overflow (> 62-bit).
    #[error("Varint overflow: value {0} exceeds 62 bits")]
    VarintOverflow(u64),

    /// Buffer provided is too small for serialization.
    #[error("Buffer too small for varint encoding")]
    BufferTooSmall,

    /// No CRYPTO frame found within payload.
    #[error("No CRYPTO frame found in QUIC Initial payload")]
    NoCryptoFrame,

    /// Invalid or unsupported frame type encountered.
    #[error("Invalid frame type: {0:#04x}")]
    InvalidFrameType(u8),

    /// Underlying TLS sniffing failed.
    #[error("TLS ClientHello sniffing failed: {0}")]
    TlsSniffFailed(String),
}

/// Parses a variable-length integer according to RFC 9000 Section 16.
///
/// Returns (consumed_bytes, decoded_value).
pub fn parse_varint(buf: &[u8]) -> Result<(usize, u64), QuicSniffError> {
    if buf.is_empty() {
        return Err(QuicSniffError::Incomplete { needed: 1 });
    }

    let first = buf[0];
    let len = 1 << ((first & 0xC0) >> 6);

    if buf.len() < len {
        return Err(QuicSniffError::Incomplete {
            needed: len - buf.len(),
        });
    }

    let mut val = (first & 0x3F) as u64;
    for &b in &buf[1..len] {
        val = (val << 8) | (b as u64);
    }

    Ok((len, val))
}

/// Encodes a 62-bit integer into QUIC variable-length format into the given output slice.
///
/// Returns the number of bytes written (1, 2, 4, or 8).
pub fn encode_varint(val: u64, out: &mut [u8]) -> Result<usize, QuicSniffError> {
    if val < (1 << 6) {
        if out.is_empty() {
            return Err(QuicSniffError::BufferTooSmall);
        }
        out[0] = val as u8;
        Ok(1)
    } else if val < (1 << 14) {
        if out.len() < 2 {
            return Err(QuicSniffError::BufferTooSmall);
        }
        out[0] = 0x40 | ((val >> 8) as u8);
        out[1] = val as u8;
        Ok(2)
    } else if val < (1 << 30) {
        if out.len() < 4 {
            return Err(QuicSniffError::BufferTooSmall);
        }
        out[0] = 0x80 | ((val >> 24) as u8);
        out[1] = (val >> 16) as u8;
        out[2] = (val >> 8) as u8;
        out[3] = val as u8;
        Ok(4)
    } else if val < (1 << 62) {
        if out.len() < 8 {
            return Err(QuicSniffError::BufferTooSmall);
        }
        out[0] = 0xC0 | ((val >> 56) as u8);
        out[1] = (val >> 48) as u8;
        out[2] = (val >> 40) as u8;
        out[3] = (val >> 32) as u8;
        out[4] = (val >> 24) as u8;
        out[5] = (val >> 16) as u8;
        out[6] = (val >> 8) as u8;
        out[7] = val as u8;
        Ok(8)
    } else {
        Err(QuicSniffError::VarintOverflow(val))
    }
}

/// Parses a QUIC Initial Packet header without heap allocation.
///
/// Validates:
/// - Header form bit (bit 7 == 1)
/// - Fixed bit (bit 6 == 1)
/// - Packet Type == Initial (0x00)
/// - Non-zero version
/// - DCID and SCID lengths
pub fn parse_quic_initial_header(buf: &[u8]) -> Result<QuicInitialHeader<'_>, QuicSniffError> {
    if buf.len() < 7 {
        return Err(QuicSniffError::Incomplete {
            needed: 7 - buf.len(),
        });
    }

    let first = buf[0];

    // Check Header Form: bit 7 must be 1 for Long Header
    if (first & 0x80) == 0 {
        return Err(QuicSniffError::NotLongHeader(first));
    }

    // Check Fixed Bit: bit 6 must be 1
    if (first & 0x40) == 0 {
        return Err(QuicSniffError::FixedBitNotSet(first));
    }

    // Check Long Packet Type: bits 4-5 must be 0x00 for Initial
    let packet_type = (first & 0x30) >> 4;
    if packet_type != QUIC_LONG_PACKET_TYPE_INITIAL {
        return Err(QuicSniffError::NotInitialPacket(packet_type));
    }

    let version = u32::from_be_bytes([buf[1], buf[2], buf[3], buf[4]]);
    if version == 0 {
        return Err(QuicSniffError::VersionNegotiation);
    }

    let dcid_len = buf[5] as usize;
    if dcid_len > 20 {
        return Err(QuicSniffError::InvalidConnectionIdLength(dcid_len));
    }

    let scid_len_offset = 6 + dcid_len;
    if buf.len() <= scid_len_offset {
        return Err(QuicSniffError::Incomplete {
            needed: scid_len_offset + 1 - buf.len(),
        });
    }

    let dcid = &buf[6..scid_len_offset];
    let scid_len = buf[scid_len_offset] as usize;
    if scid_len > 20 {
        return Err(QuicSniffError::InvalidConnectionIdLength(scid_len));
    }

    let mut cursor = scid_len_offset + 1 + scid_len;
    if buf.len() < cursor {
        return Err(QuicSniffError::Incomplete {
            needed: cursor - buf.len(),
        });
    }
    let scid = &buf[scid_len_offset + 1..cursor];

    // Initial packet specifics: Token Length (varint) + Token
    let (tlen_varint, token_len) = parse_varint(&buf[cursor..])?;
    cursor += tlen_varint;

    // Use u64 arithmetic for the bound check: `token_len` is a 62-bit
    // varint and `cursor + (token_len as usize)` can wrap on 32-bit
    // targets, silently bypassing the check.
    let token_end_u64 = (cursor as u64)
        .checked_add(token_len)
        .ok_or(QuicSniffError::VarintOverflow(token_len))?;
    if token_end_u64 > buf.len() as u64 {
        let needed = (token_end_u64 - buf.len() as u64) as usize;
        return Err(QuicSniffError::Incomplete { needed });
    }
    let token_end = token_end_u64 as usize;
    let token = &buf[cursor..token_end];
    cursor = token_end;

    // Length field (specifies remaining packet length: packet number + payload)
    let (plen_varint, payload_len) = parse_varint(&buf[cursor..])?;
    cursor += plen_varint;

    // Compute the end offset in u64 so a 62-bit varint Length cannot
    // truncate on 32-bit targets and silently bypass the bounds check.
    // `cursor` is always <= buf.len() so it fits in u64 without loss.
    let end_u64 = (cursor as u64)
        .checked_add(payload_len)
        .ok_or(QuicSniffError::VarintOverflow(payload_len))?;
    if end_u64 > buf.len() as u64 {
        let needed = (end_u64 - buf.len() as u64) as usize;
        return Err(QuicSniffError::Incomplete { needed });
    }
    let payload_end = end_u64 as usize;
    let payload = &buf[cursor..payload_end];

    Ok(QuicInitialHeader {
        version,
        dcid,
        scid,
        token,
        payload,
    })
}

/// Parses a QUIC CRYPTO frame (type 0x06) from a byte slice without heap allocation.
pub fn parse_crypto_frame(buf: &[u8]) -> Result<(usize, QuicCryptoFrame<'_>), QuicSniffError> {
    if buf.is_empty() {
        return Err(QuicSniffError::Incomplete { needed: 1 });
    }

    if buf[0] != QUIC_FRAME_TYPE_CRYPTO {
        return Err(QuicSniffError::InvalidFrameType(buf[0]));
    }

    let mut cursor = 1;
    let (olen, offset) = parse_varint(&buf[cursor..])?;
    cursor += olen;

    let (dlen_varint, data_len) = parse_varint(&buf[cursor..])?;
    cursor += dlen_varint;

    // Bound the length arithmetic in u64 so a 62-bit `data_len` cannot
    // truncate on 32-bit targets and silently bypass the check below.
    let data_end_u64 = (cursor as u64)
        .checked_add(data_len)
        .ok_or(QuicSniffError::VarintOverflow(data_len))?;
    if data_end_u64 > buf.len() as u64 {
        let needed = (data_end_u64 - buf.len() as u64) as usize;
        return Err(QuicSniffError::Incomplete { needed });
    }
    let data_end = data_end_u64 as usize;

    let data = &buf[cursor..data_end];
    Ok((data_end, QuicCryptoFrame { offset, data }))
}

/// Scans a QUIC payload for a CRYPTO frame or direct TLS ClientHello, skipping PADDING frames.
pub fn find_crypto_frame(payload: &[u8]) -> Result<QuicCryptoFrame<'_>, QuicSniffError> {
    let mut cursor = 0;
    while cursor < payload.len() {
        if payload[cursor] == QUIC_FRAME_TYPE_PADDING {
            cursor += 1;
            continue;
        }

        if payload[cursor] == QUIC_FRAME_TYPE_CRYPTO {
            let (_, frame) = parse_crypto_frame(&payload[cursor..])?;
            return Ok(frame);
        }

        // Direct TLS ClientHello handshake message
        if payload[cursor] == 0x01 && cursor + 4 <= payload.len() {
            return Ok(QuicCryptoFrame {
                offset: 0,
                data: &payload[cursor..],
            });
        }

        cursor += 1;
    }

    Err(QuicSniffError::NoCryptoFrame)
}

/// Extracts the Server Name Indication (SNI) from raw QUIC crypto data.
pub fn extract_quic_sni(crypto_data: &[u8]) -> Result<Option<&str>, QuicSniffError> {
    tls_sniffer::parse_client_hello(crypto_data)
        .map(|info| info.sni)
        .map_err(|e| match e {
            TlsSniffError::Incomplete { needed } => QuicSniffError::Incomplete { needed },
            other => QuicSniffError::TlsSniffFailed(other.to_string()),
        })
}

/// High-level sans-I/O sniffer: inspects a QUIC Initial packet, locates CRYPTO frame, and extracts SNI.
pub fn sniff_quic_initial_sni(packet: &[u8]) -> Result<Option<&str>, QuicSniffError> {
    let header = parse_quic_initial_header(packet)?;
    let crypto = find_crypto_frame(header.payload)?;
    extract_quic_sni(crypto.data)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_quic_varint_size_class_boundaries() {
        let cases: &[(u64, usize)] = &[
            (0, 1),
            (63, 1),
            (64, 2),
            (16383, 2),
            (16384, 4),
            ((1 << 30) - 1, 4),
            (1 << 30, 8),
            ((1 << 62) - 1, 8),
        ];

        let mut buf = [0u8; 8];
        for &(val, expected_len) in cases {
            let encoded = encode_varint(val, &mut buf).expect("encode");
            assert_eq!(encoded, expected_len, "encode len for {val}");

            let (decoded_len, decoded_val) = parse_varint(&buf[..encoded]).expect("decode");
            assert_eq!(decoded_len, expected_len, "decode len for {val}");
            assert_eq!(decoded_val, val, "roundtrip value for {val}");
        }
    }

    #[test]
    fn test_quic_varint_overflow_rejected() {
        let mut buf = [0u8; 8];
        assert!(encode_varint(1u64 << 62, &mut buf).is_err());
        assert!(encode_varint(u64::MAX, &mut buf).is_err());
    }

    #[test]
    fn test_quic_varint_truncated_input_incomplete() {
        // First byte declares an 8-byte varint, but only 4 bytes are available.
        let partial = [0xC0, 0x00, 0x00, 0x00];
        assert!(matches!(
            parse_varint(&partial),
            Err(QuicSniffError::Incomplete { needed: 4 })
        ));
    }

    #[test]
    fn test_quic_header_max_cid_lengths() {
        // DCID = 20 bytes (RFC 9000 max), SCID = 20 bytes.
        let dcid = [0xAA; 20];
        let scid = [0xBB; 20];
        let mut packet = Vec::new();
        packet.push(0xC0); // Initial, long header
        packet.extend_from_slice(&1u32.to_be_bytes()); // version 1
        packet.push(dcid.len() as u8);
        packet.extend_from_slice(&dcid);
        packet.push(scid.len() as u8);
        packet.extend_from_slice(&scid);
        packet.push(0x00); // token length = 0 (varint)
        packet.push(0x00); // payload length = 0 (varint)
        let header = parse_quic_initial_header(&packet).expect("parse max CID");
        assert_eq!(header.dcid.len(), 20);
        assert_eq!(header.scid.len(), 20);

        // DCID = 21 → rejected.
        let mut bad = packet.clone();
        bad[5] = 21;
        assert!(matches!(
            parse_quic_initial_header(&bad),
            Err(QuicSniffError::InvalidConnectionIdLength(21)),
        ));

        // SCID = 21 → rejected.
        let mut bad2 = packet.clone();
        // SCID length byte is at 5 + 1 + dcid.len() = 26.
        bad2[26] = 21;
        assert!(matches!(
            parse_quic_initial_header(&bad2),
            Err(QuicSniffError::InvalidConnectionIdLength(21)),
        ));
    }

    #[test]
    fn test_quic_header_zero_length_cids_allowed() {
        let mut packet = Vec::new();
        packet.push(0xC0);
        packet.extend_from_slice(&1u32.to_be_bytes());
        packet.push(0x00); // DCID length 0
        packet.push(0x00); // SCID length 0
        packet.push(0x00); // token length
        packet.push(0x00); // payload length
        let header = parse_quic_initial_header(&packet).expect("parse zero CID");
        assert!(header.dcid.is_empty());
        assert!(header.scid.is_empty());
    }

    /// The Length field inside a QUIC Initial header declares the total
    /// remaining bytes; if it exceeds the actual datagram length, parsing
    /// must return `Incomplete`, never silently truncate.
    #[test]
    fn test_quic_initial_header_rejects_short_payload() {
        let dcid = [0x01, 0x02, 0x03, 0x04];
        let scid = [0xAA, 0xBB];
        let mut packet = Vec::new();
        packet.push(0xC0); // Initial, long header
        packet.extend_from_slice(&1u32.to_be_bytes()); // version 1
        packet.push(dcid.len() as u8);
        packet.extend_from_slice(&dcid);
        packet.push(scid.len() as u8);
        packet.extend_from_slice(&scid);
        packet.push(0x00); // token length = 0
                           // Declare payload_len = 100 but provide only 10.
        packet.push(0x40);
        packet.push(100); // varint(100) = 2-byte form
        packet.extend_from_slice(&[0u8; 10]); // only 10 bytes of body

        match parse_quic_initial_header(&packet) {
            Err(QuicSniffError::Incomplete { needed }) => {
                assert_eq!(needed, 90, "expected shortfall of 90 bytes");
            }
            other => panic!("expected Incomplete, got {other:?}"),
        }
    }

    /// A QUIC Initial with a huge declared Length must be rejected via
    /// `Incomplete`, not silently truncated; the check uses u64 arithmetic
    /// so it also holds on 32-bit targets.
    #[test]
    fn test_quic_initial_huge_length_rejected() {
        let dcid = [0x01u8; 8];
        let scid = [0xAAu8; 4];
        let mut packet = Vec::new();
        packet.push(0xC0);
        packet.extend_from_slice(&1u32.to_be_bytes());
        packet.push(dcid.len() as u8);
        packet.extend_from_slice(&dcid);
        packet.push(scid.len() as u8);
        packet.extend_from_slice(&scid);
        packet.push(0x00); // token length = 0

        // Length = 2^30 - 1 (largest 4-byte varint). See RFC 9000 §16.
        // varint encoding: 0x80 | (value >> 24), then 3 bytes.
        let declared: u32 = (1 << 30) - 1;
        packet.push(0x80 | ((declared >> 24) as u8));
        packet.push((declared >> 16) as u8);
        packet.push((declared >> 8) as u8);
        packet.push(declared as u8);
        // Only 4 bytes of actual body, far short of 2^30-1.

        match parse_quic_initial_header(&packet) {
            Err(QuicSniffError::Incomplete { needed }) => {
                assert!(
                    needed >= (declared as usize) - 8,
                    "shortfall too small: {needed}",
                );
            }
            other => panic!("expected Incomplete, got {other:?}"),
        }
    }
    /// `find_crypto_frame` must not panic on arbitrary payloads — even
    /// those that contain a spurious 0x06 byte inside another frame's body
    /// — and must eventually find a valid CRYPTO frame or return Err.
    #[test]
    fn test_find_crypto_frame_never_panics_on_arbitrary_payload() {
        // A payload with a lot of 0x06 bytes that are *not* frame
        // boundaries. The scan may stop at a false positive (the caller
        // re-validates with `parse_client_hello`), but it must never panic.
        for seed in 0u64..100 {
            let mut payload = Vec::with_capacity(64);
            let mut x: u64 = seed.wrapping_mul(2654435761);
            for _ in 0..64 {
                // Knuth's 64-bit LCG (Numerical Recipes §7.1).
                x = x
                    .wrapping_mul(6364136223846793005)
                    .wrapping_add(1442695040888963407);
                payload.push((x >> 56) as u8);
            }
            // Force some 0x06 markers.
            payload[16] = 0x06;
            payload[40] = 0x06;

            // The function may return Ok(frame) or Err(NoCryptoFrame /
            // Incomplete), but it must not panic.
            let _ = find_crypto_frame(&payload);
        }
    }

    /// A QUIC Initial whose `Token Length` varint is larger than the
    /// remaining datagram must be rejected with `Incomplete`, using u64
    /// arithmetic so the check is robust on 32-bit targets.
    #[test]
    fn test_quic_initial_rejects_oversized_token() {
        let dcid = [0x01u8; 4];
        let scid = [0xAAu8; 2];
        let mut packet = Vec::new();
        packet.push(0xC0);
        packet.extend_from_slice(&1u32.to_be_bytes());
        packet.push(dcid.len() as u8);
        packet.extend_from_slice(&dcid);
        packet.push(scid.len() as u8);
        packet.extend_from_slice(&scid);

        // Token Length = 1000 encoded as a 2-byte varint (0x40 | high bits).
        packet.push(0x43);
        packet.push(0xE8);
        packet.extend_from_slice(&[0u8; 4]); // only 4 bytes of actual token

        match parse_quic_initial_header(&packet) {
            Err(QuicSniffError::Incomplete { needed }) => {
                assert_eq!(needed, 1000 - 4);
            }
            other => panic!("expected Incomplete, got {other:?}"),
        }
    }

    /// A CRYPTO frame declaring a huge `Length` must be rejected via
    /// `Incomplete` using u64 arithmetic.
    #[test]
    fn test_parse_crypto_frame_huge_length_rejected() {
        // Frame type 0x06, offset 0 (varint 0x00), then Length = 2^30 - 1.
        // varint 2^30-1 = 4-byte form: 0x80 | (v>>24), etc.
        let declared: u32 = (1 << 30) - 1;
        let mut frame = vec![0x06, 0x00];
        frame.push(0x80 | ((declared >> 24) as u8));
        frame.push((declared >> 16) as u8);
        frame.push((declared >> 8) as u8);
        frame.push(declared as u8);
        // Only 4 bytes of body (nothing near 2^30 - 1).
        frame.extend_from_slice(&[0u8; 4]);

        match parse_crypto_frame(&frame) {
            Err(QuicSniffError::Incomplete { needed }) => {
                assert!(
                    needed >= (declared as usize) - 8,
                    "shortfall too small: {needed}",
                );
            }
            other => panic!("expected Incomplete, got {other:?}"),
        }
    }
}
