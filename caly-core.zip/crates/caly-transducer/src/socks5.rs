//! Sans-I/O SOCKS5 handshake transducer and zero-allocation packet parser.
//!
//! Compliant with RFC 1928 (SOCKS Protocol Version 5).

use core::fmt;
use core::net::{Ipv4Addr, Ipv6Addr};
use core::str;
use thiserror::Error;

/// SOCKS Protocol Version 5.
pub const SOCKS_VERSION: u8 = 0x05;

/// Authentication methods defined in RFC 1928.
pub mod auth_methods {
    pub const NO_AUTH: u8 = 0x00;
    pub const GSSAPI: u8 = 0x01;
    pub const USERNAME_PASSWORD: u8 = 0x02;
    pub const NO_ACCEPTABLE: u8 = 0xFF;
}

/// SOCKS5 command types.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
#[repr(u8)]
pub enum Socks5Command {
    Connect = 0x01,
    Bind = 0x02,
    UdpAssociate = 0x03,
}

impl Socks5Command {
    /// Attempts to parse a command byte into a known SOCKS5 command.
    #[inline]
    pub fn from_u8(b: u8) -> Result<Self, Socks5Error> {
        match b {
            0x01 => Ok(Self::Connect),
            0x02 => Ok(Self::Bind),
            0x03 => Ok(Self::UdpAssociate),
            other => Err(Socks5Error::InvalidCommand(other)),
        }
    }

    #[inline]
    pub fn as_u8(self) -> u8 {
        self as u8
    }
}

/// Address Type (ATYP) indicator.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
#[repr(u8)]
pub enum AddressType {
    Ipv4 = 0x01,
    Domain = 0x03,
    Ipv6 = 0x04,
}

impl AddressType {
    #[inline]
    pub fn from_u8(b: u8) -> Result<Self, Socks5Error> {
        match b {
            0x01 => Ok(Self::Ipv4),
            0x03 => Ok(Self::Domain),
            0x04 => Ok(Self::Ipv6),
            other => Err(Socks5Error::InvalidAddressType(other)),
        }
    }
}

/// Zero-allocation representation of a SOCKS5 target address.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum Socks5Addr<'a> {
    /// IPv4 address as 4 raw octets.
    Ipv4([u8; 4]),
    /// FQDN borrowed directly from the input buffer.
    Domain(&'a str),
    /// IPv6 address as 16 raw octets.
    Ipv6([u8; 16]),
}

impl<'a> Socks5Addr<'a> {
    #[inline]
    pub fn address_type(&self) -> AddressType {
        match self {
            Self::Ipv4(_) => AddressType::Ipv4,
            Self::Domain(_) => AddressType::Domain,
            Self::Ipv6(_) => AddressType::Ipv6,
        }
    }

    #[inline]
    pub fn as_ipv4(&self) -> Option<Ipv4Addr> {
        match self {
            Self::Ipv4(octets) => Some(Ipv4Addr::from(*octets)),
            _ => None,
        }
    }

    #[inline]
    pub fn as_ipv6(&self) -> Option<Ipv6Addr> {
        match self {
            Self::Ipv6(octets) => Some(Ipv6Addr::from(*octets)),
            _ => None,
        }
    }

    #[inline]
    pub fn as_domain(&self) -> Option<&'a str> {
        match self {
            Self::Domain(d) => Some(d),
            _ => None,
        }
    }

    /// Calculates the wire-encoded length in bytes of this address.
    #[inline]
    pub fn encoded_len(&self) -> usize {
        match self {
            Self::Ipv4(_) => 1 + 4,
            Self::Domain(d) => 1 + 1 + d.len(),
            Self::Ipv6(_) => 1 + 16,
        }
    }
}

impl<'a> fmt::Display for Socks5Addr<'a> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::Ipv4(octets) => {
                let ip = Ipv4Addr::from(*octets);
                write!(f, "{}", ip)
            }
            Self::Domain(name) => write!(f, "{}", name),
            Self::Ipv6(octets) => {
                let ip = Ipv6Addr::from(*octets);
                write!(f, "[{}]", ip)
            }
        }
    }
}

/// SOCKS5 Target specifying address and port.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Socks5Target<'a> {
    pub addr: Socks5Addr<'a>,
    pub port: u16,
}

impl<'a> fmt::Display for Socks5Target<'a> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "{}:{}", self.addr, self.port)
    }
}

/// Parsed SOCKS5 client request.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Socks5Request<'a> {
    pub cmd: Socks5Command,
    pub target: Socks5Target<'a>,
}

/// Client greeting containing advertised authentication methods.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ClientGreeting<'a> {
    pub methods: &'a [u8],
}

impl<'a> ClientGreeting<'a> {
    #[inline]
    pub fn supports_no_auth(&self) -> bool {
        self.methods.contains(&auth_methods::NO_AUTH)
    }

    #[inline]
    pub fn supports_user_pass(&self) -> bool {
        self.methods.contains(&auth_methods::USERNAME_PASSWORD)
    }

    #[inline]
    pub fn supports_method(&self, method: u8) -> bool {
        self.methods.contains(&method)
    }
}

/// SOCKS5 Reply Status codes (RFC 1928 Section 6).
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
#[repr(u8)]
pub enum ReplyStatus {
    Succeeded = 0x00,
    GeneralFailure = 0x01,
    ConnectionNotAllowed = 0x02,
    NetworkUnreachable = 0x03,
    HostUnreachable = 0x04,
    ConnectionRefused = 0x05,
    TtlExpired = 0x06,
    CommandNotSupported = 0x07,
    AddressTypeNotSupported = 0x08,
}

impl ReplyStatus {
    #[inline]
    pub fn as_u8(self) -> u8 {
        self as u8
    }
}

/// Errors occurring during SOCKS5 parsing and state transitions.
#[derive(Debug, Error, PartialEq, Eq, Clone)]
pub enum Socks5Error {
    /// Insufficient bytes to complete parsing; specifies minimum bytes needed.
    #[error("Incomplete buffer: need {needed} additional bytes")]
    Incomplete { needed: usize },

    /// Received unsupported SOCKS version (must be 0x05).
    #[error("Unsupported SOCKS version: {0:#04x}")]
    UnsupportedVersion(u8),

    /// Invalid SOCKS5 command byte.
    #[error("Invalid SOCKS5 command: {0:#04x}")]
    InvalidCommand(u8),

    /// Invalid Address Type (ATYP) byte.
    #[error("Invalid address type: {0:#04x}")]
    InvalidAddressType(u8),

    /// Non-zero reserved field.
    #[error("Invalid reserved byte: expected 0x00, got {0:#04x}")]
    InvalidReservedByte(u8),

    /// Domain name is not valid UTF-8.
    #[error("Invalid domain string: non-UTF-8 encoding")]
    InvalidDomain,

    /// Target buffer too small to serialize reply.
    #[error("Target buffer capacity ({capacity}) insufficient for reply length ({required})")]
    BufferOverflow { capacity: usize, required: usize },

    /// Operation called during invalid handshake phase.
    #[error("Invalid state machine phase for operation")]
    InvalidState,
}

/// Parses a client greeting message from a byte slice without heap allocation.
///
/// Returns (consumed_bytes, ClientGreeting).
pub fn parse_client_greeting(buf: &[u8]) -> Result<(usize, ClientGreeting<'_>), Socks5Error> {
    if buf.len() < 2 {
        return Err(Socks5Error::Incomplete {
            needed: 2 - buf.len(),
        });
    }

    if buf[0] != SOCKS_VERSION {
        return Err(Socks5Error::UnsupportedVersion(buf[0]));
    }

    let nmethods = buf[1] as usize;
    let total_len = 2 + nmethods;

    if buf.len() < total_len {
        return Err(Socks5Error::Incomplete {
            needed: total_len - buf.len(),
        });
    }

    let methods = &buf[2..total_len];
    Ok((total_len, ClientGreeting { methods }))
}

/// Parses a SOCKS5 request message from a byte slice without heap allocation.
///
/// Returns (consumed_bytes, Socks5Request).
pub fn parse_client_request(buf: &[u8]) -> Result<(usize, Socks5Request<'_>), Socks5Error> {
    if buf.len() < 4 {
        return Err(Socks5Error::Incomplete {
            needed: 4 - buf.len(),
        });
    }

    if buf[0] != SOCKS_VERSION {
        return Err(Socks5Error::UnsupportedVersion(buf[0]));
    }

    let cmd = Socks5Command::from_u8(buf[1])?;

    if buf[2] != 0x00 {
        return Err(Socks5Error::InvalidReservedByte(buf[2]));
    }

    let atyp = AddressType::from_u8(buf[3])?;

    match atyp {
        AddressType::Ipv4 => {
            const REQ_LEN: usize = 10;
            if buf.len() < REQ_LEN {
                return Err(Socks5Error::Incomplete {
                    needed: REQ_LEN - buf.len(),
                });
            }

            let mut octets = [0u8; 4];
            octets.copy_from_slice(&buf[4..8]);
            let port = u16::from_be_bytes([buf[8], buf[9]]);

            Ok((
                REQ_LEN,
                Socks5Request {
                    cmd,
                    target: Socks5Target {
                        addr: Socks5Addr::Ipv4(octets),
                        port,
                    },
                },
            ))
        }
        AddressType::Domain => {
            if buf.len() < 5 {
                return Err(Socks5Error::Incomplete {
                    needed: 5 - buf.len(),
                });
            }

            let domain_len = buf[4] as usize;
            let total_len = 4 + 1 + domain_len + 2;

            if buf.len() < total_len {
                return Err(Socks5Error::Incomplete {
                    needed: total_len - buf.len(),
                });
            }

            let domain_bytes = &buf[5..5 + domain_len];
            let domain_str =
                str::from_utf8(domain_bytes).map_err(|_| Socks5Error::InvalidDomain)?;

            let port_idx = 5 + domain_len;
            let port = u16::from_be_bytes([buf[port_idx], buf[port_idx + 1]]);

            Ok((
                total_len,
                Socks5Request {
                    cmd,
                    target: Socks5Target {
                        addr: Socks5Addr::Domain(domain_str),
                        port,
                    },
                },
            ))
        }
        AddressType::Ipv6 => {
            const REQ_LEN: usize = 22;
            if buf.len() < REQ_LEN {
                return Err(Socks5Error::Incomplete {
                    needed: REQ_LEN - buf.len(),
                });
            }

            let mut octets = [0u8; 16];
            octets.copy_from_slice(&buf[4..20]);
            let port = u16::from_be_bytes([buf[20], buf[21]]);

            Ok((
                REQ_LEN,
                Socks5Request {
                    cmd,
                    target: Socks5Target {
                        addr: Socks5Addr::Ipv6(octets),
                        port,
                    },
                },
            ))
        }
    }
}

/// Creates a 2-byte SOCKS5 method selection response `[0x05, method]`.
#[inline]
pub fn create_auth_response(method: u8) -> [u8; 2] {
    [SOCKS_VERSION, method]
}

/// Zero-allocation reply buffer for SOCKS5 server responses.
/// Maximum possible SOCKS5 reply size is 3 (header) + 1 (atyp) + 1 (dlen) + 255 (domain) + 2 (port) = 262 bytes.
#[derive(Debug, Clone, Copy)]
pub struct Socks5ReplyBuffer {
    bytes: [u8; 262],
    len: usize,
}

impl Socks5ReplyBuffer {
    #[inline]
    pub fn as_slice(&self) -> &[u8] {
        &self.bytes[..self.len]
    }

    #[inline]
    pub fn len(&self) -> usize {
        self.len
    }

    #[inline]
    pub fn is_empty(&self) -> bool {
        self.len == 0
    }
}

impl AsRef<[u8]> for Socks5ReplyBuffer {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_slice()
    }
}

/// Formats a complete SOCKS5 server reply into a zero-allocation stack buffer.
pub fn create_reply_buffer(
    status: ReplyStatus,
    bound_addr: &Socks5Addr<'_>,
    bound_port: u16,
) -> Socks5ReplyBuffer {
    let mut buffer = Socks5ReplyBuffer {
        bytes: [0u8; 262],
        len: 0,
    };

    let len = write_reply(status, bound_addr, bound_port, &mut buffer.bytes)
        .expect("Socks5ReplyBuffer has sufficient capacity for any valid reply");
    buffer.len = len;
    buffer
}

/// Serializes a SOCKS5 reply directly into the provided output slice without heap allocation.
///
/// Returns the number of bytes written.
pub fn write_reply(
    status: ReplyStatus,
    bound_addr: &Socks5Addr<'_>,
    bound_port: u16,
    out: &mut [u8],
) -> Result<usize, Socks5Error> {
    let required_len = 3 + bound_addr.encoded_len() + 2;
    if out.len() < required_len {
        return Err(Socks5Error::BufferOverflow {
            capacity: out.len(),
            required: required_len,
        });
    }

    out[0] = SOCKS_VERSION;
    out[1] = status.as_u8();
    out[2] = 0x00; // Reserved

    let mut cursor = 3;
    match bound_addr {
        Socks5Addr::Ipv4(octets) => {
            out[cursor] = AddressType::Ipv4 as u8;
            cursor += 1;
            out[cursor..cursor + 4].copy_from_slice(octets);
            cursor += 4;
        }
        Socks5Addr::Domain(name) => {
            let dbytes = name.as_bytes();
            // RFC 1928 hard-limits DLEN to 255 bytes. Silently truncating
            // would produce a wire reply that the client cannot parse
            // correctly; fail loudly instead.
            if dbytes.len() > 255 {
                return Err(Socks5Error::BufferOverflow {
                    capacity: 255,
                    required: dbytes.len(),
                });
            }
            out[cursor] = AddressType::Domain as u8;
            cursor += 1;
            out[cursor] = dbytes.len() as u8;
            cursor += 1;
            out[cursor..cursor + dbytes.len()].copy_from_slice(dbytes);
            cursor += dbytes.len();
        }
        Socks5Addr::Ipv6(octets) => {
            out[cursor] = AddressType::Ipv6 as u8;
            cursor += 1;
            out[cursor..cursor + 16].copy_from_slice(octets);
            cursor += 16;
        }
    }

    let port_bytes = bound_port.to_be_bytes();
    out[cursor] = port_bytes[0];
    out[cursor + 1] = port_bytes[1];
    cursor += 2;

    Ok(cursor)
}

/// Transducer lifecycle phase for the incremental SOCKS5 state machine.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum HandshakePhase {
    Initial,
    GreetingReceived,
    AuthNegotiated,
    RequestReceived,
    Established,
    Closed,
}

/// Result produced by an incremental transduction step.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum TransducerStep<'a> {
    /// Insufficient bytes to make progress; more bytes must be read.
    NeedMoreData { needed: usize },
    /// Client greeting has been successfully parsed.
    GreetingDone {
        consumed: usize,
        greeting: ClientGreeting<'a>,
    },
    /// Client request has been successfully parsed.
    RequestDone {
        consumed: usize,
        request: Socks5Request<'a>,
    },
    /// Handshake complete.
    Complete,
}

/// Incremental sans-I/O SOCKS5 handshake transducer.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Socks5Transducer {
    phase: HandshakePhase,
}

impl Default for Socks5Transducer {
    #[inline]
    fn default() -> Self {
        Self::new()
    }
}

impl Socks5Transducer {
    #[inline]
    pub fn new() -> Self {
        Self {
            phase: HandshakePhase::Initial,
        }
    }

    #[inline]
    pub fn phase(&self) -> HandshakePhase {
        self.phase
    }

    #[inline]
    pub fn set_auth_negotiated(&mut self) {
        self.phase = HandshakePhase::AuthNegotiated;
    }

    #[inline]
    pub fn set_established(&mut self) {
        self.phase = HandshakePhase::Established;
    }

    #[inline]
    pub fn close(&mut self) {
        self.phase = HandshakePhase::Closed;
    }

    #[inline]
    pub fn reset(&mut self) {
        self.phase = HandshakePhase::Initial;
    }

    /// Feeds incoming network slice into the state machine.
    pub fn step<'a>(&mut self, buf: &'a [u8]) -> Result<TransducerStep<'a>, Socks5Error> {
        match self.phase {
            HandshakePhase::Initial => match parse_client_greeting(buf) {
                Ok((consumed, greeting)) => {
                    self.phase = HandshakePhase::GreetingReceived;
                    Ok(TransducerStep::GreetingDone { consumed, greeting })
                }
                Err(Socks5Error::Incomplete { needed }) => {
                    Ok(TransducerStep::NeedMoreData { needed })
                }
                Err(err) => Err(err),
            },
            HandshakePhase::GreetingReceived | HandshakePhase::AuthNegotiated => {
                match parse_client_request(buf) {
                    Ok((consumed, request)) => {
                        self.phase = HandshakePhase::RequestReceived;
                        Ok(TransducerStep::RequestDone { consumed, request })
                    }
                    Err(Socks5Error::Incomplete { needed }) => {
                        Ok(TransducerStep::NeedMoreData { needed })
                    }
                    Err(err) => Err(err),
                }
            }
            HandshakePhase::RequestReceived | HandshakePhase::Established => {
                Ok(TransducerStep::Complete)
            }
            HandshakePhase::Closed => Err(Socks5Error::InvalidState),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_socks5_all_commands_and_address_types() {
        let cases: &[(&[u8], Socks5Command, &str)] = &[
            // CONNECT + IPv4
            (
                &[0x05, 0x01, 0x00, 0x01, 10, 0, 0, 1, 0x00, 0x50],
                Socks5Command::Connect,
                "10.0.0.1:80",
            ),
            // CONNECT + Domain
            (
                &[
                    0x05, 0x01, 0x00, 0x03, 0x0B, b'e', b'x', b'a', b'm', b'p', b'l', b'e', b'.',
                    b'c', b'o', b'm', 0x01, 0xBB,
                ],
                Socks5Command::Connect,
                "example.com:443",
            ),
            // BIND + IPv4
            (
                &[0x05, 0x02, 0x00, 0x01, 192, 168, 1, 1, 0x1F, 0x90],
                Socks5Command::Bind,
                "192.168.1.1:8080",
            ),
            // UDP ASSOCIATE + IPv4
            (
                &[0x05, 0x03, 0x00, 0x01, 8, 8, 8, 8, 0x00, 0x35],
                Socks5Command::UdpAssociate,
                "8.8.8.8:53",
            ),
        ];

        for (raw, expected_cmd, expected_target) in cases {
            let (_, req) = parse_client_request(raw).expect("parse");
            assert_eq!(req.cmd, *expected_cmd, "command mismatch");
            assert_eq!(req.target.to_string(), *expected_target, "target mismatch");
        }
    }

    #[test]
    fn test_socks5_invalid_command_rejected() {
        // Byte 0x09 is not a valid SOCKS5 command.
        let raw = [0x05, 0x09, 0x00, 0x01, 10, 0, 0, 1, 0x00, 0x50];
        assert!(matches!(
            parse_client_request(&raw),
            Err(Socks5Error::InvalidCommand(0x09))
        ));
    }

    #[test]
    fn test_socks5_non_zero_reserved_byte_rejected() {
        let raw = [0x05, 0x01, 0xFF, 0x01, 10, 0, 0, 1, 0x00, 0x50];
        assert!(matches!(
            parse_client_request(&raw),
            Err(Socks5Error::InvalidReservedByte(0xFF))
        ));
    }

    #[test]
    fn test_socks5_domain_length_boundaries() {
        // ── Length 0 ──────────────────────────────────────────────────────────
        // [VER, CMD, RSV, ATYP=3, DLEN=0, PORT_HI, PORT_LO]
        let raw = [0x05, 0x01, 0x00, 0x03, 0x00, 0x00, 0x50];
        let (consumed, req) = parse_client_request(&raw).expect("empty domain");
        assert_eq!(consumed, 7);
        assert_eq!(req.target.addr, Socks5Addr::Domain(""));
        assert_eq!(req.target.port, 80);

        // ── Length 255 (maximum permitted by RFC 1928) ───────────────────────
        let domain = "a".repeat(255);
        let mut raw = vec![0x05, 0x01, 0x00, 0x03, 255];
        raw.extend_from_slice(domain.as_bytes());
        raw.extend_from_slice(&443u16.to_be_bytes());

        let (consumed, req) = parse_client_request(&raw).expect("max domain");
        assert_eq!(consumed, raw.len());
        assert_eq!(req.target.addr.as_domain(), Some(domain.as_str()));
        assert_eq!(req.target.port, 443);

        // ── Non-UTF-8 domain must be rejected, not panic ─────────────────────
        let mut bad = vec![0x05, 0x01, 0x00, 0x03, 0x03];
        bad.extend_from_slice(&[0xFF, 0xFE, 0xFD]); // invalid UTF-8
        bad.extend_from_slice(&[0x00, 0x50]);
        assert!(matches!(
            parse_client_request(&bad),
            Err(Socks5Error::InvalidDomain),
        ));
    }

    #[test]
    fn test_socks5_greeting_zero_methods_is_valid_but_rejected() {
        // A greeting with NMETHODS=0 is syntactically complete; semantics
        // is decided by the caller. Parsing must succeed.
        let raw = [0x05, 0x00];
        let (consumed, greeting) = parse_client_greeting(&raw).expect("zero methods");
        assert_eq!(consumed, 2);
        assert_eq!(greeting.methods, &[] as &[u8]);
        assert!(!greeting.supports_no_auth());
        assert!(!greeting.supports_user_pass());
    }

    #[test]
    fn test_socks5_reply_buffer_max_domain_length() {
        // Maximum-length domain (255) must fit.
        let domain = "a".repeat(255);
        let addr = Socks5Addr::Domain(&domain);
        let reply = create_reply_buffer(ReplyStatus::Succeeded, &addr, 65535);

        // Wire layout: VER (1) + REP (1) + RSV (1) + ATYP (1) + DLEN (1)
        //            + domain (255) + port (2) = 262 bytes.
        assert_eq!(reply.len(), 262);
        assert_eq!(reply.as_slice()[0], 0x05);
        assert_eq!(reply.as_slice()[1], 0x00);
        assert_eq!(reply.as_slice()[3], 0x03); // ATYP = domain
        assert_eq!(reply.as_slice()[4], 255);

        // Check the encoded port at the tail.
        let tail = &reply.as_slice()[reply.len() - 2..];
        assert_eq!(u16::from_be_bytes([tail[0], tail[1]]), 65535);

        // `write_reply` into an undersized buffer must return Err.
        let mut too_small = [0u8; 100];
        let r = write_reply(ReplyStatus::Succeeded, &addr, 80, &mut too_small);
        assert!(matches!(r, Err(Socks5Error::BufferOverflow { .. })));
    }

    #[test]
    fn test_socks5_write_reply_rejects_oversized_domain() {
        let domain = "a".repeat(300); // > 255
        let addr = Socks5Addr::Domain(&domain);
        let mut out = [0u8; 512];

        let r = write_reply(ReplyStatus::Succeeded, &addr, 80, &mut out);
        assert!(
            matches!(r, Err(Socks5Error::BufferOverflow { capacity: 255, .. })),
            "expected BufferOverflow(capacity=255), got {r:?}",
        );
    }

    #[test]
    fn test_socks5_write_reply_accepts_max_domain() {
        let domain = "a".repeat(255);
        let addr = Socks5Addr::Domain(&domain);
        let mut out = [0u8; 512];

        let n = write_reply(ReplyStatus::Succeeded, &addr, 80, &mut out)
            .expect("max-length domain must fit");
        assert_eq!(n, 3 + 1 + 1 + 255 + 2);
        assert_eq!(out[4], 255);
    }

    /// Property: for any syntactically valid SOCKS5 request, parse must
    /// succeed and preserve the address/port. Generating from a typed
    /// strategy (not raw bytes) guarantees we only feed well-formed input.
    #[cfg(test)]
    mod proptests {
        use super::*;
        use proptest::prelude::*;

        fn arb_ipv4_target() -> impl Strategy<Value = ([u8; 4], u16)> {
            (any::<[u8; 4]>(), any::<u16>())
        }

        fn arb_domain_target() -> impl Strategy<Value = (String, u16)> {
            ("[a-z]{1,16}\\.(com|net|org)".prop_map(|s| s), any::<u16>())
        }

        proptest! {
            #![proptest_config(crate::test_support::proptest_config(256))]

            #[test]
            fn prop_socks5_connect_ipv4_roundtrip(
                (ip, port) in arb_ipv4_target(),
                cmd in 1u8..=3u8,
            ) {
                let mut raw = vec![0x05, cmd, 0x00, 0x01];
                raw.extend_from_slice(&ip);
                raw.extend_from_slice(&port.to_be_bytes());

                let (consumed, req) = parse_client_request(&raw).expect("parse");
                prop_assert_eq!(consumed, 10);
                prop_assert_eq!(req.target.addr, Socks5Addr::Ipv4(ip));
                prop_assert_eq!(req.target.port, port);
            }

            #[test]
            fn prop_socks5_connect_domain_roundtrip(
                (domain, port) in arb_domain_target(),
            ) {
                let mut raw = vec![0x05, 0x01, 0x00, 0x03, domain.len() as u8];
                raw.extend_from_slice(domain.as_bytes());
                raw.extend_from_slice(&port.to_be_bytes());

                let (_, req) = parse_client_request(&raw).expect("parse");
                prop_assert_eq!(req.target.addr.as_domain(), Some(domain.as_str()));
                prop_assert_eq!(req.target.port, port);
            }

            /// Any byte slice must not cause a panic in the parser.
            #[test]
            fn prop_socks5_never_panics(data in prop::collection::vec(any::<u8>(), 0..64)) {
                let _ = parse_client_request(&data);
                let _ = parse_client_greeting(&data);
            }
        }
    }
}
