//! Type-Level Protocol Automata using Affine Session Types.
//!
//! Enforces protocol state transitions at compile time using linear consumption semantics:
//! state transition functions consume `self` by value, preventing reuse or state rollbacks.

use core::marker::PhantomData;
use thiserror::Error;

/// Protocol state marker types.
pub mod protocol_states {
    /// Initial unauthenticated state when a raw client connection is accepted.
    #[derive(Debug, Clone, Copy, PartialEq, Eq)]
    pub struct Unauthenticated;

    /// State where authentication method negotiation or credential verification is in progress.
    #[derive(Debug, Clone, Copy, PartialEq, Eq)]
    pub struct Authenticating;

    /// State when authentication has completed and the connection awaits proxy commands (e.g. SOCKS5 CONNECT).
    #[derive(Debug, Clone, Copy, PartialEq, Eq)]
    pub struct AwaitingCommand;

    /// State where the proxy connection is established and active in full-duplex data relay mode.
    #[derive(Debug, Clone, Copy, PartialEq, Eq)]
    pub struct Established;

    /// Terminal state indicating the protocol wire has been closed.
    #[derive(Debug, Clone, Copy, PartialEq, Eq)]
    pub struct Closed;
}

/// Errors occurring during protocol wire state transitions.
#[derive(Debug, Error, PartialEq, Eq, Clone)]
pub enum WireError {
    /// No acceptable authentication methods were provided by the client.
    #[error("No acceptable authentication methods provided")]
    NoAcceptableMethods,

    /// Client specified unsupported or invalid protocol version.
    #[error("Unsupported protocol version: {0:#04x}")]
    UnsupportedVersion(u8),

    /// Authentication credential verification failed.
    #[error("Authentication failed: {0}")]
    AuthenticationFailed(String),

    /// Illegal or invalid state transition attempted.
    #[error("Invalid protocol transition: {0}")]
    InvalidTransition(String),

    /// Connection is closed.
    #[error("Protocol wire closed")]
    ConnectionClosed,
}

/// Zero-cost protocol wire automaton enforcing affine linearity and session state at compile time.
///
/// `ProtocolWire` wraps a raw file descriptor or connection token along with a phantom
/// state marker. All state transition methods consume `self` by value, strictly enforcing
/// affine session types so that previous states cannot be reused.
#[derive(Debug)]
pub struct ProtocolWire<State> {
    raw_fd: i32,
    _marker: PhantomData<State>,
}

/// Closes `fd` if it is non-negative, then resets it to `-1`.
///
/// Errors from `close(2)` are intentionally ignored: the only failure mode
/// is `EBADF` (descriptor already invalid), which is a caller bug that we
/// cannot recover from inside `Drop`. Returning it would be pointless.
#[inline]
fn safe_close(fd: &mut i32) {
    if *fd < 0 {
        return;
    }
    // SAFETY: `*fd` is a valid, open descriptor owned by this value. After
    // this call it must not be used again; we immediately mark it as `-1`.
    // SAFETY: `fd` is an open descriptor owned by this scope; close consumes it.
    unsafe {
        libc::close(*fd);
    }
    *fd = -1;
}

impl<State> Drop for ProtocolWire<State> {
    fn drop(&mut self) {
        safe_close(&mut self.raw_fd);
    }
}

impl<State> ProtocolWire<State> {
    /// Destructures the wire, disarming automatic descriptor closure on drop,
    /// and returns the underlying raw file descriptor.
    #[inline(always)]
    pub fn into_raw_fd(mut self) -> i32 {
        let fd = self.raw_fd;
        self.raw_fd = -1;
        fd
    }

    /// Disarms the wire, preventing automatic descriptor closure on drop,
    /// returning the raw file descriptor.
    #[inline(always)]
    pub fn disarm(self) -> i32 {
        self.into_raw_fd()
    }

    /// Internal helper extracting raw_fd while disarming drop during ownership transfer.
    #[inline(always)]
    fn take_fd(self) -> i32 {
        self.into_raw_fd()
    }

    /// Returns the underlying raw file descriptor or connection token.
    #[inline]
    pub fn raw_fd(&self) -> i32 {
        self.raw_fd
    }

    /// Closes the connection from any active state, transitioning into the terminal `Closed` state.
    #[inline]
    pub fn close(self) -> ProtocolWire<protocol_states::Closed> {
        let raw_fd = self.take_fd();
        ProtocolWire {
            raw_fd,
            _marker: PhantomData,
        }
    }
}

impl ProtocolWire<protocol_states::Unauthenticated> {
    /// Constructs a new `ProtocolWire` in the `Unauthenticated` state.
    #[inline]
    pub fn new(raw_fd: i32) -> Self {
        Self {
            raw_fd,
            _marker: PhantomData,
        }
    }

    /// Validates and accepts the client greeting authentication methods.
    ///
    /// Consumes the unauthenticated wire by value and transitions to the `Authenticating` state.
    /// Returns an error if no methods are provided.
    pub fn accept_client_greet(
        self,
        methods: &[u8],
    ) -> Result<ProtocolWire<protocol_states::Authenticating>, WireError> {
        if methods.is_empty() {
            return Err(WireError::NoAcceptableMethods);
        }
        let fd = self.take_fd();
        Ok(ProtocolWire {
            raw_fd: fd,
            _marker: PhantomData,
        })
    }
}

impl ProtocolWire<protocol_states::Authenticating> {
    /// Selects the `NO_AUTH` (0x00) authentication method.
    ///
    /// Consumes the `Authenticating` wire and transitions directly to `AwaitingCommand`.
    /// Returns the updated wire and the SOCKS5 greeting response bytes `[0x05, 0x00]`.
    #[inline]
    pub fn select_no_auth(self) -> (ProtocolWire<protocol_states::AwaitingCommand>, [u8; 2]) {
        let fd = self.take_fd();
        (
            ProtocolWire {
                raw_fd: fd,
                _marker: PhantomData,
            },
            [0x05, 0x00],
        )
    }

    /// Selects the Username/Password (0x02) authentication method.
    ///
    /// Returns the updated wire (still in `Authenticating` state to verify credentials)
    /// and the greeting response bytes `[0x05, 0x02]`.
    #[inline]
    pub fn select_username_password(
        self,
    ) -> (ProtocolWire<protocol_states::Authenticating>, [u8; 2]) {
        let fd = self.take_fd();
        (
            ProtocolWire {
                raw_fd: fd,
                _marker: PhantomData,
            },
            [0x05, 0x02],
        )
    }

    /// Concludes successful authentication credential verification, advancing to `AwaitingCommand`.
    #[inline]
    pub fn finish_authentication(self) -> ProtocolWire<protocol_states::AwaitingCommand> {
        let fd = self.take_fd();
        ProtocolWire {
            raw_fd: fd,
            _marker: PhantomData,
        }
    }
}

impl ProtocolWire<protocol_states::AwaitingCommand> {
    /// Transitions the connection to `Established` relay mode once target command has succeeded.
    #[inline]
    pub fn transition_to_relay(self) -> ProtocolWire<protocol_states::Established> {
        let fd = self.take_fd();
        ProtocolWire {
            raw_fd: fd,
            _marker: PhantomData,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_session_types_full_lifecycle() {
        let wire = ProtocolWire::new(42);
        assert_eq!(wire.raw_fd(), 42);

        let wire = wire.accept_client_greet(&[0x00]).expect("greet");
        let (wire, resp) = wire.select_no_auth();
        assert_eq!(resp, [0x05, 0x00]);

        let wire = wire.transition_to_relay();
        let closed = wire.close();
        assert_eq!(closed.raw_fd(), 42);
        // `into_raw_fd` disarms the Drop; raw_fd is no longer auto-closed.
        let raw = closed.into_raw_fd();
        assert_eq!(raw, 42);
    }

    #[test]
    fn test_session_types_username_password_flow() {
        let wire = ProtocolWire::new(43);
        let wire = wire.accept_client_greet(&[0x02]).expect("greet");
        let (wire, resp) = wire.select_username_password();
        assert_eq!(resp, [0x05, 0x02]);
        let wire = wire.finish_authentication();
        let wire = wire.transition_to_relay();
        let _raw = wire.disarm();
        // No panic; type-level state machine enforced at compile time.
    }

    #[test]
    fn test_session_types_empty_greet_rejected() {
        let wire = ProtocolWire::new(44);
        let err = wire.accept_client_greet(&[]).unwrap_err();
        assert_eq!(err, WireError::NoAcceptableMethods);
    }

    #[test]
    fn test_session_types_close_from_any_state() {
        // Close directly from Unauthenticated
        let wire = ProtocolWire::new(45);
        let closed = wire.close();
        assert_eq!(closed.raw_fd(), 45);

        // Close from Authenticating
        let wire = ProtocolWire::new(46);
        let wire = wire.accept_client_greet(&[0x00]).unwrap();
        let closed = wire.close();
        assert_eq!(closed.raw_fd(), 46);

        // Close from Established
        let wire = ProtocolWire::new(47);
        let wire = wire.accept_client_greet(&[0x00]).unwrap();
        let (wire, _) = wire.select_no_auth();
        let wire = wire.transition_to_relay();
        let closed = wire.close();
        assert_eq!(closed.raw_fd(), 47);
    }

    /// Stress test for `Drop` / `into_raw_fd` coordination under
    /// concurrency. Each worker spins up `socketpair(2)`, wraps one end
    /// in a `ProtocolWire`, and either drops it (auto-close) or extracts
    /// the raw fd and closes it manually. If `Drop` double-closed a
    /// descriptor, the kernel would race fd numbers onto another thread's
    /// socket and we would observe errors on the "b" end.
    #[test]
    #[cfg_attr(miri, ignore)]
    fn test_protocol_wire_concurrent_drop_and_disarm() {
        use protocol_states::Unauthenticated;
        use std::thread;

        const WORKERS: usize = 8;
        const ITERS: usize = 256;

        let handles: Vec<_> = (0..WORKERS)
            .map(|worker_id| {
                thread::spawn(move || {
                    for i in 0..ITERS {
                        let mut sv = [0i32; 2];
                        // SAFETY: sv is a valid 2-element i32 array.
                        let rc = unsafe {
                            libc::socketpair(
                                libc::AF_UNIX,
                                libc::SOCK_STREAM | libc::SOCK_CLOEXEC,
                                0,
                                sv.as_mut_ptr(),
                            )
                        };
                        assert_eq!(rc, 0, "socketpair failed");

                        let (a, b) = (sv[0], sv[1]);
                        let wire = ProtocolWire::<Unauthenticated>::new(a);

                        // Alternate between drop-auto-close and manual-close.
                        if (worker_id + i) % 2 == 0 {
                            // Auto-close via Drop.
                            drop(wire);
                        } else {
                            // Disarm: caller takes ownership.
                            let raw = wire.into_raw_fd();
                            assert_eq!(raw, a, "into_raw_fd returned wrong fd");
                            // SAFETY: we own `raw` now.
                            unsafe { libc::close(raw) };
                        }

                        // Close the "b" end that this thread owns.
                        // SAFETY: b was returned by socketpair and belongs
                        // to this thread.
                        unsafe { libc::close(b) };

                    }
                })
            })
            .collect();

        for h in handles {
            h.join().expect("worker thread panicked");
        }
    }
}
