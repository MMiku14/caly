//! Unified Protocol Transducer & Flow Decision Engine.
//!
//! Provides an adaptive, multi-protocol state machine that transparently sniffs
//! and handles SOCKS5, HTTP CONNECT, TLS ClientHello (SNI/ALPN), and QUIC Initial packets,
//! producing deterministic routing decisions without heap reallocations.

use bytes::Bytes;
use thiserror::Error;

use crate::http_connect::{parse_connect_request, HttpConnectError, HttpConnectResponse};
use crate::quic_sniffer::{sniff_quic_initial_sni, QuicSniffError};
use crate::socks5::{
    create_reply_buffer, parse_client_greeting, parse_client_request, write_reply, ReplyStatus,
    Socks5Addr, Socks5Command, Socks5Error,
};
use crate::tls_sniffer::{parse_client_hello, TlsSniffError, TLS_CONTENT_TYPE_HANDSHAKE};

/// Hard upper bound on the amount of bytes the [`ProtocolTransducer`]
/// will accumulate while a handshake is still incomplete.
///
/// Without this cap, an attacker can open a connection, send the first
/// few bytes of a TLS / QUIC / HTTP-CONNECT handshake, and then keep the
/// socket open while slowly dribbling more bytes. Every dribble appends
/// to the internal buffer, which grows without bound until the process
/// is OOM-killed (a classic slowloris-style amplification).
///
/// 64 KiB comfortably exceeds every protocol's own maximum handshake
/// size (TLS record ≤ 18 KiB, QUIC Initial ≤ 1200 B, HTTP CONNECT
/// request line ≤ a few KiB in any reasonable deployment).
pub const MAX_HANDSHAKE_BUFFER: usize = 64 * 1024;

/// Routing policy decision determined by the protocol inspection pipeline.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum FlowDecision {
    /// Direct connection to target without encapsulation or upstream proxy.
    Direct,
    /// Forward traffic via an outbound proxy or upstream relay node.
    Proxy(String),
    /// Reject the connection immediately (policy violation or malformed handshake).
    Reject,
    /// Handshake is incomplete; continue reading from client.
    Continue,
}

/// Operational output from feeding packet fragments into the protocol transducer.
#[derive(Debug, Clone)]
pub enum TransducerOutput {
    /// Flow has been identified as direct; bypass userspace (e.g. via eBPF Sockmap).
    DirectForward,
    /// Flow payload to be forwarded upstream to the proxy/server.
    ProxyForward(Bytes),
    /// Handshake in progress or handshake response written; continue reading.
    Continue,
    /// Unrecoverable protocol error or connection termination.
    Terminate,
}

/// Errors occurring during protocol detection and transduction.
#[derive(Error, Debug)]
pub enum TransducerError {
    #[error("Protocol error: {0}")]
    Protocol(String),

    #[error("Incomplete data buffer, needed at least {needed} additional bytes")]
    Incomplete { needed: usize },

    #[error("SOCKS5 protocol error: {0}")]
    Socks5(#[from] Socks5Error),

    #[error("HTTP CONNECT error: {0}")]
    HttpConnect(#[from] HttpConnectError),

    #[error("TLS sniffing error: {0}")]
    Tls(#[from] TlsSniffError),

    #[error("QUIC sniffing error: {0}")]
    Quic(#[from] QuicSniffError),

    #[error("Invalid state transition")]
    InvalidState,
}

/// Internal phase of protocol detection.
#[derive(Debug, Clone, PartialEq, Eq)]
enum TransducerPhase {
    /// Awaiting initial packet to identify protocol family.
    Detect,
    /// SOCKS5: Greeting accepted, awaiting client Connect/Bind command.
    Socks5AwaitingCommand,
    /// Fully established connection; streaming payload bytes.
    Established,
    /// Connection terminated or rejected.
    Closed,
}

/// Unified protocol inspection and transduction state machine.
pub struct ProtocolTransducer {
    phase: TransducerPhase,
    decision: Option<FlowDecision>,
    buffer: Vec<u8>,
    client_reply: Option<Bytes>,
}

impl Default for ProtocolTransducer {
    fn default() -> Self {
        Self::new()
    }
}

impl ProtocolTransducer {
    /// Creates a new uninitialized `ProtocolTransducer` ready for protocol detection.
    pub fn new() -> Self {
        Self {
            phase: TransducerPhase::Detect,
            decision: None,
            buffer: Vec::with_capacity(512),
            client_reply: None,
        }
    }

    /// Current routing decision, if resolved.
    #[inline]
    pub fn decision(&self) -> Option<FlowDecision> {
        self.decision.clone()
    }

    /// Target destination host/port string if resolved from protocol handshake.
    #[inline]
    pub fn target_address(&self) -> Option<&str> {
        match self.decision {
            Some(FlowDecision::Proxy(ref target)) => Some(target.as_str()),
            _ => None,
        }
    }

    /// Retrieve and clear any pending handshake response intended for the client socket.
    #[inline]
    pub fn take_client_reply(&mut self) -> Option<Bytes> {
        self.client_reply.take()
    }

    /// Read-only view of pending client reply.
    #[inline]
    pub fn client_reply(&self) -> Option<&Bytes> {
        self.client_reply.as_ref()
    }

    /// Returns `true` if the handshake has completed and data relaying is active.
    #[inline]
    pub fn is_established(&self) -> bool {
        self.phase == TransducerPhase::Established
    }

    /// Consumes incoming client bytes, updates internal protocol state, and returns action directive.
    pub fn consume(&mut self, data: &[u8]) -> Result<TransducerOutput, TransducerError> {
        if data.is_empty() {
            return Ok(TransducerOutput::Continue);
        }

        match self.phase {
            TransducerPhase::Established => {
                // Once established, forward payload according to decision
                match self.decision {
                    Some(FlowDecision::Direct) => Ok(TransducerOutput::DirectForward),
                    Some(FlowDecision::Proxy(_)) => {
                        Ok(TransducerOutput::ProxyForward(Bytes::copy_from_slice(data)))
                    }
                    Some(FlowDecision::Reject) | Some(FlowDecision::Continue) | None => {
                        Ok(TransducerOutput::Terminate)
                    }
                }
            }
            TransducerPhase::Closed => Ok(TransducerOutput::Terminate),
            TransducerPhase::Socks5AwaitingCommand => {
                // Append and attempt to parse SOCKS5 request
                let full_data = if self.buffer.is_empty() {
                    data
                } else {
                    self.buffer.extend_from_slice(data);
                    &self.buffer[..]
                };

                match parse_client_request(full_data) {
                    Ok((consumed, req)) => {
                        // Only CONNECT is handled by this transducer. BIND
                        // and UDP ASSOCIATE require a listen-back socket
                        // or a UDP relay path this layer does not
                        // implement; silently accepting them as CONNECT
                        // would route traffic to the wrong target over
                        // the wrong transport. Reply with RFC 1928 §6
                        // "command not supported" (0x07) and close.
                        if req.cmd != Socks5Command::Connect {
                            let dummy_bind = Socks5Addr::Ipv4([0, 0, 0, 0]);
                            let mut reply_buf = [0u8; 10];
                            let n = write_reply(
                                ReplyStatus::CommandNotSupported,
                                &dummy_bind,
                                0,
                                &mut reply_buf[..],
                            )
                            .expect(
                                "10-byte stack buffer is sufficient for an IPv4 reply header",
                            );
                            self.client_reply = Some(Bytes::copy_from_slice(&reply_buf[..n]));
                            self.phase = TransducerPhase::Closed;
                            self.decision = Some(FlowDecision::Reject);
                            return Err(TransducerError::Protocol(format!(
                                "SOCKS5 command {:?} is not supported by the proxy",
                                req.cmd,
                            )));
                        }

                        let target_str = req.target.to_string();
                        self.decision = Some(FlowDecision::Proxy(target_str));

                        // Generate SOCKS5 Success reply (0x05, 0x00, 0x00, 0x01, 0,0,0,0, 0,0)
                        let dummy_bind = Socks5Addr::Ipv4([0, 0, 0, 0]);
                        let reply_buf = create_reply_buffer(ReplyStatus::Succeeded, &dummy_bind, 0);
                        self.client_reply = Some(Bytes::copy_from_slice(reply_buf.as_slice()));

                        self.phase = TransducerPhase::Established;

                        let remaining = &full_data[consumed..];
                        if !remaining.is_empty() {
                            let forward = Bytes::copy_from_slice(remaining);
                            self.buffer.clear();
                            Ok(TransducerOutput::ProxyForward(forward))
                        } else {
                            self.buffer.clear();
                            Ok(TransducerOutput::Continue)
                        }
                    }
                    Err(Socks5Error::Incomplete { needed: _ }) => {
                        if self.buffer.is_empty() {
                            self.buffer.extend_from_slice(data);
                        }
                        self.decision = Some(FlowDecision::Continue);
                        Ok(TransducerOutput::Continue)
                    }
                    Err(err) => {
                        self.phase = TransducerPhase::Closed;
                        self.decision = Some(FlowDecision::Reject);
                        Err(TransducerError::Socks5(err))
                    }
                }
            }
            TransducerPhase::Detect => {
                // Enforce the amplification bound before growing the buffer.
                if self.buffer.len() + data.len() > MAX_HANDSHAKE_BUFFER {
                    self.phase = TransducerPhase::Closed;
                    self.decision = Some(FlowDecision::Reject);
                    return Err(TransducerError::Protocol(format!(
                        "handshake buffer exceeded {} bytes (slowloris guard)",
                        MAX_HANDSHAKE_BUFFER,
                    )));
                }

                let full_data = if self.buffer.is_empty() {
                    data
                } else {
                    self.buffer.extend_from_slice(data);
                    &self.buffer[..]
                };

                // Protocol Signature 1: SOCKS5 (Starts with 0x05)
                if full_data[0] == 0x05 {
                    match parse_client_greeting(full_data) {
                        Ok((consumed, greeting)) => {
                            if !greeting.supports_no_auth() {
                                self.phase = TransducerPhase::Closed;
                                self.decision = Some(FlowDecision::Reject);
                                self.client_reply = Some(Bytes::from_static(&[0x05, 0xFF]));
                                return Err(TransducerError::Protocol(
                                    "No acceptable auth method".into(),
                                ));
                            }

                            // Reply NO_AUTH (0x05, 0x00)
                            self.client_reply = Some(Bytes::from_static(&[0x05, 0x00]));
                            self.phase = TransducerPhase::Socks5AwaitingCommand;

                            let remaining = full_data[consumed..].to_vec();
                            self.buffer.clear();
                            if !remaining.is_empty() {
                                return self.consume(&remaining);
                            }
                            self.decision = Some(FlowDecision::Continue);
                            return Ok(TransducerOutput::Continue);
                        }
                        Err(Socks5Error::Incomplete { needed: _ }) => {
                            if self.buffer.is_empty() {
                                self.buffer.extend_from_slice(data);
                            }
                            self.decision = Some(FlowDecision::Continue);
                            return Ok(TransducerOutput::Continue);
                        }
                        Err(e) => {
                            self.phase = TransducerPhase::Closed;
                            self.decision = Some(FlowDecision::Reject);
                            return Err(TransducerError::Socks5(e));
                        }
                    }
                }

                // Protocol Signature 2: HTTP CONNECT (Starts with "CONNECT ")
                if full_data.starts_with(b"CONNECT ") || full_data.starts_with(b"CONNECT\t") {
                    match parse_connect_request(full_data) {
                        Ok((consumed, req)) => {
                            let target_str = format!("{}:{}", req.host, req.port);
                            self.decision = Some(FlowDecision::Proxy(target_str));
                            self.client_reply = Some(Bytes::from_static(
                                HttpConnectResponse::connection_established(),
                            ));
                            self.phase = TransducerPhase::Established;

                            let remaining = &full_data[consumed..];
                            if !remaining.is_empty() {
                                let forward = Bytes::copy_from_slice(remaining);
                                self.buffer.clear();
                                return Ok(TransducerOutput::ProxyForward(forward));
                            } else {
                                self.buffer.clear();
                                return Ok(TransducerOutput::Continue);
                            }
                        }
                        Err(HttpConnectError::Incomplete) => {
                            if self.buffer.is_empty() {
                                self.buffer.extend_from_slice(data);
                            }
                            self.decision = Some(FlowDecision::Continue);
                            return Ok(TransducerOutput::Continue);
                        }
                        Err(err) => {
                            self.phase = TransducerPhase::Closed;
                            self.decision = Some(FlowDecision::Reject);
                            return Err(TransducerError::HttpConnect(err));
                        }
                    }
                }

                // Protocol Signature 3: TLS ClientHello (Record Content Type 0x16)
                if full_data[0] == TLS_CONTENT_TYPE_HANDSHAKE {
                    match parse_client_hello(full_data) {
                        Ok(info) => {
                            if let Some(sni) = info.sni {
                                self.decision = Some(FlowDecision::Proxy(format!("{}:443", sni)));
                            } else {
                                self.decision = Some(FlowDecision::Direct);
                            }
                            self.phase = TransducerPhase::Established;
                            let forward_bytes = Bytes::copy_from_slice(full_data);
                            self.buffer.clear();
                            // TLS ClientHello must be forwarded verbatim to the upstream server
                            return Ok(TransducerOutput::ProxyForward(forward_bytes));
                        }
                        Err(TlsSniffError::Incomplete { needed: _ }) => {
                            if self.buffer.is_empty() {
                                self.buffer.extend_from_slice(data);
                            }
                            self.decision = Some(FlowDecision::Continue);
                            return Ok(TransducerOutput::Continue);
                        }
                        Err(_) => {
                            // Non-TLS or invalid TLS record; fallback to Direct
                            self.decision = Some(FlowDecision::Direct);
                            self.phase = TransducerPhase::Established;
                            self.buffer.clear();
                            return Ok(TransducerOutput::DirectForward);
                        }
                    }
                }

                // Protocol Signature 4: QUIC Initial Packet (Long Header bit 0x80)
                if (full_data[0] & 0x80) != 0 && full_data.len() >= 5 {
                    if let Ok(Some(sni)) = sniff_quic_initial_sni(full_data) {
                        self.decision = Some(FlowDecision::Proxy(format!("{}:443", sni)));
                        self.phase = TransducerPhase::Established;
                        let forward_bytes = Bytes::copy_from_slice(full_data);
                        self.buffer.clear();
                        return Ok(TransducerOutput::ProxyForward(forward_bytes));
                    }
                }

                // Default / Passthrough Fallback
                self.decision = Some(FlowDecision::Direct);
                self.phase = TransducerPhase::Established;
                self.buffer.clear();
                Ok(TransducerOutput::DirectForward)
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    /// Slowloris guard: an attacker dribbling an incomplete TLS / QUIC /
    /// HTTP-CONNECT handshake must not be able to grow the internal buffer
    /// past `MAX_HANDSHAKE_BUFFER`.
    #[test]
    fn test_unified_transducer_rejects_oversized_handshake_buffer() {
        let mut pt = ProtocolTransducer::new();

        // First chunk: a TLS record header that declares a huge body, so
        // the transducer buffers it and waits for more.
        let mut prefix = vec![0x16, 0x03, 0x01];
        prefix.extend_from_slice(&0xFFFFu16.to_be_bytes()); // record_len = 65535

        let res = pt.consume(&prefix);
        assert!(res.is_ok(), "first chunk should be accepted or buffered");

        // Feed well past the cap in 4 KiB chunks.
        let chunk = [0u8; 4096];
        let mut err_seen = false;
        for _ in 0..32 {
            match pt.consume(&chunk) {
                Ok(_) => {}
                Err(TransducerError::Protocol(msg)) => {
                    assert!(
                        msg.contains("slowloris"),
                        "unexpected protocol error: {msg}",
                    );
                    err_seen = true;
                    break;
                }
                Err(e) => panic!("unexpected error: {e}"),
            }
        }
        assert!(
            err_seen,
            "transducer must reject once buffer exceeds the cap",
        );

        // Once the transducer transitions to `Closed`, further input is
        // reported as `Terminate` (see `TransducerPhase::Closed`). The
        // reactor treats `Terminate` and `Err` identically — both tear
        // down the connection — so either outcome is a valid terminal
        // state.
        let after = pt.consume(&chunk);
        match after {
            Err(_) => {}
            Ok(TransducerOutput::Terminate) => {}
            other => panic!("expected Terminate or Err after Closed, got {other:?}"),
        }
    }
}
