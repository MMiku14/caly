//! Sans-I/O TLS ClientHello sniffer and extension extractor.
//!
//! Analyzes TLS records and ClientHello handshakes with zero heap allocations,
//! extracting Server Name Indication (SNI, RFC 6066) and Application-Layer
//! Protocol Negotiation (ALPN, RFC 7301).

use core::str;
use thiserror::Error;

/// TLS ContentType for Handshake records.
pub const TLS_CONTENT_TYPE_HANDSHAKE: u8 = 0x16;

/// TLS HandshakeType for ClientHello.
pub const TLS_HANDSHAKE_TYPE_CLIENT_HELLO: u8 = 0x01;

/// Extension type: Server Name Indication (RFC 6066).
pub const TLS_EXTENSION_SNI: u16 = 0x0000;

/// Extension type: Application-Layer Protocol Negotiation (RFC 7301).
pub const TLS_EXTENSION_ALPN: u16 = 0x0010;

/// Maximum number of ALPN protocol strings stored without heap allocation.
pub const MAX_ALPN_PROTOCOLS: usize = 8;

/// Extracted TLS ClientHello metadata.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ClientHelloInfo<'a> {
    /// Client legacy protocol version (e.g. (3, 3) for TLS 1.2 / TLS 1.3).
    pub legacy_version: (u8, u8),
    /// 32-byte client random.
    pub random: &'a [u8; 32],
    /// Client session ID.
    pub session_id: &'a [u8],
    /// Extracted Server Name Indication (SNI) hostname.
    pub sni: Option<&'a str>,
    /// Extracted ALPN protocol identifiers.
    pub alpn: [Option<&'a str>; MAX_ALPN_PROTOCOLS],
    /// Number of valid ALPN protocols stored in alpn.
    pub alpn_count: usize,
}

impl<'a> ClientHelloInfo<'a> {
    /// Returns an iterator over the extracted ALPN protocols.
    pub fn alpn_protocols(&self) -> impl Iterator<Item = &'a str> + '_ {
        self.alpn[..self.alpn_count].iter().filter_map(|&p| p)
    }

    /// Checks if a specific ALPN protocol was advertised (e.g. "h2").
    pub fn has_alpn(&self, protocol: &str) -> bool {
        self.alpn_protocols().any(|p| p == protocol)
    }
}

/// Errors occurring during TLS ClientHello sniffing.
#[derive(Debug, Error, PartialEq, Eq, Clone)]
pub enum TlsSniffError {
    /// Record or handshake requires more bytes to be fully parsed.
    #[error("Incomplete TLS data: need {needed} additional bytes")]
    Incomplete { needed: usize },

    /// First byte is not a TLS Handshake record (0x16).
    #[error("Not a TLS handshake record (content type: {0:#04x})")]
    NotTlsHandshake(u8),

    /// Handshake message type is not ClientHello (0x01).
    #[error("Not a ClientHello handshake message (type: {0:#04x})")]
    NotClientHello(u8),

    /// Structural corruption in TLS record or handshake extensions.
    #[error("Malformed TLS message: {0}")]
    Malformed(&'static str),
}

/// Parses a TLS ClientHello from a raw byte buffer.
///
/// Accepts either:
/// 1. A standard TLS Record starting with ContentType = 0x16 (5-byte header).
/// 2. A direct TLS Handshake message starting with HandshakeType = 0x01 (as used in QUIC CRYPTO frames).
///
/// Operates with zero heap allocations.
pub fn parse_client_hello(buf: &[u8]) -> Result<ClientHelloInfo<'_>, TlsSniffError> {
    if buf.is_empty() {
        return Err(TlsSniffError::Incomplete { needed: 5 });
    }

    if buf[0] == TLS_CONTENT_TYPE_HANDSHAKE {
        if buf.len() < 5 {
            return Err(TlsSniffError::Incomplete {
                needed: 5 - buf.len(),
            });
        }
        let record_len = u16::from_be_bytes([buf[3], buf[4]]) as usize;
        let total_record_len = 5 + record_len;

        if buf.len() < total_record_len {
            return Err(TlsSniffError::Incomplete {
                needed: total_record_len - buf.len(),
            });
        }

        parse_client_hello_handshake(&buf[5..total_record_len])
    } else if buf[0] == TLS_HANDSHAKE_TYPE_CLIENT_HELLO {
        parse_client_hello_handshake(buf)
    } else {
        Err(TlsSniffError::NotTlsHandshake(buf[0]))
    }
}

/// Parses the inner TLS Handshake payload starting with HandshakeType 0x01.
pub fn parse_client_hello_handshake(hs: &[u8]) -> Result<ClientHelloInfo<'_>, TlsSniffError> {
    if hs.len() < 4 {
        return Err(TlsSniffError::Incomplete {
            needed: 4 - hs.len(),
        });
    }

    if hs[0] != TLS_HANDSHAKE_TYPE_CLIENT_HELLO {
        return Err(TlsSniffError::NotClientHello(hs[0]));
    }

    let hs_len = ((hs[1] as usize) << 16) | ((hs[2] as usize) << 8) | (hs[3] as usize);
    let total_hs_len = 4 + hs_len;

    if hs.len() < total_hs_len {
        return Err(TlsSniffError::Incomplete {
            needed: total_hs_len - hs.len(),
        });
    }

    let slice = &hs[4..total_hs_len];

    // Minimum ClientHello size: Version (2) + Random (32) + SessionIdLen (1) = 35 bytes
    if slice.len() < 35 {
        return Err(TlsSniffError::Malformed("Truncated ClientHello header"));
    }

    let legacy_version = (slice[0], slice[1]);
    let random: &[u8; 32] = match slice[2..34].try_into() {
        Ok(r) => r,
        Err(_) => return Err(TlsSniffError::Malformed("Invalid random length")),
    };

    let sid_len = slice[34] as usize;
    let mut cursor = 35 + sid_len;

    if slice.len() < cursor {
        return Err(TlsSniffError::Malformed("Truncated session ID"));
    }
    let session_id = &slice[35..cursor];

    // Cipher Suites
    if slice.len() < cursor + 2 {
        return Err(TlsSniffError::Malformed("Missing cipher suites length"));
    }
    let cs_len = u16::from_be_bytes([slice[cursor], slice[cursor + 1]]) as usize;
    cursor += 2 + cs_len;

    if slice.len() < cursor + 1 {
        return Err(TlsSniffError::Malformed(
            "Missing compression methods length",
        ));
    }
    let comp_len = slice[cursor] as usize;
    cursor += 1 + comp_len;

    let mut sni = None;
    let mut alpn = [None; MAX_ALPN_PROTOCOLS];
    let mut alpn_count = 0;

    // Check if extensions exist
    if cursor < slice.len() {
        if slice.len() < cursor + 2 {
            return Err(TlsSniffError::Malformed("Truncated extensions length"));
        }
        let ext_total_len = u16::from_be_bytes([slice[cursor], slice[cursor + 1]]) as usize;
        cursor += 2;

        let ext_end = cursor + ext_total_len;
        if slice.len() < ext_end {
            return Err(TlsSniffError::Malformed("Truncated extensions body"));
        }

        while cursor + 4 <= ext_end {
            let ext_type = u16::from_be_bytes([slice[cursor], slice[cursor + 1]]);
            let ext_len = u16::from_be_bytes([slice[cursor + 2], slice[cursor + 3]]) as usize;
            cursor += 4;

            let ext_data_end = cursor + ext_len;
            if ext_data_end > ext_end {
                break;
            }

            let ext_data = &slice[cursor..ext_data_end];

            match ext_type {
                TLS_EXTENSION_SNI => {
                    if ext_data.len() >= 5 {
                        let list_len = u16::from_be_bytes([ext_data[0], ext_data[1]]) as usize;
                        if ext_data.len() >= 2 + list_len && list_len >= 3 {
                            let name_type = ext_data[2];
                            let name_len = u16::from_be_bytes([ext_data[3], ext_data[4]]) as usize;
                            if name_type == 0x00 && ext_data.len() >= 5 + name_len {
                                if let Ok(s) = str::from_utf8(&ext_data[5..5 + name_len]) {
                                    sni = Some(s);
                                }
                            }
                        }
                    }
                }
                TLS_EXTENSION_ALPN if ext_data.len() >= 2 => {
                    let list_len = u16::from_be_bytes([ext_data[0], ext_data[1]]) as usize;
                    let mut p_cursor = 2;
                    let p_end = (2 + list_len).min(ext_data.len());

                    while p_cursor < p_end {
                        let p_len = ext_data[p_cursor] as usize;
                        p_cursor += 1;
                        if p_cursor + p_len <= p_end {
                            if let Ok(proto) = str::from_utf8(&ext_data[p_cursor..p_cursor + p_len])
                            {
                                if alpn_count < MAX_ALPN_PROTOCOLS {
                                    alpn[alpn_count] = Some(proto);
                                    alpn_count += 1;
                                }
                            }
                            p_cursor += p_len;
                        } else {
                            break;
                        }
                    }
                }
                _ => {}
            }

            cursor = ext_data_end;
        }
    }

    Ok(ClientHelloInfo {
        legacy_version,
        random,
        session_id,
        sni,
        alpn,
        alpn_count,
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_tls_sniffer_all_prefix_truncations_do_not_panic() {
        // Build a minimal but fully valid ClientHello record.
        let mut hs_body = Vec::new();
        hs_body.extend_from_slice(&[0x03, 0x03]); // legacy version
        hs_body.extend_from_slice(&[0xAA; 32]); // random
        hs_body.push(0x00); // session id len
        hs_body.extend_from_slice(&[0x00, 0x02, 0x13, 0x01]); // cipher suites
        hs_body.extend_from_slice(&[0x01, 0x00]); // compression
        hs_body.extend_from_slice(&[0x00, 0x00]); // extensions len

        let mut hs = Vec::new();
        hs.push(TLS_HANDSHAKE_TYPE_CLIENT_HELLO);
        let len = hs_body.len();
        hs.push((len >> 16) as u8);
        hs.push((len >> 8) as u8);
        hs.push(len as u8);
        hs.extend_from_slice(&hs_body);

        let mut record = Vec::new();
        record.push(TLS_CONTENT_TYPE_HANDSHAKE);
        record.extend_from_slice(&[0x03, 0x01]);
        record.extend_from_slice(&(hs.len() as u16).to_be_bytes());
        record.extend_from_slice(&hs);

        // Full record must parse.
        assert!(parse_client_hello(&record).is_ok());

        // Every truncated prefix must Err, and must not panic.
        for cut in 0..record.len() {
            let res = std::panic::catch_unwind(|| parse_client_hello(&record[..cut]));
            assert!(res.is_ok(), "panic at cut={cut}");
            assert!(res.unwrap().is_err(), "unexpected success at cut={cut}");
        }
    }

    #[test]
    fn test_tls_sniffer_max_alpn_protocols() {
        // Provide MAX_ALPN_PROTOCOLS + 4 entries; only the first
        // MAX_ALPN_PROTOCOLS must be recorded, without panic.
        let extra = 4usize;
        let total = MAX_ALPN_PROTOCOLS + extra;

        // Build ALPN extension.
        let mut alpn_list = Vec::new();
        for i in 0..total {
            let proto = format!("p{i:02}");
            alpn_list.push(proto.len() as u8);
            alpn_list.extend_from_slice(proto.as_bytes());
        }
        let mut alpn_ext = Vec::new();
        alpn_ext.extend_from_slice(&TLS_EXTENSION_ALPN.to_be_bytes());
        let alpn_ext_len = 2 + alpn_list.len();
        alpn_ext.extend_from_slice(&(alpn_ext_len as u16).to_be_bytes());
        alpn_ext.extend_from_slice(&(alpn_list.len() as u16).to_be_bytes());
        alpn_ext.extend_from_slice(&alpn_list);

        // Wrap into a minimal ClientHello handshake.
        let mut hs_body = Vec::new();
        hs_body.extend_from_slice(&[0x03, 0x03]);
        hs_body.extend_from_slice(&[0xBB; 32]);
        hs_body.push(0x00);
        hs_body.extend_from_slice(&[0x00, 0x02, 0x13, 0x01]);
        hs_body.extend_from_slice(&[0x01, 0x00]);
        hs_body.extend_from_slice(&(alpn_ext.len() as u16).to_be_bytes());
        hs_body.extend_from_slice(&alpn_ext);

        let mut hs = Vec::new();
        hs.push(TLS_HANDSHAKE_TYPE_CLIENT_HELLO);
        let len = hs_body.len();
        hs.push((len >> 16) as u8);
        hs.push((len >> 8) as u8);
        hs.push(len as u8);
        hs.extend_from_slice(&hs_body);

        let info = parse_client_hello_handshake(&hs).expect("parse");
        assert_eq!(info.alpn_count, MAX_ALPN_PROTOCOLS);
        assert!(info.has_alpn("p00"));
        assert!(info.has_alpn("p07"));
        // Beyond-MAX entries must not appear.
        assert!(!info.has_alpn("p08"));
    }
}
