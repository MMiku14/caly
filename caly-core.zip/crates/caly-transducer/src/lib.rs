// `workspace-hack` is a cargo-hakari synthetic crate that unifies
// feature resolution across the workspace. It is intentionally
// never `use`d by any source file, so the standard
// `unused_crate_dependencies` lint does not apply here.
#![allow(unused_crate_dependencies)]
//! `caly-transducer`: High-performance Sans-I/O Protocol Transducers & Session Automata.
//!
//! Provides zero-allocation, sans-I/O protocol state machines, session types,
//! and sniffing logic for SOCKS5, HTTP CONNECT, TLS ClientHello SNI/ALPN, and QUIC Initial packets.

#![deny(unsafe_op_in_unsafe_fn)]
#![warn(clippy::undocumented_unsafe_blocks)]
#![warn(clippy::multiple_unsafe_ops_per_block)]
#![allow(unsafe_code)]

pub mod http_connect;
pub mod quic_sniffer;
pub mod session_types;
pub mod socks5;
pub mod tls_sniffer;
pub mod unified;

/// Shared test-support helpers. Currently only used to centralize proptest
/// configuration so that Miri (which does not support `getcwd` under
/// isolation) does not trip proptest's built-in file-based failure
/// persistence.
#[cfg(test)]
pub(crate) mod test_support {
    /// Returns a `proptest` config with `cases` case budget.
    ///
    /// Under Miri we additionally:
    /// * disable `FileFailurePersistence` (avoids `getcwd` and file IO), and
    /// * clamp the case count to a small value (the interpreter is ~100x
    ///   slower than native, and proptest cases dominate the runtime).
    pub(crate) fn proptest_config(cases: u32) -> proptest::test_runner::Config {
        let mut cfg = proptest::test_runner::Config::default();
        cfg.cases = cases;
        #[cfg(miri)]
        {
            cfg.failure_persistence = None;
            cfg.cases = cfg.cases.min(16);
        }
        cfg
    }
}

pub use http_connect::{
    parse_connect_request, HttpConnectError, HttpConnectRequest, HttpConnectResponse, HttpHeader,
    MAX_HEADERS,
};
pub use quic_sniffer::{
    encode_varint, extract_quic_sni, find_crypto_frame, parse_crypto_frame,
    parse_quic_initial_header, parse_varint, sniff_quic_initial_sni, QuicCryptoFrame,
    QuicInitialHeader, QuicSniffError,
};
pub use session_types::{protocol_states, ProtocolWire, WireError};
pub use socks5::{
    auth_methods, create_auth_response, create_reply_buffer, parse_client_greeting,
    parse_client_request, write_reply, AddressType, ClientGreeting, HandshakePhase, ReplyStatus,
    Socks5Addr, Socks5Command, Socks5Error, Socks5ReplyBuffer, Socks5Request, Socks5Target,
    Socks5Transducer, TransducerStep, SOCKS_VERSION,
};
pub use tls_sniffer::{
    parse_client_hello, parse_client_hello_handshake, ClientHelloInfo, TlsSniffError,
    MAX_ALPN_PROTOCOLS, TLS_CONTENT_TYPE_HANDSHAKE, TLS_EXTENSION_ALPN, TLS_EXTENSION_SNI,
    TLS_HANDSHAKE_TYPE_CLIENT_HELLO,
};
pub use unified::{FlowDecision, ProtocolTransducer, TransducerError, TransducerOutput};

#[cfg(test)]
mod tests {
    use super::*;

    // =========================================================================
    // Unified Protocol Transducer Tests
    // =========================================================================
    #[test]
    fn test_unified_transducer_socks5() {
        let mut pt = ProtocolTransducer::new();
        assert_eq!(pt.decision(), None);

        // 1. SOCKS5 greeting
        let greet = [0x05, 0x01, 0x00];
        let out = pt.consume(&greet).expect("consume greeting");
        assert!(matches!(out, TransducerOutput::Continue));
        assert_eq!(pt.decision(), Some(FlowDecision::Continue));
        let reply = pt.take_client_reply().expect("client reply");
        assert_eq!(&reply[..], &[0x05, 0x00]);

        // 2. SOCKS5 connect request: 127.0.0.1:1080
        let req = [
            0x05, 0x01, 0x00, 0x01, // VER, CMD=1, RSV, ATYP=1
            127, 0, 0, 1, // 127.0.0.1
            0x04, 0x38, // 1080
        ];
        let out = pt.consume(&req).expect("consume request");
        assert!(matches!(out, TransducerOutput::Continue));
        assert_eq!(
            pt.decision(),
            Some(FlowDecision::Proxy("127.0.0.1:1080".into()))
        );
        let reply = pt.take_client_reply().expect("success reply");
        assert_eq!(reply[0], 0x05);
        assert_eq!(reply[1], 0x00); // Succeeded
        assert!(pt.is_established());

        // 3. Established payload forwarding
        let payload = b"Hello upstream";
        let out = pt.consume(payload).expect("consume payload");
        match out {
            TransducerOutput::ProxyForward(bytes) => assert_eq!(&bytes[..], payload),
            _ => panic!("Expected ProxyForward"),
        }
    }

    #[test]
    fn test_unified_transducer_http_connect() {
        let mut pt = ProtocolTransducer::new();
        let raw = b"CONNECT proxy.example.com:8443 HTTP/1.1\r\nHost: proxy.example.com:8443\r\n\r\nExtraPayload";
        let out = pt.consume(raw).expect("consume http connect");
        assert_eq!(
            pt.decision(),
            Some(FlowDecision::Proxy("proxy.example.com:8443".into()))
        );
        match out {
            TransducerOutput::ProxyForward(bytes) => assert_eq!(&bytes[..], b"ExtraPayload"),
            _ => panic!("Expected ProxyForward with ExtraPayload"),
        }
        let reply = pt.take_client_reply().expect("http 200 reply");
        assert!(reply.starts_with(b"HTTP/1.1 200 Connection Established"));
        assert!(pt.is_established());
    }

    #[test]
    fn test_unified_transducer_direct_fallback() {
        let mut pt = ProtocolTransducer::new();
        let raw = b"SSH-2.0-OpenSSH_9.3\r\n";
        let out = pt.consume(raw).expect("consume direct");
        assert_eq!(pt.decision(), Some(FlowDecision::Direct));
        assert!(matches!(out, TransducerOutput::DirectForward));
        assert!(pt.is_established());
    }

    // =========================================================================
    // 1. Session Types Affine Automata Tests
    // =========================================================================
    #[test]
    fn test_session_types_linear_transitions() {
        let wire = ProtocolWire::new(100);
        assert_eq!(wire.raw_fd(), 100);

        let methods = [0x00, 0x02];
        let wire = wire.accept_client_greet(&methods).expect("greet accepted");

        let (wire, resp) = wire.select_no_auth();
        assert_eq!(resp, [0x05, 0x00]);

        let wire = wire.transition_to_relay();
        let closed = wire.close();
        assert_eq!(closed.into_raw_fd(), 100);
    }

    #[test]
    fn test_session_types_username_password_flow() {
        let wire = ProtocolWire::new(101);
        let wire = wire.accept_client_greet(&[0x02]).expect("methods accepted");

        let (wire, resp) = wire.select_username_password();
        assert_eq!(resp, [0x05, 0x02]);

        let wire = wire.finish_authentication();
        let wire = wire.transition_to_relay();
        let closed = wire.close();
        assert_eq!(closed.into_raw_fd(), 101);
    }

    #[test]
    fn test_session_types_empty_greet_error() {
        let wire = ProtocolWire::new(102);
        let err = wire.accept_client_greet(&[]).unwrap_err();
        assert_eq!(err, WireError::NoAcceptableMethods);
    }

    // =========================================================================
    // 2. SOCKS5 Parsing & Transducer Tests
    // =========================================================================
    #[test]
    fn test_socks5_greeting_parsing() {
        let raw = [0x05, 0x02, 0x00, 0x02];
        let (consumed, greet) = parse_client_greeting(&raw).expect("valid greeting");
        assert_eq!(consumed, 4);
        assert!(greet.supports_no_auth());
        assert!(greet.supports_user_pass());
        assert!(!greet.supports_method(0x01));

        let incomplete = [0x05, 0x03, 0x00];
        let err = parse_client_greeting(&incomplete).unwrap_err();
        assert_eq!(err, Socks5Error::Incomplete { needed: 2 });

        let invalid_ver = [0x04, 0x01, 0x00];
        let err = parse_client_greeting(&invalid_ver).unwrap_err();
        assert_eq!(err, Socks5Error::UnsupportedVersion(0x04));
    }

    #[test]
    fn test_socks5_request_ipv4() {
        let raw = [0x05, 0x01, 0x00, 0x01, 127, 0, 0, 1, 0x1F, 0x90];
        let (consumed, req) = parse_client_request(&raw).expect("valid ipv4 request");
        assert_eq!(consumed, 10);
        assert_eq!(req.cmd, Socks5Command::Connect);
        assert_eq!(req.target.port, 8080);
        assert_eq!(req.target.addr, Socks5Addr::Ipv4([127, 0, 0, 1]));
        assert_eq!(req.target.to_string(), "127.0.0.1:8080");
    }

    #[test]
    fn test_socks5_request_domain() {
        let domain = b"example.com";
        let mut raw = Vec::new();
        raw.extend_from_slice(&[0x05, 0x01, 0x00, 0x03, domain.len() as u8]);
        raw.extend_from_slice(domain);
        raw.extend_from_slice(&443u16.to_be_bytes());

        let (consumed, req) = parse_client_request(&raw).expect("valid domain request");
        assert_eq!(consumed, 4 + 1 + domain.len() + 2);
        assert_eq!(req.cmd, Socks5Command::Connect);
        assert_eq!(req.target.port, 443);
        assert_eq!(req.target.addr, Socks5Addr::Domain("example.com"));
        assert_eq!(req.target.to_string(), "example.com:443");
    }

    #[test]
    fn test_socks5_request_ipv6() {
        let mut raw = vec![0x05, 0x03, 0x00, 0x04];
        let ip_bytes = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1];
        raw.extend_from_slice(&ip_bytes);
        raw.extend_from_slice(&1080u16.to_be_bytes());

        let (consumed, req) = parse_client_request(&raw).expect("valid ipv6 request");
        assert_eq!(consumed, 22);
        assert_eq!(req.cmd, Socks5Command::UdpAssociate);
        assert_eq!(req.target.port, 1080);
        assert_eq!(req.target.addr, Socks5Addr::Ipv6(ip_bytes));
        assert_eq!(req.target.to_string(), "[::1]:1080");
    }

    #[test]
    fn test_socks5_reply_serialization() {
        let addr = Socks5Addr::Ipv4([0, 0, 0, 0]);
        let reply = create_reply_buffer(ReplyStatus::Succeeded, &addr, 1080);
        let bytes = reply.as_slice();
        assert_eq!(bytes.len(), 10);
        assert_eq!(bytes[0], 0x05);
        assert_eq!(bytes[1], 0x00);
        assert_eq!(bytes[2], 0x00);
        assert_eq!(bytes[3], 0x01);
        assert_eq!(&bytes[4..8], &[0, 0, 0, 0]);
        assert_eq!(u16::from_be_bytes([bytes[8], bytes[9]]), 1080);
    }

    #[test]
    fn test_socks5_transducer_lifecycle() {
        let mut transducer = Socks5Transducer::new();
        assert_eq!(transducer.phase(), HandshakePhase::Initial);

        let greet_raw = [0x05, 0x01, 0x00];
        match transducer.step(&greet_raw).unwrap() {
            TransducerStep::GreetingDone { consumed, greeting } => {
                assert_eq!(consumed, 3);
                assert!(greeting.supports_no_auth());
            }
            _ => panic!("Expected GreetingDone"),
        }

        transducer.set_auth_negotiated();
        assert_eq!(transducer.phase(), HandshakePhase::AuthNegotiated);

        let req_raw = [0x05, 0x01, 0x00, 0x01, 10, 0, 0, 1, 0x00, 0x50];
        match transducer.step(&req_raw).unwrap() {
            TransducerStep::RequestDone { consumed, request } => {
                assert_eq!(consumed, 10);
                assert_eq!(request.cmd, Socks5Command::Connect);
                assert_eq!(request.target.port, 80);
            }
            _ => panic!("Expected RequestDone"),
        }

        transducer.set_established();
        assert_eq!(transducer.phase(), HandshakePhase::Established);
    }

    // =========================================================================
    // 3. HTTP CONNECT Proxy Parser Tests
    // =========================================================================
    #[test]
    fn test_http_connect_standard() {
        let raw = b"CONNECT example.com:443 HTTP/1.1\r\nHost: example.com:443\r\nUser-Agent: caly-core/4.0\r\nProxy-Connection: Keep-Alive\r\n\r\n";
        let (consumed, req) = parse_connect_request(raw).expect("parse http connect");

        assert_eq!(consumed, raw.len());
        assert_eq!(req.host, "example.com");
        assert_eq!(req.port, 443);
        assert_eq!(req.http_version, "HTTP/1.1");
        assert_eq!(req.raw_target, "example.com:443");
        assert_eq!(req.get_header("Host"), Some("example.com:443"));
        assert_eq!(req.get_header("user-agent"), Some("caly-core/4.0"));
        assert_eq!(req.get_header("proxy-connection"), Some("Keep-Alive"));
        assert_eq!(req.get_header("non-existent"), None);

        assert_eq!(
            HttpConnectResponse::connection_established(),
            b"HTTP/1.1 200 Connection Established\r\n\r\n"
        );
    }

    #[test]
    fn test_http_connect_ipv6_and_defaults() {
        let raw = b"CONNECT [2001:db8::1]:8443 HTTP/1.1\r\nHost: [2001:db8::1]:8443\r\n\r\n";
        let (consumed, req) = parse_connect_request(raw).expect("parse ipv6 connect");

        assert_eq!(consumed, raw.len());
        assert_eq!(req.host, "2001:db8::1");
        assert_eq!(req.port, 8443);

        let raw2 = b"CONNECT proxy.local HTTP/1.1\r\n\r\n";
        let (_, req2) = parse_connect_request(raw2).expect("parse default port");
        assert_eq!(req2.host, "proxy.local");
        assert_eq!(req2.port, 443);
    }

    #[test]
    fn test_http_connect_errors() {
        let incomplete = b"CONNECT example.com:443 HTTP/1.1\r\nHost: example.com";
        assert_eq!(
            parse_connect_request(incomplete).unwrap_err(),
            HttpConnectError::Incomplete
        );

        let invalid_method = b"GET /index.html HTTP/1.1\r\nHost: example.com\r\n\r\n";
        assert!(matches!(
            parse_connect_request(invalid_method).unwrap_err(),
            HttpConnectError::InvalidMethod(_)
        ));
    }

    // =========================================================================
    // 4. TLS ClientHello SNI & ALPN Sniffer Tests
    // =========================================================================
    #[test]
    fn test_tls_client_hello_sni_and_alpn() {
        let sni_str = b"caly.network";
        let mut sni_ext = Vec::new();
        sni_ext.extend_from_slice(&TLS_EXTENSION_SNI.to_be_bytes());
        let sni_entry_len = 1 + 2 + sni_str.len();
        let sni_list_len = sni_entry_len;
        let sni_data_len = 2 + sni_list_len;
        sni_ext.extend_from_slice(&(sni_data_len as u16).to_be_bytes());
        sni_ext.extend_from_slice(&(sni_list_len as u16).to_be_bytes());
        sni_ext.push(0x00);
        sni_ext.extend_from_slice(&(sni_str.len() as u16).to_be_bytes());
        sni_ext.extend_from_slice(sni_str);

        let mut alpn_ext = Vec::new();
        alpn_ext.extend_from_slice(&TLS_EXTENSION_ALPN.to_be_bytes());
        let alpn_list = b"\x02h2\x08http/1.1";
        let alpn_ext_len = 2 + alpn_list.len();
        alpn_ext.extend_from_slice(&(alpn_ext_len as u16).to_be_bytes());
        alpn_ext.extend_from_slice(&(alpn_list.len() as u16).to_be_bytes());
        alpn_ext.extend_from_slice(alpn_list);

        let mut extensions = Vec::new();
        extensions.extend_from_slice(&sni_ext);
        extensions.extend_from_slice(&alpn_ext);

        let mut hs_body = Vec::new();
        hs_body.extend_from_slice(&[0x03, 0x03]);
        hs_body.extend_from_slice(&[0xAA; 32]);
        hs_body.push(0x00);
        hs_body.extend_from_slice(&[0x00, 0x02, 0x13, 0x01]);
        hs_body.extend_from_slice(&[0x01, 0x00]);
        hs_body.extend_from_slice(&(extensions.len() as u16).to_be_bytes());
        hs_body.extend_from_slice(&extensions);

        let mut hs = Vec::new();
        hs.push(TLS_HANDSHAKE_TYPE_CLIENT_HELLO);
        let hs_len = hs_body.len();
        hs.push((hs_len >> 16) as u8);
        hs.push((hs_len >> 8) as u8);
        hs.push(hs_len as u8);
        hs.extend_from_slice(&hs_body);

        let mut record = Vec::new();
        record.push(TLS_CONTENT_TYPE_HANDSHAKE);
        record.extend_from_slice(&[0x03, 0x01]);
        record.extend_from_slice(&(hs.len() as u16).to_be_bytes());
        record.extend_from_slice(&hs);

        let info = parse_client_hello(&record).expect("parse tls client hello record");
        assert_eq!(info.sni, Some("caly.network"));
        assert!(info.has_alpn("h2"));
        assert!(info.has_alpn("http/1.1"));
        assert!(!info.has_alpn("spdy/3.1"));

        let direct_info = parse_client_hello(&hs).expect("parse direct client hello");
        assert_eq!(direct_info.sni, Some("caly.network"));
        assert!(direct_info.has_alpn("h2"));
    }

    // =========================================================================
    // 5. QUIC Initial Packet & Varint Tests
    // =========================================================================
    #[test]
    fn test_quic_varint_roundtrip() {
        let test_values = [
            0u64,
            42,
            63,
            64,
            15213,
            16383,
            16384,
            1073741823,
            1073741824,
            4611686018427387903,
        ];
        let mut buf = [0u8; 8];

        for &val in &test_values {
            let encoded_len = encode_varint(val, &mut buf).expect("varint encodes");
            let (decoded_len, decoded_val) =
                parse_varint(&buf[..encoded_len]).expect("varint decodes");
            assert_eq!(encoded_len, decoded_len);
            assert_eq!(val, decoded_val);
        }
    }

    #[test]
    fn test_quic_initial_header_and_crypto_sni() {
        let dcid = [0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08];
        let scid = [0xAA, 0xBB, 0xCC, 0xDD];
        let token = b"token123";

        let sni_str = b"quic.caly.io";
        let mut sni_ext = Vec::new();
        sni_ext.extend_from_slice(&TLS_EXTENSION_SNI.to_be_bytes());
        let sni_data_len = 2 + 1 + 2 + sni_str.len();
        sni_ext.extend_from_slice(&(sni_data_len as u16).to_be_bytes());
        sni_ext.extend_from_slice(&((1 + 2 + sni_str.len()) as u16).to_be_bytes());
        sni_ext.push(0x00);
        sni_ext.extend_from_slice(&(sni_str.len() as u16).to_be_bytes());
        sni_ext.extend_from_slice(sni_str);

        let mut hs_body = Vec::new();
        hs_body.extend_from_slice(&[0x03, 0x03]);
        hs_body.extend_from_slice(&[0x55; 32]);
        hs_body.push(0x00);
        hs_body.extend_from_slice(&[0x00, 0x02, 0x13, 0x01]);
        hs_body.extend_from_slice(&[0x01, 0x00]);
        hs_body.extend_from_slice(&(sni_ext.len() as u16).to_be_bytes());
        hs_body.extend_from_slice(&sni_ext);

        let mut hs = Vec::new();
        hs.push(TLS_HANDSHAKE_TYPE_CLIENT_HELLO);
        let hs_len = hs_body.len();
        hs.push((hs_len >> 16) as u8);
        hs.push((hs_len >> 8) as u8);
        hs.push(hs_len as u8);
        hs.extend_from_slice(&hs_body);

        let mut crypto_frame = Vec::new();
        crypto_frame.push(0x06); // QUIC CRYPTO frame
        let mut varint_buf = [0u8; 8];
        let vlen = encode_varint(0, &mut varint_buf).unwrap();
        crypto_frame.extend_from_slice(&varint_buf[..vlen]);
        let vlen = encode_varint(hs.len() as u64, &mut varint_buf).unwrap();
        crypto_frame.extend_from_slice(&varint_buf[..vlen]);
        crypto_frame.extend_from_slice(&hs);

        let mut payload = vec![0x00, 0x00, 0x00, 0x00];
        payload.extend_from_slice(&crypto_frame);

        let mut packet = Vec::new();
        packet.push(0xC0);
        packet.extend_from_slice(&1u32.to_be_bytes());
        packet.push(dcid.len() as u8);
        packet.extend_from_slice(&dcid);
        packet.push(scid.len() as u8);
        packet.extend_from_slice(&scid);

        let vlen = encode_varint(token.len() as u64, &mut varint_buf).unwrap();
        packet.extend_from_slice(&varint_buf[..vlen]);
        packet.extend_from_slice(token);

        // RFC 9000 §17.2.2: the `Length` field covers the Packet Number
        // plus the (encrypted) payload. We declare 2 bytes for the Packet
        // Number placeholder and must physically append them, otherwise
        // the strict `parse_quic_initial_header` rejects the datagram as
        // `Incomplete` — an earlier truncated-accepting parser was masking
        // exactly this class of malformed packet.
        let total_payload_len = payload.len() + 2;
        let vlen = encode_varint(total_payload_len as u64, &mut varint_buf).unwrap();
        packet.extend_from_slice(&varint_buf[..vlen]);
        packet.extend_from_slice(&payload);
        packet.extend_from_slice(&[0u8; 2]); // Packet Number placeholder

        let header = parse_quic_initial_header(&packet).expect("quic initial header");
        assert_eq!(header.version, 1);
        assert_eq!(header.dcid, &dcid);
        assert_eq!(header.scid, &scid);
        assert_eq!(header.token, token);

        let sniffed_sni = sniff_quic_initial_sni(&packet).expect("sniff quic sni");
        assert_eq!(sniffed_sni, Some("quic.caly.io"));
    }

    #[test]
    fn test_socks5_truncated_at_every_boundary() {
        // Every prefix of a valid request must either NeedMoreData or error,
        // never panic and never claim success.
        let full = [0x05, 0x01, 0x00, 0x01, 127, 0, 0, 1, 0x1F, 0x90];
        for cut in 0..full.len() {
            let mut t = Socks5Transducer::new();
            let res = t.step(&full[..cut]);
            assert!(res.is_ok(), "cut={cut}: unexpected Err on truncated input");
        }
    }

    #[test]
    fn test_http_connect_header_count_bound() {
        // Exactly MAX_HEADERS+10 headers; must parse first MAX_HEADERS.
        let mut raw = Vec::new();
        raw.extend_from_slice(b"CONNECT example.com:443 HTTP/1.1\r\n");
        for i in 0..(MAX_HEADERS + 10) {
            raw.extend_from_slice(format!("X-Custom-{i}: v\r\n").as_bytes());
        }
        raw.extend_from_slice(b"\r\n");

        let (_, req) = parse_connect_request(&raw).expect("parse");
        assert_eq!(req.header_count(), MAX_HEADERS);
    }

    #[test]
    fn test_unified_transducer_empty_input_is_continue() {
        let mut pt = ProtocolTransducer::new();
        let out = pt.consume(b"").unwrap();
        assert!(matches!(out, TransducerOutput::Continue));
    }
}
