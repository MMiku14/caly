//! QSBR (Quiescent State Based Reclamation) Wait-Free RCU Coordinator.

pub use crate::hierarchical_qsbr::{HierarchicalQsbrCoordinator, NumaNodeQsbr};

use parking_lot::{Mutex, RwLock};
use std::collections::VecDeque;
use std::sync::atomic::{AtomicBool, AtomicU64, Ordering};
use std::sync::Arc;

/// Per-core QSBR registration and state handle.
pub struct QsbrCoreHandle {
    pub current_epoch: AtomicU64,
    pub active: AtomicBool,
    core_id: usize,
}

impl QsbrCoreHandle {
    pub fn new(core_id: usize, initial_epoch: u64) -> Self {
        Self {
            current_epoch: AtomicU64::new(initial_epoch),
            active: AtomicBool::new(true),
            core_id,
        }
    }

    #[inline]
    pub fn core_id(&self) -> usize {
        self.core_id
    }

    #[inline]
    pub fn epoch(&self) -> u64 {
        self.current_epoch.load(Ordering::Acquire)
    }

    #[inline]
    pub fn is_active(&self) -> bool {
        self.active.load(Ordering::Acquire)
    }

    /// Announces that this core has passed a quiescent state and reached the given epoch.
    #[inline(always)]
    pub fn quiescent_state(&self, epoch: u64) {
        self.current_epoch.store(epoch, Ordering::Release);
    }

    /// Marks this core as offline/inactive, allowing reclamation without waiting on it.
    #[inline]
    pub fn offline(&self) {
        self.active.store(false, Ordering::Release);
    }

    /// Re-activates this core with the latest global epoch.
    #[inline]
    pub fn online(&self, epoch: u64) {
        self.current_epoch.store(epoch, Ordering::Release);
        self.active.store(true, Ordering::Release);
    }
}

struct RetiredItem {
    generation: u64,
    reclaimer: Box<dyn FnOnce() + Send + 'static>,
}

/// Global QSBR coordinator tracking epochs and deferred memory reclamation.
pub struct QsbrCoordinator {
    pub global_epoch: AtomicU64,
    pub core_handles: RwLock<Vec<Arc<QsbrCoreHandle>>>,
    retirement_queue: Mutex<VecDeque<RetiredItem>>,
}

impl QsbrCoordinator {
    pub fn new() -> Self {
        Self {
            global_epoch: AtomicU64::new(1),
            core_handles: RwLock::new(Vec::new()),
            retirement_queue: Mutex::new(VecDeque::new()),
        }
    }

    #[inline]
    pub fn global_epoch(&self) -> u64 {
        self.global_epoch.load(Ordering::Acquire)
    }

    /// Registers a new core handle into the coordinator.
    pub fn register_core(&self, core_id: usize) -> Arc<QsbrCoreHandle> {
        let current_epoch = self.global_epoch();
        let handle = Arc::new(QsbrCoreHandle::new(core_id, current_epoch));
        self.core_handles.write().push(handle.clone());
        handle
    }

    /// Advances the global epoch monotonically.
    #[inline]
    pub fn advance_epoch(&self) -> u64 {
        self.global_epoch.fetch_add(1, Ordering::AcqRel) + 1
    }

    /// Checks whether all active cores have witnessed an epoch >= retired_generation.
    pub fn try_reclaim(&self, retired_generation: u64) -> bool {
        let handles = self.core_handles.read();
        for handle in handles.iter() {
            if handle.is_active() && handle.epoch() < retired_generation {
                return false;
            }
        }
        true
    }

    /// Retires an object with a destructor closure to be executed once quiescent quiet-period passes.
    pub fn retire<T: Send + 'static>(&self, item: T) {
        let gen = self.global_epoch();
        let reclaimer = Box::new(move || {
            drop(item);
        });

        self.retirement_queue.lock().push_back(RetiredItem {
            generation: gen,
            reclaimer,
        });
    }

    /// Explicitly binds retired item to a known invalidation generation epoch.
    pub fn retire_at_epoch(&self, epoch: u64, reclaimer: Box<dyn FnOnce() + Send + 'static>) {
        self.retirement_queue.lock().push_back(RetiredItem {
            generation: epoch,
            reclaimer,
        });
    }
    /// Polls and reclaims all retired items whose quiescent period has completed.
    ///
    /// The reclaimer closure is invoked **after** the queue mutex is released.
    /// Holding the lock while running arbitrary user code risks a deadlock:
    /// a reclaimer may drop a type whose `Drop` retires another item (e.g.
    /// dropping a `ConfigRcu` whose `Drop` retires its current config),
    /// which would try to re-acquire the same mutex and hang the thread.
    pub fn poll_reclaim(&self) -> usize {
        // Snapshot every eligible item in a single pass. The earlier
        // implementation only inspected `queue.front()`: a single entry
        // retired at a newer epoch blocked every older, already-quiescent
        // entry behind it, indefinitely delaying reclamation whenever
        // retirements arrived out of order (which the orchestrator
        // produces whenever a hot reload and a drop interleave).
        let eligible: Vec<RetiredItem> = {
            let mut queue = self.retirement_queue.lock();
            let mut eligible = Vec::with_capacity(queue.len());
            let mut pending = VecDeque::with_capacity(queue.len());
            while let Some(item) = queue.pop_front() {
                if self.try_reclaim(item.generation) {
                    eligible.push(item);
                } else {
                    pending.push_back(item);
                }
            }
            *queue = pending;
            eligible
        };

        // Run the reclaimer closures with the lock released: a reclaimer
        // may drop a value whose `Drop` retires another item (e.g.
        // dropping a `ConfigRcu`), which would re-enter
        // `retirement_queue.lock()` and deadlock.
        let n = eligible.len();
        for item in eligible {
            (item.reclaimer)();
        }
        n
    }

    #[inline]
    pub fn pending_reclamations(&self) -> usize {
        self.retirement_queue.lock().len()
    }
}

impl Default for QsbrCoordinator {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    /// A reclaimer closure that retires another item must not deadlock.
    /// This is the regression test for the "poll_reclaim holds the queue
    /// lock while running user code" bug.
    #[test]
    fn test_poll_reclaim_reentrant_retire_does_not_deadlock() {
        use std::sync::atomic::{AtomicBool, Ordering};
        use std::sync::Arc;

        let coord = Arc::new(QsbrCoordinator::new());
        let core = coord.register_core(0);

        let inner_ran = Arc::new(AtomicBool::new(false));
        let inner_ran_clone = inner_ran.clone();
        let coord_for_closure = coord.clone();

        // Outer retire: on reclaim, retire an inner item.
        let ep1 = coord.advance_epoch();
        coord.retire_at_epoch(
            ep1,
            Box::new(move || {
                // Re-entrant retire from inside the reclaimer. If
                // `poll_reclaim` still held the queue mutex, this call
                // would deadlock.
                let ep_inner = coord_for_closure.advance_epoch();
                coord_for_closure.retire_at_epoch(
                    ep_inner,
                    Box::new(move || {
                        inner_ran_clone.store(true, Ordering::Release);
                    }),
                );
            }),
        );

        // Make everything quiescent, then poll twice:
        //   First poll drops the outer item (which enqueues the inner one).
        //   Second poll drops the inner item.
        core.quiescent_state(coord.global_epoch());
        assert_eq!(coord.poll_reclaim(), 1, "outer item should be reclaimed");

        core.quiescent_state(coord.global_epoch());
        assert_eq!(coord.poll_reclaim(), 1, "inner item should be reclaimed");

        assert!(inner_ran.load(Ordering::Acquire));
    }
}
