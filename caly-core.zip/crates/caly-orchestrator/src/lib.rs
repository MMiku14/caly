// `workspace-hack` is a cargo-hakari synthetic crate that unifies
// feature resolution across the workspace. It is intentionally
// never `use`d by any source file, so the standard
// `unused_crate_dependencies` lint does not apply here.
#![allow(unused_crate_dependencies)]
//! Caly-Orchestrator: Multi-Core Reactor Initialization, Hierarchical QSBR,
//! Speculative Continuous Feedback DNS Pipeline, and Dynamic Outbound Dialing Engine.

#![deny(unsafe_op_in_unsafe_fn)]
#![warn(clippy::undocumented_unsafe_blocks)]
#![warn(clippy::multiple_unsafe_ops_per_block)]
pub mod config_rcu;
pub mod drain;
pub mod hierarchical_qsbr;
pub mod outbound;
pub mod qsbr;

pub use config_rcu::ConfigRcu;
pub use drain::{DrainConfig, DrainController, DrainError, DrainReport};
pub use hierarchical_qsbr::{HierarchicalQsbrCoordinator, NumaNodeQsbr};
pub use outbound::{OutboundDialer, OutboundError, OutboundSession, OutboundState};
pub use qsbr::{QsbrCoordinator, QsbrCoreHandle};

// Re-exports from sub-crates for convenient orchestrator consumption
pub use caly_memory::{ColorPartition, HugePageArena};
pub use caly_reactor::token::{IoOperation, IoToken};
pub use caly_spatial::dns_pipeline::SpeculativeDnsPipeline;
pub use caly_spatial::{
    BddEngine, DnsIndependence, Protocol, RouteAction, RouteDecision, RouteQuery, RouterConfig,
    SpatialRouter, SpatialRule,
};

use std::collections::HashMap;
use std::net::IpAddr;
use std::sync::atomic::{AtomicBool, AtomicUsize, Ordering};
use std::sync::Arc;
use std::thread::{self, JoinHandle};
use thiserror::Error;

use caly_reactor::{pin_to_core, CoreReactor, CoreReactorConfig, ReactorError};

#[derive(Error, Debug)]
pub enum OrchestratorError {
    #[error("Reactor initialization error: {0}")]
    Reactor(#[from] ReactorError),
    #[error("Drain error: {0}")]
    Drain(#[from] DrainError),
    #[error("Outbound error: {0}")]
    Outbound(#[from] OutboundError),
    #[error("Configuration error: {0}")]
    Config(String),
}

/// Daemon and Engine Configuration for Caly Core.
#[derive(Debug, Clone)]
pub struct OrchestratorConfig {
    pub core_ids: Vec<usize>,
    pub numa_nodes: Vec<usize>,
    pub core_numa_map: HashMap<usize, usize>,
    pub hugepage_arena_bytes: usize,
    pub router_config: RouterConfig,
    pub default_dns_ttl_secs: u64,
}

impl Default for OrchestratorConfig {
    fn default() -> Self {
        let core_ids = vec![0, 1];
        let numa_nodes = vec![0];
        let mut core_numa_map = HashMap::new();
        for &cid in &core_ids {
            core_numa_map.insert(cid, 0);
        }
        Self {
            core_ids,
            numa_nodes,
            core_numa_map,
            hugepage_arena_bytes: 4 * 1024 * 1024, // 4MB
            router_config: RouterConfig::default(),
            default_dns_ttl_secs: 300,
        }
    }
}

/// Central Orchestrator coordinating all subsystem manifolds.
pub struct Orchestrator {
    config: OrchestratorConfig,
    qsbr: Arc<QsbrCoordinator>,
    hierarchical_qsbr: Arc<HierarchicalQsbrCoordinator>,
    active_flows: Arc<AtomicUsize>,
    pending_write_server: Arc<AtomicUsize>,
    pending_write_client: Arc<AtomicUsize>,
    active_connecting: Arc<AtomicUsize>,
    shutdown_flag: Arc<AtomicBool>,
    router: Arc<SpatialRouter>,
    dns_pipeline: Arc<SpeculativeDnsPipeline>,
    dialer: Arc<OutboundDialer>,
    arena: Arc<HugePageArena>,
}

impl Orchestrator {
    /// Initializes a new Caly Kernel Orchestrator.
    pub fn new(config: OrchestratorConfig) -> Result<Self, OrchestratorError> {
        let arena = HugePageArena::new(config.hugepage_arena_bytes).map_err(|e| {
            OrchestratorError::Config(format!("Hugepage arena allocation failed: {e}"))
        })?;

        let router = SpatialRouter::compile(config.router_config.clone()).map_err(|e| {
            OrchestratorError::Config(format!("Spatial router compilation failed: {e}"))
        })?;

        let hierarchical_qsbr = Arc::new(HierarchicalQsbrCoordinator::new(&config.numa_nodes));
        let qsbr = Arc::new(QsbrCoordinator::new());
        let dns_pipeline =
            Arc::new(SpeculativeDnsPipeline::new().with_default_ttl(config.default_dns_ttl_secs));

        let active_flows = Arc::new(AtomicUsize::new(0));
        let pending_write_server = Arc::new(AtomicUsize::new(0));
        let pending_write_client = Arc::new(AtomicUsize::new(0));
        let active_connecting = Arc::new(AtomicUsize::new(0));

        let dialer = Arc::new(OutboundDialer::new(
            dns_pipeline.clone(),
            active_flows.clone(),
            pending_write_server.clone(),
            pending_write_client.clone(),
            active_connecting.clone(),
        ));

        Ok(Self {
            config,
            qsbr,
            hierarchical_qsbr,
            active_flows,
            pending_write_server,
            pending_write_client,
            active_connecting,
            shutdown_flag: Arc::new(AtomicBool::new(false)),
            router: Arc::new(router),
            dns_pipeline,
            dialer,
            arena: Arc::new(arena),
        })
    }

    #[inline]
    pub fn qsbr(&self) -> Arc<QsbrCoordinator> {
        self.qsbr.clone()
    }

    #[inline]
    pub fn hierarchical_qsbr(&self) -> Arc<HierarchicalQsbrCoordinator> {
        self.hierarchical_qsbr.clone()
    }

    #[inline]
    pub fn active_flows(&self) -> Arc<AtomicUsize> {
        self.active_flows.clone()
    }

    #[inline]
    pub fn pending_write_server(&self) -> Arc<AtomicUsize> {
        self.pending_write_server.clone()
    }

    #[inline]
    pub fn pending_write_client(&self) -> Arc<AtomicUsize> {
        self.pending_write_client.clone()
    }

    #[inline]
    pub fn active_connecting(&self) -> Arc<AtomicUsize> {
        self.active_connecting.clone()
    }

    #[inline]
    pub fn router(&self) -> Arc<SpatialRouter> {
        self.router.clone()
    }

    #[inline]
    pub fn dns_pipeline(&self) -> Arc<SpeculativeDnsPipeline> {
        self.dns_pipeline.clone()
    }

    #[inline]
    pub fn dialer(&self) -> Arc<OutboundDialer> {
        self.dialer.clone()
    }

    #[inline]
    pub fn arena(&self) -> Arc<HugePageArena> {
        self.arena.clone()
    }

    /// Evaluates spatial routing policy, utilizing the continuous feedback DNS grid when
    /// the route rule requires IP resolution.
    ///
    /// Returns `(RouteDecision, Option<IpAddr>)` where the second element is the speculative
    /// best IP candidate for early dialing if available.
    pub fn route_and_resolve(
        &self,
        domain: Option<&str>,
        ip: Option<IpAddr>,
        port: u16,
        protocol: u8,
    ) -> (RouteDecision, Option<IpAddr>) {
        let proto = Protocol::from_u8(protocol);

        // 1. Resolve speculative candidate if domain is provided
        let (resolved_ips, speculative_best) = if let Some(dom) = domain {
            let best = self.dns_pipeline.speculative_best(dom);
            let all = self.dns_pipeline.resolve(dom);
            (all, best)
        } else {
            (None, None)
        };

        // 2. Formulate query
        let query = RouteQuery {
            domain,
            ip: ip.or(speculative_best),
            port,
            protocol: proto,
            process: None,
            dns_resolved_ips: resolved_ips.as_deref(),
        };

        let decision = self.router.route(&query);
        (decision, speculative_best)
    }

    /// Creates a formal drain controller monitoring flows, pending write DMA buffers, and connecting states.
    pub fn drain_controller(&self) -> DrainController {
        DrainController::new(
            self.qsbr.clone(),
            Some(self.hierarchical_qsbr.clone()),
            self.active_flows.clone(),
            self.pending_write_server.clone(),
            self.pending_write_client.clone(),
            self.active_connecting.clone(),
        )
    }

    /// Executes graceful formal drain.
    pub fn drain(&self, config: DrainConfig) -> Result<DrainReport, DrainError> {
        self.shutdown_flag.store(true, Ordering::SeqCst);
        self.drain_controller().drain(config)
    }

    /// Spawns worker threads for each core with NUMA pinning, io_uring reactors, and hierarchical QSBR registration.
    pub fn spawn_reactors(
        &self,
    ) -> Result<Vec<JoinHandle<Result<(), ReactorError>>>, OrchestratorError> {
        let mut handles = Vec::with_capacity(self.config.core_ids.len());

        for &core_id in &self.config.core_ids {
            let numa_id = self
                .config
                .core_numa_map
                .get(&core_id)
                .copied()
                .unwrap_or(0);
            let qsbr_handle = self.qsbr.register_core(core_id);
            let h_qsbr_handle = self.hierarchical_qsbr.register_core(core_id, numa_id);
            let shutdown = self.shutdown_flag.clone();
            let qsbr_coord = self.qsbr.clone();
            let h_qsbr_coord = self.hierarchical_qsbr.clone();

            let reactor_config = CoreReactorConfig {
                core_id,
                backend: caly_reactor::ReactorBackend::Auto,
                ingress_mode: caly_reactor::IngressMode::IoUring,
                ring_entries: 1024,
                fixed_buffers: 256,
                buffer_size: 16384,
                spin_limit: 100,
                xsk_config: None,
            };

            let handle = thread::spawn(move || {
                let _ = pin_to_core(core_id);
                let mut reactor = CoreReactor::new(reactor_config)?;

                while !shutdown.load(Ordering::Relaxed) {
                    let _ = reactor.run_tick()?;
                    let cur_epoch = qsbr_coord.global_epoch();
                    qsbr_handle.quiescent_state(cur_epoch);

                    let h_cur_epoch = h_qsbr_coord.global_epoch();
                    h_qsbr_handle.quiescent_state(h_cur_epoch);
                }

                qsbr_handle.offline();
                h_qsbr_handle.offline();
                Ok(())
            });

            handles.push(handle);
        }

        Ok(handles)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::net::Ipv4Addr;

    #[test]
    fn test_orchestrator_initialization_and_coordination() {
        let config = OrchestratorConfig::default();
        let orch = Orchestrator::new(config).expect("orchestrator should initialize");

        assert_eq!(orch.active_flows().load(Ordering::SeqCst), 0);
        assert_eq!(orch.pending_write_server().load(Ordering::SeqCst), 0);
        assert_eq!(orch.pending_write_client().load(Ordering::SeqCst), 0);
        assert_eq!(orch.active_connecting().load(Ordering::SeqCst), 0);
        assert!(orch.arena().capacity() > 0);
    }

    #[test]
    fn test_speculative_dns_route_lookup() {
        let mut r_cfg = RouterConfig::default();
        r_cfg
            .ipv4_cidrs
            .push(("10.0.0.0/8".into(), RouteAction::Direct));
        r_cfg.ipv4_cidrs.push((
            "192.168.0.0/16".into(),
            RouteAction::Proxy("us-outbound".into()),
        ));

        let config = OrchestratorConfig {
            router_config: r_cfg,
            ..Default::default()
        };
        let orch = Orchestrator::new(config).expect("orchestrator initialized");

        let domain = "service.caly.internal";
        let target_ip = IpAddr::V4(Ipv4Addr::new(192, 168, 5, 20));
        orch.dns_pipeline()
            .insert_mapping(domain, vec![target_ip], 300);

        let (decision, speculative_ip) = orch.route_and_resolve(Some(domain), None, 8080, 6);
        assert_eq!(speculative_ip, Some(target_ip));
        assert_eq!(decision.action, RouteAction::Proxy("us-outbound".into()));

        // Continuous feedback update
        orch.dns_pipeline()
            .record_feedback(domain, target_ip, 1_500_000, true, 1000);
        let best = orch.dns_pipeline().speculative_best(domain);
        assert_eq!(best, Some(target_ip));
    }

    #[test]
    fn test_dynamic_outbound_full_lifecycle_drain() {
        let config = OrchestratorConfig::default();
        let orch = Orchestrator::new(config).expect("orchestrator initialized");

        let domain = "node1.caly.internal";
        let ip = IpAddr::V4(Ipv4Addr::new(10, 0, 0, 1));
        orch.dns_pipeline().insert_mapping(domain, vec![ip], 300);

        // 1. Dynamic Dial
        let dialer = orch.dialer();
        let (mut session, token) = dialer
            .initiate_dial(101, 3, Some(domain), None, 443, 500)
            .expect("initiate dial");

        assert_eq!(token.op, IoOperation::Connect);
        assert_eq!(token.conn_id, 101);
        assert_eq!(orch.active_connecting().load(Ordering::SeqCst), 1);
        assert_eq!(orch.active_flows().load(Ordering::SeqCst), 1);

        // 2. Connect completed
        dialer
            .on_connect_completed(&mut session, true, Some(4), 1000, 2_400_000_000)
            .expect("connect completion");
        assert_eq!(orch.active_connecting().load(Ordering::SeqCst), 0);

        // 3. In-flight Writes
        let w_token = dialer.submit_write_server(&mut session, 2, 512);
        assert_eq!(w_token.op, IoOperation::WriteServer);
        assert_eq!(orch.pending_write_server().load(Ordering::SeqCst), 1);

        // 4. Complete Write & Close
        dialer.on_write_server_completed(&mut session, 512);
        assert_eq!(orch.pending_write_server().load(Ordering::SeqCst), 0);

        dialer.close_session(&mut session, "Teardown");
        assert_eq!(orch.active_flows().load(Ordering::SeqCst), 0);

        // 5. Formal Drain
        let drain_cfg = DrainConfig {
            timeout_cycles: 20_000_000,
            min_decay_step_cycles: 100,
            max_decay_step_cycles: 1_000,
            decay_multiplier: 1.2,
        };
        let report = orch.drain(drain_cfg).expect("drain should succeed");
        assert_eq!(report.drained_flows, 0); // Already 0 flows
        assert_eq!(report.drained_server_writes, 0);
    }
}
