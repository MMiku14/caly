//! Formal Drain Controller: Event-driven hardware TSC cycle decay and QSBR epoch synchronization.
//!
//! Monitors all active flows, pending `IoOperation::WriteServer` in-flight buffers,
//! pending `IoOperation::WriteClient` in-flight buffers, and active connecting flows
//! to guarantee zero-loss graceful termination across NUMA domains.

use std::sync::atomic::{AtomicUsize, Ordering};
use std::sync::Arc;
use thiserror::Error;

use caly_memory::{estimate_tsc_frequency_hz, read_tsc, tsc_cycles_to_nanos};
use caly_reactor::cpu_pause;

use crate::hierarchical_qsbr::HierarchicalQsbrCoordinator;
use crate::qsbr::QsbrCoordinator;

#[derive(Error, Debug)]
pub enum DrainError {
    #[error("Drain timed out after {elapsed_cycles} cycles: {remaining_flows} flows, {remaining_server_writes} server writes, {remaining_client_writes} client writes, {remaining_connecting} connecting")]
    DrainTimeout {
        remaining_flows: usize,
        remaining_server_writes: usize,
        remaining_client_writes: usize,
        remaining_connecting: usize,
        elapsed_cycles: u64,
    },
    #[error("Controller interrupted")]
    Interrupted,
}

#[derive(Debug, Clone)]
pub struct DrainConfig {
    pub timeout_cycles: u64,
    pub min_decay_step_cycles: u64,
    pub max_decay_step_cycles: u64,
    pub decay_multiplier: f64,
}

impl Default for DrainConfig {
    fn default() -> Self {
        let freq = estimate_tsc_frequency_hz();
        let timeout_cycles = freq * 5; // 5 seconds default timeout
        Self {
            timeout_cycles,
            min_decay_step_cycles: 1_000,
            max_decay_step_cycles: 50_000,
            decay_multiplier: 1.5,
        }
    }
}

#[derive(Debug, Clone)]
pub struct DrainReport {
    pub drained_flows: usize,
    pub drained_server_writes: usize,
    pub drained_client_writes: usize,
    pub drained_connecting_flows: usize,
    pub elapsed_cycles: u64,
    pub elapsed_nanos: u64,
    pub final_epoch: u64,
    pub reclaimed_objects: usize,
}

/// Comprehensive formal drain coordinator.
pub struct DrainController {
    qsbr: Arc<QsbrCoordinator>,
    hierarchical_qsbr: Option<Arc<HierarchicalQsbrCoordinator>>,
    active_flows: Arc<AtomicUsize>,
    pending_write_server: Arc<AtomicUsize>,
    pending_write_client: Arc<AtomicUsize>,
    active_connecting: Arc<AtomicUsize>,
}

impl DrainController {
    /// Creates a new `DrainController` monitoring flows, in-flight writes, and connecting states.
    pub fn new(
        qsbr: Arc<QsbrCoordinator>,
        hierarchical_qsbr: Option<Arc<HierarchicalQsbrCoordinator>>,
        active_flows: Arc<AtomicUsize>,
        pending_write_server: Arc<AtomicUsize>,
        pending_write_client: Arc<AtomicUsize>,
        active_connecting: Arc<AtomicUsize>,
    ) -> Self {
        Self {
            qsbr,
            hierarchical_qsbr,
            active_flows,
            pending_write_server,
            pending_write_client,
            active_connecting,
        }
    }

    /// Replaces coarse sleep polling with event-driven hardware TSC cycle decay and QSBR epoch synchronization.
    ///
    /// Evaluates that:
    /// - `active_flows == 0`
    /// - `pending_write_server == 0` (no uncommitted upstream DMA writes)
    /// - `pending_write_client == 0` (no uncommitted downstream reply writes)
    /// - `active_connecting == 0` (no in-flight async connect SQEs)
    pub fn drain(&self, config: DrainConfig) -> Result<DrainReport, DrainError> {
        // Snapshot all counters *before* any blocking work. TSC frequency
        // calibration below may spin for several milliseconds, during which
        // concurrently-draining flows could already have completed, so the
        // counters would read as zero even though there was work to drain.
        let initial_flows = self.active_flows.load(Ordering::Acquire);
        let initial_server_writes = self.pending_write_server.load(Ordering::Acquire);
        let initial_client_writes = self.pending_write_client.load(Ordering::Acquire);
        let initial_connecting = self.active_connecting.load(Ordering::Acquire);

        let start_tsc = read_tsc();
        let freq = estimate_tsc_frequency_hz();

        let mut current_decay_step = config.min_decay_step_cycles;
        let mut total_reclaimed = 0;
        #[allow(unused_assignments)]
        let mut latest_epoch = self.qsbr.global_epoch();

        loop {
            // 1. Synchronize and poll QSBR reclamation
            latest_epoch = self.qsbr.advance_epoch();
            if let Some(ref h_qsbr) = self.hierarchical_qsbr {
                let _ = h_qsbr.advance_epoch();
            }
            total_reclaimed += self.qsbr.poll_reclaim();

            // 2. Sample all 4 in-flight tracking counters
            let remaining_flows = self.active_flows.load(Ordering::Acquire);
            let remaining_server_writes = self.pending_write_server.load(Ordering::Acquire);
            let remaining_client_writes = self.pending_write_client.load(Ordering::Acquire);
            let remaining_connecting = self.active_connecting.load(Ordering::Acquire);

            // 3. Check for full quiet state
            if remaining_flows == 0
                && remaining_server_writes == 0
                && remaining_client_writes == 0
                && remaining_connecting == 0
            {
                let now_tsc = read_tsc();
                let elapsed_cycles = now_tsc.saturating_sub(start_tsc);
                let elapsed_nanos = tsc_cycles_to_nanos(elapsed_cycles, freq);

                return Ok(DrainReport {
                    drained_flows: initial_flows,
                    drained_server_writes: initial_server_writes,
                    drained_client_writes: initial_client_writes,
                    drained_connecting_flows: initial_connecting,
                    elapsed_cycles,
                    elapsed_nanos,
                    final_epoch: latest_epoch,
                    reclaimed_objects: total_reclaimed,
                });
            }

            // 4. Timeout evaluation
            let now_tsc = read_tsc();
            let elapsed_cycles = now_tsc.saturating_sub(start_tsc);
            if elapsed_cycles >= config.timeout_cycles {
                return Err(DrainError::DrainTimeout {
                    remaining_flows,
                    remaining_server_writes,
                    remaining_client_writes,
                    remaining_connecting,
                    elapsed_cycles,
                });
            }

            // 5. Hardware TSC spin-loop decay
            let spin_target = now_tsc + current_decay_step;
            while read_tsc() < spin_target {
                cpu_pause();
            }

            // 6. Exponential step decay
            current_decay_step = ((current_decay_step as f64) * config.decay_multiplier) as u64;
            if current_decay_step > config.max_decay_step_cycles {
                current_decay_step = config.max_decay_step_cycles;
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_drain_controller_monitors_all_operations() {
        let qsbr = Arc::new(QsbrCoordinator::new());
        let flows = Arc::new(AtomicUsize::new(2));
        let server_writes = Arc::new(AtomicUsize::new(1));
        let client_writes = Arc::new(AtomicUsize::new(1));
        let connecting = Arc::new(AtomicUsize::new(1));

        let controller = DrainController::new(
            qsbr.clone(),
            None,
            flows.clone(),
            server_writes.clone(),
            client_writes.clone(),
            connecting.clone(),
        );

        let config = DrainConfig {
            timeout_cycles: 50_000_000,
            min_decay_step_cycles: 500,
            max_decay_step_cycles: 5_000,
            decay_multiplier: 1.2,
        };

        // Simulate background thread completing operations
        let f = flows.clone();
        let sw = server_writes.clone();
        let cw = client_writes.clone();
        let conn = connecting.clone();

        std::thread::spawn(move || {
            std::thread::sleep(std::time::Duration::from_millis(5));
            conn.store(0, Ordering::Release);
            sw.store(0, Ordering::Release);
            cw.store(0, Ordering::Release);
            f.store(0, Ordering::Release);
        });

        let report = controller.drain(config).expect("drain should succeed");
        assert_eq!(report.drained_flows, 2);
        assert_eq!(report.drained_server_writes, 1);
        assert_eq!(report.drained_client_writes, 1);
        assert_eq!(report.drained_connecting_flows, 1);
    }
}
