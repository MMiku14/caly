//! Wait-Free RCU Configuration Swap.

use std::sync::atomic::{AtomicPtr, Ordering};
use std::sync::Arc;

use crate::qsbr::{QsbrCoordinator, QsbrCoreHandle};

/// Zero-lock Wait-Free RCU wrapper for dynamic configurations.
///
/// # Lifetime of retired configs
///
/// Every [`ConfigRcu::hot_reload`] call allocates a new `Box<T>` and hands
/// the previous one to the associated [`QsbrCoordinator`] for deferred
/// reclamation. The retired allocation is freed only when the coordinator's
/// retirement queue is drained via [`QsbrCoordinator::poll_reclaim`] (or
/// equivalently via [`crate::drain::DrainController::drain`]).
///
/// Callers are therefore expected to:
/// 1. Run a drain / poll loop on the coordinator after any hot reload storm.
/// 2. Ensure all reader threads have signalled a quiescent state at or past
///    the returned epoch before the allocation is actually dropped.
///
/// Not draining leaks the config allocations; the `Drop` impl of this struct
/// only frees the *current* config, not the retired ones.
pub struct ConfigRcu<T> {
    current: AtomicPtr<T>,
    qsbr: Arc<QsbrCoordinator>,
}

unsafe impl<T: Send + Sync> Send for ConfigRcu<T> {}
unsafe impl<T: Send + Sync> Sync for ConfigRcu<T> {}

impl<T: Send + Sync + 'static> ConfigRcu<T> {
    pub fn new(initial: T, qsbr: Arc<QsbrCoordinator>) -> Self {
        let ptr = Box::into_raw(Box::new(initial));
        Self {
            current: AtomicPtr::new(ptr),
            qsbr,
        }
    }

    /// Reads configuration pointer with zero locks.
    ///
    /// # Safety
    /// Caller must be executing within a QSBR epoch critical section (before next quiescent state).
    #[inline(always)]
    pub unsafe fn read_raw(&self) -> *const T {
        self.current.load(Ordering::Acquire)
    }

    /// Reads configuration reference with zero locks.
    ///
    /// `handle` is accepted as proof that the caller is inside a QSBR
    /// critical section. It is *not* consumed — the reference returned
    /// borrows from `self` — but it is checked in debug builds so a
    /// misused handle (e.g. one already taken offline) fails loudly
    /// instead of silently reading freed memory.
    #[inline(always)]
    pub unsafe fn read(&self, handle: &QsbrCoreHandle) -> &T {
        debug_assert!(
            handle.is_active(),
            "ConfigRcu::read called with an offline QSBR handle",
        );
        // SAFETY: Caller guarantees a QSBR critical section is active.
        unsafe { &*self.read_raw() }
    }

    /// Reads cloned configuration for safe detached usage.
    ///
    /// # Safety contract (not enforced by the type system)
    ///
    /// The internal `read_raw()` returns a bare pointer; between the load
    /// and the `clone()` there is a window during which another thread may
    /// call [`Self::hot_reload`], swap the pointer, advance the QSBR epoch,
    /// and (after a drain) free the old allocation. That would be a
    /// use-after-free.
    ///
    /// To use this method safely, the caller must:
    /// 1. Enter a QSBR critical section (`ConfigRcu::read` with an active
    ///    handle, or a `DrainController`-managed epoch), **or**
    /// 2. Guarantee no concurrent `hot_reload` is in flight — for example
    ///    during single-threaded initialization or after a full quiescent
    ///    barrier has been observed.
    ///
    /// The function cannot be marked `unsafe fn` without a breaking API
    /// change, so this contract is enforced by documentation only.
    pub fn read_cloned(&self) -> T
    where
        T: Clone,
    {
        // SAFETY: caller is responsible for the contract described above.
        unsafe { (&*self.read_raw()).clone() }
    }

    /// Hot-reloads configuration by updating atomic pointer and queuing old config for reclamation after QSBR epoch quiet period.
    pub fn hot_reload(&self, new_config: T) -> u64 {
        let new_ptr = Box::into_raw(Box::new(new_config));
        // Advance QSBR generation epoch
        let retired_epoch = self.qsbr.advance_epoch();
        // Atomic swap configuration pointer
        let old_ptr = self.current.swap(new_ptr, Ordering::AcqRel);

        // Reclaim the previous config via QSBR. We move the raw pointer back
        // into a `Box<T>` *before* handing it to the closure: `Box<T>` is
        // `Send` whenever `T: Send`, and `T: Send + Sync + 'static` is required
        // by this impl, so the reclaimer may legally run on any thread.
        //
        // Round-tripping through `usize` here would erase pointer provenance
        // (rejected by `-Zmiri-strict-provenance` and future Rust editions);
        // the `Box` path preserves it and costs nothing extra.
        //
        // Soundness: once `old_ptr` has been atomically swapped out of
        // `self.current`, no other thread can observe it. The reclaimer owns
        // the sole `Box<T>` and drops it exactly once.
        if !old_ptr.is_null() {
            // SAFETY: `old_ptr` came from `Box::into_raw` in a previous
            // `hot_reload` call (or `ConfigRcu::new`), and was just removed
            // from `self.current` under `AcqRel`.
            let old_box: Box<T> = unsafe { Box::from_raw(old_ptr) };
            self.qsbr.retire_at_epoch(
                retired_epoch,
                Box::new(move || {
                    drop(old_box);
                }),
            );
        }

        retired_epoch
    }
}

impl<T> Drop for ConfigRcu<T> {
    fn drop(&mut self) {
        let ptr = self.current.swap(std::ptr::null_mut(), Ordering::AcqRel);
        if !ptr.is_null() {
            unsafe {
                drop(Box::from_raw(ptr));
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_config_rcu_multiple_hot_reloads_monotonic_epoch() {
        let qsbr = Arc::new(QsbrCoordinator::new());
        let ctrl = ConfigRcu::new(100u32, qsbr.clone());

        assert_eq!(ctrl.read_cloned(), 100);

        let e1 = ctrl.hot_reload(200);
        assert_eq!(ctrl.read_cloned(), 200);

        let e2 = ctrl.hot_reload(300);
        assert!(
            e2 > e1,
            "epoch must monotonically advance (e1={e1}, e2={e2})"
        );
        assert_eq!(ctrl.read_cloned(), 300);

        let e3 = ctrl.hot_reload(400);
        assert!(e3 > e2);
        assert_eq!(ctrl.read_cloned(), 400);

        // Three configs (100, 200, 300) have been retired; none are freed
        // until the caller drains the QSBR queue. This test deliberately
        // exercises that contract so Miri verifies the retirement closures
        // actually reconstitute and drop the raw pointers without leaking.
        assert_eq!(qsbr.pending_reclamations(), 3);
        assert_eq!(qsbr.poll_reclaim(), 3);
        assert_eq!(qsbr.pending_reclamations(), 0);

        // `ctrl` drops at end of scope, freeing the final (400) config.
    }

    #[test]
    fn test_config_rcu_drop_releases_current() {
        let qsbr = Arc::new(QsbrCoordinator::new());
        {
            let _ctrl = ConfigRcu::new(String::from("v1"), qsbr.clone());
        }
        // If Drop didn't deallocate, Miri would flag the leak.
        // This test mainly guards against regressions in Drop impl.
    }
}
