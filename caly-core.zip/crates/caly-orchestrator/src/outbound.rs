//! Full-Lifecycle Dynamic Outbound Reactor Integration and Async Dialing State Machine.
//!
//! Coordinates:
//! - Asynchronous outbound socket connection lifecycle with `IoToken` and `IoOperation`.
//! - Continuous feedback integration with `SpeculativeDnsPipeline` for dynamic endpoint selection.
//! - Non-blocking token-encoded submission tracking for io_uring CQE completions.
//! - Telemetry and pending operation accounting for zero-loss graceful formal draining.

use std::net::{IpAddr, SocketAddr};
use std::sync::atomic::{AtomicUsize, Ordering};
use std::sync::Arc;
use thiserror::Error;

use caly_memory::tsc_cycles_to_nanos;
use caly_reactor::token::{IoOperation, IoToken};
use caly_spatial::dns_pipeline::SpeculativeDnsPipeline;

#[derive(Error, Debug)]
pub enum OutboundError {
    #[error("DNS resolution failed for domain: {0}")]
    DnsResolutionFailed(String),

    #[error("Socket creation failed: {0}")]
    SocketCreationFailed(String),

    #[error("Invalid state transition from {from:?} to {to:?}")]
    InvalidStateTransition { from: String, to: String },

    #[error("Connection timed out")]
    Timeout,
}

/// Dynamic Outbound Session State Machine.
#[derive(Debug, Clone, PartialEq)]
pub enum OutboundState {
    /// Initial unallocated state.
    Idle,
    /// Querying continuous feedback DNS pipeline.
    DnsQuerying {
        domain: String,
        port: u16,
        start_tsc: u64,
    },
    /// Asynchronous non-blocking connect SQE in flight.
    Connecting {
        target_addr: SocketAddr,
        start_tsc: u64,
        attempts: u32,
        token: IoToken,
    },
    /// Outbound TCP stream established, awaiting initial handshake/payload.
    Connected {
        server_fd: i32,
        target_addr: SocketAddr,
        established_tsc: u64,
        rtt_nanos: u64,
    },
    /// Active bidirectional streaming through zero-copy ring buffers.
    Streaming {
        client_fd: i32,
        server_fd: i32,
        bytes_up: u64,
        bytes_down: u64,
    },
    /// In-flight data flushing prior to formal termination.
    Flushing {
        pending_server_writes: usize,
        pending_client_writes: usize,
    },
    /// Final closed state.
    Closed { reason: String },
}

/// Outbound Connection Session Context.
pub struct OutboundSession {
    pub conn_id: u32,
    pub client_fd: i32,
    pub server_fd: Option<i32>,
    pub domain: Option<String>,
    pub target_addr: Option<SocketAddr>,
    pub state: OutboundState,
    pub created_tsc: u64,
    pub pending_server_writes: usize,
    pub pending_client_writes: usize,
}

impl OutboundSession {
    /// Creates a new idle session.
    pub fn new(conn_id: u32, client_fd: i32, created_tsc: u64) -> Self {
        Self {
            conn_id,
            client_fd,
            server_fd: None,
            domain: None,
            target_addr: None,
            state: OutboundState::Idle,
            created_tsc,
            pending_server_writes: 0,
            pending_client_writes: 0,
        }
    }

    /// Check if session is currently connecting.
    pub fn is_connecting(&self) -> bool {
        matches!(self.state, OutboundState::Connecting { .. })
    }

    /// Check if session is established and active.
    pub fn is_active(&self) -> bool {
        matches!(
            self.state,
            OutboundState::Connected { .. } | OutboundState::Streaming { .. }
        )
    }

    /// Total pending in-flight writes for this session.
    pub fn pending_writes(&self) -> usize {
        self.pending_server_writes + self.pending_client_writes
    }
}

/// Dynamic Outbound Reactor Dialer and Lifecycle Controller.
pub struct OutboundDialer {
    dns_pipeline: Arc<SpeculativeDnsPipeline>,
    active_flows: Arc<AtomicUsize>,
    pending_write_server: Arc<AtomicUsize>,
    pending_write_client: Arc<AtomicUsize>,
    active_connecting: Arc<AtomicUsize>,
}

impl OutboundDialer {
    /// Creates a new outbound dialer bound to the shared orchestrator telemetry counters.
    pub fn new(
        dns_pipeline: Arc<SpeculativeDnsPipeline>,
        active_flows: Arc<AtomicUsize>,
        pending_write_server: Arc<AtomicUsize>,
        pending_write_client: Arc<AtomicUsize>,
        active_connecting: Arc<AtomicUsize>,
    ) -> Self {
        Self {
            dns_pipeline,
            active_flows,
            pending_write_server,
            pending_write_client,
            active_connecting,
        }
    }

    /// Access the underlying speculative DNS pipeline.
    pub fn dns_pipeline(&self) -> &Arc<SpeculativeDnsPipeline> {
        &self.dns_pipeline
    }

    /// Initiates an asynchronous dynamic outbound dial.
    ///
    /// Selects the optimal endpoint via the speculative DNS pipeline if domain is provided,
    /// increments active connecting flow telemetry, and returns an encoded `IoToken::Connect`.
    pub fn initiate_dial(
        &self,
        conn_id: u32,
        client_fd: i32,
        domain: Option<&str>,
        ip: Option<IpAddr>,
        port: u16,
        now_tsc: u64,
    ) -> Result<(OutboundSession, IoToken), OutboundError> {
        let mut session = OutboundSession::new(conn_id, client_fd, now_tsc);

        // 1. Resolve endpoint target address
        let target_ip = match (ip, domain) {
            (Some(explicit_ip), _) => explicit_ip,
            (None, Some(dom)) => {
                session.domain = Some(dom.to_string());
                // Prefer the speculative best; fall back to the full resolution set.
                if let Some(best_ip) = self.dns_pipeline.speculative_best(dom) {
                    best_ip
                } else if let Some(resolved_ips) = self.dns_pipeline.resolve(dom) {
                    resolved_ips
                        .first()
                        .copied()
                        .ok_or_else(|| OutboundError::DnsResolutionFailed(dom.to_string()))?
                } else {
                    // The DNS grid has no entry for this domain. Previously
                    // this fell back to loopback (127.0.0.1), which silently
                    // connected the caller to the wrong endpoint. Return a
                    // hard error instead so the orchestrator can enqueue a
                    // background resolution and retry.
                    return Err(OutboundError::DnsResolutionFailed(dom.to_string()));
                }
            }
            (None, None) => {
                return Err(OutboundError::DnsResolutionFailed(
                    "(neither ip nor domain provided)".to_string(),
                ));
            }
        };

        let target_addr = SocketAddr::new(target_ip, port);
        session.target_addr = Some(target_addr);

        // 2. Generate io_uring submission token
        let token = IoToken::new(IoOperation::Connect, None, conn_id);

        session.state = OutboundState::Connecting {
            target_addr,
            start_tsc: now_tsc,
            attempts: 1,
            token,
        };

        self.active_connecting.fetch_add(1, Ordering::SeqCst);
        self.active_flows.fetch_add(1, Ordering::SeqCst);

        Ok((session, token))
    }

    /// Handles completion of an asynchronous connect operation from CQE.
    pub fn on_connect_completed(
        &self,
        session: &mut OutboundSession,
        success: bool,
        server_fd: Option<i32>,
        now_tsc: u64,
        freq_hz: u64,
    ) -> Result<(), OutboundError> {
        let (target_addr, start_tsc) = match &session.state {
            OutboundState::Connecting {
                target_addr,
                start_tsc,
                ..
            } => (*target_addr, *start_tsc),
            other => {
                return Err(OutboundError::InvalidStateTransition {
                    from: format!("{other:?}"),
                    to: "Connected".into(),
                });
            }
        };

        // Decrement connecting counter
        self.active_connecting.fetch_sub(1, Ordering::SeqCst);

        let elapsed_cycles = now_tsc.saturating_sub(start_tsc);
        let rtt_nanos = tsc_cycles_to_nanos(elapsed_cycles, freq_hz);

        if success {
            let s_fd = server_fd.unwrap_or(session.client_fd + 100);
            session.server_fd = Some(s_fd);
            session.state = OutboundState::Connected {
                server_fd: s_fd,
                target_addr,
                established_tsc: now_tsc,
                rtt_nanos,
            };

            // Positive continuous feedback update to speculative DNS grid
            if let Some(ref dom) = session.domain {
                self.dns_pipeline
                    .record_feedback(dom, target_addr.ip(), rtt_nanos, true, now_tsc);
            }

            Ok(())
        } else {
            session.state = OutboundState::Closed {
                reason: "Connect failed".into(),
            };
            self.active_flows.fetch_sub(1, Ordering::SeqCst);

            // Negative continuous feedback update to speculative DNS grid
            if let Some(ref dom) = session.domain {
                self.dns_pipeline
                    .record_feedback(dom, target_addr.ip(), rtt_nanos, false, now_tsc);
            }

            Err(OutboundError::Timeout)
        }
    }

    /// Submits a write operation to the upstream server socket, tracking pending write count.
    pub fn submit_write_server(
        &self,
        session: &mut OutboundSession,
        buf_idx: u16,
        _len: usize,
    ) -> IoToken {
        self.pending_write_server.fetch_add(1, Ordering::SeqCst);
        session.pending_server_writes += 1;
        IoToken::new(IoOperation::WriteServer, Some(buf_idx), session.conn_id)
    }

    /// Handles completion of a write operation to the upstream server socket.
    pub fn on_write_server_completed(&self, session: &mut OutboundSession, bytes: usize) {
        if session.pending_server_writes > 0 {
            session.pending_server_writes -= 1;
            self.pending_write_server.fetch_sub(1, Ordering::SeqCst);
        }
        if let OutboundState::Streaming {
            ref mut bytes_up, ..
        } = session.state
        {
            *bytes_up += bytes as u64;
        }
    }

    /// Submits a write operation back to the client socket, tracking pending write count.
    pub fn submit_write_client(
        &self,
        session: &mut OutboundSession,
        buf_idx: u16,
        _len: usize,
    ) -> IoToken {
        self.pending_write_client.fetch_add(1, Ordering::SeqCst);
        session.pending_client_writes += 1;
        IoToken::new(IoOperation::WriteClient, Some(buf_idx), session.conn_id)
    }

    /// Handles completion of a write operation to the downstream client socket.
    pub fn on_write_client_completed(&self, session: &mut OutboundSession, bytes: usize) {
        if session.pending_client_writes > 0 {
            session.pending_client_writes -= 1;
            self.pending_write_client.fetch_sub(1, Ordering::SeqCst);
        }
        if let OutboundState::Streaming {
            ref mut bytes_down, ..
        } = session.state
        {
            *bytes_down += bytes as u64;
        }
    }

    /// Closes an outbound session, decrementing active flow telemetry and ensuring
    /// all in-flight pending writes are accounted for.
    pub fn close_session(&self, session: &mut OutboundSession, reason: &str) {
        if session.is_connecting() {
            self.active_connecting.fetch_sub(1, Ordering::SeqCst);
        }

        if session.pending_server_writes > 0 {
            self.pending_write_server
                .fetch_sub(session.pending_server_writes, Ordering::SeqCst);
            session.pending_server_writes = 0;
        }

        if session.pending_client_writes > 0 {
            self.pending_write_client
                .fetch_sub(session.pending_client_writes, Ordering::SeqCst);
            session.pending_client_writes = 0;
        }

        if session.state != OutboundState::Idle
            && !matches!(session.state, OutboundState::Closed { .. })
        {
            self.active_flows.fetch_sub(1, Ordering::SeqCst);
        }

        session.state = OutboundState::Closed {
            reason: reason.to_string(),
        };
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::net::Ipv4Addr;

    #[test]
    fn test_dynamic_outbound_state_machine_with_tokens() {
        let dns = Arc::new(SpeculativeDnsPipeline::new());
        let domain = "gateway.us-west.caly.internal";
        let ip = IpAddr::V4(Ipv4Addr::new(192, 168, 1, 100));
        dns.insert_mapping(domain, vec![ip], 300);

        let active_flows = Arc::new(AtomicUsize::new(0));
        let pending_write_server = Arc::new(AtomicUsize::new(0));
        let pending_write_client = Arc::new(AtomicUsize::new(0));
        let active_connecting = Arc::new(AtomicUsize::new(0));

        let dialer = OutboundDialer::new(
            dns.clone(),
            active_flows.clone(),
            pending_write_server.clone(),
            pending_write_client.clone(),
            active_connecting.clone(),
        );

        // 1. Initiate Dial
        let (mut session, token) = dialer
            .initiate_dial(42, 10, Some(domain), None, 443, 1000)
            .expect("initiate dial");

        assert_eq!(token.op, IoOperation::Connect);
        assert_eq!(token.conn_id, 42);
        assert_eq!(active_connecting.load(Ordering::SeqCst), 1);
        assert_eq!(active_flows.load(Ordering::SeqCst), 1);
        assert!(session.is_connecting());

        // 2. Complete Connect
        dialer
            .on_connect_completed(&mut session, true, Some(11), 2000, 2_400_000_000)
            .expect("connect completion");

        assert_eq!(active_connecting.load(Ordering::SeqCst), 0);
        assert_eq!(active_flows.load(Ordering::SeqCst), 1);
        assert!(session.is_active());

        // 3. Write Server & Write Client
        let s_token = dialer.submit_write_server(&mut session, 5, 256);
        assert_eq!(s_token.op, IoOperation::WriteServer);
        assert_eq!(s_token.buf_idx, Some(5));
        assert_eq!(pending_write_server.load(Ordering::SeqCst), 1);

        let c_token = dialer.submit_write_client(&mut session, 6, 128);
        assert_eq!(c_token.op, IoOperation::WriteClient);
        assert_eq!(c_token.buf_idx, Some(6));
        assert_eq!(pending_write_client.load(Ordering::SeqCst), 1);

        // Complete writes
        dialer.on_write_server_completed(&mut session, 256);
        assert_eq!(pending_write_server.load(Ordering::SeqCst), 0);

        dialer.on_write_client_completed(&mut session, 128);
        assert_eq!(pending_write_client.load(Ordering::SeqCst), 0);

        // 4. Close Session
        dialer.close_session(&mut session, "Normal disconnect");
        assert_eq!(active_flows.load(Ordering::SeqCst), 0);
    }

    #[test]
    fn test_outbound_invalid_state_transitions() {
        use std::sync::atomic::AtomicUsize;

        use std::net::{IpAddr, Ipv4Addr};

        let dns = Arc::new(SpeculativeDnsPipeline::new());
        // Register the domain used below — `initiate_dial` now returns a hard
        // error for unknown domains instead of silently dialing loopback.
        dns.insert_mapping(
            "x.internal",
            vec![IpAddr::V4(Ipv4Addr::new(10, 0, 0, 1))],
            60,
        );
        let flows = Arc::new(AtomicUsize::new(0));
        let pw_s = Arc::new(AtomicUsize::new(0));
        let pw_c = Arc::new(AtomicUsize::new(0));
        let ac = Arc::new(AtomicUsize::new(0));
        let dialer = OutboundDialer::new(dns, flows, pw_s, pw_c, ac);

        // 1. on_connect_completed on an Idle session should error.
        let mut idle = OutboundSession::new(1, 10, 0);
        let err = dialer
            .on_connect_completed(&mut idle, true, Some(11), 100, 1_000_000_000)
            .unwrap_err();
        assert!(
            matches!(err, OutboundError::InvalidStateTransition { .. }),
            "expected InvalidStateTransition, got {err:?}",
        );

        // 2. Calling on_connect_completed twice should error the second time.
        let (mut session, _) = dialer
            .initiate_dial(2, 12, Some("x.internal"), None, 443, 0)
            .expect("dial");
        dialer
            .on_connect_completed(&mut session, true, Some(13), 100, 1_000_000_000)
            .expect("first connect");
        let err = dialer
            .on_connect_completed(&mut session, true, Some(14), 200, 1_000_000_000)
            .unwrap_err();
        assert!(matches!(err, OutboundError::InvalidStateTransition { .. }));
    }

    #[test]
    fn test_outbound_session_predicates() {
        let mut s = OutboundSession::new(7, 20, 0);
        assert!(!s.is_connecting());
        assert!(!s.is_active());
        assert_eq!(s.pending_writes(), 0);

        s.pending_server_writes = 2;
        s.pending_client_writes = 3;
        assert_eq!(s.pending_writes(), 5);
    }

    #[test]
    fn test_outbound_close_is_idempotent() {
        use std::sync::atomic::AtomicUsize;

        let dns = Arc::new(SpeculativeDnsPipeline::new());
        let flows = Arc::new(AtomicUsize::new(0));
        let pw_s = Arc::new(AtomicUsize::new(0));
        let pw_c = Arc::new(AtomicUsize::new(0));
        let ac = Arc::new(AtomicUsize::new(0));
        let dialer = OutboundDialer::new(
            dns.clone(),
            flows.clone(),
            pw_s.clone(),
            pw_c.clone(),
            ac.clone(),
        );

        // Register a domain so initiate_dial succeeds.
        use std::net::{IpAddr, Ipv4Addr};
        dns.insert_mapping(
            "idempotent.example",
            vec![IpAddr::V4(Ipv4Addr::new(10, 0, 0, 1))],
            60,
        );

        let (mut session, _) = dialer
            .initiate_dial(1, 10, Some("idempotent.example"), None, 443, 0)
            .expect("dial");

        // Should succeed while connecting.
        dialer
            .on_connect_completed(&mut session, true, Some(11), 100, 1_000_000_000)
            .expect("connect");

        assert_eq!(flows.load(Ordering::SeqCst), 1);
        assert_eq!(ac.load(Ordering::SeqCst), 0);

        // First close decrements `active_flows` to 0.
        dialer.close_session(&mut session, "normal");
        assert_eq!(flows.load(Ordering::SeqCst), 0);

        // Second / third close must be no-ops: counters must not go negative.
        dialer.close_session(&mut session, "again");
        dialer.close_session(&mut session, "yet again");
        assert_eq!(flows.load(Ordering::SeqCst), 0);
        assert_eq!(ac.load(Ordering::SeqCst), 0);
        assert_eq!(pw_s.load(Ordering::SeqCst), 0);
        assert_eq!(pw_c.load(Ordering::SeqCst), 0);
    }

    #[test]
    fn test_outbound_close_while_connecting_decrements_both_counters() {
        use std::net::{IpAddr, Ipv4Addr};
        use std::sync::atomic::AtomicUsize;

        let dns = Arc::new(SpeculativeDnsPipeline::new());
        dns.insert_mapping(
            "connecting.example",
            vec![IpAddr::V4(Ipv4Addr::new(10, 0, 0, 1))],
            60,
        );
        let flows = Arc::new(AtomicUsize::new(0));
        let pw_s = Arc::new(AtomicUsize::new(0));
        let pw_c = Arc::new(AtomicUsize::new(0));
        let ac = Arc::new(AtomicUsize::new(0));
        let dialer = OutboundDialer::new(dns, flows.clone(), pw_s, pw_c, ac.clone());

        let (mut session, _) = dialer
            .initiate_dial(2, 20, Some("connecting.example"), None, 443, 0)
            .expect("dial");

        assert_eq!(ac.load(Ordering::SeqCst), 1);
        assert_eq!(flows.load(Ordering::SeqCst), 1);

        // Close before the connect completes.
        dialer.close_session(&mut session, "aborted");
        assert_eq!(ac.load(Ordering::SeqCst), 0);
        assert_eq!(flows.load(Ordering::SeqCst), 0);
    }
}
