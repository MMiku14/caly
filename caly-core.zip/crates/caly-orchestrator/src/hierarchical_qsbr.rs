//! NUMA-Local Hierarchical QSBR (Quiescent State Based Reclamation).
//!
//! On high-core-count multi-socket systems (e.g. 64-128+ cores across 2-8 NUMA sockets),
//! cross-socket bus interconnects (Intel UPI / AMD Infinity Fabric) suffer from severe cache
//! bounce and latency penalties if every core directly contends on a single global atomic epoch
//! or central lock.
//!
//! Hierarchical QSBR partitions core epoch tracking into NUMA-local structures:
//! 1. `NumaNodeQsbr`: Maintains local core handles and aggregates the local quiescent epoch
//!    on the local NUMA node without crossing the socket bus.
//! 2. `HierarchicalQsbrCoordinator`: Periodically harmonizes the local epochs across all
//!    NUMA nodes into the global system epoch, minimizing cross-socket traffic.

use parking_lot::{Mutex, RwLock};
use std::collections::{HashMap, VecDeque};
use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::Arc;

use crate::qsbr::QsbrCoreHandle;

/// Tracks quiescent epochs for cores belonging to a single NUMA socket.
pub struct NumaNodeQsbr {
    numa_id: usize,
    /// Minimum epoch witnessed by all active cores on this NUMA socket.
    local_epoch: AtomicU64,
    /// Core handles pinned to this NUMA socket.
    core_handles: RwLock<Vec<Arc<QsbrCoreHandle>>>,
}

impl NumaNodeQsbr {
    /// Create a new NUMA node manager.
    pub fn new(numa_id: usize, initial_epoch: u64) -> Self {
        Self {
            numa_id,
            local_epoch: AtomicU64::new(initial_epoch),
            core_handles: RwLock::new(Vec::new()),
        }
    }

    /// NUMA socket identifier.
    #[inline]
    pub fn numa_id(&self) -> usize {
        self.numa_id
    }

    /// Read the currently aggregated local epoch for this NUMA socket.
    #[inline]
    pub fn local_epoch(&self) -> u64 {
        self.local_epoch.load(Ordering::Acquire)
    }

    /// Registers a new core on this NUMA socket.
    pub fn register_core(&self, core_id: usize, current_global_epoch: u64) -> Arc<QsbrCoreHandle> {
        let handle = Arc::new(QsbrCoreHandle::new(core_id, current_global_epoch));
        self.core_handles.write().push(handle.clone());
        handle
    }

    /// Scans active cores on this NUMA socket and computes the local minimum epoch.
    /// Updates `local_epoch` cache line locally without generating cross-socket cache line invalidations.
    pub fn aggregate_local_epoch(&self) -> u64 {
        let handles = self.core_handles.read();
        if handles.is_empty() {
            return self.local_epoch.load(Ordering::Acquire);
        }

        let mut min_epoch = u64::MAX;
        let mut has_active = false;

        for h in handles.iter() {
            if h.is_active() {
                has_active = true;
                let ep = h.epoch();
                if ep < min_epoch {
                    min_epoch = ep;
                }
            }
        }

        let result = if has_active {
            min_epoch
        } else {
            self.local_epoch.load(Ordering::Acquire)
        };

        self.local_epoch.store(result, Ordering::Release);
        result
    }

    /// Returns the number of registered cores on this node.
    pub fn core_count(&self) -> usize {
        self.core_handles.read().len()
    }
}

struct RetiredItem {
    generation: u64,
    reclaimer: Box<dyn FnOnce() + Send + 'static>,
}

/// Global coordinator aggregating NUMA node epochs into the global system epoch.
pub struct HierarchicalQsbrCoordinator {
    global_epoch: AtomicU64,
    /// Cached system-wide minimum epoch across all NUMA nodes.
    system_min_epoch: AtomicU64,
    nodes: HashMap<usize, Arc<NumaNodeQsbr>>,
    retirement_queue: Mutex<VecDeque<RetiredItem>>,
}

impl HierarchicalQsbrCoordinator {
    /// Creates a hierarchical coordinator for the specified NUMA socket IDs.
    pub fn new(numa_node_ids: &[usize]) -> Self {
        let initial_epoch = 1;
        let mut nodes = HashMap::new();
        for &nid in numa_node_ids {
            nodes.insert(nid, Arc::new(NumaNodeQsbr::new(nid, initial_epoch)));
        }

        Self {
            global_epoch: AtomicU64::new(initial_epoch),
            system_min_epoch: AtomicU64::new(initial_epoch),
            nodes,
            retirement_queue: Mutex::new(VecDeque::new()),
        }
    }

    /// Current global generation epoch.
    #[inline]
    pub fn global_epoch(&self) -> u64 {
        self.global_epoch.load(Ordering::Acquire)
    }

    /// System-wide minimum quiescent epoch across all NUMA nodes.
    #[inline]
    pub fn system_min_epoch(&self) -> u64 {
        self.system_min_epoch.load(Ordering::Acquire)
    }

    /// Access a specific NUMA node manager.
    pub fn node(&self, numa_id: usize) -> Option<Arc<NumaNodeQsbr>> {
        self.nodes.get(&numa_id).cloned()
    }

    /// Number of configured NUMA nodes.
    pub fn node_count(&self) -> usize {
        self.nodes.len()
    }

    /// Registers a worker core onto a target NUMA socket.
    pub fn register_core(&self, core_id: usize, numa_id: usize) -> Arc<QsbrCoreHandle> {
        let node = self.nodes.get(&numa_id).unwrap_or_else(|| {
            panic!(
                "Invalid NUMA node ID {numa_id}; configured nodes: {:?}",
                self.nodes.keys().collect::<Vec<_>>()
            )
        });
        node.register_core(core_id, self.global_epoch())
    }

    /// Advances the global epoch monotonically.
    #[inline]
    pub fn advance_epoch(&self) -> u64 {
        self.global_epoch.fetch_add(1, Ordering::AcqRel) + 1
    }

    /// Aggregates local epochs from all NUMA sockets and updates the system minimum.
    /// This is the only operation that traverses NUMA interconnects.
    pub fn sync_nodes(&self) -> u64 {
        if self.nodes.is_empty() {
            let ep = self.global_epoch();
            self.system_min_epoch.store(ep, Ordering::Release);
            return ep;
        }

        let mut min_system_epoch = u64::MAX;
        for node in self.nodes.values() {
            let node_epoch = node.aggregate_local_epoch();
            if node_epoch < min_system_epoch {
                min_system_epoch = node_epoch;
            }
        }

        if min_system_epoch == u64::MAX {
            min_system_epoch = self.global_epoch();
        }

        self.system_min_epoch
            .store(min_system_epoch, Ordering::Release);
        min_system_epoch
    }

    /// Checks if all cores across all NUMA sockets have witnessed `retired_generation`.
    pub fn try_reclaim(&self, retired_generation: u64) -> bool {
        // Fast path: check cached system-wide minimum epoch without cross-node traversal
        if self.system_min_epoch.load(Ordering::Acquire) >= retired_generation {
            return true;
        }

        // Slow path: synchronize across NUMA nodes
        self.sync_nodes() >= retired_generation
    }

    /// Retires an item with an RAII drop closure.
    pub fn retire<T: Send + 'static>(&self, item: T) {
        let gen = self.global_epoch();
        let reclaimer = Box::new(move || {
            drop(item);
        });

        self.retirement_queue.lock().push_back(RetiredItem {
            generation: gen,
            reclaimer,
        });
    }

    /// Explicitly binds retired item to a known invalidation generation epoch.
    pub fn retire_at_epoch(&self, epoch: u64, reclaimer: Box<dyn FnOnce() + Send + 'static>) {
        self.retirement_queue.lock().push_back(RetiredItem {
            generation: epoch,
            reclaimer,
        });
    }
    /// Polls and reclaims all retired items whose quiescent period has completed.
    ///
    /// The reclaimer closure is invoked **after** the queue mutex is released.
    /// Holding the lock while running arbitrary user code risks a deadlock:
    /// a reclaimer may drop a type whose `Drop` retires another item (e.g.
    /// dropping a `ConfigRcu` whose `Drop` retires its current config),
    /// which would try to re-acquire the same mutex and hang the thread.
    pub fn poll_reclaim(&self) -> usize {
        // Same rationale as `QsbrCoordinator::poll_reclaim`: the queue
        // is partitioned in one pass so a newer-epoch entry cannot
        // starve older entries behind it, and the reclaimer closures run
        // with the lock released to survive re-entrant retirement.
        let eligible: Vec<RetiredItem> = {
            let mut queue = self.retirement_queue.lock();
            let mut eligible = Vec::with_capacity(queue.len());
            let mut pending = VecDeque::with_capacity(queue.len());
            while let Some(item) = queue.pop_front() {
                if self.try_reclaim(item.generation) {
                    eligible.push(item);
                } else {
                    pending.push_back(item);
                }
            }
            *queue = pending;
            eligible
        };

        let n = eligible.len();
        for item in eligible {
            (item.reclaimer)();
        }
        n
    }

    /// Number of items awaiting quiescent reclamation.
    #[inline]
    pub fn pending_reclamations(&self) -> usize {
        self.retirement_queue.lock().len()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::sync::atomic::AtomicBool;

    #[test]
    fn test_hierarchical_qsbr_multi_node() {
        let numa_nodes = vec![0, 1];
        let coord = HierarchicalQsbrCoordinator::new(&numa_nodes);
        assert_eq!(coord.global_epoch(), 1);
        assert_eq!(coord.node_count(), 2);

        // Core 0 & 1 on NUMA 0; Core 2 & 3 on NUMA 1
        let c0 = coord.register_core(0, 0);
        let c1 = coord.register_core(1, 0);
        let c2 = coord.register_core(2, 1);
        let c3 = coord.register_core(3, 1);

        let new_epoch = coord.advance_epoch();
        assert_eq!(new_epoch, 2);

        let reclaimed_flag = Arc::new(AtomicBool::new(false));
        let flag_clone = reclaimed_flag.clone();
        // Retire at the *new* epoch: `try_reclaim` requires every active core
        // to advance its per-core epoch to >= the retirement epoch before the
        // reclaimer runs. This mirrors the usage pattern in
        // `ConfigRcu::hot_reload` (advance first, then retire).
        coord.retire_at_epoch(
            new_epoch,
            Box::new(move || {
                flag_clone.store(true, Ordering::Release);
            }),
        );

        // Only NUMA 0 cores advance
        c0.quiescent_state(2);
        c1.quiescent_state(2);
        assert!(!coord.try_reclaim(2));
        assert_eq!(coord.poll_reclaim(), 0);

        // Only one core on NUMA 1 advances
        c2.quiescent_state(2);
        assert!(!coord.try_reclaim(2));

        // Final core on NUMA 1 advances
        c3.quiescent_state(2);
        assert!(coord.try_reclaim(2));
        assert_eq!(coord.poll_reclaim(), 1);
        assert!(reclaimed_flag.load(Ordering::Acquire));
    }

    #[test]
    fn test_hierarchical_qsbr_offline_core_does_not_block_reclaim() {
        let coord = HierarchicalQsbrCoordinator::new(&[0]);
        let c0 = coord.register_core(0, 0);
        let c1 = coord.register_core(1, 0);

        let ep = coord.advance_epoch(); // ep == 2
        c0.quiescent_state(ep);
        // c1 stays behind
        assert!(!coord.try_reclaim(ep));

        // Taking c1 offline should unblock reclamation.
        c1.offline();
        assert!(coord.try_reclaim(ep));
    }

    #[test]
    fn test_hierarchical_qsbr_retire_and_poll() {
        use std::sync::atomic::{AtomicUsize, Ordering};
        use std::sync::Arc;

        let coord = HierarchicalQsbrCoordinator::new(&[0]);
        let c0 = coord.register_core(0, 0);

        let dropped = Arc::new(AtomicUsize::new(0));
        let dropped_clone = dropped.clone();

        let ep = coord.advance_epoch();
        coord.retire_at_epoch(
            ep,
            Box::new(move || {
                dropped_clone.fetch_add(1, Ordering::Release);
            }),
        );

        assert_eq!(coord.poll_reclaim(), 0, "no quiescent yet");

        c0.quiescent_state(ep);
        assert_eq!(coord.poll_reclaim(), 1, "should now reclaim");
        assert_eq!(dropped.load(Ordering::Acquire), 1);
    }

    #[test]
    fn test_hierarchical_poll_reclaim_reentrant_retire_does_not_deadlock() {
        use std::sync::atomic::{AtomicBool, Ordering};
        use std::sync::Arc;

        let coord = Arc::new(HierarchicalQsbrCoordinator::new(&[0]));
        let core = coord.register_core(0, 0);

        let inner_ran = Arc::new(AtomicBool::new(false));
        let inner_ran_clone = inner_ran.clone();
        let coord_for_closure = coord.clone();

        let ep1 = coord.advance_epoch();
        coord.retire_at_epoch(
            ep1,
            Box::new(move || {
                let ep_inner = coord_for_closure.advance_epoch();
                coord_for_closure.retire_at_epoch(
                    ep_inner,
                    Box::new(move || {
                        inner_ran_clone.store(true, Ordering::Release);
                    }),
                );
            }),
        );

        core.quiescent_state(coord.global_epoch());
        assert_eq!(coord.poll_reclaim(), 1);

        core.quiescent_state(coord.global_epoch());
        assert_eq!(coord.poll_reclaim(), 1);

        assert!(inner_ran.load(Ordering::Acquire));
    }
}
