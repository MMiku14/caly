//! Caly-Orchestrator Daemon Entry Point.
//!
//! Orchestrates the full lifecycle of the Caly Network Kernel:
//! - Physical HugePage cache-colored arena
//! - NUMA-local Hierarchical QSBR Epoch Reclamation
//! - Spatial Router with ROBDD Zero-DNS proofs
//! - Speculative Continuous Feedback DNS Grid
//! - Dynamic Outbound Dialing with `IoToken` and `IoOperation`
//! - Event-driven hardware TSC cycle decay graceful formal drain

use std::net::{IpAddr, Ipv4Addr};
use std::sync::atomic::{AtomicBool, Ordering};
use std::time::Duration;

use caly_orchestrator::drain::DrainConfig;
use caly_orchestrator::{IoToken, Orchestrator, OrchestratorConfig, RouteAction, RouterConfig};

static RUNNING: AtomicBool = AtomicBool::new(true);

extern "C" fn handle_signal(_sig: libc::c_int) {
    RUNNING.store(false, Ordering::SeqCst);
}

fn setup_signals() {
    #[cfg(target_os = "linux")]
    // SAFETY: `zeroed` produces a valid all-zero value for the C-FFI POD type.
    unsafe {
        let mut sa: libc::sigaction = std::mem::zeroed();
        sa.sa_sigaction = handle_signal as *const () as usize;
        sa.sa_flags = 0;
        libc::sigemptyset(&mut sa.sa_mask);
        libc::sigaction(libc::SIGINT, &sa, std::ptr::null_mut());
        libc::sigaction(libc::SIGTERM, &sa, std::ptr::null_mut());
    }
}

fn main() {
    println!("[caly-orchestrator] Initializing REV 5.0 Kernel Architecture with Dynamic Outbound Reactor...");
    setup_signals();

    let mut router_config = RouterConfig::default();
    router_config
        .ipv4_cidrs
        .push(("10.0.0.0/8".into(), RouteAction::Direct));
    router_config
        .ipv4_cidrs
        .push(("172.16.0.0/12".into(), RouteAction::Direct));
    router_config
        .ipv4_cidrs
        .push(("192.168.0.0/16".into(), RouteAction::Direct));

    let config = OrchestratorConfig {
        router_config,
        ..Default::default()
    };

    println!(
        "[caly-orchestrator] NUMA topology: {} socket(s) {:?}, worker cores: {:?}",
        config.numa_nodes.len(),
        config.numa_nodes,
        config.core_ids
    );

    let orchestrator = match Orchestrator::new(config) {
        Ok(orch) => orch,
        Err(e) => {
            eprintln!("[caly-orchestrator] Initialization error: {e}");
            std::process::exit(1);
        }
    };

    println!(
        "[caly-orchestrator] HugePage Arena mapped: {} bytes (HugeTLB: {})",
        orchestrator.arena().capacity(),
        orchestrator.arena().is_hugetlb()
    );
    println!("[caly-orchestrator] Spatial Router compiled successfully");
    println!(
        "[caly-orchestrator] Hierarchical QSBR active (global epoch: {})",
        orchestrator.hierarchical_qsbr().global_epoch()
    );

    // Seed continuous feedback DNS grid
    let dns = orchestrator.dns_pipeline();
    dns.insert_mapping(
        "gateway.internal",
        vec![
            IpAddr::V4(Ipv4Addr::new(10, 0, 0, 1)),
            IpAddr::V4(Ipv4Addr::new(10, 0, 0, 2)),
        ],
        300,
    );
    println!(
        "[caly-orchestrator] Speculative DNS Pipeline seeded with {} domain grid(s)",
        dns.len()
    );

    // Demonstrate dynamic outbound dialing token encoding
    let dialer = orchestrator.dialer();
    match dialer.initiate_dial(1, 100, Some("gateway.internal"), None, 443, 0) {
        Ok((mut session, token)) => {
            println!(
                "[caly-orchestrator] Initiated dynamic dial: op={:?}, conn_id={}, token_raw={:#x}",
                token.op,
                token.conn_id,
                IoToken::encode(token.op, token.buf_idx, token.conn_id)
            );
            // Simulate successful connect completion
            let _ = dialer.on_connect_completed(&mut session, true, Some(101), 1000, 2_400_000_000);
            dialer.close_session(&mut session, "Startup check complete");
        }
        Err(e) => {
            eprintln!("[caly-orchestrator] Dialer check error: {e}");
        }
    }

    let reactor_threads = match orchestrator.spawn_reactors() {
        Ok(t) => t,
        Err(e) => {
            eprintln!("[caly-orchestrator] Failed to spawn reactor threads: {e}");
            std::process::exit(1);
        }
    };

    println!(
        "[caly-orchestrator] Running {} reactor worker core(s)...",
        reactor_threads.len()
    );

    // Loop until signal received or in demonstration run
    let mut check_ticks = 0;
    while RUNNING.load(Ordering::Relaxed) && check_ticks < 5 {
        std::thread::sleep(Duration::from_millis(100));
        check_ticks += 1;
    }

    println!("[caly-orchestrator] Shutdown initiated. Executing formal TSC cycle drain...");
    match orchestrator.drain(DrainConfig::default()) {
        Ok(report) => {
            println!(
                "[caly-orchestrator] Drain completed: {} flows, {} server writes, {} client writes drained in {} cycles ({} ns)",
                report.drained_flows,
                report.drained_server_writes,
                report.drained_client_writes,
                report.elapsed_cycles,
                report.elapsed_nanos
            );
        }
        Err(e) => {
            eprintln!("[caly-orchestrator] Drain error: {e}");
        }
    }

    println!("[caly-orchestrator] Caly Core shut down cleanly.");
}
