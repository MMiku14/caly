//! Criterion benchmarks for the SIMD cyclic mask operator.

use criterion::{black_box, criterion_group, criterion_main, BenchmarkId, Criterion, Throughput};
use caly_pipe::simd_mask::{apply_mask, apply_mask_with_backend, SimdBackend};

fn bench_simd_mask_throughput(c: &mut Criterion) {
    let key = [0x11, 0x22, 0x33, 0x44];

    let mut group = c.benchmark_group("simd_mask/throughput");
    for size in [16usize, 32, 48, 64, 128, 512, 4096, 16_384, 65_536, 262_144] {
        let base = vec![0u8; size];
        group.throughput(Throughput::Bytes(size as u64));
        group.bench_with_input(
            BenchmarkId::new("auto_backend", size),
            &base,
            |b, base| {
                b.iter_batched(
                    || base.clone(),
                    |mut buf| {
                        apply_mask(key, black_box(&mut buf));
                        buf
                    },
                    criterion::BatchSize::SmallInput,
                );
            },
        );
    }
    group.finish();

    let mut group = c.benchmark_group("simd_mask/backends");
    let base = vec![0u8; 4096];
    group.throughput(Throughput::Bytes(4096));
    for backend in [
        SimdBackend::Scalar,
        SimdBackend::Sse2,
        SimdBackend::Avx2,
        SimdBackend::Avx512,
    ] {
        group.bench_with_input(
            BenchmarkId::from_parameter(format!("{backend:?}")),
            &base,
            |b, base| {
                b.iter_batched(
                    || base.clone(),
                    |mut buf| {
                        let _ = apply_mask_with_backend(key, 0, black_box(&mut buf), backend);
                        buf
                    },
                    criterion::BatchSize::SmallInput,
                );
            },
        );
    }
    group.finish();
}

criterion_group!(benches, bench_simd_mask_throughput);
criterion_main!(benches);
