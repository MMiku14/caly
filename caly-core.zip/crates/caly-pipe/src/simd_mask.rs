//! AVX-512, AVX2, SSE2, NEON & 64-bit word unrolling WebSocket cyclic masking operator.
//!
//! Provides ultra-high-throughput in-place XOR masking and unmasking according to RFC 6455
//! Section 5.3, supporting arbitrary buffer alignments, remainder offsets, and hardware backends.

use crate::error::PipeError;
use crate::pipeline::{InPlaceTransducer, StreamTransducer};
use core::sync::atomic::{AtomicU8, Ordering};

/// Target hardware architecture backend for SIMD acceleration.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum SimdBackend {
    /// Intel AVX-512 (512-bit vector registers: `_mm512_xor_si512`).
    Avx512,
    /// Intel/AMD AVX2 (256-bit vector registers: `_mm256_xor_si256`).
    Avx2,
    /// x86 SSE2 baseline (128-bit vector registers: `_mm_xor_si128`).
    Sse2,
    /// ARM NEON (128-bit vector registers: `veorq_u8`).
    Neon,
    /// Portable scalar fallback using 64-bit word unrolling.
    Scalar,
}

static CACHED_BACKEND: AtomicU8 = AtomicU8::new(0);

const BACKEND_UNINIT: u8 = 0;
const BACKEND_AVX512: u8 = 1;
const BACKEND_AVX2: u8 = 2;
const BACKEND_SSE2: u8 = 3;
const BACKEND_NEON: u8 = 4;
const BACKEND_SCALAR: u8 = 5;

/// Detects the highest performance SIMD backend supported by the host CPU.
/// Caches the result in an atomic variable for zero runtime dispatch overhead on subsequent calls.
#[inline(always)]
pub fn detect_best_backend() -> SimdBackend {
    let cached = CACHED_BACKEND.load(Ordering::Relaxed);
    if cached != BACKEND_UNINIT {
        return match cached {
            BACKEND_AVX512 => SimdBackend::Avx512,
            BACKEND_AVX2 => SimdBackend::Avx2,
            BACKEND_SSE2 => SimdBackend::Sse2,
            BACKEND_NEON => SimdBackend::Neon,
            _ => SimdBackend::Scalar,
        };
    }

    let detected = detect_hardware_backend();
    let val = match detected {
        SimdBackend::Avx512 => BACKEND_AVX512,
        SimdBackend::Avx2 => BACKEND_AVX2,
        SimdBackend::Sse2 => BACKEND_SSE2,
        SimdBackend::Neon => BACKEND_NEON,
        SimdBackend::Scalar => BACKEND_SCALAR,
    };
    CACHED_BACKEND.store(val, Ordering::Relaxed);
    detected
}

fn detect_hardware_backend() -> SimdBackend {
    #[cfg(target_arch = "x86_64")]
    {
        if is_x86_feature_detected!("avx512f") {
            return SimdBackend::Avx512;
        }
        if is_x86_feature_detected!("avx2") {
            return SimdBackend::Avx2;
        }
        if is_x86_feature_detected!("sse2") {
            return SimdBackend::Sse2;
        }
    }

    #[cfg(target_arch = "aarch64")]
    {
        return SimdBackend::Neon;
    }

    #[allow(unreachable_code)]
    SimdBackend::Scalar
}

/// Computes the 4-byte rotated masking key for an arbitrary offset into the cyclic 4-byte mask.
#[inline(always)]
pub const fn rotate_mask_key(key: [u8; 4], offset: usize) -> [u8; 4] {
    let o = offset & 3;
    [key[o], key[(o + 1) & 3], key[(o + 2) & 3], key[(o + 3) & 3]]
}

/// Applies a 4-byte WebSocket cyclic XOR mask in-place starting at offset 0.
///
/// ## Performance
///
/// The dispatcher (`apply_mask_with_backend`) selects between two
/// paths based on `data.len()`:
///
/// 1. **Small buffers (`< 128 B`)**: 64-bit unrolled scalar loop. SIMD
///    setup (mask construction, `#[target_feature]` call frame)
///    dominates below this threshold; Criterion measured 64 B at
///    ~97 ns on AVX-512 vs ~20 ns for scalar.
/// 2. **Larger buffers**: AVX-512 (2× unroll, 128 B/iter) / AVX2
///    (2× unroll, 64 B/iter) / SSE2 / NEON.
#[inline(always)]
pub fn apply_mask(key: [u8; 4], data: &mut [u8]) {
    let _ = apply_mask_offset(key, 0, data);
}

/// Applies a 4-byte WebSocket cyclic XOR mask in-place starting at an arbitrary cyclic offset.
///
/// Returns the updated mask offset `(offset + data.len()) % 4` for subsequent continuous stream chunks.
#[inline(always)]
pub fn apply_mask_offset(key: [u8; 4], offset: usize, data: &mut [u8]) -> usize {
    apply_mask_with_backend(key, offset, data, detect_best_backend())
}

/// Applies a 4-byte WebSocket cyclic XOR mask in-place using a specific backend.
#[inline(always)]
pub fn apply_mask_with_backend(
    key: [u8; 4],
    offset: usize,
    data: &mut [u8],
    backend: SimdBackend,
) -> usize {
    let len = data.len();
    if len == 0 {
        return offset & 3;
    }

    let rotated = rotate_mask_key(key, offset);

    // Small-buffer fast path.
    //
    // Criterion measurements (2026-09-27, Skylake-X) showed 64 B and
    // 128 B regressing 59 % / 15 % through the SIMD dispatch: the
    // AVX-512 path pays for `_mm512_set1_epi32` + a `#[target_feature]`
    // call frame without amortizing it over enough bytes. Below
    // `SCALAR_THRESHOLD`, the 64-bit unrolled scalar loop is both
    // shorter and faster.
    const SCALAR_THRESHOLD: usize = 128;
    if len < SCALAR_THRESHOLD {
        apply_scalar_64(rotated, data);
        return (offset + len) & 3;
    }

    // Guard every SIMD dispatch with a runtime CPU feature check. The
    // `#[target_feature(enable = "...")]` functions invoke instructions that
    // the host CPU may not implement (e.g. AVX-512 on pre-Skylake, AVX2 on
    // pre-Haswell, NEON on x86). Calling them unconditionally is undefined
    // behaviour; here we fall back to the scalar path if the feature is
    // missing. In steady-state production code the backend selected by
    // `detect_best_backend()` is already known to be supported, so the check
    // is effectively free (a cached CPUID flag load).
    #[cfg(target_arch = "x86_64")]
    {
        match backend {
            SimdBackend::Avx512 if is_x86_feature_detected!("avx512f") => {
                // SAFETY: `is_x86_feature_detected!` above confirmed
                // AVX-512F support, which is the sole precondition of
                // `apply_avx512`.
                unsafe { apply_avx512(rotated, data) };
                return (offset + len) & 3;
            }
            SimdBackend::Avx2 if is_x86_feature_detected!("avx2") => {
                // SAFETY: AVX2 detected above.
                unsafe { apply_avx2(rotated, data) };
                return (offset + len) & 3;
            }
            SimdBackend::Sse2 if is_x86_feature_detected!("sse2") => {
                // SAFETY: SSE2 detected above.
                unsafe { apply_sse2(rotated, data) };
                return (offset + len) & 3;
            }
            _ => {}
        }
    }

    #[cfg(target_arch = "aarch64")]
    {
        if matches!(backend, SimdBackend::Neon) && std::arch::is_aarch64_feature_detected!("neon") {
            unsafe { apply_neon(rotated, data) };
            return (offset + len) & 3;
        }
    }

    // Scalar fallback (also the correct path when `backend` names an
    // unsupported SIMD extension).
    apply_scalar_64(rotated, data);
    (offset + len) & 3
}

/// AVX-512 wide-vector in-place masking implementation (64 bytes per vector, unrolled 2x to 128 bytes).
#[cfg(target_arch = "x86_64")]
#[target_feature(enable = "avx512f")]
// The whole body shares one SAFETY invariant ("AVX-512F is available,
// the slice is in bounds"), so we group the intrinsic calls into a
// single auditable `unsafe` block instead of scattering dozens of
// one-op blocks.
#[allow(clippy::multiple_unsafe_ops_per_block)]
unsafe fn apply_avx512(rotated: [u8; 4], data: &mut [u8]) {
    // SAFETY: Caller guarantees AVX-512F support; `data.len()` is respected by the loop bounds and the trailing scalar path.
    unsafe {
        use core::arch::x86_64::*;

        let len = data.len();
        let k32 = u32::from_ne_bytes(rotated);
        let v_mask = _mm512_set1_epi32(k32 as i32);

        let mut ptr = data.as_mut_ptr();
        let mut rem = len;

        // Unroll 2x: 128 bytes per loop
        while rem >= 128 {
            let v0 = _mm512_loadu_si512(ptr as *const _);
            let v1 = _mm512_loadu_si512(ptr.add(64) as *const _);

            let r0 = _mm512_xor_si512(v0, v_mask);
            let r1 = _mm512_xor_si512(v1, v_mask);

            _mm512_storeu_si512(ptr as *mut _, r0);
            _mm512_storeu_si512(ptr.add(64) as *mut _, r1);

            ptr = ptr.add(128);
            rem -= 128;
        }

        // 64-byte vector remainder
        if rem >= 64 {
            let v0 = _mm512_loadu_si512(ptr as *const _);
            let r0 = _mm512_xor_si512(v0, v_mask);
            _mm512_storeu_si512(ptr as *mut _, r0);

            rem -= 64;
        }

        // Trailing remainder using scalar 64-bit and bytes
        if rem > 0 {
            let processed = len - rem;
            apply_scalar_64_tail(rotated, &mut data[processed..]);
        }
    }
}

/// AVX2 wide-vector in-place masking implementation (32 bytes per vector, unrolled 2x to 64 bytes).
#[cfg(target_arch = "x86_64")]
#[target_feature(enable = "avx2")]
// See `apply_avx512` for the rationale behind the function-level allow.
#[allow(clippy::multiple_unsafe_ops_per_block)]
unsafe fn apply_avx2(rotated: [u8; 4], data: &mut [u8]) {
    // SAFETY: Caller guarantees AVX2 support; `data.len()` is respected by the loop bounds and the trailing scalar path.
    unsafe {
        use core::arch::x86_64::*;

        let len = data.len();
        let k32 = u32::from_ne_bytes(rotated);
        let v_mask = _mm256_set1_epi32(k32 as i32);

        let mut ptr = data.as_mut_ptr();
        let mut rem = len;

        // Unroll 2x: 64 bytes per loop
        while rem >= 64 {
            let v0 = _mm256_loadu_si256(ptr as *const _);
            let v1 = _mm256_loadu_si256(ptr.add(32) as *const _);

            let r0 = _mm256_xor_si256(v0, v_mask);
            let r1 = _mm256_xor_si256(v1, v_mask);

            _mm256_storeu_si256(ptr as *mut _, r0);
            _mm256_storeu_si256(ptr.add(32) as *mut _, r1);

            ptr = ptr.add(64);
            rem -= 64;
        }

        // 32-byte vector remainder
        if rem >= 32 {
            let v0 = _mm256_loadu_si256(ptr as *const _);
            let r0 = _mm256_xor_si256(v0, v_mask);
            _mm256_storeu_si256(ptr as *mut _, r0);

            rem -= 32;
        }

        // Trailing remainder
        if rem > 0 {
            let processed = len - rem;
            apply_scalar_64_tail(rotated, &mut data[processed..]);
        }
    }
}

/// SSE2 baseline in-place masking implementation (16 bytes per vector, unrolled 2x to 32 bytes).
#[cfg(target_arch = "x86_64")]
#[target_feature(enable = "sse2")]
// See `apply_avx512` for the rationale behind the function-level allow.
#[allow(clippy::multiple_unsafe_ops_per_block)]
unsafe fn apply_sse2(rotated: [u8; 4], data: &mut [u8]) {
    // SAFETY: Caller guarantees SSE2 support; `data.len()` is respected by the loop bounds and the trailing scalar path.
    unsafe {
        use core::arch::x86_64::*;

        let len = data.len();
        let k32 = u32::from_ne_bytes(rotated);
        let v_mask = _mm_set1_epi32(k32 as i32);

        let mut ptr = data.as_mut_ptr();
        let mut rem = len;

        // Unroll 2x: 32 bytes per loop
        while rem >= 32 {
            let v0 = _mm_loadu_si128(ptr as *const _);
            let v1 = _mm_loadu_si128(ptr.add(16) as *const _);

            let r0 = _mm_xor_si128(v0, v_mask);
            let r1 = _mm_xor_si128(v1, v_mask);

            _mm_storeu_si128(ptr as *mut _, r0);
            _mm_storeu_si128(ptr.add(16) as *mut _, r1);

            ptr = ptr.add(32);
            rem -= 32;
        }

        if rem >= 16 {
            let v0 = _mm_loadu_si128(ptr as *const _);
            let r0 = _mm_xor_si128(v0, v_mask);
            _mm_storeu_si128(ptr as *mut _, r0);

            rem -= 16;
        }

        if rem > 0 {
            let processed = len - rem;
            apply_scalar_64_tail(rotated, &mut data[processed..]);
        }
    }
}

/// ARM NEON 128-bit vector in-place masking implementation.
#[cfg(target_arch = "aarch64")]
#[target_feature(enable = "neon")]
unsafe fn apply_neon(rotated: [u8; 4], data: &mut [u8]) {
    // SAFETY: Caller guarantees NEON support; `data.len()` is respected by the loop bounds and the trailing scalar path.
    unsafe {
        use core::arch::aarch64::*;

        let len = data.len();
        let k32 = u32::from_ne_bytes(rotated);
        let v_mask = vdupq_n_u32(k32);
        let v_mask_u8 = vreinterpretq_u8_u32(v_mask);

        let mut ptr = data.as_mut_ptr();
        let mut rem = len;

        while rem >= 32 {
            let v0 = vld1q_u8(ptr);
            let v1 = vld1q_u8(ptr.add(16));

            let r0 = veorq_u8(v0, v_mask_u8);
            let r1 = veorq_u8(v1, v_mask_u8);

            vst1q_u8(ptr, r0);
            vst1q_u8(ptr.add(16), r1);

            ptr = ptr.add(32);
            rem -= 32;
        }

        if rem >= 16 {
            let v0 = vld1q_u8(ptr);
            let r0 = veorq_u8(v0, v_mask_u8);
            vst1q_u8(ptr, r0);

            ptr = ptr.add(16);
            rem -= 16;
        }

        if rem > 0 {
            let processed = len - rem;
            apply_scalar_64_tail(rotated, &mut data[processed..]);
        }
    }
}

/// Highly optimized portable scalar fallback using 64-bit word unrolling.
///
/// Processes 32 bytes per iteration using four independent `u64` XORs.
/// Hand-written instead of `chunks_exact_mut(32)` because the iterator
/// version compiles to repeated `split_at_mut` + bounds checks; the
/// straight-line version is a single `while i + 32 <= len` test per
/// 32 bytes, and the compiler can keep all four words in registers.
// See `apply_avx512` for the rationale behind the function-level allow.
#[allow(clippy::multiple_unsafe_ops_per_block)]
#[inline(always)]
pub fn apply_scalar_64(rotated: [u8; 4], data: &mut [u8]) {
    let len = data.len();
    let k32 = u32::from_ne_bytes(rotated) as u64;
    let k64 = (k32 << 32) | k32;

    let ptr = data.as_mut_ptr();
    let mut i = 0usize;

    // 32 B / iteration: four u64 XORs.
    while i + 32 <= len {
        // SAFETY: `i + 32 <= len` guarantees the four reads/writes at
        // `i + {0,8,16,24}` fall inside the slice, which is exclusively
        // borrowed by `data: &mut [u8]`.
        unsafe {
            let w0 = (ptr.add(i) as *const u64).read_unaligned() ^ k64;
            let w1 = (ptr.add(i + 8) as *const u64).read_unaligned() ^ k64;
            let w2 = (ptr.add(i + 16) as *const u64).read_unaligned() ^ k64;
            let w3 = (ptr.add(i + 24) as *const u64).read_unaligned() ^ k64;
            (ptr.add(i) as *mut u64).write_unaligned(w0);
            (ptr.add(i + 8) as *mut u64).write_unaligned(w1);
            (ptr.add(i + 16) as *mut u64).write_unaligned(w2);
            (ptr.add(i + 24) as *mut u64).write_unaligned(w3);
        }
        i += 32;
    }

    // 8 B remainder.
    while i + 8 <= len {
        // SAFETY: `i + 8 <= len`.
        unsafe {
            let w = (ptr.add(i) as *const u64).read_unaligned() ^ k64;
            (ptr.add(i) as *mut u64).write_unaligned(w);
        }
        i += 8;
    }

    // Byte tail (0..7 bytes).
    let rem = &mut data[i..];
    for (j, byte) in rem.iter_mut().enumerate() {
        *byte ^= rotated[j & 3];
    }
}

/// Handles remainder bytes up to 31 bytes using 8-byte steps and byte-level loop.
#[inline(always)]
fn apply_scalar_64_tail(rotated: [u8; 4], tail: &mut [u8]) {
    let k32 = u32::from_ne_bytes(rotated) as u64;
    let k64 = (k32 << 32) | k32;

    let (chunks8, rem) = tail.as_chunks_mut::<8>();
    for chunk in chunks8 {
        let w = u64::from_ne_bytes(*chunk);
        chunk.copy_from_slice(&(w ^ k64).to_ne_bytes());
    }

    let rem_len = rem.len();
    for i in 0..rem_len {
        rem[i] ^= rotated[i & 3];
    }
}

/// Stateful WebSocket SIMD mask operator conforming to [`InPlaceTransducer`] and [`StreamTransducer`].
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct SimdMaskOperator {
    key: [u8; 4],
    offset: usize,
    backend: SimdBackend,
}

impl SimdMaskOperator {
    /// Creates a new operator with the provided 4-byte key and automatic architecture detection.
    #[inline(always)]
    pub fn new(key: [u8; 4]) -> Self {
        Self {
            key,
            offset: 0,
            backend: detect_best_backend(),
        }
    }

    /// Creates a new operator explicitly configured with a specific SIMD backend.
    #[inline(always)]
    pub fn with_backend(key: [u8; 4], backend: SimdBackend) -> Self {
        Self {
            key,
            offset: 0,
            backend,
        }
    }

    /// Returns the currently active masking key.
    #[inline(always)]
    pub const fn key(&self) -> [u8; 4] {
        self.key
    }

    /// Updates the masking key.
    #[inline(always)]
    pub fn set_key(&mut self, key: [u8; 4]) {
        self.key = key;
    }

    /// Returns the current running cyclic offset (0..3).
    #[inline(always)]
    pub const fn offset(&self) -> usize {
        self.offset
    }

    /// Sets the current cyclic offset.
    #[inline(always)]
    pub fn set_offset(&mut self, offset: usize) {
        self.offset = offset & 3;
    }

    /// Returns the active SIMD backend.
    #[inline(always)]
    pub const fn backend(&self) -> SimdBackend {
        self.backend
    }
}

impl InPlaceTransducer for SimdMaskOperator {
    type Error = PipeError;

    #[inline(always)]
    fn transform_mut(&mut self, buffer: &mut [u8]) -> Result<usize, Self::Error> {
        self.offset = apply_mask_with_backend(self.key, self.offset, buffer, self.backend);
        Ok(buffer.len())
    }

    #[inline(always)]
    fn reset(&mut self) {
        self.offset = 0;
    }
}

impl StreamTransducer for SimdMaskOperator {
    type Error = PipeError;
    type Input<'a>
        = &'a mut [u8]
    where
        Self: 'a;
    type Output<'a>
        = &'a mut [u8]
    where
        Self: 'a;

    #[inline(always)]
    fn transform<'a>(&mut self, input: Self::Input<'a>) -> Result<Self::Output<'a>, Self::Error> {
        self.offset = apply_mask_with_backend(self.key, self.offset, input, self.backend);
        Ok(input)
    }

    #[inline(always)]
    fn reset(&mut self) {
        self.offset = 0;
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_simd_mask_large_buffer_matches_scalar_reference() {
        // 256 KiB covers every SIMD main-loop iteration count and forces the
        // scalar tail path for a non-multiple-of-128 size.
        let key = [0xA5, 0x5A, 0xC3, 0x3C];
        let len = 256 * 1024 + 17; // non-power-of-2, non-multiple of 4

        let original: Vec<u8> = (0..len).map(|i| (i & 0xFF) as u8).collect();
        let mut masked = original.clone();

        let _ = apply_mask(key, &mut masked);

        for i in 0..len {
            let expect = original[i] ^ key[i % 4];
            assert_eq!(masked[i], expect, "mismatch at {i}");
        }

        // Round-trip restores the original bytes.
        let _ = apply_mask(key, &mut masked);
        assert_eq!(masked, original);
    }

    #[test]
    fn test_simd_mask_backend_consistency() {
        // All *supported* backends must produce identical output for the same
        // input. Unsupported SIMD extensions are skipped: calling them is UB
        // (the inner `apply_*` functions carry `#[target_feature]`), and under
        // Miri `is_x86_feature_detected!` reports the baseline target features
        // only, so the AVX/AVX-512 branches would never be taken anyway.
        let key = [0x9E, 0x37, 0x79, 0xB0];
        let original: Vec<u8> = (0..1027u32)
            .map(|i| (i.wrapping_mul(7) & 0xFF) as u8)
            .collect();

        let mut reference = original.clone();
        let _ = apply_mask_with_backend(key, 0, &mut reference, SimdBackend::Scalar);

        let mut supported = vec![SimdBackend::Scalar];

        #[cfg(target_arch = "x86_64")]
        {
            if is_x86_feature_detected!("sse2") {
                supported.push(SimdBackend::Sse2);
            }
            if is_x86_feature_detected!("avx2") {
                supported.push(SimdBackend::Avx2);
            }
            if is_x86_feature_detected!("avx512f") {
                supported.push(SimdBackend::Avx512);
            }
        }

        #[cfg(target_arch = "aarch64")]
        {
            if std::arch::is_aarch64_feature_detected!("neon") {
                supported.push(SimdBackend::Neon);
            }
        }

        assert!(
            !supported.is_empty(),
            "scalar backend must always be usable"
        );

        for backend in supported {
            let mut buf = original.clone();
            let _ = apply_mask_with_backend(key, 0, &mut buf, backend);
            assert_eq!(
                buf, reference,
                "backend {backend:?} produced divergent output",
            );
        }
    }

    /// `apply_scalar_64` must produce byte-identical results to a naive
    /// per-byte XOR loop across every remainder class. The hand-written
    /// 32 / 8 / byte-tail decomposition is easy to get wrong at the
    /// boundary, so we exercise lengths 0..=96 exhaustively.
    #[test]
    fn test_apply_scalar_64_matches_reference() {
        let key = [0xA5u8, 0x5A, 0xC3, 0x3C];

        for len in 0usize..=96 {
            let original: Vec<u8> = (0..len).map(|i| ((i * 7) & 0xFF) as u8).collect();
            let mut got = original.clone();

            super::apply_scalar_64(key, &mut got);

            for i in 0..len {
                let expected = original[i] ^ key[i & 3];
                assert_eq!(
                    got[i], expected,
                    "len={len} at index {i}: got {:#x}, expected {:#x}",
                    got[i], expected,
                );
            }
        }
    }

    /// Below `SCALAR_THRESHOLD`, `apply_mask_with_backend` routes to
    /// the 64-bit unrolled scalar loop. Its result must be byte-equal
    /// to the explicit `SimdBackend::Scalar` path, and to a naive
    /// reference XOR, for every size that crosses the threshold.
    #[test]
    fn test_small_buffer_scalar_fast_path_is_correct() {
        let key = [0xC3u8, 0x5A, 0x1E, 0x99];
        // Sizes bracketing SCALAR_THRESHOLD = 128.
        for len in [0usize, 1, 7, 32, 63, 64, 96, 127, 128, 129] {
            let original: Vec<u8> = (0..len).map(|i| (i.wrapping_mul(31) & 0xFF) as u8).collect();

            let mut dispatched = original.clone();
            let _ = super::apply_mask(key, &mut dispatched);

            let mut reference = original.clone();
            let _ = super::apply_mask_with_backend(key, 0, &mut reference, SimdBackend::Scalar);

            assert_eq!(
                dispatched, reference,
                "len={len}: dispatched vs explicit scalar diverge",
            );

            for i in 0..len {
                let expected = original[i] ^ key[i & 3];
                assert_eq!(
                    dispatched[i], expected,
                    "len={len} at index {i}: got {:#x}, expected {:#x}",
                    dispatched[i], expected,
                );
            }
        }
    }

    /// The 16 B / 32 B single-instruction tail must agree with the
    /// scalar fallback across those same lengths.
    #[test]
    fn test_tiny_simd_tail_matches_scalar() {
        let key = [0x11u8, 0x22, 0x33, 0x44];

        for len in [1usize, 15, 16, 17, 31, 32, 33, 47, 48, 63, 64, 65] {
            let original: Vec<u8> = (0..len).map(|i| (i & 0xFF) as u8).collect();

            let mut scalar = original.clone();
            super::apply_scalar_64(key, &mut scalar);

            let mut dispatched = original.clone();
            let _ = super::apply_mask(key, &mut dispatched);

            assert_eq!(
                dispatched, scalar,
                "len={len}: dispatched SIMD vs scalar diverge",
            );
        }
    }
}
