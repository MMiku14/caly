//! Hardware-Accelerated Cryptographic Primitives for Caly-Pipe.
//!
//! Provides:
//! - **Intel SHA-NI**: Hardware-accelerated SHA-256 using Intel SHA extensions
//!   (`_mm_sha256rnds2_epu32`, `_mm_sha256msg1_epu32`, `_mm_sha256msg2_epu32`) with
//!   runtime CPU feature detection (`is_x86_feature_detected!("sha")`) and scalar fallback.
//! - **Vectorized ChaCha20**: High-throughput stream cipher execution using AVX-512
//!   (512-bit registers processing two 64-byte blocks = 128 bytes per round) and AVX2
//!   (256-bit registers processing 64 bytes / 128 bytes per round), with runtime CPU feature
//!   detection and scalar word fallback.

/// SHA-256 round constant schedule words.
pub const SHA256_K: [u32; 64] = [
    0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
    0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
    0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
    0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
    0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
    0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
    0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
    0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
];

/// SHA-256 standard initial state vector.
pub const SHA256_INIT: [u32; 8] = [
    0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a, 0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19,
];

// ============================================================================
// Intel SHA-NI Implementation (x86_64)
// ============================================================================

/// Checks whether Intel SHA-NI intrinsics and SSSE3/SSE4.1 are supported at runtime.
#[inline(always)]
pub fn has_sha_ni() -> bool {
    #[cfg(target_arch = "x86_64")]
    {
        is_x86_feature_detected!("sha")
            && is_x86_feature_detected!("ssse3")
            && is_x86_feature_detected!("sse4.1")
    }
    #[cfg(not(target_arch = "x86_64"))]
    {
        false
    }
}

/// Compresses a 64-byte block using Intel SHA-NI instructions.
///
/// # Safety
/// Caller must ensure that CPU supports `sha`, `ssse3`, and `sse4.1`.
#[cfg(target_arch = "x86_64")]
#[target_feature(enable = "sha,ssse3,sse4.1")]
pub unsafe fn sha256_compress_ni(state: &mut [u32; 8], block: &[u8; 64]) {
    // SAFETY: Caller guarantees CPU support for SHA-NI, SSSE3, and SSE4.1. All loads/stores stay within `state` (8 u32) and `block` (64 bytes).
    unsafe {
        use core::arch::x86_64::*;

        // Big-endian byte swapping mask for 32-bit words
        let mask = _mm_set_epi8(12, 13, 14, 15, 8, 9, 10, 11, 4, 5, 6, 7, 0, 1, 2, 3);

        // Initial state registers:
        // state0: [3]=A, [2]=B, [1]=E, [0]=F
        // state1: [3]=C, [2]=D, [1]=G, [0]=H
        let mut state0 = _mm_set_epi32(
            state[0] as i32,
            state[1] as i32,
            state[4] as i32,
            state[5] as i32,
        );
        let mut state1 = _mm_set_epi32(
            state[2] as i32,
            state[3] as i32,
            state[6] as i32,
            state[7] as i32,
        );

        let abef_save = state0;
        let cdgh_save = state1;

        let mut w: [__m128i; 16] = [
            _mm_shuffle_epi8(
                _mm_loadu_si128(block.as_ptr().add(0) as *const __m128i),
                mask,
            ),
            _mm_shuffle_epi8(
                _mm_loadu_si128(block.as_ptr().add(16) as *const __m128i),
                mask,
            ),
            _mm_shuffle_epi8(
                _mm_loadu_si128(block.as_ptr().add(32) as *const __m128i),
                mask,
            ),
            _mm_shuffle_epi8(
                _mm_loadu_si128(block.as_ptr().add(48) as *const __m128i),
                mask,
            ),
            _mm_setzero_si128(),
            _mm_setzero_si128(),
            _mm_setzero_si128(),
            _mm_setzero_si128(),
            _mm_setzero_si128(),
            _mm_setzero_si128(),
            _mm_setzero_si128(),
            _mm_setzero_si128(),
            _mm_setzero_si128(),
            _mm_setzero_si128(),
            _mm_setzero_si128(),
            _mm_setzero_si128(),
        ];

        // Compute message schedule W[16..63] via SHA256MSG1 and SHA256MSG2
        for i in 4..16 {
            let s = _mm_sha256msg1_epu32(w[i - 4], w[i - 3]);
            let s = _mm_add_epi32(s, _mm_alignr_epi8(w[i - 1], w[i - 2], 4));
            w[i] = _mm_sha256msg2_epu32(s, w[i - 1]);
        }

        // Execute 64 rounds (16 groups of 4 rounds, 2 rounds per sha256rnds2 instruction)
        for (i, wi) in w.iter().enumerate() {
            let k_ptr = SHA256_K.as_ptr().add(i * 4) as *const __m128i;
            let mut m = _mm_add_epi32(*wi, _mm_loadu_si128(k_ptr));
            state1 = _mm_sha256rnds2_epu32(state1, state0, m);
            m = _mm_shuffle_epi32(m, 0x0E);
            state0 = _mm_sha256rnds2_epu32(state0, state1, m);
        }

        state0 = _mm_add_epi32(state0, abef_save);
        state1 = _mm_add_epi32(state1, cdgh_save);

        let mut buf0 = [0u32; 4];
        let mut buf1 = [0u32; 4];
        _mm_storeu_si128(buf0.as_mut_ptr() as *mut __m128i, state0);
        _mm_storeu_si128(buf1.as_mut_ptr() as *mut __m128i, state1);

        state[0] = buf0[3];
        state[1] = buf0[2];
        state[2] = buf1[3];
        state[3] = buf1[2];
        state[4] = buf0[1];
        state[5] = buf0[0];
        state[6] = buf1[1];
        state[7] = buf1[0];
    }
}

/// Executes full SHA-256 using Intel SHA-NI intrinsics.
///
/// # Safety
///
/// The caller must ensure that the CPU executing this function supports
/// the `sha`, `ssse3`, and `sse4.1` features. Use `has_sha_ni()` to
/// perform the runtime check before calling.
#[cfg(target_arch = "x86_64")]
pub unsafe fn sha256_ni_impl(data: &[u8]) -> [u8; 32] {
    // SAFETY: Caller guarantees SHA-NI support. `sha256_compress_ni` is invoked only on 64-byte aligned chunks taken from `data` or from a local 64-byte padding block.
    unsafe {
        let mut state = SHA256_INIT;
        let total_len = data.len();
        let (chunks, remainder) = data.as_chunks::<64>();
        for block in chunks {
            sha256_compress_ni(&mut state, block);
        }

        let mut block = [0u8; 64];
        block[..remainder.len()].copy_from_slice(remainder);
        block[remainder.len()] = 0x80;

        if remainder.len() >= 56 {
            sha256_compress_ni(&mut state, &block);
            block = [0u8; 64];
        }

        let bit_len = (total_len as u64) * 8;
        block[56..64].copy_from_slice(&bit_len.to_be_bytes());
        sha256_compress_ni(&mut state, &block);

        let mut digest = [0u8; 32];
        for (i, word) in state.iter().enumerate() {
            digest[i * 4..(i + 1) * 4].copy_from_slice(&word.to_be_bytes());
        }
        digest
    }
}

// ============================================================================
// Scalar Constant-Time SHA-256 Fallback
// ============================================================================

/// Scalar constant-time 64-byte block compression function.
pub fn sha256_compress_scalar(state: &mut [u32; 8], block: &[u8; 64]) {
    let mut w = [0u32; 64];
    for i in 0..16 {
        let mut b = [0u8; 4];
        b.copy_from_slice(&block[i * 4..(i + 1) * 4]);
        w[i] = u32::from_be_bytes(b);
    }

    for i in 16..64 {
        let s0 = w[i - 15].rotate_right(7) ^ w[i - 15].rotate_right(18) ^ (w[i - 15] >> 3);
        let s1 = w[i - 2].rotate_right(17) ^ w[i - 2].rotate_right(19) ^ (w[i - 2] >> 10);
        w[i] = w[i - 16]
            .wrapping_add(s0)
            .wrapping_add(w[i - 7])
            .wrapping_add(s1);
    }

    let mut a = state[0];
    let mut b = state[1];
    let mut c = state[2];
    let mut d = state[3];
    let mut e = state[4];
    let mut f = state[5];
    let mut g = state[6];
    let mut h = state[7];

    for i in 0..64 {
        let s1 = e.rotate_right(6) ^ e.rotate_right(11) ^ e.rotate_right(25);
        let ch = (e & f) ^ (!e & g);
        let temp1 = h
            .wrapping_add(s1)
            .wrapping_add(ch)
            .wrapping_add(SHA256_K[i])
            .wrapping_add(w[i]);
        let s0 = a.rotate_right(2) ^ a.rotate_right(13) ^ a.rotate_right(22);
        let maj = (a & b) ^ (a & c) ^ (b & c);
        let temp2 = s0.wrapping_add(maj);

        h = g;
        g = f;
        f = e;
        e = d.wrapping_add(temp1);
        d = c;
        c = b;
        b = a;
        a = temp1.wrapping_add(temp2);
    }

    state[0] = state[0].wrapping_add(a);
    state[1] = state[1].wrapping_add(b);
    state[2] = state[2].wrapping_add(c);
    state[3] = state[3].wrapping_add(d);
    state[4] = state[4].wrapping_add(e);
    state[5] = state[5].wrapping_add(f);
    state[6] = state[6].wrapping_add(g);
    state[7] = state[7].wrapping_add(h);
}

/// Computes SHA-256 digest using the constant-time scalar implementation.
pub fn sha256_scalar(data: &[u8]) -> [u8; 32] {
    let mut state = SHA256_INIT;
    let total_len = data.len();
    let (chunks, remainder) = data.as_chunks::<64>();
    for block in chunks {
        sha256_compress_scalar(&mut state, block);
    }

    let mut block = [0u8; 64];
    block[..remainder.len()].copy_from_slice(remainder);
    block[remainder.len()] = 0x80;

    if remainder.len() >= 56 {
        sha256_compress_scalar(&mut state, &block);
        block = [0u8; 64];
    }

    let bit_len = (total_len as u64) * 8;
    block[56..64].copy_from_slice(&bit_len.to_be_bytes());
    sha256_compress_scalar(&mut state, &block);

    let mut digest = [0u8; 32];
    for (i, word) in state.iter().enumerate() {
        digest[i * 4..(i + 1) * 4].copy_from_slice(&word.to_be_bytes());
    }
    digest
}

/// Automatically dispatches to Intel SHA-NI or scalar SHA-256 based on CPU feature detection.
#[inline(always)]
pub fn sha256(data: &[u8]) -> [u8; 32] {
    #[cfg(target_arch = "x86_64")]
    {
        if has_sha_ni() {
            return unsafe { sha256_ni_impl(data) };
        }
    }
    sha256_scalar(data)
}

/// Computes HMAC-SHA256 with ZERO heap allocation, utilizing hardware SHA-NI instructions.
#[inline(always)]
pub fn hmac_sha256(key: &[u8], message: &[u8]) -> [u8; 32] {
    crate::reality::hmac_sha256(key, message)
}

// ============================================================================
// Vectorized ChaCha20 Stream Cipher (AVX-512 & AVX2)
// ============================================================================

const CHACHA_CONSTANTS: [u32; 4] = [0x61707865, 0x3320646e, 0x79622d32, 0x6b206574];

/// Checks whether AVX-512 Foundation instructions are supported at runtime.
#[inline(always)]
pub fn has_avx512() -> bool {
    #[cfg(target_arch = "x86_64")]
    {
        is_x86_feature_detected!("avx512f")
    }
    #[cfg(not(target_arch = "x86_64"))]
    {
        false
    }
}

/// Checks whether AVX2 instructions are supported at runtime.
#[inline(always)]
pub fn has_avx2() -> bool {
    #[cfg(target_arch = "x86_64")]
    {
        is_x86_feature_detected!("avx2")
    }
    #[cfg(not(target_arch = "x86_64"))]
    {
        false
    }
}

/// Scalar ChaCha20 implementation for arbitrary byte lengths and fallback.
pub fn chacha20_scalar(key: &[u8; 32], nonce: &[u8; 12], mut counter: u32, data: &mut [u8]) {
    let mut key_words = [0u32; 8];
    for i in 0..8 {
        let mut b = [0u8; 4];
        b.copy_from_slice(&key[i * 4..(i + 1) * 4]);
        key_words[i] = u32::from_le_bytes(b);
    }

    let mut nonce_words = [0u32; 3];
    for i in 0..3 {
        let mut b = [0u8; 4];
        b.copy_from_slice(&nonce[i * 4..(i + 1) * 4]);
        nonce_words[i] = u32::from_le_bytes(b);
    }

    let mut chunks = data.chunks_mut(64);
    for chunk in chunks.by_ref() {
        let state = [
            CHACHA_CONSTANTS[0],
            CHACHA_CONSTANTS[1],
            CHACHA_CONSTANTS[2],
            CHACHA_CONSTANTS[3],
            key_words[0],
            key_words[1],
            key_words[2],
            key_words[3],
            key_words[4],
            key_words[5],
            key_words[6],
            key_words[7],
            counter,
            nonce_words[0],
            nonce_words[1],
            nonce_words[2],
        ];

        let mut working = state;
        for _ in 0..10 {
            // Column rounds
            qr_scalar(&mut working, 0, 4, 8, 12);
            qr_scalar(&mut working, 1, 5, 9, 13);
            qr_scalar(&mut working, 2, 6, 10, 14);
            qr_scalar(&mut working, 3, 7, 11, 15);
            // Diagonal rounds
            qr_scalar(&mut working, 0, 5, 10, 15);
            qr_scalar(&mut working, 1, 6, 11, 12);
            qr_scalar(&mut working, 2, 7, 8, 13);
            qr_scalar(&mut working, 3, 4, 9, 14);
        }

        for i in 0..16 {
            working[i] = working[i].wrapping_add(state[i]);
        }

        let mut block = [0u8; 64];
        for (i, word) in working.iter().enumerate() {
            block[i * 4..(i + 1) * 4].copy_from_slice(&word.to_le_bytes());
        }

        for (i, byte) in chunk.iter_mut().enumerate() {
            *byte ^= block[i];
        }

        counter = counter.wrapping_add(1);
    }
}

#[inline(always)]
fn qr_scalar(state: &mut [u32; 16], a: usize, b: usize, c: usize, d: usize) {
    state[a] = state[a].wrapping_add(state[b]);
    state[d] ^= state[a];
    state[d] = state[d].rotate_left(16);

    state[c] = state[c].wrapping_add(state[d]);
    state[b] ^= state[c];
    state[b] = state[b].rotate_left(12);

    state[a] = state[a].wrapping_add(state[b]);
    state[d] ^= state[a];
    state[d] = state[d].rotate_left(8);

    state[c] = state[c].wrapping_add(state[d]);
    state[b] ^= state[c];
    state[b] = state[b].rotate_left(7);
}

/// AVX2-accelerated ChaCha20 keystream XOR processing 64 bytes or 128 bytes per round.
///
/// # Safety
/// Caller must ensure CPU supports `avx2`.
#[cfg(target_arch = "x86_64")]
#[target_feature(enable = "avx2")]
pub unsafe fn chacha20_avx2_impl(
    key: &[u8; 32],
    nonce: &[u8; 12],
    mut counter: u32,
    data: &mut [u8],
) {
    // SAFETY: Caller guarantees AVX2 support. Every loop iteration checks `offset + 128 <= data.len()` before touching memory, and the trailing scalar path handles the remainder.
    unsafe {
        use core::arch::x86_64::*;

        let mut key_words = [0u32; 8];
        for i in 0..8 {
            let mut b = [0u8; 4];
            b.copy_from_slice(&key[i * 4..(i + 1) * 4]);
            key_words[i] = u32::from_le_bytes(b);
        }

        let mut nonce_words = [0u32; 3];
        for i in 0..3 {
            let mut b = [0u8; 4];
            b.copy_from_slice(&nonce[i * 4..(i + 1) * 4]);
            nonce_words[i] = u32::from_le_bytes(b);
        }

        let r0 = _mm_set_epi32(
            CHACHA_CONSTANTS[3] as i32,
            CHACHA_CONSTANTS[2] as i32,
            CHACHA_CONSTANTS[1] as i32,
            CHACHA_CONSTANTS[0] as i32,
        );
        let r1 = _mm_set_epi32(
            key_words[3] as i32,
            key_words[2] as i32,
            key_words[1] as i32,
            key_words[0] as i32,
        );
        let r2 = _mm_set_epi32(
            key_words[7] as i32,
            key_words[6] as i32,
            key_words[5] as i32,
            key_words[4] as i32,
        );

        let rot16_mask = _mm256_set_epi8(
            13, 12, 15, 14, 9, 8, 11, 10, 5, 4, 7, 6, 1, 0, 3, 2, 13, 12, 15, 14, 9, 8, 11, 10, 5,
            4, 7, 6, 1, 0, 3, 2,
        );
        let rot8_mask = _mm256_set_epi8(
            14, 13, 12, 15, 10, 9, 8, 11, 6, 5, 4, 7, 2, 1, 0, 3, 14, 13, 12, 15, 10, 9, 8, 11, 6,
            5, 4, 7, 2, 1, 0, 3,
        );

        let mut offset = 0;
        while offset + 128 <= data.len() {
            let mut a = _mm256_broadcastsi128_si256(r0);
            let mut b = _mm256_broadcastsi128_si256(r1);
            let mut c = _mm256_broadcastsi128_si256(r2);

            let r3_0 = _mm_set_epi32(
                nonce_words[2] as i32,
                nonce_words[1] as i32,
                nonce_words[0] as i32,
                counter as i32,
            );
            let r3_1 = _mm_set_epi32(
                nonce_words[2] as i32,
                nonce_words[1] as i32,
                nonce_words[0] as i32,
                (counter + 1) as i32,
            );
            let mut d = _mm256_set_m128i(r3_1, r3_0);

            let a0 = a;
            let b0 = b;
            let c0 = c;
            let d0 = d;

            for _ in 0..10 {
                // Column round
                a = _mm256_add_epi32(a, b);
                d = _mm256_xor_si256(d, a);
                d = _mm256_shuffle_epi8(d, rot16_mask);

                c = _mm256_add_epi32(c, d);
                b = _mm256_xor_si256(b, c);
                b = _mm256_xor_si256(_mm256_slli_epi32(b, 12), _mm256_srli_epi32(b, 20));

                a = _mm256_add_epi32(a, b);
                d = _mm256_xor_si256(d, a);
                d = _mm256_shuffle_epi8(d, rot8_mask);

                c = _mm256_add_epi32(c, d);
                b = _mm256_xor_si256(b, c);
                b = _mm256_xor_si256(_mm256_slli_epi32(b, 7), _mm256_srli_epi32(b, 25));

                // Diagonal round: roll
                b = _mm256_shuffle_epi32(b, 0x39);
                c = _mm256_shuffle_epi32(c, 0x4E);
                d = _mm256_shuffle_epi32(d, 0x93);

                a = _mm256_add_epi32(a, b);
                d = _mm256_xor_si256(d, a);
                d = _mm256_shuffle_epi8(d, rot16_mask);

                c = _mm256_add_epi32(c, d);
                b = _mm256_xor_si256(b, c);
                b = _mm256_xor_si256(_mm256_slli_epi32(b, 12), _mm256_srli_epi32(b, 20));

                a = _mm256_add_epi32(a, b);
                d = _mm256_xor_si256(d, a);
                d = _mm256_shuffle_epi8(d, rot8_mask);

                c = _mm256_add_epi32(c, d);
                b = _mm256_xor_si256(b, c);
                b = _mm256_xor_si256(_mm256_slli_epi32(b, 7), _mm256_srli_epi32(b, 25));

                // Diagonal round: unroll
                b = _mm256_shuffle_epi32(b, 0x93);
                c = _mm256_shuffle_epi32(c, 0x4E);
                d = _mm256_shuffle_epi32(d, 0x39);
            }

            a = _mm256_add_epi32(a, a0);
            b = _mm256_add_epi32(b, b0);
            c = _mm256_add_epi32(c, c0);
            d = _mm256_add_epi32(d, d0);

            let ptr = data.as_mut_ptr().add(offset);

            // Block 0 (low 128 bits)
            let mut k0 = _mm256_castsi256_si128(a);
            let mut k1 = _mm256_castsi256_si128(b);
            let mut k2 = _mm256_castsi256_si128(c);
            let mut k3 = _mm256_castsi256_si128(d);

            let d0 = _mm_loadu_si128(ptr.add(0) as *const __m128i);
            let d1 = _mm_loadu_si128(ptr.add(16) as *const __m128i);
            let d2 = _mm_loadu_si128(ptr.add(32) as *const __m128i);
            let d3 = _mm_loadu_si128(ptr.add(48) as *const __m128i);

            _mm_storeu_si128(ptr.add(0) as *mut __m128i, _mm_xor_si128(d0, k0));
            _mm_storeu_si128(ptr.add(16) as *mut __m128i, _mm_xor_si128(d1, k1));
            _mm_storeu_si128(ptr.add(32) as *mut __m128i, _mm_xor_si128(d2, k2));
            _mm_storeu_si128(ptr.add(48) as *mut __m128i, _mm_xor_si128(d3, k3));

            // Block 1 (high 128 bits)
            k0 = _mm256_extracti128_si256(a, 1);
            k1 = _mm256_extracti128_si256(b, 1);
            k2 = _mm256_extracti128_si256(c, 1);
            k3 = _mm256_extracti128_si256(d, 1);

            let d4 = _mm_loadu_si128(ptr.add(64) as *const __m128i);
            let d5 = _mm_loadu_si128(ptr.add(80) as *const __m128i);
            let d6 = _mm_loadu_si128(ptr.add(96) as *const __m128i);
            let d7 = _mm_loadu_si128(ptr.add(112) as *const __m128i);

            _mm_storeu_si128(ptr.add(64) as *mut __m128i, _mm_xor_si128(d4, k0));
            _mm_storeu_si128(ptr.add(80) as *mut __m128i, _mm_xor_si128(d5, k1));
            _mm_storeu_si128(ptr.add(96) as *mut __m128i, _mm_xor_si128(d6, k2));
            _mm_storeu_si128(ptr.add(112) as *mut __m128i, _mm_xor_si128(d7, k3));

            offset += 128;
            counter = counter.wrapping_add(2);
        }

        // Process remaining bytes with scalar ChaCha20
        if offset < data.len() {
            chacha20_scalar(key, nonce, counter, &mut data[offset..]);
        }
    }
}

/// AVX-512-accelerated ChaCha20 keystream XOR processing two 64-byte blocks (128 bytes) per round.
///
/// # Safety
/// Caller must ensure CPU supports `avx512f`.
#[cfg(target_arch = "x86_64")]
#[target_feature(enable = "avx512f")]
pub unsafe fn chacha20_avx512_impl(
    key: &[u8; 32],
    nonce: &[u8; 12],
    mut counter: u32,
    data: &mut [u8],
) {
    // SAFETY: Caller guarantees AVX-512F support. Every loop iteration checks `offset + 128 <= data.len()` before touching memory, and the trailing scalar path handles the remainder.
    unsafe {
        use core::arch::x86_64::*;

        let mut key_words = [0u32; 8];
        for i in 0..8 {
            let mut b = [0u8; 4];
            b.copy_from_slice(&key[i * 4..(i + 1) * 4]);
            key_words[i] = u32::from_le_bytes(b);
        }

        let mut nonce_words = [0u32; 3];
        for i in 0..3 {
            let mut b = [0u8; 4];
            b.copy_from_slice(&nonce[i * 4..(i + 1) * 4]);
            nonce_words[i] = u32::from_le_bytes(b);
        }

        let r0 = _mm_set_epi32(
            CHACHA_CONSTANTS[3] as i32,
            CHACHA_CONSTANTS[2] as i32,
            CHACHA_CONSTANTS[1] as i32,
            CHACHA_CONSTANTS[0] as i32,
        );
        let r1 = _mm_set_epi32(
            key_words[3] as i32,
            key_words[2] as i32,
            key_words[1] as i32,
            key_words[0] as i32,
        );
        let r2 = _mm_set_epi32(
            key_words[7] as i32,
            key_words[6] as i32,
            key_words[5] as i32,
            key_words[4] as i32,
        );

        let mut offset = 0;
        while offset + 128 <= data.len() {
            let mut a = _mm512_broadcast_i32x4(r0);
            let mut b = _mm512_broadcast_i32x4(r1);
            let mut c = _mm512_broadcast_i32x4(r2);

            let r3_0 = _mm_set_epi32(
                nonce_words[2] as i32,
                nonce_words[1] as i32,
                nonce_words[0] as i32,
                counter as i32,
            );
            let r3_1 = _mm_set_epi32(
                nonce_words[2] as i32,
                nonce_words[1] as i32,
                nonce_words[0] as i32,
                (counter + 1) as i32,
            );
            let r3_dummy = _mm_setzero_si128();

            let d_lo = _mm256_set_m128i(r3_1, r3_0);
            let d_hi = _mm256_set_m128i(r3_dummy, r3_dummy);
            let mut d = _mm512_castsi256_si512(d_lo);
            d = _mm512_inserti64x4(d, d_hi, 1);

            let a0 = a;
            let b0 = b;
            let c0 = c;
            let d0 = d;

            for _ in 0..10 {
                // Column round
                a = _mm512_add_epi32(a, b);
                d = _mm512_xor_si512(d, a);
                d = _mm512_rol_epi32(d, 16);

                c = _mm512_add_epi32(c, d);
                b = _mm512_xor_si512(b, c);
                b = _mm512_rol_epi32(b, 12);

                a = _mm512_add_epi32(a, b);
                d = _mm512_xor_si512(d, a);
                d = _mm512_rol_epi32(d, 8);

                c = _mm512_add_epi32(c, d);
                b = _mm512_xor_si512(b, c);
                b = _mm512_rol_epi32(b, 7);

                // Diagonal round: roll
                b = _mm512_shuffle_epi32(b, 0x39);
                c = _mm512_shuffle_epi32(c, 0x4E);
                d = _mm512_shuffle_epi32(d, 0x93);

                a = _mm512_add_epi32(a, b);
                d = _mm512_xor_si512(d, a);
                d = _mm512_rol_epi32(d, 16);

                c = _mm512_add_epi32(c, d);
                b = _mm512_xor_si512(b, c);
                b = _mm512_rol_epi32(b, 12);

                a = _mm512_add_epi32(a, b);
                d = _mm512_xor_si512(d, a);
                d = _mm512_rol_epi32(d, 8);

                c = _mm512_add_epi32(c, d);
                b = _mm512_xor_si512(b, c);
                b = _mm512_rol_epi32(b, 7);

                // Diagonal round: unroll
                b = _mm512_shuffle_epi32(b, 0x93);
                c = _mm512_shuffle_epi32(c, 0x4E);
                d = _mm512_shuffle_epi32(d, 0x39);
            }

            a = _mm512_add_epi32(a, a0);
            b = _mm512_add_epi32(b, b0);
            c = _mm512_add_epi32(c, c0);
            d = _mm512_add_epi32(d, d0);

            let a_256 = _mm512_castsi512_si256(a);
            let b_256 = _mm512_castsi512_si256(b);
            let c_256 = _mm512_castsi512_si256(c);
            let d_256 = _mm512_castsi512_si256(d);

            let ptr = data.as_mut_ptr().add(offset);

            // Block 0
            let mut k0 = _mm256_castsi256_si128(a_256);
            let mut k1 = _mm256_castsi256_si128(b_256);
            let mut k2 = _mm256_castsi256_si128(c_256);
            let mut k3 = _mm256_castsi256_si128(d_256);

            let d0 = _mm_loadu_si128(ptr.add(0) as *const __m128i);
            let d1 = _mm_loadu_si128(ptr.add(16) as *const __m128i);
            let d2 = _mm_loadu_si128(ptr.add(32) as *const __m128i);
            let d3 = _mm_loadu_si128(ptr.add(48) as *const __m128i);

            _mm_storeu_si128(ptr.add(0) as *mut __m128i, _mm_xor_si128(d0, k0));
            _mm_storeu_si128(ptr.add(16) as *mut __m128i, _mm_xor_si128(d1, k1));
            _mm_storeu_si128(ptr.add(32) as *mut __m128i, _mm_xor_si128(d2, k2));
            _mm_storeu_si128(ptr.add(48) as *mut __m128i, _mm_xor_si128(d3, k3));

            // Block 1
            k0 = _mm256_extracti128_si256(a_256, 1);
            k1 = _mm256_extracti128_si256(b_256, 1);
            k2 = _mm256_extracti128_si256(c_256, 1);
            k3 = _mm256_extracti128_si256(d_256, 1);

            let d4 = _mm_loadu_si128(ptr.add(64) as *const __m128i);
            let d5 = _mm_loadu_si128(ptr.add(80) as *const __m128i);
            let d6 = _mm_loadu_si128(ptr.add(96) as *const __m128i);
            let d7 = _mm_loadu_si128(ptr.add(112) as *const __m128i);

            _mm_storeu_si128(ptr.add(64) as *mut __m128i, _mm_xor_si128(d4, k0));
            _mm_storeu_si128(ptr.add(80) as *mut __m128i, _mm_xor_si128(d5, k1));
            _mm_storeu_si128(ptr.add(96) as *mut __m128i, _mm_xor_si128(d6, k2));
            _mm_storeu_si128(ptr.add(112) as *mut __m128i, _mm_xor_si128(d7, k3));

            offset += 128;
            counter = counter.wrapping_add(2);
        }

        if offset < data.len() {
            chacha20_scalar(key, nonce, counter, &mut data[offset..]);
        }
    }
}

/// Automatically selects AVX-512, AVX2, or scalar ChaCha20 for in-place keystream XOR.
#[inline(always)]
pub fn chacha20_xor(key: &[u8; 32], nonce: &[u8; 12], counter: u32, data: &mut [u8]) {
    #[cfg(target_arch = "x86_64")]
    {
        if has_avx512() {
            // SAFETY: guarded by runtime feature detection above.
            return unsafe { chacha20_avx512_impl(key, nonce, counter, data) };
        }
        if has_avx2() {
            // SAFETY: guarded by runtime feature detection above.
            return unsafe { chacha20_avx2_impl(key, nonce, counter, data) };
        }
    }
    chacha20_scalar(key, nonce, counter, data);
}
