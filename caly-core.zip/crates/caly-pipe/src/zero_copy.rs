//! Zero-Copy DMA Buffer Slices, io_uring Fixed Buffer Descriptors, and Splicing Bridges.
//!
//! Provides hardware-aligned memory views, pre-registered buffer descriptors compatible
//! with Linux `io_uring` fixed buffers (`IORING_REGISTER_BUFFERS`), and circular ring-buffer
//! splicing bridges without runtime heap allocation.

use crate::error::{PipeError, Result};
use core::marker::PhantomData;
use core::ops::{Deref, DerefMut, Range};

// ============================================================================
// DMA Buffer Slice
// ============================================================================

/// Zero-copy mutable slice representing a memory region pre-registered with the kernel or DMA engine.
///
/// Binds a raw pointer, capacity, registration buffer index, and offset into a safe Rust view.
#[derive(Debug)]
pub struct DmaSlice<'a> {
    ptr: *mut u8,
    len: usize,
    buf_index: u16,
    offset: u32,
    _marker: PhantomData<&'a mut [u8]>,
}

// SAFETY: `DmaSlice` is a borrow of a pre-registered DMA region; the
// `PhantomData<&'a mut [u8]>` marker enforces exclusive ownership for
// the lifetime, so `Send` is sound.
unsafe impl<'a> Send for DmaSlice<'a> {}
// SAFETY: `&DmaSlice` exposes only read-only access (`as_slice`);
// mutation requires `&mut DmaSlice`.
unsafe impl<'a> Sync for DmaSlice<'a> {}

impl<'a> DmaSlice<'a> {
    /// Private constructor. Every public constructor and view-producing
    /// method funnels through here so the pointer/len/offset invariants
    /// are documented (and audited) in exactly one place.
    #[inline(always)]
    fn with_parts(ptr: *mut u8, len: usize, buf_index: u16, offset: u32) -> Self {
        Self {
            ptr,
            len,
            buf_index,
            offset,
            _marker: PhantomData,
        }
    }

    /// Constructs a `DmaSlice` from raw pointer and metadata.
    ///
    /// # Safety
    ///
    /// * `ptr` must be a valid, non-null pointer to at least `len` bytes
    ///   of initialized memory.
    /// * The memory must remain valid and not be mutated through any other
    ///   pointer for the entire lifetime `'a` of the returned `DmaSlice`.
    /// * `len` must not exceed the size of the allocation `ptr` was derived
    ///   from.
    #[inline(always)]
    pub unsafe fn from_raw_parts(ptr: *mut u8, len: usize, buf_index: u16, offset: u32) -> Self {
        Self::with_parts(ptr, len, buf_index, offset)
    }

    /// Creates a `DmaSlice` from a standard mutable byte slice.
    #[inline(always)]
    pub fn from_mut_slice(slice: &'a mut [u8], buf_index: u16, offset: u32) -> Self {
        Self::with_parts(slice.as_mut_ptr(), slice.len(), buf_index, offset)
    }

    /// Returns the kernel fixed buffer index (e.g. for `io_uring` fixed buffers).
    #[inline(always)]
    pub const fn buf_index(&self) -> u16 {
        self.buf_index
    }

    /// Returns the offset of this slice within the registered master buffer.
    #[inline(always)]
    pub const fn offset(&self) -> u32 {
        self.offset
    }

    /// Returns the length in bytes.
    #[inline(always)]
    pub const fn len(&self) -> usize {
        self.len
    }

    /// Returns true if empty.
    #[inline(always)]
    pub const fn is_empty(&self) -> bool {
        self.len == 0
    }

    /// Checks if the underlying pointer satisfies a specified byte alignment.
    ///
    /// `align` must be a nonzero power of two.
    #[inline(always)]
    pub fn is_aligned_to(&self, align: usize) -> bool {
        debug_assert!(align.is_power_of_two(), "align must be a power of two");
        (self.ptr as usize) & (align - 1) == 0
    }

    /// Obtains an immutable slice.
    #[inline(always)]
    pub fn as_slice(&self) -> &[u8] {
        // SAFETY: `ptr`/`len` describe a valid, initialized, non-aliased
        // mutable slice (invariant of `with_parts`).
        unsafe { core::slice::from_raw_parts(self.ptr, self.len) }
    }

    /// Obtains a mutable slice.
    #[inline(always)]
    pub fn as_mut_slice(&mut self) -> &mut [u8] {
        // SAFETY: `ptr`/`len` describe a valid, initialized, non-aliased
        // mutable slice (invariant of `with_parts`).
        unsafe { core::slice::from_raw_parts_mut(self.ptr, self.len) }
    }

    /// Splits the DMA slice into two contiguous disjoint DMA slices at index `mid`.
    #[inline(always)]
    #[track_caller]
    pub fn split_at(self, mid: usize) -> (DmaSlice<'a>, DmaSlice<'a>) {
        assert!(mid <= self.len, "Split index out of bounds");
        // SAFETY: `mid <= self.len`, so `ptr.add(mid)` stays inside the
        // original DMA region.
        let right_ptr = unsafe { self.ptr.add(mid) };
        let right_offset = self.offset + mid as u32;
        (
            Self::with_parts(self.ptr, mid, self.buf_index, self.offset),
            Self::with_parts(right_ptr, self.len - mid, self.buf_index, right_offset),
        )
    }

    /// Advances the start of the DMA slice by `count` bytes, shrinking its length.
    #[inline(always)]
    #[track_caller]
    pub fn advance(&mut self, count: usize) {
        assert!(count <= self.len, "Advance count out of bounds");
        // SAFETY: `count <= self.len`, so the new pointer stays inside
        // the original DMA region.
        self.ptr = unsafe { self.ptr.add(count) };
        self.len -= count;
        self.offset += count as u32;
    }

    /// Returns a subslice within the given range.
    #[inline(always)]
    pub fn subslice(self, range: Range<usize>) -> Result<DmaSlice<'a>> {
        if range.start > range.end || range.end > self.len {
            return Err(PipeError::BufferOverflow {
                required: range.end,
                available: self.len,
            });
        }
        let len = range.end - range.start;
        // SAFETY: `range.end <= self.len` was checked above, so
        // `range.start <= self.len` too.
        let ptr = unsafe { self.ptr.add(range.start) };
        Ok(Self::with_parts(
            ptr,
            len,
            self.buf_index,
            self.offset + range.start as u32,
        ))
    }

    /// Crate-private accessor returning the raw `(ptr, len, buf_index, offset)`
    /// quadruple. Used by [`DmaDescriptor::from_dma_slice`] so this module
    /// remains the only place that materializes the raw fields.
    #[inline(always)]
    pub(crate) const fn raw_parts(&self) -> (*mut u8, usize, u16, u32) {
        (self.ptr, self.len, self.buf_index, self.offset)
    }
}

impl<'a> Deref for DmaSlice<'a> {
    type Target = [u8];

    #[inline(always)]
    fn deref(&self) -> &Self::Target {
        self.as_slice()
    }
}

impl<'a> DerefMut for DmaSlice<'a> {
    #[inline(always)]
    fn deref_mut(&mut self) -> &mut Self::Target {
        self.as_mut_slice()
    }
}

// ============================================================================
// DMA Descriptor for io_uring / Hardware Rings
// ============================================================================

/// Bitflags for [`DmaDescriptor`].
pub mod dma_flags {
    /// Ingress / Read transfer operation.
    pub const FLAG_READ: u16 = 1 << 0;
    /// Egress / Write transfer operation.
    pub const FLAG_WRITE: u16 = 1 << 1;
    /// Buffer is registered in kernel fixed buffer table.
    pub const FLAG_FIXED_BUFFER: u16 = 1 << 2;
    /// Direct kernel splice / zero-copy bridge.
    pub const FLAG_SPLICE: u16 = 1 << 3;
    /// Transfer has completed successfully.
    pub const FLAG_COMPLETED: u16 = 1 << 4;
    /// Error encountered during transfer.
    pub const FLAG_ERROR: u16 = 1 << 5;
}

/// 32-byte hardware/kernel aligned DMA descriptor for io_uring and hardware ring buffers.
#[repr(C, align(32))]
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct DmaDescriptor {
    /// Virtual or physical address of the buffer memory.
    pub addr: u64,
    /// Transfer length in bytes.
    pub len: u32,
    /// Offset within pre-registered buffer.
    pub offset: u32,
    /// Kernel registered fixed buffer index.
    pub buf_index: u16,
    /// Operation control flags (see [`dma_flags`]).
    pub flags: u16,
    /// Stream / Channel identifier.
    pub stream_id: u32,
    /// User context data / opaque identifier (e.g. io_uring `user_data`).
    pub user_data: u64,
}

// The descriptor is part of the kernel-facing ABI: `addr`/`len`/`offset`
// are read by the kernel and by hardware rings, and the whole struct is
// expected to fit exactly one 32-byte cache line / ring entry. Pin the
// layout at compile time so a future field reorder fails to build rather
// than silently misroutes.
const _: () = assert!(core::mem::size_of::<DmaDescriptor>() == 32);
const _: () = assert!(core::mem::align_of::<DmaDescriptor>() == 32);

impl DmaDescriptor {
    /// Constructs a new DMA descriptor.
    #[inline(always)]
    pub const fn new(
        addr: u64,
        len: u32,
        offset: u32,
        buf_index: u16,
        flags: u16,
        stream_id: u32,
        user_data: u64,
    ) -> Self {
        Self {
            addr,
            len,
            offset,
            buf_index,
            flags,
            stream_id,
            user_data,
        }
    }

    /// Constructs a descriptor from an existing [`DmaSlice`].
    #[inline(always)]
    pub fn from_dma_slice(slice: &DmaSlice, flags: u16, stream_id: u32, user_data: u64) -> Self {
        let (ptr, len, buf_index, offset) = slice.raw_parts();
        Self {
            addr: ptr as u64,
            len: len as u32,
            offset,
            buf_index,
            flags: flags | dma_flags::FLAG_FIXED_BUFFER,
            stream_id,
            user_data,
        }
    }

    /// Checks if this descriptor targets a registered fixed buffer.
    #[inline(always)]
    pub const fn is_fixed_buffer(&self) -> bool {
        (self.flags & dma_flags::FLAG_FIXED_BUFFER) != 0
    }

    /// Checks if this descriptor requests zero-copy pipe splicing.
    #[inline(always)]
    pub const fn is_splice(&self) -> bool {
        (self.flags & dma_flags::FLAG_SPLICE) != 0
    }

    /// Checks if the transfer completed.
    #[inline(always)]
    pub const fn is_completed(&self) -> bool {
        (self.flags & dma_flags::FLAG_COMPLETED) != 0
    }

    /// Marks the descriptor as completed.
    #[inline(always)]
    pub fn mark_completed(&mut self) {
        self.flags |= dma_flags::FLAG_COMPLETED;
    }

    /// Marks the descriptor with error status.
    #[inline(always)]
    pub fn mark_error(&mut self) {
        self.flags |= dma_flags::FLAG_ERROR;
    }
}

// ============================================================================
// Fixed DMA Buffer Pool
// ============================================================================

/// Computes the "all free" bitmap at compile time.
///
/// Bits `[0, NUM_SLOTS)` are set to 1 (free); bits `[NUM_SLOTS, 256)` are
/// left at 0. Establishing this invariant in the constructor is what lets
/// [`DmaPool::available_slots`] reduce to a plain popcount over all four
/// words, and what makes the `slot >= NUM_SLOTS` guard in
/// [`DmaPool::alloc_slice`] a debug-only assertion rather than a hot-path
/// branch.
const fn initial_bitmap<const NUM_SLOTS: usize>() -> [u64; 4] {
    let mut bm = [0u64; 4];
    let mut i = 0;
    while i < NUM_SLOTS {
        bm[i / 64] |= 1u64 << (i % 64);
        i += 1;
    }
    bm
}

/// Static bitmap-tracked fixed buffer pool for DMA allocations.
///
/// Allocates fixed-size slices from a pre-allocated contiguous memory region without heap interaction.
pub struct DmaPool<const NUM_SLOTS: usize, const SLOT_SIZE: usize> {
    base_ptr: *mut u8,
    /// Bitmap of free slots (1 = free, 0 = allocated).
    ///
    /// **Invariant:** bits in the range `[NUM_SLOTS, 256)` are always zero.
    /// Established by [`initial_bitmap`], preserved by [`alloc_slice`]
    /// (only clears bits) and [`release_slice`] (only sets bits with
    /// `slot < NUM_SLOTS`). Several methods below rely on this to skip
    /// bounds checks in hot paths.
    bitmap: [u64; 4],
}

// SAFETY: `DmaPool` owns a unique contiguous allocation; moving it
// across threads is equivalent to moving the underlying block.
unsafe impl<const NUM_SLOTS: usize, const SLOT_SIZE: usize> Send for DmaPool<NUM_SLOTS, SLOT_SIZE> {}
// SAFETY: `&DmaPool` exposes only `available_slots` (read-only);
// mutation requires `&mut self`.
unsafe impl<const NUM_SLOTS: usize, const SLOT_SIZE: usize> Sync for DmaPool<NUM_SLOTS, SLOT_SIZE> {}

impl<const NUM_SLOTS: usize, const SLOT_SIZE: usize> DmaPool<NUM_SLOTS, SLOT_SIZE> {
    /// Creates a pool over `base_ptr`.
    ///
    /// # Safety
    /// `base_ptr` must point to a valid block of at least `NUM_SLOTS * SLOT_SIZE` bytes.
    pub unsafe fn new(base_ptr: *mut u8) -> Self {
        // Compile-time contract. Catches oversized pools and zero-sized
        // slots at monomorphization, not at first `alloc_slice`.
        const { assert!(NUM_SLOTS <= 256, "DmaPool supports up to 256 slots") };
        const { assert!(SLOT_SIZE > 0, "SLOT_SIZE must be nonzero") };

        Self {
            base_ptr,
            bitmap: initial_bitmap::<NUM_SLOTS>(),
        }
    }

    /// Allocates a registered DMA buffer slot.
    #[inline]
    pub fn alloc_slice(&mut self) -> Option<DmaSlice<'static>> {
        for (word_idx, word) in self.bitmap.iter_mut().enumerate() {
            if *word == 0 {
                continue;
            }
            let bit_idx = word.trailing_zeros() as usize;
            let slot = word_idx * 64 + bit_idx;
            // Invariant: no bit at index >= NUM_SLOTS is ever set, so this
            // is guaranteed by construction; keep as a debug-only check.
            debug_assert!(
                slot < NUM_SLOTS,
                "DmaPool bitmap invariant violated: bit {slot} >= NUM_SLOTS ({NUM_SLOTS})",
            );
            *word &= !(1u64 << bit_idx);

            let offset = slot * SLOT_SIZE;
            // SAFETY: `slot < NUM_SLOTS`, so `offset < NUM_SLOTS *
            // SLOT_SIZE`, which is the size of the allocation
            // `base_ptr` was created from.
            let ptr = unsafe { self.base_ptr.add(offset) };

            // SAFETY: `ptr`/`SLOT_SIZE` describe a valid slot inside the
            // pool's contiguous allocation, and the slot has just been
            // marked allocated.
            return Some(unsafe {
                DmaSlice::from_raw_parts(ptr, SLOT_SIZE, slot as u16, 0)
            });
        }
        None
    }

    /// Releases a previously allocated slot by index.
    #[inline]
    pub fn release_slice(&mut self, slot: u16) {
        let slot = slot as usize;
        if slot < NUM_SLOTS {
            self.bitmap[slot / 64] |= 1u64 << (slot % 64);
        }
    }

    /// Returns the number of currently free slots.
    #[inline]
    pub fn available_slots(&self) -> usize {
        // Invariant: bits >= NUM_SLOTS are always zero, so a plain
        // popcount over the whole bitmap is exact. The debug assertion
        // below catches any future violation at the source.
        let free: usize = self.bitmap.iter().map(|w| w.count_ones() as usize).sum();
        debug_assert!(
            free <= NUM_SLOTS,
            "DmaPool bitmap invariant violated: {free} free bits > NUM_SLOTS ({NUM_SLOTS})",
        );
        free
    }
}

// ============================================================================
// Splicing Bridge
// ============================================================================

// SplicingBridge is defined canonical in `crate::splicing_bridge`
pub use crate::splicing_bridge::SplicingBridge;

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_dma_pool_exhaustion_and_slot_reuse() {
        let mut memory = [0u8; 8 * 64];
        let mut pool: DmaPool<8, 64> = unsafe { DmaPool::new(memory.as_mut_ptr()) };

        assert_eq!(pool.available_slots(), 8);

        let mut acquired = Vec::new();
        for _ in 0..8 {
            acquired.push(pool.alloc_slice().expect("slot available"));
        }

        // Pool is exhausted.
        assert!(pool.alloc_slice().is_none(), "pool should be exhausted");
        assert_eq!(pool.available_slots(), 0);

        // Each slice has a unique buf_index.
        let mut indices: Vec<u16> = acquired.iter().map(|s| s.buf_index()).collect();
        indices.sort();
        indices.dedup();
        assert_eq!(indices.len(), 8, "buf_index collision");

        // Release one and reuse the same slot.
        let freed = acquired[3].buf_index();
        pool.release_slice(freed);
        assert_eq!(pool.available_slots(), 1);

        let reused = pool.alloc_slice().expect("reuse released slot");
        assert_eq!(reused.buf_index(), freed);
    }

    #[test]
    fn test_dma_pool_non_multiple_of_64_slots() {
        // NUM_SLOTS = 70, not a multiple of 64.
        let mut memory = [0u8; 70 * 64];
        let mut pool: DmaPool<70, 64> = unsafe { DmaPool::new(memory.as_mut_ptr()) };

        assert_eq!(pool.available_slots(), 70);

        let mut acquired = Vec::new();
        for _ in 0..70 {
            acquired.push(pool.alloc_slice().expect("slot available"));
        }

        // Pool is exhausted; `available_slots` must agree with reality.
        assert_eq!(pool.available_slots(), 0);
        assert!(pool.alloc_slice().is_none(), "must be exhausted");

        // Each slot index must be in 0..70, no fake "free" slots.
        for s in &acquired {
            assert!(
                (s.buf_index() as usize) < 70,
                "slot index {} out of range",
                s.buf_index(),
            );
        }
    }
}
