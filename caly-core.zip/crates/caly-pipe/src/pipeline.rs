//! Static Pipeline Fusion with Generic Associated Types (GATs).
//!
//! Provides zero-allocation, monomorphic stream transducer combinators with
//! complete inlining and zero virtual dispatch (`#[inline(always)]`).

use core::fmt;
use core::marker::PhantomData;
use crate::error::PipeError;

// ============================================================================
// Core Stream & In-Place Transducer Traits
// ============================================================================

/// Core trait representing a stream transducer capable of transforming
/// input buffer slices or items into output views using Generic Associated Types (GATs).
///
/// Implementations are strictly monomorphized without virtual dispatch tables,
/// allowing LLVM to perform static pipeline fusion, dead-code elimination,
/// and vectorization across fused pipe stages.
pub trait StreamTransducer: 'static {
    /// Associated error type emitted on transformation failure.
    type Error: std::error::Error + Send + Sync + 'static;

    /// GAT input type constrained to the lifetime of the transform call.
    type Input<'a>
    where
        Self: 'a;

    /// GAT output type borrowing from or derived from the input.
    type Output<'a>
    where
        Self: 'a;

    /// Transforms the input view into an output view without heap allocation.
    fn transform<'a>(&mut self, input: Self::Input<'a>) -> Result<Self::Output<'a>, Self::Error>;

    /// Resets internal transducer state (e.g. counters, cyclic masks, IVs).
    fn reset(&mut self);

    /// Statically fuses `self` with `next` into a monomorphic [`Pipe<Self, Next>`].
    #[inline(always)]
    fn pipe<Next>(self, next: Next) -> Pipe<Self, Next>
    where
        Self: Sized,
        Next: StreamTransducer<Error = Self::Error>,
    {
        Pipe::new(self, next)
    }
}

/// Specialized trait for zero-allocation in-place buffer mutation.
///
/// Operates directly on a mutable byte slice, modifying bytes in place and
/// returning the number of valid active bytes remaining.
pub trait InPlaceTransducer: 'static {
    /// Associated error type emitted on transformation failure.
    type Error: std::error::Error + Send + Sync + 'static;

    /// Mutates the provided byte buffer in-place.
    ///
    /// Returns the number of valid/processed bytes in `buffer`.
    fn transform_mut(&mut self, buffer: &mut [u8]) -> Result<usize, Self::Error>;

    /// In-place transformation returning the number of transformed bytes, ignoring errors.
    #[inline(always)]
    fn transform_in_place(&mut self, buffer: &mut [u8]) -> usize {
        self.transform_mut(buffer).unwrap_or(0)
    }

    /// Resets internal transducer state.
    fn reset(&mut self);

    /// Monomorphically fuses this in-place transducer with `next`.
    #[inline(always)]
    fn fuse<Next>(self, next: Next) -> InPlacePipe<Self, Next>
    where
        Self: Sized,
        Next: InPlaceTransducer<Error = Self::Error>,
    {
        InPlacePipe::new(self, next)
    }

    /// Adapts this in-place transducer into a GAT [`StreamTransducer`].
    #[inline(always)]
    fn into_stream(self) -> InPlaceAdapter<Self>
    where
        Self: Sized,
    {
        InPlaceAdapter::new(self)
    }
}

// ============================================================================
// Monomorphic Pipeline Combinators
// ============================================================================

/// Monomorphic pipeline combinator fusing transducer `A` and transducer `B`.
///
/// Guarantees static dispatch and deep inlining (`#[inline(always)]`).
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq)]
pub struct Pipe<A, B> {
    /// First pipeline transducer stage.
    pub first: A,
    /// Second pipeline transducer stage.
    pub second: B,
}

impl<A, B> Pipe<A, B> {
    /// Constructs a new statically fused pipeline.
    #[inline(always)]
    pub const fn new(first: A, second: B) -> Self {
        Self { first, second }
    }

    /// Decomposes the pipeline into its constituent stages.
    #[inline(always)]
    pub fn into_inner(self) -> (A, B) {
        (self.first, self.second)
    }

    /// Borrows the first stage.
    #[inline(always)]
    pub const fn first(&self) -> &A {
        &self.first
    }

    /// Mutably borrows the first stage.
    #[inline(always)]
    pub fn first_mut(&mut self) -> &mut A {
        &mut self.first
    }

    /// Borrows the second stage.
    #[inline(always)]
    pub const fn second(&self) -> &B {
        &self.second
    }

    /// Mutably borrows the second stage.
    #[inline(always)]
    pub fn second_mut(&mut self) -> &mut B {
        &mut self.second
    }
}

impl<A, B> StreamTransducer for Pipe<A, B>
where
    A: StreamTransducer,
    B: for<'a> StreamTransducer<Input<'a> = A::Output<'a>, Error = A::Error>,
{
    type Error = A::Error;
    type Input<'a> = A::Input<'a> where Self: 'a;
    type Output<'a> = B::Output<'a> where Self: 'a;

    #[inline(always)]
    fn transform<'a>(&mut self, input: Self::Input<'a>) -> Result<Self::Output<'a>, Self::Error> {
        let intermediate = self.first.transform(input)?;
        self.second.transform(intermediate)
    }

    #[inline(always)]
    fn reset(&mut self) {
        self.first.reset();
        self.second.reset();
    }
}

/// Monomorphic pipeline combinator fusing two in-place transducers `A` and `B`.
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq)]
pub struct InPlacePipe<A, B> {
    /// First in-place pipeline stage.
    pub first: A,
    /// Second in-place pipeline stage.
    pub second: B,
}

impl<A, B> InPlacePipe<A, B> {
    /// Constructs a new in-place pipeline.
    #[inline(always)]
    pub const fn new(first: A, second: B) -> Self {
        Self { first, second }
    }

    /// Decomposes into inner stages.
    #[inline(always)]
    pub fn into_inner(self) -> (A, B) {
        (self.first, self.second)
    }

    /// Borrows the first stage.
    #[inline(always)]
    pub const fn first(&self) -> &A {
        &self.first
    }

    /// Mutably borrows the first stage.
    #[inline(always)]
    pub fn first_mut(&mut self) -> &mut A {
        &mut self.first
    }

    /// Borrows the second stage.
    #[inline(always)]
    pub const fn second(&self) -> &B {
        &self.second
    }

    /// Mutably borrows the second stage.
    #[inline(always)]
    pub fn second_mut(&mut self) -> &mut B {
        &mut self.second
    }
}

impl<A, B> InPlaceTransducer for InPlacePipe<A, B>
where
    A: InPlaceTransducer,
    B: InPlaceTransducer<Error = A::Error>,
{
    type Error = A::Error;

    #[inline(always)]
    fn transform_mut(&mut self, buffer: &mut [u8]) -> Result<usize, Self::Error> {
        let written = self.first.transform_mut(buffer)?;
        let capped = written.min(buffer.len());
        self.second.transform_mut(&mut buffer[..capped])
    }

    #[inline(always)]
    fn reset(&mut self) {
        self.first.reset();
        self.second.reset();
    }
}

// ============================================================================
// Primitive & Utility Transducers
// ============================================================================

/// Zero-cost identity transducer that passes buffers through unchanged.
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq)]
pub struct IdentityTransducer<E = PipeError> {
    _marker: PhantomData<fn() -> E>,
}

impl<E: std::error::Error + Send + Sync + 'static> IdentityTransducer<E> {
    /// Creates a new identity transducer.
    #[inline(always)]
    pub const fn new() -> Self {
        Self {
            _marker: PhantomData,
        }
    }
}

impl<E: std::error::Error + Send + Sync + 'static> StreamTransducer for IdentityTransducer<E> {
    type Error = E;
    type Input<'a> = &'a mut [u8] where Self: 'a;
    type Output<'a> = &'a mut [u8] where Self: 'a;

    #[inline(always)]
    fn transform<'a>(&mut self, input: Self::Input<'a>) -> Result<Self::Output<'a>, Self::Error> {
        Ok(input)
    }

    #[inline(always)]
    fn reset(&mut self) {}
}

impl<E: std::error::Error + Send + Sync + 'static> InPlaceTransducer for IdentityTransducer<E> {
    type Error = E;

    #[inline(always)]
    fn transform_mut(&mut self, buffer: &mut [u8]) -> Result<usize, Self::Error> {
        Ok(buffer.len())
    }

    #[inline(always)]
    fn reset(&mut self) {}
}

/// Adapts an [`InPlaceTransducer`] to implement [`StreamTransducer`].
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq)]
pub struct InPlaceAdapter<T> {
    /// Wrapped in-place transducer.
    pub inner: T,
}

impl<T> InPlaceAdapter<T> {
    /// Wraps an in-place transducer into a stream transducer.
    #[inline(always)]
    pub const fn new(inner: T) -> Self {
        Self { inner }
    }

    /// Unwraps the underlying in-place transducer.
    #[inline(always)]
    pub fn into_inner(self) -> T {
        self.inner
    }

    /// Borrows the underlying in-place transducer.
    #[inline(always)]
    pub const fn inner(&self) -> &T {
        &self.inner
    }

    /// Mutably borrows the underlying in-place transducer.
    #[inline(always)]
    pub fn inner_mut(&mut self) -> &mut T {
        &mut self.inner
    }
}

impl<T: InPlaceTransducer> StreamTransducer for InPlaceAdapter<T> {
    type Error = T::Error;
    type Input<'a> = &'a mut [u8] where Self: 'a;
    type Output<'a> = &'a mut [u8] where Self: 'a;

    #[inline(always)]
    fn transform<'a>(&mut self, input: Self::Input<'a>) -> Result<Self::Output<'a>, Self::Error> {
        let len = self.inner.transform_mut(input)?;
        let capped = len.min(input.len());
        Ok(&mut input[..capped])
    }

    #[inline(always)]
    fn reset(&mut self) {
        self.inner.reset();
    }
}

impl<T: InPlaceTransducer> InPlaceTransducer for InPlaceAdapter<T> {
    type Error = T::Error;

    #[inline(always)]
    fn transform_mut(&mut self, buffer: &mut [u8]) -> Result<usize, Self::Error> {
        self.inner.transform_mut(buffer)
    }

    #[inline(always)]
    fn reset(&mut self) {
        self.inner.reset();
    }
}

/// Closure-based in-place transformer for flexible inline transformations.
#[derive(Clone, Copy)]
pub struct MapInPlace<F, E = PipeError> {
    func: F,
    _marker: PhantomData<fn() -> E>,
}

impl<F, E> fmt::Debug for MapInPlace<F, E> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("MapInPlace").finish_non_exhaustive()
    }
}

impl<F, E> MapInPlace<F, E>
where
    E: std::error::Error + Send + Sync + 'static,
    F: FnMut(&mut [u8]) -> Result<usize, E>,
{
    /// Constructs a closure-backed in-place transducer.
    #[inline(always)]
    pub const fn new(func: F) -> Self {
        Self {
            func,
            _marker: PhantomData,
        }
    }
}

impl<F, E> InPlaceTransducer for MapInPlace<F, E>
where
    E: std::error::Error + Send + Sync + 'static,
    F: FnMut(&mut [u8]) -> Result<usize, E> + 'static,
{
    type Error = E;

    #[inline(always)]
    fn transform_mut(&mut self, buffer: &mut [u8]) -> Result<usize, Self::Error> {
        (self.func)(buffer)
    }

    #[inline(always)]
    fn reset(&mut self) {}
}

impl<F, E> StreamTransducer for MapInPlace<F, E>
where
    E: std::error::Error + Send + Sync + 'static,
    F: FnMut(&mut [u8]) -> Result<usize, E> + 'static,
{
    type Error = E;
    type Input<'a> = &'a mut [u8] where Self: 'a;
    type Output<'a> = &'a mut [u8] where Self: 'a;

    #[inline(always)]
    fn transform<'a>(&mut self, input: Self::Input<'a>) -> Result<Self::Output<'a>, Self::Error> {
        let len = (self.func)(input)?;
        let capped = len.min(input.len());
        Ok(&mut input[..capped])
    }

    #[inline(always)]
    fn reset(&mut self) {}
}

/// Telemetry and monitoring tap that inspects data in the pipeline without modifying it.
#[derive(Clone, Copy)]
pub struct InspectTransducer<F, E = PipeError> {
    inspector: F,
    _marker: PhantomData<fn() -> E>,
}

impl<F, E> fmt::Debug for InspectTransducer<F, E> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("InspectTransducer").finish_non_exhaustive()
    }
}

impl<F, E> InspectTransducer<F, E>
where
    E: std::error::Error + Send + Sync + 'static,
    F: FnMut(&[u8]),
{
    /// Creates a new inspection tap.
    #[inline(always)]
    pub const fn new(inspector: F) -> Self {
        Self {
            inspector,
            _marker: PhantomData,
        }
    }
}

impl<F, E> InPlaceTransducer for InspectTransducer<F, E>
where
    E: std::error::Error + Send + Sync + 'static,
    F: FnMut(&[u8]) + 'static,
{
    type Error = E;

    #[inline(always)]
    fn transform_mut(&mut self, buffer: &mut [u8]) -> Result<usize, Self::Error> {
        (self.inspector)(buffer);
        Ok(buffer.len())
    }

    #[inline(always)]
    fn reset(&mut self) {}
}

impl<F, E> StreamTransducer for InspectTransducer<F, E>
where
    E: std::error::Error + Send + Sync + 'static,
    F: FnMut(&[u8]) + 'static,
{
    type Error = E;
    type Input<'a> = &'a mut [u8] where Self: 'a;
    type Output<'a> = &'a mut [u8] where Self: 'a;

    #[inline(always)]
    fn transform<'a>(&mut self, input: Self::Input<'a>) -> Result<Self::Output<'a>, Self::Error> {
        (self.inspector)(input);
        Ok(input)
    }

    #[inline(always)]
    fn reset(&mut self) {}
}

/// Running byte-counter transducer that tallies throughput without modifying bytes.
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq)]
pub struct CounterTransducer<E = PipeError> {
    total_bytes: u64,
    _marker: PhantomData<fn() -> E>,
}

impl<E: std::error::Error + Send + Sync + 'static> CounterTransducer<E> {
    /// Creates a new counter transducer.
    #[inline(always)]
    pub const fn new() -> Self {
        Self {
            total_bytes: 0,
            _marker: PhantomData,
        }
    }

    /// Returns the cumulative number of bytes that passed through.
    #[inline(always)]
    pub const fn total_bytes(&self) -> u64 {
        self.total_bytes
    }
}

impl<E: std::error::Error + Send + Sync + 'static> InPlaceTransducer for CounterTransducer<E> {
    type Error = E;

    #[inline(always)]
    fn transform_mut(&mut self, buffer: &mut [u8]) -> Result<usize, Self::Error> {
        self.total_bytes = self.total_bytes.wrapping_add(buffer.len() as u64);
        Ok(buffer.len())
    }

    #[inline(always)]
    fn reset(&mut self) {
        self.total_bytes = 0;
    }
}

impl<E: std::error::Error + Send + Sync + 'static> StreamTransducer for CounterTransducer<E> {
    type Error = E;
    type Input<'a> = &'a mut [u8] where Self: 'a;
    type Output<'a> = &'a mut [u8] where Self: 'a;

    #[inline(always)]
    fn transform<'a>(&mut self, input: Self::Input<'a>) -> Result<Self::Output<'a>, Self::Error> {
        self.total_bytes = self.total_bytes.wrapping_add(input.len() as u64);
        Ok(input)
    }

    #[inline(always)]
    fn reset(&mut self) {
        self.total_bytes = 0;
    }
}

// ============================================================================
// Grand Unified Network Transducer & State Machine Pipelines
// ============================================================================

/// Status result emitted when advancing a [`NetworkTransducer`].
#[derive(Debug, PartialEq, Eq)]
pub enum TransduceResult<'a, O> {
    /// Handshake or protocol phase completed, emitting an output token.
    Complete(O),
    /// Data has been processed/mutated in-place; pipeline should continue streaming with the slice.
    Continue(&'a mut [u8]),
    /// Flow has been identified as a direct or decoy stream; bypass user-space processing.
    DirectBypass,
    /// Connection has been closed or terminated.
    Closed,
}

impl<'a, O> TransduceResult<'a, O> {
    /// Maps the `Complete(O)` variant using `f`, leaving other variants untouched.
    #[inline(always)]
    pub fn map_complete<U, F: FnOnce(O) -> U>(self, f: F) -> TransduceResult<'a, U> {
        match self {
            Self::Complete(out) => TransduceResult::Complete(f(out)),
            Self::Continue(slice) => TransduceResult::Continue(slice),
            Self::DirectBypass => TransduceResult::DirectBypass,
            Self::Closed => TransduceResult::Closed,
        }
    }
}

/// Grand unified network transducer trait for stateful, zero-allocation protocol and stream processing.
pub trait NetworkTransducer: 'static {
    /// Copyable state tracking the current phase of the transducer.
    type State: Copy;
    /// Output token emitted when this transducer completes its processing.
    type Output;
    /// Associated error type emitted on protocol or state failure.
    type Error: std::error::Error + Send + Sync + 'static;

    /// Advances the transducer state with the given mutable input buffer.
    fn advance<'a>(
        &mut self,
        state: &mut Self::State,
        input: &'a mut [u8],
    ) -> Result<TransduceResult<'a, Self::Output>, Self::Error>;

    /// Statically fuses `self` with `next` into a [`Fuse<Self, Next>`].
    #[inline(always)]
    fn fuse<Next>(self, next: Next) -> Fuse<Self, Next>
    where
        Self: Sized,
        Next: NetworkTransducer<Error = Self::Error>,
    {
        Fuse::new(self, next)
    }

    /// Chains `self` with `next`, invoking `transition` when `self` completes to initialize `next`'s state.
    #[inline(always)]
    fn then<Next, F>(self, next: Next, transition: F) -> Then<Self, Next, F>
    where
        Self: Sized,
        Next: NetworkTransducer<Error = Self::Error>,
        F: Fn(&Self::Output) -> Next::State + 'static,
    {
        Then::new(self, next, transition)
    }
}

/// Monomorphic sequential fusion of two network transducers `T1` and `T2`.
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq)]
pub struct Fuse<T1, T2> {
    /// First fused network transducer stage.
    pub first: T1,
    /// Second fused network transducer stage.
    pub second: T2,
}

impl<T1, T2> Fuse<T1, T2> {
    /// Creates a fused transducer from two stages.
    #[inline(always)]
    pub const fn new(first: T1, second: T2) -> Self {
        Self { first, second }
    }

    /// Decomposes into constituent transducers.
    #[inline(always)]
    pub fn into_inner(self) -> (T1, T2) {
        (self.first, self.second)
    }
}

/// State machine tracker for [`Fuse`] and [`Then`].
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum FuseState<S1: Copy, S2: Copy> {
    /// Processing within the first stage.
    First(S1),
    /// Processing within the second stage.
    Second(S2),
    /// Direct bypass active.
    DirectBypass,
    /// Terminal closed state.
    Closed,
}

/// Unified output type for [`Fuse`] and [`Then`].
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum FuseOutput<O1, O2> {
    /// Output produced by the first stage.
    First(O1),
    /// Output produced by the second stage.
    Second(O2),
}

impl<T1, T2> NetworkTransducer for Fuse<T1, T2>
where
    T1: NetworkTransducer,
    T2: NetworkTransducer<Error = T1::Error>,
{
    type State = FuseState<T1::State, T2::State>;
    type Output = FuseOutput<T1::Output, T2::Output>;
    type Error = T1::Error;

    #[inline(always)]
    fn advance<'a>(
        &mut self,
        state: &mut Self::State,
        input: &'a mut [u8],
    ) -> Result<TransduceResult<'a, Self::Output>, Self::Error> {
        match state {
            FuseState::First(s1) => match self.first.advance(s1, input)? {
                TransduceResult::Continue(rem) => Ok(TransduceResult::Continue(rem)),
                TransduceResult::DirectBypass => {
                    *state = FuseState::DirectBypass;
                    Ok(TransduceResult::DirectBypass)
                }
                TransduceResult::Closed => {
                    *state = FuseState::Closed;
                    Ok(TransduceResult::Closed)
                }
                TransduceResult::Complete(out1) => {
                    Ok(TransduceResult::Complete(FuseOutput::First(out1)))
                }
            },
            FuseState::Second(s2) => match self.second.advance(s2, input)? {
                TransduceResult::Continue(rem) => Ok(TransduceResult::Continue(rem)),
                TransduceResult::DirectBypass => {
                    *state = FuseState::DirectBypass;
                    Ok(TransduceResult::DirectBypass)
                }
                TransduceResult::Closed => {
                    *state = FuseState::Closed;
                    Ok(TransduceResult::Closed)
                }
                TransduceResult::Complete(out2) => {
                    Ok(TransduceResult::Complete(FuseOutput::Second(out2)))
                }
            },
            FuseState::DirectBypass => Ok(TransduceResult::DirectBypass),
            FuseState::Closed => Ok(TransduceResult::Closed),
        }
    }
}

/// Transition combinator executing `T1`, then invoking `F` on completion to initialize `T2`.
#[derive(Debug, Clone, Copy)]
pub struct Then<T1, T2, F> {
    /// First transducer stage.
    pub first: T1,
    /// Second transducer stage.
    pub second: T2,
    /// Transition combinator function.
    pub transition: F,
}

impl<T1, T2, F> Then<T1, T2, F> {
    /// Creates a conditional transition combinator.
    #[inline(always)]
    pub const fn new(first: T1, second: T2, transition: F) -> Self {
        Self {
            first,
            second,
            transition,
        }
    }

    /// Decomposes into constituent stages and transition function.
    #[inline(always)]
    pub fn into_inner(self) -> (T1, T2, F) {
        (self.first, self.second, self.transition)
    }
}

impl<T1, T2, F> NetworkTransducer for Then<T1, T2, F>
where
    T1: NetworkTransducer,
    T2: NetworkTransducer<Error = T1::Error>,
    F: Fn(&T1::Output) -> T2::State + 'static,
{
    type State = FuseState<T1::State, T2::State>;
    type Output = FuseOutput<T1::Output, T2::Output>;
    type Error = T1::Error;

    #[inline(always)]
    fn advance<'a>(
        &mut self,
        state: &mut Self::State,
        input: &'a mut [u8],
    ) -> Result<TransduceResult<'a, Self::Output>, Self::Error> {
        match state {
            FuseState::First(s1) => match self.first.advance(s1, input)? {
                TransduceResult::Continue(rem) => Ok(TransduceResult::Continue(rem)),
                TransduceResult::DirectBypass => {
                    *state = FuseState::DirectBypass;
                    Ok(TransduceResult::DirectBypass)
                }
                TransduceResult::Closed => {
                    *state = FuseState::Closed;
                    Ok(TransduceResult::Closed)
                }
                TransduceResult::Complete(out1) => {
                    let s2 = (self.transition)(&out1);
                    *state = FuseState::Second(s2);
                    Ok(TransduceResult::Complete(FuseOutput::First(out1)))
                }
            },
            FuseState::Second(s2) => match self.second.advance(s2, input)? {
                TransduceResult::Continue(rem) => Ok(TransduceResult::Continue(rem)),
                TransduceResult::DirectBypass => {
                    *state = FuseState::DirectBypass;
                    Ok(TransduceResult::DirectBypass)
                }
                TransduceResult::Closed => {
                    *state = FuseState::Closed;
                    Ok(TransduceResult::Closed)
                }
                TransduceResult::Complete(out2) => {
                    Ok(TransduceResult::Complete(FuseOutput::Second(out2)))
                }
            },
            FuseState::DirectBypass => Ok(TransduceResult::DirectBypass),
            FuseState::Closed => Ok(TransduceResult::Closed),
        }
    }
}

// ============================================================================
// Specific Network Transducer Implementations
// ============================================================================

/// Phase state for the SOCKS5 handshake transducer.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Socks5PipeState {
    /// Awaiting client version and method greeting.
    AwaitingGreeting,
    /// Awaiting client SOCKS5 command (CONNECT).
    AwaitingCommand,
    /// Handshake completed; connection established.
    Established,
    /// Connection closed.
    Closed,
}

/// Parsed SOCKS5 connection destination.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Socks5ConnectedTarget {
    /// Destination port.
    pub port: u16,
    /// True if IPv4 address.
    pub is_ipv4: bool,
    /// Compact IPv4 octets.
    pub ipv4_addr: [u8; 4],
}

/// Sans-I/O SOCKS5 handshake network transducer.
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq)]
pub struct Socks5HandshakeTransducer;

impl Socks5HandshakeTransducer {
    const SOCKS_VERSION: u8 = 0x05;
    const CMD_CONNECT: u8 = 0x01;
    const ATYP_IPV4: u8 = 0x01;
    const AUTH_NONE: u8 = 0x00;

    /// Constructs a new SOCKS5 handshake transducer.
    #[inline(always)]
    pub const fn new() -> Self {
        Self
    }

    #[cold]
    #[inline(never)]
    fn fail_closed<T>(state: &mut Socks5PipeState, msg: &'static str) -> Result<T, PipeError> {
        *state = Socks5PipeState::Closed;
        Err(PipeError::InvalidTlsHandshake(msg))
    }

    #[cold]
    #[inline(never)]
    fn fail_underflow<T>(expected: usize, received: usize) -> Result<T, PipeError> {
        Err(PipeError::BufferUnderflow { expected, received })
    }
}

impl NetworkTransducer for Socks5HandshakeTransducer {
    type State = Socks5PipeState;
    type Output = Socks5ConnectedTarget;
    type Error = PipeError;

    #[inline(always)]
    fn advance<'a>(
        &mut self,
        state: &mut Self::State,
        input: &'a mut [u8],
    ) -> Result<TransduceResult<'a, Self::Output>, Self::Error> {
        match *state {
            Socks5PipeState::AwaitingGreeting => {
                if input.len() < 3 || input[0] != Self::SOCKS_VERSION {
                    return Self::fail_closed(state, "Invalid SOCKS5 greeting");
                }
                let expected_len = 2 + (input[1] as usize);
                if input.len() < expected_len {
                    return Self::fail_underflow(expected_len, input.len());
                }

                // Respond in-place with No-Authentication required: [0x05, 0x00]
                input[0] = Self::SOCKS_VERSION;
                input[1] = Self::AUTH_NONE;
                *state = Socks5PipeState::AwaitingCommand;
                Ok(TransduceResult::Continue(&mut input[..2]))
            }
            Socks5PipeState::AwaitingCommand => {
                if input.len() < 7
                    || input[0] != Self::SOCKS_VERSION
                    || input[1] != Self::CMD_CONNECT
                {
                    return Self::fail_closed(state, "Invalid SOCKS5 CONNECT command");
                }

                let target = match input[3] {
                    Self::ATYP_IPV4 => {
                        if input.len() < 10 {
                            return Self::fail_underflow(10, input.len());
                        }
                        let ipv4_addr = [input[4], input[5], input[6], input[7]];
                        let port = u16::from_be_bytes([input[8], input[9]]);
                        Socks5ConnectedTarget {
                            port,
                            is_ipv4: true,
                            ipv4_addr,
                        }
                    }
                    _ => {
                        return Self::fail_closed(state, "Unsupported SOCKS5 address type");
                    }
                };

                // Write success reply: [VER=0x05, REP=0x00, RSV=0x00, ATYP=0x01, 0, 0, 0, 0, port_hi, port_lo]
                let [port_hi, port_lo] = target.port.to_be_bytes();
                input[..10].copy_from_slice(&[
                    Self::SOCKS_VERSION,
                    0x00,
                    0x00,
                    Self::ATYP_IPV4,
                    0,
                    0,
                    0,
                    0,
                    port_hi,
                    port_lo,
                ]);
                *state = Socks5PipeState::Established;
                Ok(TransduceResult::Complete(target))
            }
            Socks5PipeState::Established => Ok(TransduceResult::Continue(input)),
            Socks5PipeState::Closed => Ok(TransduceResult::Closed),
        }
    }
}

/// Phase state for the REALITY steganography transducer.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum RealityPipeState {
    /// Awaiting TLS 1.3 ClientHello record.
    AwaitingClientHello,
    /// Authenticated authentic client with derived keys.
    Authenticated {
        /// Derived session keys.
        keys: crate::reality::RealityKeys,
        /// Matching short ID.
        short_id: [u8; 8],
    },
    /// Detected active probe or unauthorized client; traffic diverted to direct bypass.
    DecoyFallback,
    /// Connection terminated.
    Closed,
}

/// Output emitted when REALITY authentication succeeds.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct RealityPipeOutput {
    /// Cryptographic session keys.
    pub keys: crate::reality::RealityKeys,
    /// Verified client short ID.
    pub short_id: [u8; 8],
}

/// REALITY in-place steganography and handshake network transducer.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct RealityStegoTransducer {
    /// REALITY server steganography context.
    pub server_ctx: crate::reality::RealityServerContext,
}

impl RealityStegoTransducer {
    /// Constructs a REALITY steganography transducer with a server context.
    #[inline(always)]
    pub const fn new(server_ctx: crate::reality::RealityServerContext) -> Self {
        Self { server_ctx }
    }
}

impl NetworkTransducer for RealityStegoTransducer {
    type State = RealityPipeState;
    type Output = RealityPipeOutput;
    type Error = PipeError;

    #[inline(always)]
    fn advance<'a>(
        &mut self,
        state: &mut Self::State,
        input: &'a mut [u8],
    ) -> Result<TransduceResult<'a, Self::Output>, Self::Error> {
        match state {
            RealityPipeState::AwaitingClientHello => {
                match self.server_ctx.process_handshake(input)? {
                    crate::reality::RealityDecision::Authenticated {
                        keys,
                        short_id,
                        ..
                    } => {
                        *state = RealityPipeState::Authenticated { keys, short_id };
                        Ok(TransduceResult::Complete(RealityPipeOutput {
                            keys,
                            short_id,
                        }))
                    }
                    crate::reality::RealityDecision::DecoyFallback { .. } => {
                        *state = RealityPipeState::DecoyFallback;
                        Ok(TransduceResult::DirectBypass)
                    }
                }
            }
            RealityPipeState::Authenticated { .. } => Ok(TransduceResult::Continue(input)),
            RealityPipeState::DecoyFallback => Ok(TransduceResult::DirectBypass),
            RealityPipeState::Closed => Ok(TransduceResult::Closed),
        }
    }
}

/// Phase state for the SIMD WebSocket cyclic masking transducer.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct WebSocketPipeState {
    /// Current 4-byte cyclic mask phase offset (0..3).
    pub mask_offset: usize,
    /// Total number of bytes masked through this pipeline.
    pub total_masked: u64,
}

impl Default for WebSocketPipeState {
    #[inline(always)]
    fn default() -> Self {
        Self {
            mask_offset: 0,
            total_masked: 0,
        }
    }
}

/// High-throughput WebSocket SIMD cyclic masking network transducer.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct WebSocketMaskTransducer {
    /// 4-byte cyclic masking key.
    pub mask_key: [u8; 4],
}

impl WebSocketMaskTransducer {
    /// Creates a new WebSocket mask transducer with a 4-byte key.
    #[inline(always)]
    pub const fn new(mask_key: [u8; 4]) -> Self {
        Self { mask_key }
    }
}

impl NetworkTransducer for WebSocketMaskTransducer {
    type State = WebSocketPipeState;
    type Output = usize;
    type Error = PipeError;

    #[inline(always)]
    fn advance<'a>(
        &mut self,
        state: &mut Self::State,
        input: &'a mut [u8],
    ) -> Result<TransduceResult<'a, Self::Output>, Self::Error> {
        let len = input.len();
        state.mask_offset =
            crate::simd_mask::apply_mask_offset(self.mask_key, state.mask_offset, input);
        state.total_masked = state.total_masked.wrapping_add(len as u64);
        Ok(TransduceResult::Continue(input))
    }
}

// ============================================================================
// Grand Unified Transducer-Pipe
// ============================================================================

/// Phase state of the [`GrandUnifiedPipe`].
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum GrandUnifiedState {
    /// SOCKS5 greeting negotiation.
    Socks5Greeting,
    /// SOCKS5 command reception and address extraction.
    Socks5Command,
    /// REALITY TLS 1.3 ClientHello steganography authentication.
    RealityInspection,
    /// Streaming data relay with SIMD cyclic masking.
    StreamingRelay {
        /// Current WebSocket mask offset.
        ws_offset: usize,
    },
    /// Traffic diverted via direct kernel bypass.
    DirectBypassed,
    /// Closed state.
    Closed,
}

/// Output events emitted across the unified pipeline lifecycle.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum GrandUnifiedOutput {
    /// SOCKS5 handshake established with target port.
    Socks5Established(Socks5ConnectedTarget),
    /// REALITY client authenticated.
    RealityAuthenticated(RealityPipeOutput),
    /// Streaming relay packet processed.
    RelayPacket(usize),
}

/// The Grand Unified Transducer-Pipe: Monomorphically fuses SOCKS5 handshake,
/// REALITY steganography, and WebSocket SIMD masking into a single zero-allocation pipeline.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct GrandUnifiedPipe {
    /// SOCKS5 handshake stage.
    pub socks5: Socks5HandshakeTransducer,
    /// REALITY steganography stage.
    pub reality: RealityStegoTransducer,
    /// WebSocket SIMD masking stage.
    pub ws_masker: WebSocketMaskTransducer,
}

impl GrandUnifiedPipe {
    /// Constructs a grand unified proxy pipeline.
    #[inline(always)]
    pub const fn new(
        server_ctx: crate::reality::RealityServerContext,
        mask_key: [u8; 4],
    ) -> Self {
        Self {
            socks5: Socks5HandshakeTransducer::new(),
            reality: RealityStegoTransducer::new(server_ctx),
            ws_masker: WebSocketMaskTransducer::new(mask_key),
        }
    }
}

impl NetworkTransducer for GrandUnifiedPipe {
    type State = GrandUnifiedState;
    type Output = GrandUnifiedOutput;
    type Error = PipeError;

    #[inline(always)]
    fn advance<'a>(
        &mut self,
        state: &mut Self::State,
        input: &'a mut [u8],
    ) -> Result<TransduceResult<'a, Self::Output>, Self::Error> {
        match *state {
            GrandUnifiedState::Socks5Greeting => {
                let mut s5_state = Socks5PipeState::AwaitingGreeting;
                match self.socks5.advance(&mut s5_state, input) {
                    Ok(TransduceResult::Continue(buf)) => {
                        *state = GrandUnifiedState::Socks5Command;
                        Ok(TransduceResult::Continue(buf))
                    }
                    Ok(TransduceResult::Complete(_)) => {
                        *state = GrandUnifiedState::Socks5Command;
                        Ok(TransduceResult::Continue(input))
                    }
                    Ok(TransduceResult::DirectBypass) => {
                        *state = GrandUnifiedState::DirectBypassed;
                        Ok(TransduceResult::DirectBypass)
                    }
                    Ok(TransduceResult::Closed) => {
                        *state = GrandUnifiedState::Closed;
                        Ok(TransduceResult::Closed)
                    }
                    Err(e) => {
                        if s5_state == Socks5PipeState::Closed {
                            *state = GrandUnifiedState::Closed;
                        }
                        Err(e)
                    }
                }
            }
            GrandUnifiedState::Socks5Command => {
                let mut s5_state = Socks5PipeState::AwaitingCommand;
                match self.socks5.advance(&mut s5_state, input) {
                    Ok(TransduceResult::Complete(target)) => {
                        *state = GrandUnifiedState::StreamingRelay { ws_offset: 0 };
                        Ok(TransduceResult::Complete(
                            GrandUnifiedOutput::Socks5Established(target),
                        ))
                    }
                    Ok(TransduceResult::Continue(buf)) => Ok(TransduceResult::Continue(buf)),
                    Ok(TransduceResult::DirectBypass) => {
                        *state = GrandUnifiedState::DirectBypassed;
                        Ok(TransduceResult::DirectBypass)
                    }
                    Ok(TransduceResult::Closed) => {
                        *state = GrandUnifiedState::Closed;
                        Ok(TransduceResult::Closed)
                    }
                    Err(e) => {
                        if s5_state == Socks5PipeState::Closed {
                            *state = GrandUnifiedState::Closed;
                        }
                        Err(e)
                    }
                }
            }
            GrandUnifiedState::RealityInspection => {
                let mut r_state = RealityPipeState::AwaitingClientHello;
                match self.reality.advance(&mut r_state, input) {
                    Ok(TransduceResult::Complete(out)) => {
                        *state = GrandUnifiedState::StreamingRelay { ws_offset: 0 };
                        Ok(TransduceResult::Complete(
                            GrandUnifiedOutput::RealityAuthenticated(out),
                        ))
                    }
                    Ok(TransduceResult::DirectBypass) => {
                        *state = GrandUnifiedState::DirectBypassed;
                        Ok(TransduceResult::DirectBypass)
                    }
                    Ok(TransduceResult::Continue(buf)) => Ok(TransduceResult::Continue(buf)),
                    Ok(TransduceResult::Closed) => {
                        *state = GrandUnifiedState::Closed;
                        Ok(TransduceResult::Closed)
                    }
                    Err(e) => {
                        if r_state == RealityPipeState::Closed {
                            *state = GrandUnifiedState::Closed;
                        }
                        Err(e)
                    }
                }
            }
            GrandUnifiedState::StreamingRelay { ref mut ws_offset } => {
                let len = input.len();
                let mut ws_state = WebSocketPipeState {
                    mask_offset: *ws_offset,
                    total_masked: 0,
                };
                let res = self.ws_masker.advance(&mut ws_state, input)?;
                *ws_offset = ws_state.mask_offset;
                match res {
                    TransduceResult::Continue(buf) => Ok(TransduceResult::Continue(buf)),
                    TransduceResult::Complete(_) => Ok(TransduceResult::Complete(
                        GrandUnifiedOutput::RelayPacket(len),
                    )),
                    TransduceResult::DirectBypass => {
                        *state = GrandUnifiedState::DirectBypassed;
                        Ok(TransduceResult::DirectBypass)
                    }
                    TransduceResult::Closed => {
                        *state = GrandUnifiedState::Closed;
                        Ok(TransduceResult::Closed)
                    }
                }
            }
            GrandUnifiedState::DirectBypassed => Ok(TransduceResult::DirectBypass),
            GrandUnifiedState::Closed => Ok(TransduceResult::Closed),
        }
    }
}

#[cfg(test)]
mod pipeline_tests {
    use super::*;

    #[test]
    fn test_in_place_and_stream_fusion() {
        let mut seen_len = 0usize;
        let inspect = InspectTransducer::<_, PipeError>::new(move |buf| {
            seen_len = buf.len();
        });
        let xor_one = MapInPlace::<_, PipeError>::new(|buf| {
            for b in buf.iter_mut() {
                *b ^= 0xFF;
            }
            Ok(buf.len())
        });
        let counter = CounterTransducer::<PipeError>::new();

        let mut pipe = IdentityTransducer::<PipeError>::new()
            .pipe(inspect)
            .pipe(xor_one)
            .pipe(counter);

        let mut data = [0x00, 0xAA, 0x55, 0xFF];
        let out = pipe.transform(&mut data).expect("transform");
        assert_eq!(out, &[0xFF, 0x55, 0xAA, 0x00]);
        assert_eq!(pipe.second().total_bytes(), 4);

        pipe.reset();
        assert_eq!(pipe.second().total_bytes(), 0);
    }

    #[test]
    fn test_socks5_handshake_and_underflow() {
        let mut s5 = Socks5HandshakeTransducer::new();
        let mut state = Socks5PipeState::AwaitingGreeting;

        // 1. Greeting with NMETHODS = 2, but only 1 method byte provided -> BufferUnderflow
        let mut partial_greeting = [0x05, 0x02, 0x00];
        let err = s5.advance(&mut state, &mut partial_greeting).unwrap_err();
        assert!(matches!(
            err,
            PipeError::BufferUnderflow {
                expected: 4,
                received: 3
            }
        ));
        assert_eq!(state, Socks5PipeState::AwaitingGreeting);

        // 2. Complete greeting -> transitions to AwaitingCommand and writes [0x05, 0x00]
        let mut greeting = [0x05, 0x01, 0x00];
        let res = s5.advance(&mut state, &mut greeting).expect("greeting ok");
        assert_eq!(res, TransduceResult::Continue(&mut [0x05, 0x00][..]));
        assert_eq!(state, Socks5PipeState::AwaitingCommand);

        // 3. Partial IPv4 CONNECT command (8 bytes < 10) -> BufferUnderflow
        let mut partial_cmd = [0x05, 0x01, 0x00, 0x01, 127, 0, 0, 1];
        let err = s5.advance(&mut state, &mut partial_cmd).unwrap_err();
        assert!(matches!(
            err,
            PipeError::BufferUnderflow {
                expected: 10,
                received: 8
            }
        ));
        assert_eq!(state, Socks5PipeState::AwaitingCommand);

        // 4. Full IPv4 CONNECT to 127.0.0.1:8080
        let mut cmd = [0x05, 0x01, 0x00, 0x01, 127, 0, 0, 1, 0x1F, 0x90];
        let res = s5.advance(&mut state, &mut cmd).expect("connect ok");
        assert_eq!(
            res,
            TransduceResult::Complete(Socks5ConnectedTarget {
                port: 8080,
                is_ipv4: true,
                ipv4_addr: [127, 0, 0, 1],
            })
        );
        assert_eq!(state, Socks5PipeState::Established);
        assert_eq!(
            &cmd,
            &[0x05, 0x00, 0x00, 0x01, 0, 0, 0, 0, 0x1F, 0x90]
        );
    }

    #[test]
    fn test_socks5_invalid_greeting_closes_state() {
        let mut s5 = Socks5HandshakeTransducer::new();
        let mut state = Socks5PipeState::AwaitingGreeting;

        let mut bad = [0x04, 0x01, 0x00];
        assert!(s5.advance(&mut state, &mut bad).is_err());
        assert_eq!(state, Socks5PipeState::Closed);
    }
}
