// `workspace-hack` is a cargo-hakari synthetic crate that unifies
// feature resolution across the workspace. It is intentionally
// never `use`d by any source file, so the standard
// `unused_crate_dependencies` lint does not apply here.
#![allow(unused_crate_dependencies)]
//! # Caly Pipe (`caly-pipe`)
//!
//! Monomorphic zero-copy streaming pipeline fusion, wide-vector SIMD masking,
//! REALITY steganography primitives, and DMA descriptors for `caly-core`.
//!
//! ## Architectural Highlights
//!
//! - **Static Pipeline Fusion with GATs**: Monomorphic [`StreamTransducer`] and [`InPlaceTransducer`]
//!   combinators guarantee zero virtual dispatch, full compiler inlining (`#[inline(always)]`),
//!   and zero heap allocations during packet processing.
//! - **AVX-512 & NEON Wide-Vector SIMD Masking**: Real-time cyclic XOR masking operator for WebSocket
//!   and proxy framing, featuring runtime CPU feature detection (AVX-512, AVX2, SSE2, NEON) and
//!   unrolled 64-bit scalar fallback.
//! - **REALITY Steganography & Handshake Transforms**: In-place TLS 1.3 ClientHello parsing,
//!   constant-time RFC 7748 X25519 Montgomery ladder scalar multiplication, HKDF-SHA256 key derivation,
//!   AuthKey validation, in-place ciphertext substitution, and zero-copy decoy fallback splicing.
//! - **Zero-Copy DMA & io_uring Descriptors**: Hardware-aligned memory slices ([`DmaSlice`]), fixed
//!   buffer descriptors ([`DmaDescriptor`]), static slot pools ([`DmaPool`]), and ring-buffer
//!   splicing bridges ([`SplicingBridge`]).

#![deny(unsafe_op_in_unsafe_fn)]
#![warn(clippy::undocumented_unsafe_blocks)]
#![warn(clippy::multiple_unsafe_ops_per_block)]
#![warn(missing_docs)]
#![deny(rust_2021_compatibility)]

// Silence cargo's unused-dependency false positive for x25519-dalek.
// The crate is only referenced via fully-qualified paths
// (`x25519_dalek::x25519(...)` in `reality.rs`). Cargo's static
// analyzer does not track path-only usages, so we declare the extern
// crate here as an explicit no-op import.
#[allow(unused_imports)]
use x25519_dalek as _;

pub mod crypto_accel;
pub mod error;
pub mod pipeline;
pub mod reality;
pub mod simd_mask;
pub mod splicing_bridge;
pub mod zero_copy;

// Top-level re-exports
pub use crypto_accel::{chacha20_scalar, has_avx2, has_avx512, has_sha_ni, sha256_scalar};
pub use error::{PipeError, Result};
pub use pipeline::{
    CounterTransducer, Fuse, FuseOutput, FuseState, GrandUnifiedOutput, GrandUnifiedPipe,
    GrandUnifiedState, IdentityTransducer, InPlaceAdapter, InPlacePipe, InPlaceTransducer,
    InspectTransducer, MapInPlace, NetworkTransducer, Pipe, RealityPipeOutput, RealityPipeState,
    RealityStegoTransducer, Socks5ConnectedTarget, Socks5HandshakeTransducer, Socks5PipeState,
    StreamTransducer, Then, TransduceResult, WebSocketMaskTransducer, WebSocketPipeState,
};
pub use reality::{
    chacha20_xor, hkdf_expand, hkdf_extract, hmac_sha256, sha256, x25519, RealityClientHello,
    RealityDecision, RealityKeys, RealityServerContext,
};
pub use simd_mask::{
    apply_mask, apply_mask_offset, apply_mask_with_backend, detect_best_backend, rotate_mask_key,
    SimdBackend, SimdMaskOperator,
};
pub use splicing_bridge::{SplicingBridge, UmemChunkBridge};
pub use zero_copy::{dma_flags, DmaDescriptor, DmaPool, DmaSlice};

// ============================================================================
// Micro-Benchmark Stubs & Throughput Utilities
// ============================================================================

/// Micro-benchmarking utilities for verifying zero-copy throughput and pipeline latency.
pub mod bench {
    use super::*;

    /// Measures throughput of SIMD mask operator over a given buffer length.
    ///
    /// Returns `(nanoseconds_per_op, gigabytes_per_second)`.
    pub fn benchmark_simd_throughput(len: usize, iterations: usize) -> (f64, f64) {
        let mut buf = vec![0xAAu8; len];
        let key = [0x12, 0x34, 0x56, 0x78];

        let start = std::time::Instant::now();
        for _ in 0..iterations {
            apply_mask(key, &mut buf);
        }
        let elapsed = start.elapsed();

        let total_ns = elapsed.as_nanos() as f64;
        let ns_per_op = total_ns / (iterations as f64);
        let total_bytes = (len as f64) * (iterations as f64);
        let gb_per_sec = (total_bytes / (1024.0 * 1024.0 * 1024.0)) / elapsed.as_secs_f64();

        (ns_per_op, gb_per_sec)
    }

    /// Measures pipeline dispatch overhead across fused in-place stages.
    pub fn benchmark_pipeline_overhead(iterations: usize) -> f64 {
        let mut buf = [0x55u8; 128];
        let p = IdentityTransducer::<PipeError>::new()
            .fuse(IdentityTransducer::<PipeError>::new())
            .fuse(IdentityTransducer::<PipeError>::new())
            .fuse(IdentityTransducer::<PipeError>::new());

        let mut fused = p;
        let start = std::time::Instant::now();
        for _ in 0..iterations {
            let _ = fused.transform_mut(&mut buf);
        }
        let elapsed = start.elapsed();
        (elapsed.as_nanos() as f64) / (iterations as f64)
    }

    /// Measures throughput of accelerated SHA-256 over a given payload length.
    pub fn benchmark_sha256_throughput(len: usize, iterations: usize) -> (f64, f64) {
        let buf = vec![0x37u8; len];
        let start = std::time::Instant::now();
        for _ in 0..iterations {
            let _ = sha256(&buf);
        }
        let elapsed = start.elapsed();
        let total_ns = elapsed.as_nanos() as f64;
        let ns_per_op = total_ns / (iterations as f64);
        let total_bytes = (len as f64) * (iterations as f64);
        let gb_per_sec = (total_bytes / (1024.0 * 1024.0 * 1024.0)) / elapsed.as_secs_f64();
        (ns_per_op, gb_per_sec)
    }

    /// Measures throughput of vectorized ChaCha20 stream cipher over a given payload length.
    pub fn benchmark_chacha20_throughput(len: usize, iterations: usize) -> (f64, f64) {
        let mut buf = vec![0x42u8; len];
        let key = [0x5au8; 32];
        let nonce = [0x12u8; 12];
        let start = std::time::Instant::now();
        for _ in 0..iterations {
            chacha20_xor(&key, &nonce, 1, &mut buf);
        }
        let elapsed = start.elapsed();
        let total_ns = elapsed.as_nanos() as f64;
        let ns_per_op = total_ns / (iterations as f64);
        let total_bytes = (len as f64) * (iterations as f64);
        let gb_per_sec = (total_bytes / (1024.0 * 1024.0 * 1024.0)) / elapsed.as_secs_f64();
        (ns_per_op, gb_per_sec)
    }
}

// ============================================================================
// Comprehensive Unit Tests
// ============================================================================

#[cfg(test)]
mod tests {
    use super::*;

    // --- Pipeline Fusion Tests ---

    #[test]
    fn test_identity_transducer() {
        // `IdentityTransducer<E>` has no usable default for `E` at a value-level
        // `::new()` call, so annotate it explicitly.
        let mut id = IdentityTransducer::<PipeError>::new();
        let mut data = [1, 2, 3, 4, 5];
        let len = id.transform_mut(&mut data).unwrap();
        assert_eq!(len, 5);
        assert_eq!(data, [1, 2, 3, 4, 5]);

        let out = id.transform(&mut data).unwrap();
        assert_eq!(out, &[1, 2, 3, 4, 5]);
    }

    #[test]
    fn test_monomorphic_pipe_fusion() {
        // Annotate each closure's return type so the error type parameter `E`
        // of `MapInPlace<F, E>` is unambiguously `PipeError`, matching the
        // `Error = Self::Error` bound required by `InPlaceTransducer::fuse`.
        let op1 = MapInPlace::new(|buf: &mut [u8]| -> std::result::Result<usize, PipeError> {
            for b in buf.iter_mut() {
                *b = b.wrapping_add(10);
            }
            Ok(buf.len())
        });

        let op2 = MapInPlace::new(|buf: &mut [u8]| -> std::result::Result<usize, PipeError> {
            for b in buf.iter_mut() {
                *b = b.wrapping_mul(2);
            }
            Ok(buf.len())
        });

        let mut pipeline = op1.fuse(op2);
        let mut data = [1, 2, 3, 4];
        let len = pipeline.transform_mut(&mut data).unwrap();
        assert_eq!(len, 4);
        // (1 + 10) * 2 = 22, (2 + 10) * 2 = 24, (3 + 10) * 2 = 26, (4 + 10) * 2 = 28
        assert_eq!(data, [22, 24, 26, 28]);
    }

    #[test]
    fn test_counter_and_inspect_transducer() {
        use std::sync::atomic::{AtomicUsize, Ordering};
        use std::sync::Arc;

        // `InPlaceTransducer: 'static` requires the inspector closure to be
        // `'static`, so it cannot borrow the stack-local counter. Share an
        // `Arc<AtomicUsize>` instead: the closure `move`s one handle, and the
        // test keeps another to read the accumulated sum after the pipeline runs.
        let inspected_sum = Arc::new(AtomicUsize::new(0));
        let inspected_sum_shared = Arc::clone(&inspected_sum);
        let inspect = InspectTransducer::new(move |slice: &[u8]| {
            let delta: usize = slice.iter().map(|&x| x as usize).sum();
            inspected_sum_shared.fetch_add(delta, Ordering::Relaxed);
        });

        // Same as above: pin `E` to `PipeError` explicitly.
        let counter = CounterTransducer::<PipeError>::new();
        let mut pipeline = inspect.fuse(counter);

        let mut data = [10u8, 20, 30];
        let _ = pipeline.transform_mut(&mut data).unwrap();

        assert_eq!(inspected_sum.load(Ordering::Relaxed), 60);
        assert_eq!(pipeline.second.total_bytes(), 3);
    }

    // --- SIMD Masking Tests ---

    #[test]
    fn test_rotate_mask_key() {
        let key = [0x11, 0x22, 0x33, 0x44];
        assert_eq!(rotate_mask_key(key, 0), [0x11, 0x22, 0x33, 0x44]);
        assert_eq!(rotate_mask_key(key, 1), [0x22, 0x33, 0x44, 0x11]);
        assert_eq!(rotate_mask_key(key, 2), [0x33, 0x44, 0x11, 0x22]);
        assert_eq!(rotate_mask_key(key, 3), [0x44, 0x11, 0x22, 0x33]);
        assert_eq!(rotate_mask_key(key, 4), [0x11, 0x22, 0x33, 0x44]);
    }

    #[test]
    fn test_simd_mask_rfc6455_vector() {
        // RFC 6455 Section 5.7: "Hello" masked with key 0x37fa213d
        // Plaintext: [0x48, 0x65, 0x6c, 0x6c, 0x6f]
        // Key: [0x37, 0xfa, 0x21, 0x3d]
        // Masked: [0x7f, 0x9f, 0x4d, 0x51, 0x58]
        let mut data = [0x48, 0x65, 0x6c, 0x6c, 0x6f];
        let key = [0x37, 0xfa, 0x21, 0x3d];

        apply_mask(key, &mut data);
        assert_eq!(data, [0x7f, 0x9f, 0x4d, 0x51, 0x58]);

        // Unmasking (idempotent / roundtrip)
        apply_mask(key, &mut data);
        assert_eq!(data, [0x48, 0x65, 0x6c, 0x6c, 0x6f]);
    }

    #[test]
    fn test_simd_mask_various_lengths_and_offsets() {
        let key = [0xA1, 0xB2, 0xC3, 0xD4];
        let lengths = [
            0, 1, 2, 3, 4, 7, 8, 15, 16, 31, 32, 63, 64, 127, 128, 255, 256, 1024,
        ];

        for &len in &lengths {
            for offset in 0..4 {
                let original = vec![0x42u8; len];
                let mut test_buf = original.clone();

                let next_offset = apply_mask_offset(key, offset, &mut test_buf);
                assert_eq!(next_offset, (offset + len) % 4);

                // Verify against naive scalar reference
                for i in 0..len {
                    let expected_byte = original[i] ^ key[(offset + i) % 4];
                    assert_eq!(
                        test_buf[i], expected_byte,
                        "Mismatch at len={len}, offset={offset}, idx={i}"
                    );
                }

                // Round-trip unmask
                let final_offset = apply_mask_offset(key, offset, &mut test_buf);
                assert_eq!(final_offset, (offset + len) % 4);
                assert_eq!(test_buf, original);
            }
        }
    }

    #[test]
    fn test_simd_mask_operator_transducer() {
        let key = [0x01, 0x02, 0x03, 0x04];
        let mut op = SimdMaskOperator::new(key);

        let mut chunk1 = [0xAAu8; 10];
        let mut chunk2 = [0xBBu8; 10];

        let _ = op.transform_mut(&mut chunk1).unwrap();
        assert_eq!(op.offset(), 10 % 4); // 2

        let _ = op.transform_mut(&mut chunk2).unwrap();
        assert_eq!(op.offset(), 20 % 4); // 0
    }

    // --- REALITY Steganography Tests ---

    #[test]
    fn test_x25519_key_exchange() {
        // Alice private key
        let a_priv: [u8; 32] = [
            0x77, 0x07, 0x6d, 0x0a, 0x73, 0x18, 0xa5, 0x7d, 0x3c, 0x16, 0xc1, 0x72, 0x51, 0x52,
            0xc8, 0x62, 0x44, 0x91, 0xae, 0xdd, 0x98, 0x2a, 0xe9, 0x99, 0xee, 0x3e, 0x45, 0xf0,
            0x0a, 0x36, 0xec, 0x45,
        ];
        // Bob private key
        let b_priv: [u8; 32] = [
            0x5d, 0xab, 0x08, 0x7e, 0x62, 0x4a, 0x8a, 0x4b, 0x79, 0xe1, 0x7f, 0x8b, 0x83, 0x80,
            0x0e, 0xe6, 0x6f, 0x3b, 0xb1, 0x29, 0x26, 0x18, 0xb6, 0xfd, 0x1c, 0x2f, 0x8b, 0x27,
            0xff, 0x88, 0xe0, 0xeb,
        ];

        let mut u9 = [0u8; 32];
        u9[0] = 9;

        let a_pub = x25519(&a_priv, &u9);
        let b_pub = x25519(&b_priv, &u9);

        // DH shared secrets must match exactly
        let shared_a = x25519(&a_priv, &b_pub);
        let shared_b = x25519(&b_priv, &a_pub);

        assert_eq!(shared_a, shared_b);
        assert_ne!(shared_a, [0u8; 32]);
    }

    #[test]
    fn test_sha256_and_hmac() {
        let empty_hash = sha256(b"");
        assert_eq!(
            empty_hash,
            [
                0xe3, 0xb0, 0xc4, 0x42, 0x98, 0xfc, 0x1c, 0x14, 0x9a, 0xfb, 0xf4, 0xc8, 0x99, 0x6f,
                0xb9, 0x24, 0x27, 0xae, 0x41, 0xe4, 0x64, 0x9b, 0x93, 0x4c, 0xa4, 0x95, 0x99, 0x1b,
                0x78, 0x52, 0xb8, 0x55
            ]
        );

        let mac = hmac_sha256(b"key", b"The quick brown fox jumps over the lazy dog");
        assert_eq!(
            mac,
            [
                0xf7, 0xbc, 0x83, 0xf4, 0x30, 0x53, 0x84, 0x24, 0xb1, 0x32, 0x98, 0xe6, 0xaa, 0x6f,
                0xb1, 0x43, 0xef, 0x4d, 0x59, 0xa1, 0x49, 0x46, 0x17, 0x59, 0x97, 0x47, 0x9d, 0xbc,
                0x2d, 0x1a, 0x3c, 0xd8
            ]
        );
    }

    #[test]
    fn test_chacha20_roundtrip() {
        let key = [0x22u8; 32];
        let nonce = [0x33u8; 12];
        let original = b"Zero-allocation streaming pipeline fusion for REALITY protocol";
        let mut buf = original.to_vec();

        chacha20_xor(&key, &nonce, 1, &mut buf);
        assert_ne!(buf.as_slice(), original);

        chacha20_xor(&key, &nonce, 1, &mut buf);
        assert_eq!(buf.as_slice(), original);
    }

    #[test]
    fn test_reality_client_hello_parsing_and_authentication() {
        // Construct a synthetic valid TLS 1.3 ClientHello record
        let mut record = Vec::new();
        // TLS Record Header: 0x16 (Handshake), Version 0x0301, Length (to be patched)
        record.extend_from_slice(&[0x16, 0x03, 0x01, 0x00, 0x00]);

        let hs_start = record.len();
        // Handshake: Type 0x01 (ClientHello), Length (to be patched)
        record.extend_from_slice(&[0x01, 0x00, 0x00, 0x00]);
        // Client version: 0x0303
        record.extend_from_slice(&[0x03, 0x03]);

        // Random: 32 bytes
        let mut client_random = [0x55u8; 32];
        let random_pos = record.len();
        record.extend_from_slice(&client_random);

        // Session ID: 32 bytes (client ephemeral pubkey)
        let client_priv = [0x11u8; 32];
        let mut u9 = [0u8; 32];
        u9[0] = 9;
        let client_pub = x25519(&client_priv, &u9);

        record.push(32); // Session ID length
        record.extend_from_slice(&client_pub);

        // Cipher suites: 1 suite (TLS_AES_128_GCM_SHA256: 0x1301)
        record.extend_from_slice(&[0x00, 0x02, 0x13, 0x01]);
        // Compression: 1 method (null: 0x00)
        record.extend_from_slice(&[0x01, 0x00]);

        // Extensions
        let ext_len_pos = record.len();
        record.extend_from_slice(&[0x00, 0x00]); // Ext length placeholder
        let ext_start = record.len();

        // Extension: SNI (0x0000) -> "gateway.apple.com"
        let host = b"gateway.apple.com";
        record.extend_from_slice(&[0x00, 0x00]); // type
        let sni_ext_len = (5 + host.len()) as u16;
        record.extend_from_slice(&sni_ext_len.to_be_bytes());
        record.extend_from_slice(&((3 + host.len()) as u16).to_be_bytes());
        record.push(0x00); // host_name
        record.extend_from_slice(&(host.len() as u16).to_be_bytes());
        record.extend_from_slice(host);

        // Patch extension length
        let ext_len = (record.len() - ext_start) as u16;
        record[ext_len_pos..ext_len_pos + 2].copy_from_slice(&ext_len.to_be_bytes());

        // Patch Handshake length
        let hs_len = (record.len() - hs_start - 4) as u32;
        record[hs_start + 1] = ((hs_len >> 16) & 0xFF) as u8;
        record[hs_start + 2] = ((hs_len >> 8) & 0xFF) as u8;
        record[hs_start + 3] = (hs_len & 0xFF) as u8;

        // Patch Record length
        let rec_len = (record.len() - 5) as u16;
        record[3..5].copy_from_slice(&rec_len.to_be_bytes());

        // Setup REALITY server
        let server_priv = [0x22u8; 32];
        let short_id: [u8; 8] = [0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88];
        let ctx =
            RealityServerContext::new(server_priv, vec![short_id], "gateway.apple.com".to_string());

        // Derive expected auth HMAC to simulate client embedding token in Random
        let keys = ctx.derive_keys(&client_pub, &short_id).unwrap();
        let expected_hmac = hmac_sha256(&keys.auth_key, &client_pub);
        client_random[..16].copy_from_slice(&expected_hmac[..16]);
        record[random_pos..random_pos + 16].copy_from_slice(&expected_hmac[..16]);

        // Process handshake
        let decision = ctx.process_handshake(&mut record).unwrap();
        match decision {
            RealityDecision::Authenticated {
                peer_pubkey,
                short_id: sid,
                ..
            } => {
                assert_eq!(peer_pubkey, client_pub);
                assert_eq!(sid, short_id);
            }
            RealityDecision::DecoyFallback { .. } => panic!("Expected authentication success"),
        }
    }

    // --- Zero-Copy DMA & Splicing Tests ---

    #[test]
    fn test_dma_slice_split_and_advance() {
        let mut buffer = [10u8, 20, 30, 40, 50, 60];
        let dma = DmaSlice::from_mut_slice(&mut buffer, 1, 0);

        let (left, right) = dma.split_at(2);
        assert_eq!(left.len(), 2);
        assert_eq!(left.as_slice(), &[10, 20]);
        assert_eq!(right.len(), 4);
        assert_eq!(right.as_slice(), &[30, 40, 50, 60]);
        assert_eq!(right.offset(), 2);

        let mut right_mut = right;
        right_mut.advance(1);
        assert_eq!(right_mut.as_slice(), &[40, 50, 60]);
        assert_eq!(right_mut.offset(), 3);
    }

    #[test]
    fn test_dma_descriptor_construction() {
        let desc = DmaDescriptor::new(
            0x1000,
            4096,
            0,
            2,
            dma_flags::FLAG_READ | dma_flags::FLAG_FIXED_BUFFER,
            1,
            42,
        );

        assert!(desc.is_fixed_buffer());
        assert!(!desc.is_completed());
        assert_eq!(desc.user_data, 42);

        let mut desc_mut = desc;
        desc_mut.mark_completed();
        assert!(desc_mut.is_completed());
    }

    #[test]
    fn test_dma_pool_allocation_and_release() {
        let mut memory = [0u8; 4096 * 4];
        let mut pool: DmaPool<4, 4096> = unsafe { DmaPool::new(memory.as_mut_ptr()) };

        assert_eq!(pool.available_slots(), 4);

        let s0 = pool.alloc_slice().unwrap();
        assert_eq!(s0.buf_index(), 0);
        assert_eq!(pool.available_slots(), 3);

        let s1 = pool.alloc_slice().unwrap();
        assert_eq!(s1.buf_index(), 1);
        assert_eq!(pool.available_slots(), 2);

        pool.release_slice(s0.buf_index());
        assert_eq!(pool.available_slots(), 3);

        let s0_reused = pool.alloc_slice().unwrap();
        assert_eq!(s0_reused.buf_index(), 0);
    }

    #[test]
    fn test_splicing_bridge_ring_wrap() {
        let mut bridge: SplicingBridge<16> = SplicingBridge::new();
        assert_eq!(bridge.capacity(), 16);
        assert_eq!(bridge.len(), 0);

        // Splice in 10 bytes: [1..=10]
        let input1: [u8; 10] = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
        let written = bridge.splice_from(&input1);
        assert_eq!(written, 10);
        assert_eq!(bridge.len(), 10);

        // Read out 6 bytes
        let mut out1 = [0u8; 6];
        let read = bridge.splice_to(&mut out1);
        assert_eq!(read, 6);
        assert_eq!(out1, [1, 2, 3, 4, 5, 6]);
        assert_eq!(bridge.len(), 4); // [7, 8, 9, 10] remain

        // Splice in 10 more bytes: [11..=20] (forces ring wrap!)
        let input2: [u8; 10] = [11, 12, 13, 14, 15, 16, 17, 18, 19, 20];
        let written2 = bridge.splice_from(&input2);
        assert_eq!(written2, 10);
        assert_eq!(bridge.len(), 14);

        // Read all 14 bytes across the wrap boundary
        let mut out2 = [0u8; 14];
        let read2 = bridge.splice_to(&mut out2);
        assert_eq!(read2, 14);
        assert_eq!(out2, [7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20]);
        assert_eq!(bridge.len(), 0);
    }

    // --- Crypto Acceleration Tests (Intel SHA-NI & AVX-512/AVX2 ChaCha20) ---

    #[test]
    fn test_sha_ni_vs_scalar_equivalence() {
        let test_payloads: [&[u8]; 5] = [
            b"",
            b"abc",
            b"message digest",
            b"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789",
            &[0xAA; 1000],
        ];

        for payload in &test_payloads {
            let digest_scalar = sha256_scalar(payload);
            let digest_accel = sha256(payload);
            assert_eq!(
                digest_accel,
                digest_scalar,
                "Mismatch on payload len {}",
                payload.len()
            );
        }

        // Verify known NIST test vector: SHA-256("abc")
        let expected_abc = [
            0xba, 0x78, 0x16, 0xbf, 0x8f, 0x01, 0xcf, 0xea, 0x41, 0x41, 0x40, 0xde, 0x5d, 0xae,
            0x22, 0x23, 0xb0, 0x03, 0x61, 0xa3, 0x96, 0x17, 0x7a, 0x9c, 0xb4, 0x10, 0xff, 0x61,
            0xf2, 0x00, 0x15, 0xad,
        ];
        assert_eq!(sha256(b"abc"), expected_abc);
    }

    #[test]
    fn test_chacha20_vectorized_vs_scalar_equivalence() {
        let key = [
            0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d,
            0x0e, 0x0f, 0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18, 0x19, 0x1a, 0x1b,
            0x1c, 0x1d, 0x1e, 0x1f,
        ];
        let nonce = [
            0x00, 0x00, 0x00, 0x09, 0x00, 0x00, 0x00, 0x4a, 0x00, 0x00, 0x00, 0x00,
        ];

        // Test varying lengths across 1..=512 bytes
        for len in [1, 15, 64, 127, 128, 255, 256, 512] {
            let mut data_scalar = vec![0x77u8; len];
            let mut data_accel = vec![0x77u8; len];

            chacha20_scalar(&key, &nonce, 1, &mut data_scalar);
            chacha20_xor(&key, &nonce, 1, &mut data_accel);

            assert_eq!(data_accel, data_scalar, "Mismatch at length {}", len);
        }

        // Verify RFC 8439 section 2.3.2 first 16 bytes of keystream
        let mut zero_buf = [0u8; 64];
        chacha20_xor(&key, &nonce, 1, &mut zero_buf);
        let expected_prefix = [
            0x10, 0xf1, 0xe7, 0xe4, 0xd1, 0x3b, 0x59, 0x15, 0x50, 0x0f, 0xdd, 0x1f, 0xa3, 0x20,
            0x71, 0xc4,
        ];
        assert_eq!(&zero_buf[..16], &expected_prefix);
    }

    // --- Grand Unified Transducer-Pipe Tests ---

    #[test]
    fn test_network_transducer_socks5() {
        let mut s5 = Socks5HandshakeTransducer::new();
        let mut state = Socks5PipeState::AwaitingGreeting;

        // Step 1: Greeting [0x05, 0x01 (1 method), 0x00 (No Auth)]
        let mut greeting_pkt = [0x05, 0x01, 0x00];
        let res1 = s5.advance(&mut state, &mut greeting_pkt).unwrap();
        assert_eq!(state, Socks5PipeState::AwaitingCommand);
        match res1 {
            TransduceResult::Continue(ref b) => assert_eq!(&b[..], &[0x05, 0x00]),
            _ => panic!("expected Continue"),
        };

        // Step 2: Command CONNECT to 192.168.1.1:8080 (IPv4 atyp=1)
        let mut cmd_pkt = [
            0x05, 0x01, 0x00, 0x01, // VER, CMD, RSV, ATYP=IPv4
            192, 168, 1, 1, // IP
            0x1F, 0x90, // Port 8080
        ];
        let res2 = s5.advance(&mut state, &mut cmd_pkt).unwrap();
        assert_eq!(state, Socks5PipeState::Established);
        assert_eq!(
            res2,
            TransduceResult::Complete(Socks5ConnectedTarget {
                port: 8080,
                is_ipv4: true,
                ipv4_addr: [192, 168, 1, 1],
            })
        );
    }

    #[test]
    fn test_network_transducer_reality_decoy_direct_bypass() {
        let server_ctx = RealityServerContext::new(
            [0x22u8; 32],
            vec![[0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08]],
            "www.apple.com".to_string(),
        );

        let mut stego = RealityStegoTransducer::new(server_ctx);
        let mut state = RealityPipeState::AwaitingClientHello;

        // Arbitrary unauthorized TLS record (active probe simulation)
        let mut bogus_tls = [
            0x16, 0x03, 0x03, 0x00, 0x2A, // Record header
            0x01, 0x00, 0x00, 0x26, // Handshake ClientHello
            0x03, 0x03, // Client version
        ]
        .to_vec();
        bogus_tls.resize(47, 0x99);

        let res = stego.advance(&mut state, &mut bogus_tls).unwrap();
        // Active probe must directly result in DirectBypass!
        assert_eq!(res, TransduceResult::DirectBypass);
        assert_eq!(state, RealityPipeState::DecoyFallback);
    }

    #[test]
    fn test_grand_unified_pipeline_full_lifecycle() {
        let server_ctx = RealityServerContext::new(
            [0x33u8; 32],
            vec![[0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88]],
            "gateway.cloudflare.com".to_string(),
        );
        let mask_key = [0x50, 0x60, 0x70, 0x80];
        let mut pipe = GrandUnifiedPipe::new(server_ctx, mask_key);
        let mut state = GrandUnifiedState::Socks5Greeting;

        // 1. SOCKS5 Greeting
        let mut greet = [0x05, 0x01, 0x00];
        let r1 = pipe.advance(&mut state, &mut greet).unwrap();
        assert_eq!(state, GrandUnifiedState::Socks5Command);
        match r1 {
            TransduceResult::Continue(ref b) => assert_eq!(&b[..], &[0x05, 0x00]),
            _ => panic!("expected Continue"),
        };

        // 2. SOCKS5 Connect
        let mut cmd = [0x05, 0x01, 0x00, 0x01, 10, 0, 0, 1, 0x01, 0xBB]; // port 443
        let r2 = pipe.advance(&mut state, &mut cmd).unwrap();
        assert_eq!(state, GrandUnifiedState::StreamingRelay { ws_offset: 0 });
        assert_eq!(
            r2,
            TransduceResult::Complete(GrandUnifiedOutput::Socks5Established(
                Socks5ConnectedTarget {
                    port: 443,
                    is_ipv4: true,
                    ipv4_addr: [10, 0, 0, 1],
                }
            ))
        );

        // 3. Streaming Relay with SIMD WebSocket Masking
        let mut stream_chunk = *b"Hello Unified Transducer-Pipe!";
        let r3 = pipe.advance(&mut state, &mut stream_chunk).unwrap();
        assert_eq!(
            state,
            GrandUnifiedState::StreamingRelay { ws_offset: 30 % 4 }
        );
        match r3 {
            TransduceResult::Continue(buf) => {
                assert_eq!(buf.len(), 30);
                // Unmasking again with the same key should restore original text.
                // `*buf` is `[u8]` (unsized) so copy it out into an owned `Vec<u8>`
                // before mutating in place.
                let mut restored = buf.to_vec();
                apply_mask(mask_key, &mut restored);
                assert_eq!(restored.as_slice(), b"Hello Unified Transducer-Pipe!");
            }
            _ => panic!("Expected Continue with masked payload"),
        }
    }
}
