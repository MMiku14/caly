//! Error definitions for the `caly-pipe` pipeline and stream transform crate.

use thiserror::Error;

/// Enumerates all errors arising from pipeline execution, SIMD transformations,
/// REALITY handshake validation, and zero-copy DMA bridging.
#[derive(Debug, Error, PartialEq, Eq, Clone)]
pub enum PipeError {
    /// Generic or user-defined transducer processing failure.
    #[error("Pipeline transducer error: {0}")]
    Transducer(&'static str),

    /// Provided buffer is insufficient to store the transformed output or required frame.
    #[error("Buffer overflow: required {required} bytes, available {available} bytes")]
    BufferOverflow {
        /// Number of bytes required.
        required: usize,
        /// Number of bytes actually available.
        available: usize,
    },

    /// Not enough data in buffer to parse the expected structure.
    #[error("Buffer underflow: expected at least {expected} bytes, received {received} bytes")]
    BufferUnderflow {
        /// Number of bytes expected.
        expected: usize,
        /// Number of bytes received.
        received: usize,
    },

    /// TLS record format or ClientHello handshake structure is malformed.
    #[error("Invalid TLS handshake: {0}")]
    InvalidTlsHandshake(&'static str),

    /// REALITY authentication verification failed (e.g. invalid HMAC or unknown short ID).
    #[error("REALITY authentication failed: {0}")]
    RealityAuthFailed(&'static str),

    /// Cryptographic calculation (X25519, HKDF, SHA256) encountered invalid parameters.
    #[error("Cryptographic operation error: {0}")]
    CryptoError(&'static str),

    /// DMA descriptor or fixed buffer registry error.
    #[error("DMA ring buffer error: {0}")]
    DmaError(&'static str),

    /// Splicing bridge buffer has reached maximum capacity and cannot accept more bytes.
    #[error("Splicing bridge capacity exhausted")]
    SplicingCapacityExhausted,

    /// Pointer or buffer does not satisfy the required hardware alignment.
    #[error("Alignment fault: address {address:#x} not aligned to {required_align} bytes")]
    AlignmentFault {
        /// Misaligned memory address.
        address: usize,
        /// Minimum required alignment.
        required_align: usize,
    },
}

/// Convenience alias for results returned by `caly-pipe`.
pub type Result<T, E = PipeError> = core::result::Result<T, E>;
