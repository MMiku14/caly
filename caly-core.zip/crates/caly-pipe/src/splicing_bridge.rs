//! Splicing Bridge and Zero-Copy Ring Buffer Transformation.
//!
//! Provides circular DMA ring-buffer bridging and zero-copy in-place stream transduction,
//! fully compatible with Linux AF_XDP UMEM chunks and io_uring fixed buffer slices.

use crate::zero_copy::DmaSlice;
use crate::InPlaceTransducer;
use core::marker::PhantomData;

/// Circular ring-buffer bridging and zero-copy splicing pipe without heap allocation.
///
/// Exposes memory as pairs of contiguous slices matching the write and read windows,
/// allowing direct integration with kernel `splice(2)`, `vmsplice`, `io_uring`, and `AF_XDP`.
#[derive(Debug)]
pub struct SplicingBridge<const CAPACITY: usize> {
    buffer: [u8; CAPACITY],
    head: usize, // Read cursor
    tail: usize, // Write cursor
    len: usize,  // Total readable bytes in buffer
}

impl<const CAPACITY: usize> SplicingBridge<CAPACITY> {
    /// Constructs a new empty splicing bridge.
    pub const fn new() -> Self {
        Self {
            buffer: [0u8; CAPACITY],
            head: 0,
            tail: 0,
            len: 0,
        }
    }

    /// Returns the total capacity in bytes.
    #[inline(always)]
    pub const fn capacity(&self) -> usize {
        CAPACITY
    }

    /// Returns the number of bytes currently buffered and available to read.
    #[inline(always)]
    pub const fn len(&self) -> usize {
        self.len
    }

    /// Returns true if the bridge contains no readable data.
    #[inline(always)]
    pub const fn is_empty(&self) -> bool {
        self.len == 0
    }

    /// Returns the remaining write capacity.
    #[inline(always)]
    pub const fn available_write(&self) -> usize {
        CAPACITY - self.len
    }

    /// Clears the ring buffer without deallocating.
    #[inline(always)]
    pub fn clear(&mut self) {
        self.head = 0;
        self.tail = 0;
        self.len = 0;
    }

    /// Returns up to two contiguous mutable slices into which new ingress data may be written directly.
    pub fn write_slices_mut(&mut self) -> (&mut [u8], &mut [u8]) {
        let free = CAPACITY - self.len;
        if free == 0 {
            let (a, b) = self.buffer.split_at_mut(0);
            return (a, b);
        }

        let tail = self.tail;
        let head = self.head;
        if tail < head {
            let (_, after_tail) = self.buffer.split_at_mut(tail);
            let (first, rest) = after_tail.split_at_mut(free);
            let (empty, _) = rest.split_at_mut(0);
            (first, empty)
        } else {
            let to_end = CAPACITY - tail;
            if free <= to_end {
                let (_, after_tail) = self.buffer.split_at_mut(tail);
                let (first, rest) = after_tail.split_at_mut(free);
                let (empty, _) = rest.split_at_mut(0);
                (first, empty)
            } else {
                let from_start = free - to_end;
                let (front, back) = self.buffer.split_at_mut(tail);
                let (first, _) = back.split_at_mut(to_end);
                let (second, _) = front.split_at_mut(from_start.min(head));
                (first, second)
            }
        }
    }

    /// Commits `bytes` written into the slices provided by [`Self::write_slices_mut`].
    pub fn commit_write(&mut self, bytes: usize) {
        assert!(
            bytes <= CAPACITY - self.len,
            "Committed more bytes than available space"
        );
        self.tail = (self.tail + bytes) % CAPACITY;
        self.len += bytes;
    }

    /// Returns up to two contiguous slices representing available readable egress data.
    pub fn read_slices(&self) -> (&[u8], &[u8]) {
        if self.len == 0 {
            return (&self.buffer[0..0], &self.buffer[0..0]);
        }

        let head = self.head;
        if head < self.tail {
            (&self.buffer[head..self.tail], &self.buffer[0..0])
        } else {
            let to_end = CAPACITY - head;
            let first = &self.buffer[head..head + to_end];
            let second = &self.buffer[0..self.tail];
            (first, second)
        }
    }

    /// Returns up to two contiguous mutable slices representing available readable egress data.
    pub fn read_slices_mut(&mut self) -> (&mut [u8], &mut [u8]) {
        if self.len == 0 {
            let (a, b) = self.buffer.split_at_mut(0);
            return (a, b);
        }

        let head = self.head;
        let tail = self.tail;
        if head < tail {
            let (_, after_head) = self.buffer.split_at_mut(head);
            let (first, rest) = after_head.split_at_mut(tail - head);
            let (empty, _) = rest.split_at_mut(0);
            (first, empty)
        } else {
            let to_end = CAPACITY - head;
            let (front, back) = self.buffer.split_at_mut(head);
            let (first, _) = back.split_at_mut(to_end);
            let (second, _) = front.split_at_mut(tail);
            (first, second)
        }
    }

    /// Commits `bytes` read/consumed from the bridge.
    pub fn commit_read(&mut self, bytes: usize) {
        assert!(
            bytes <= self.len,
            "Committed more bytes than available data"
        );
        self.head = (self.head + bytes) % CAPACITY;
        self.len -= bytes;
    }

    /// Transforms the unread bytes directly in the DMA ring without moving memory.
    ///
    /// Executes the provided [`InPlaceTransducer`] over both contiguous read windows in-place,
    /// avoiding buffer shifts and heap reallocations.
    pub fn splice_in_place_transform<T: InPlaceTransducer>(&mut self, transducer: &mut T) -> usize {
        if self.len == 0 {
            return 0;
        }

        let (s1, s2) = self.read_slices_mut();
        let mut total_transformed = 0;

        if !s1.is_empty() {
            if let Ok(n) = transducer.transform_mut(s1) {
                total_transformed += n;
            }
        }

        if !s2.is_empty() {
            if let Ok(n) = transducer.transform_mut(s2) {
                total_transformed += n;
            }
        }

        total_transformed
    }

    /// Splices data from `src` into the ring buffer without heap allocation.
    pub fn splice_from(&mut self, src: &[u8]) -> usize {
        let (s1, s2) = self.write_slices_mut();
        let mut total_copied = 0;

        let to_copy1 = src.len().min(s1.len());
        if to_copy1 > 0 {
            s1[..to_copy1].copy_from_slice(&src[..to_copy1]);
            total_copied += to_copy1;
        }

        let rem_src = &src[to_copy1..];
        let to_copy2 = rem_src.len().min(s2.len());
        if to_copy2 > 0 {
            s2[..to_copy2].copy_from_slice(&rem_src[..to_copy2]);
            total_copied += to_copy2;
        }

        self.commit_write(total_copied);
        total_copied
    }

    /// Splices data from a registered DMA slice into the ring buffer.
    #[inline(always)]
    pub fn splice_from_dma(&mut self, dma: &DmaSlice<'_>) -> usize {
        self.splice_from(dma.as_slice())
    }

    /// Splices data out of the ring buffer into `dst` without heap allocation.
    pub fn splice_to(&mut self, dst: &mut [u8]) -> usize {
        let (r1, r2) = self.read_slices();
        let mut total_copied = 0;

        let to_copy1 = dst.len().min(r1.len());
        if to_copy1 > 0 {
            dst[..to_copy1].copy_from_slice(&r1[..to_copy1]);
            total_copied += to_copy1;
        }

        let rem_dst = &mut dst[to_copy1..];
        let to_copy2 = rem_dst.len().min(r2.len());
        if to_copy2 > 0 {
            rem_dst[..to_copy2].copy_from_slice(&r2[..to_copy2]);
            total_copied += to_copy2;
        }

        self.commit_read(total_copied);
        total_copied
    }

    /// Splices data out of the ring buffer into a registered mutable DMA slice.
    #[inline(always)]
    pub fn splice_to_dma(&mut self, dma: &mut DmaSlice<'_>) -> usize {
        self.splice_to(dma.as_mut_slice())
    }

    /// Returns the current read windows as a pair of immutable byte slices.
    #[inline(always)]
    pub fn as_dma_slices(&self) -> (&[u8], &[u8]) {
        self.read_slices()
    }

    /// Exposes the current mutable read windows as a pair of [`DmaSlice`] descriptors.
    pub fn as_dma_slices_mut(&mut self, buf_index: u16) -> (DmaSlice<'_>, DmaSlice<'_>) {
        let (s1, s2) = self.read_slices_mut();
        let s1_len = s1.len();
        let p1 = s1.as_mut_ptr();
        let p2 = s2.as_mut_ptr();
        let s2_len = s2.len();
        // SAFETY: `p1`/`s1_len` describe the first contiguous read
        // window returned by `read_slices_mut`, which borrowed `self`
        // for the duration of this call.
        let dma1 = unsafe { DmaSlice::from_raw_parts(p1, s1_len, buf_index, 0) };
        // SAFETY: `p2`/`s2_len` describe the second contiguous read
        // window; both pointers come from the same `self.buffer` split.
        let dma2 = unsafe { DmaSlice::from_raw_parts(p2, s2_len, buf_index, s1_len as u32) };
        (dma1, dma2)
    }

    /// Executes an in-place transformation closure across both readable slices without copying.
    pub fn bridge_in_place<F, R>(&mut self, f: F) -> R
    where
        F: FnOnce(&mut [u8], &mut [u8]) -> (usize, R),
    {
        let (s1, s2) = self.read_slices_mut();
        let (consumed, res) = f(s1, s2);
        self.commit_read(consumed);
        res
    }
}

impl<const CAPACITY: usize> Default for SplicingBridge<CAPACITY> {
    fn default() -> Self {
        Self::new()
    }
}

/// Zero-copy borrowing bridge over an AF_XDP UMEM packet chunk or io_uring fixed buffer.
///
/// Binds directly to the memory region mapped by AF_XDP or HugeTLB without taking ownership
/// or copying packet frames, enabling wire-speed in-place transduction.
#[derive(Debug)]
pub struct UmemChunkBridge<'a> {
    ptr: *mut u8,
    #[allow(dead_code)]
    len: usize,
    head: usize,
    tail: usize,
    chunk_index: u32,
    _marker: PhantomData<&'a mut [u8]>,
}

// SAFETY: `UmemChunkBridge` wraps a raw pointer into a UMEM chunk
// that the caller has guaranteed is exclusively owned for lifetime
// `'a`. Moving it across threads is equivalent to moving `&mut [u8]`.
unsafe impl<'a> Send for UmemChunkBridge<'a> {}
// SAFETY: `&UmemChunkBridge` only exposes `as_slice()` (read-only);
// mutation requires `&mut self`.
unsafe impl<'a> Sync for UmemChunkBridge<'a> {}

impl<'a> UmemChunkBridge<'a> {
    /// Constructs a `UmemChunkBridge` from raw UMEM pointer and chunk length.
    ///
    /// # Safety
    ///
    /// * `ptr` must point to a valid UMEM chunk of at least `len` bytes.
    /// * The chunk must not be concurrently accessed through any other
    ///   AF_XDP descriptor or socket for the lifetime `'a`.
    /// * The chunk must remain registered in the UMEM for the entire
    ///   duration of the borrow.
    #[inline(always)]
    pub unsafe fn from_raw_parts(ptr: *mut u8, len: usize, chunk_index: u32) -> Self {
        Self {
            ptr,
            len,
            head: 0,
            tail: len,
            chunk_index,
            _marker: PhantomData,
        }
    }

    /// Constructs a `UmemChunkBridge` from a standard mutable byte slice.
    #[inline(always)]
    pub fn from_mut_slice(slice: &'a mut [u8], chunk_index: u32) -> Self {
        let len = slice.len();
        Self {
            ptr: slice.as_mut_ptr(),
            len,
            head: 0,
            tail: len,
            chunk_index,
            _marker: PhantomData,
        }
    }

    /// Constructs a `UmemChunkBridge` from an existing [`DmaSlice`].
    #[inline(always)]
    pub fn from_dma_slice(dma: &'a mut DmaSlice<'_>) -> Self {
        let chunk_index = dma.buf_index() as u32;
        Self::from_mut_slice(dma.as_mut_slice(), chunk_index)
    }

    /// Returns the chunk index or identifier.
    #[inline(always)]
    pub const fn chunk_index(&self) -> u32 {
        self.chunk_index
    }

    /// Returns the number of readable bytes remaining in this chunk.
    #[inline(always)]
    pub fn len(&self) -> usize {
        self.tail.saturating_sub(self.head)
    }

    /// Returns true if all readable bytes have been consumed.
    #[inline(always)]
    pub fn is_empty(&self) -> bool {
        self.head >= self.tail
    }

    /// Returns an immutable sub-slice of available data.
    #[inline(always)]
    pub fn as_slice(&self) -> &[u8] {
        if self.is_empty() {
            &[]
        } else {
            // SAFETY: `self.head <= self.tail`, and `self.ptr` was
            // supplied by the caller as pointing to at least `self.tail`
            // bytes, so `ptr.add(head)` stays inside the chunk.
            let p = unsafe { self.ptr.add(self.head) };
            // SAFETY: `p` and `self.len()` describe a valid,
            // initialized slice of UMEM bytes.
            unsafe { core::slice::from_raw_parts(p, self.len()) }
        }
    }

    /// Returns a mutable sub-slice of available data.
    #[inline(always)]
    pub fn as_mut_slice(&mut self) -> &mut [u8] {
        if self.is_empty() {
            &mut []
        } else {
            let l = self.len();
            // SAFETY: same bound as in `as_slice`: `ptr.add(head)` is
            // inside the chunk mapping.
            let p = unsafe { self.ptr.add(self.head) };
            // SAFETY: `&mut self` guarantees exclusive access; `p` and
            // `l` describe the remaining valid bytes.
            unsafe { core::slice::from_raw_parts_mut(p, l) }
        }
    }

    /// Transforms data directly in the UMEM chunk in-place with zero heap allocation.
    pub fn splice_in_place_transform<T: InPlaceTransducer>(&mut self, transducer: &mut T) -> usize {
        let slice = self.as_mut_slice();
        if slice.is_empty() {
            return 0;
        }
        transducer.transform_mut(slice).unwrap_or_default()
    }

    /// Advances the read cursor by `bytes`.
    #[inline(always)]
    pub fn commit_read(&mut self, bytes: usize) {
        self.head = (self.head + bytes).min(self.tail);
    }

    /// Converts this bridge into a [`DmaSlice`] descriptor.
    #[inline(always)]
    pub fn into_dma_slice(self) -> DmaSlice<'a> {
        // SAFETY: `ptr.add(head)` stays inside the chunk; `head <= tail`.
        let p = unsafe { self.ptr.add(self.head) };
        // SAFETY: `p`/`len` describe a valid, initialized slice; the
        // buffer index and offset are the bridge's own bookkeeping.
        unsafe {
            DmaSlice::from_raw_parts(p, self.len(), self.chunk_index as u16, self.head as u32)
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_splicing_bridge_full_circular_coverage() {
        let mut bridge: SplicingBridge<8> = SplicingBridge::new();

        // 20 rounds of write(6) + read(6), forcing wrap-around each time.
        for round in 0..20u32 {
            let data: Vec<u8> = (0..6).map(|i| ((round * 6 + i) & 0xFF) as u8).collect();
            let written = bridge.splice_from(&data);
            assert_eq!(written, 6, "round {round}: write short");

            let mut out = [0u8; 6];
            let read = bridge.splice_to(&mut out);
            assert_eq!(read, 6, "round {round}: read short");
            assert_eq!(&out, data.as_slice(), "round {round}: data mismatch");
        }

        assert!(bridge.is_empty());
        assert_eq!(bridge.available_write(), 8);
    }
    #[test]
    fn test_splicing_bridge_partial_commit() {
        // Bridge capacity = 16 bytes.
        let mut bridge: SplicingBridge<16> = SplicingBridge::new();

        // ── Step 1: fill 10 / 16. ──────────────────────────────────────────
        bridge.splice_from(&[1, 2, 3, 4, 5, 6, 7, 8, 9, 10]);
        assert_eq!(bridge.len(), 10);
        assert_eq!(bridge.available_write(), 6);

        // ── Step 2: consume 4 bytes; available_write grows back to 10. ─────
        let mut partial = [0u8; 4];
        assert_eq!(bridge.splice_to(&mut partial), 4);
        assert_eq!(partial, [1, 2, 3, 4]);
        assert_eq!(bridge.len(), 6);
        assert_eq!(bridge.available_write(), 10);

        // ── Step 3: write 8 more bytes; they all fit (10 free). ────────────
        let appended = bridge.splice_from(&[11, 12, 13, 14, 15, 16, 17, 18]);
        assert_eq!(appended, 8, "8 bytes should fit in 10 free slots");
        assert_eq!(bridge.len(), 14);
        assert_eq!(bridge.available_write(), 2);

        // ── Step 4: try to write 5 bytes; only 2 fit → partial commit. ─────
        let extra = bridge.splice_from(&[20, 21, 22, 23, 24]);
        assert_eq!(extra, 2, "only 2 free bytes");
        assert_eq!(bridge.len(), 16, "buffer should now be completely full");
        assert_eq!(bridge.available_write(), 0);

        // ── Step 5: drain and verify strict FIFO ordering. ─────────────────
        let mut rest = [0u8; 16];
        assert_eq!(bridge.splice_to(&mut rest), 16);
        assert_eq!(
            rest,
            [5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 20, 21],
        );
        assert!(bridge.is_empty());
    }

    #[test]
    fn test_splicing_bridge_in_place_transform() {
        use crate::simd_mask::SimdMaskOperator;

        let mut bridge: SplicingBridge<32> = SplicingBridge::new();
        bridge.splice_from(b"0123456789abcdef");

        let key = [0x11, 0x22, 0x33, 0x44];
        let mut masker = SimdMaskOperator::new(key);
        let n = bridge.splice_in_place_transform(&mut masker);
        assert_eq!(n, 16);

        // Read out; should be masked.
        let mut out = [0u8; 16];
        bridge.splice_to(&mut out);
        for i in 0..16 {
            let expect = b"0123456789abcdef"[i] ^ key[i % 4];
            assert_eq!(out[i], expect);
        }
    }
}
