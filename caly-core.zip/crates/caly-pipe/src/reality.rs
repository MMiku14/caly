//! REALITY In-Place Steganography & Handshake Transform Primitives.
//!
//! Provides zero-allocation parsing of TLS 1.3 ClientHello records, ephemeral X25519
//! ECDH key exchange parsing (from Session ID, Random, or KeyShare extension), HKDF-SHA256
//! key derivation, in-place AuthKey / SessionKey verification, ciphertext substitution,
//! and zero-copy decoy fallback splicing helpers.

use crate::error::{PipeError, Result};

// ============================================================================
// Curve25519 / X25519 Montgomery Ladder (RFC 7748)
// ============================================================================
/// Computes the X25519 Diffie-Hellman scalar multiplication (RFC 7748).
///
/// Implemented directly on `curve25519_dalek::MontgomeryPoint::mul_clamped`
/// to remove any ambiguity about the wrapper layer's semantics.
#[inline]
pub fn x25519(scalar: &[u8; 32], point: &[u8; 32]) -> [u8; 32] {
    use curve25519_dalek::montgomery::MontgomeryPoint;
    MontgomeryPoint(*point).mul_clamped(*scalar).to_bytes()
}

// ============================================================================
// SHA-256, HMAC-SHA256, HKDF-SHA256 (RFC 6234, RFC 2104, RFC 5869)
// ============================================================================

const SHA256_K: [u32; 64] = [
    0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
    0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
    0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
    0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
    0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
    0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
    0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
    0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
];

/// Zero-allocation streaming SHA-256 state (RFC 6234).
#[derive(Clone, Copy, Debug)]
pub struct Sha256Hasher {
    state: [u32; 8],
    buf: [u8; 64],
    buf_len: usize,
    total_len: u64,
}

impl Default for Sha256Hasher {
    #[inline(always)]
    fn default() -> Self {
        Self::new()
    }
}

impl Sha256Hasher {
    /// Creates a new streaming SHA-256 hasher initialized to FIPS 180-4 standard constants.
    #[inline(always)]
    pub const fn new() -> Self {
        Self {
            state: [
                0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a, 0x510e527f, 0x9b05688c, 0x1f83d9ab,
                0x5be0cd19,
            ],
            buf: [0u8; 64],
            buf_len: 0,
            total_len: 0,
        }
    }

    /// Ingests arbitrary slice of bytes into the streaming hash state with ZERO allocations.
    pub fn update(&mut self, mut data: &[u8]) {
        self.total_len += data.len() as u64;

        if self.buf_len > 0 {
            let to_copy = (64 - self.buf_len).min(data.len());
            self.buf[self.buf_len..self.buf_len + to_copy].copy_from_slice(&data[..to_copy]);
            self.buf_len += to_copy;
            data = &data[to_copy..];

            if self.buf_len == 64 {
                let block = self.buf;
                sha256_compress_block(&mut self.state, &block);
                self.buf_len = 0;
            }
        }

        while data.len() >= 64 {
            let mut block = [0u8; 64];
            block.copy_from_slice(&data[..64]);
            sha256_compress_block(&mut self.state, &block);
            data = &data[64..];
        }

        if !data.is_empty() {
            self.buf[..data.len()].copy_from_slice(data);
            self.buf_len = data.len();
        }
    }

    /// Finalizes the SHA-256 hash, executing padding in-place on the stack, returning the 32-byte digest.
    pub fn finalize(mut self) -> [u8; 32] {
        let remainder = self.buf_len;
        self.buf[remainder] = 0x80;

        if remainder >= 56 {
            for byte in &mut self.buf[remainder + 1..64] {
                *byte = 0;
            }
            let block = self.buf;
            sha256_compress_block(&mut self.state, &block);
            self.buf = [0u8; 64];
        } else {
            for byte in &mut self.buf[remainder + 1..56] {
                *byte = 0;
            }
        }

        let bit_len = self.total_len * 8;
        self.buf[56..64].copy_from_slice(&bit_len.to_be_bytes());
        let block = self.buf;
        sha256_compress_block(&mut self.state, &block);

        let mut digest = [0u8; 32];
        for (i, word) in self.state.iter().enumerate() {
            digest[i * 4..(i + 1) * 4].copy_from_slice(&word.to_be_bytes());
        }
        digest
    }
}

#[inline(always)]
fn sha256_compress_block(state: &mut [u32; 8], block: &[u8; 64]) {
    #[cfg(target_arch = "x86_64")]
    {
        if crate::crypto_accel::has_sha_ni() {
            // SAFETY: `has_sha_ni()` verified SHA-NI + SSSE3 + SSE4.1
            // support at runtime, which is the sole precondition of
            // `sha256_compress_ni`.
            unsafe {
                crate::crypto_accel::sha256_compress_ni(state, block);
                return;
            }
        }
    }
    sha256_compress(state, block);
}

/// Computes SHA-256 hash of `data` utilizing hardware SHA-NI instructions with zero allocations.
pub fn sha256(data: &[u8]) -> [u8; 32] {
    crate::crypto_accel::sha256(data)
}

#[inline(always)]
fn sha256_compress(state: &mut [u32; 8], block: &[u8]) {
    let mut w = [0u32; 64];
    for i in 0..16 {
        let mut b = [0u8; 4];
        b.copy_from_slice(&block[i * 4..(i + 1) * 4]);
        w[i] = u32::from_be_bytes(b);
    }

    for i in 16..64 {
        let s0 = w[i - 15].rotate_right(7) ^ w[i - 15].rotate_right(18) ^ (w[i - 15] >> 3);
        let s1 = w[i - 2].rotate_right(17) ^ w[i - 2].rotate_right(19) ^ (w[i - 2] >> 10);
        w[i] = w[i - 16]
            .wrapping_add(s0)
            .wrapping_add(w[i - 7])
            .wrapping_add(s1);
    }

    let mut a = state[0];
    let mut b = state[1];
    let mut c = state[2];
    let mut d = state[3];
    let mut e = state[4];
    let mut f = state[5];
    let mut g = state[6];
    let mut h = state[7];

    for i in 0..64 {
        let s1 = e.rotate_right(6) ^ e.rotate_right(11) ^ e.rotate_right(25);
        let ch = (e & f) ^ ((!e) & g);
        let temp1 = h
            .wrapping_add(s1)
            .wrapping_add(ch)
            .wrapping_add(SHA256_K[i])
            .wrapping_add(w[i]);
        let s0 = a.rotate_right(2) ^ a.rotate_right(13) ^ a.rotate_right(22);
        let maj = (a & b) ^ (a & c) ^ (b & c);
        let temp2 = s0.wrapping_add(maj);

        h = g;
        g = f;
        f = e;
        e = d.wrapping_add(temp1);
        d = c;
        c = b;
        b = a;
        a = temp1.wrapping_add(temp2);
    }

    state[0] = state[0].wrapping_add(a);
    state[1] = state[1].wrapping_add(b);
    state[2] = state[2].wrapping_add(c);
    state[3] = state[3].wrapping_add(d);
    state[4] = state[4].wrapping_add(e);
    state[5] = state[5].wrapping_add(f);
    state[6] = state[6].wrapping_add(g);
    state[7] = state[7].wrapping_add(h);
}

/// Computes HMAC-SHA256 message authentication code (RFC 2104) with ZERO heap allocation.
pub fn hmac_sha256(key: &[u8], message: &[u8]) -> [u8; 32] {
    let mut k_pad = [0u8; 64];
    if key.len() > 64 {
        let hash = sha256(key);
        k_pad[..32].copy_from_slice(&hash);
    } else {
        k_pad[..key.len()].copy_from_slice(key);
    }

    let mut ipad = [0u8; 64];
    let mut opad = [0u8; 64];
    for i in 0..64 {
        ipad[i] = k_pad[i] ^ 0x36;
        opad[i] = k_pad[i] ^ 0x5c;
    }

    // Inner hash: H(ipad || message) - Streaming, Zero Heap Allocation!
    let mut inner = Sha256Hasher::new();
    inner.update(&ipad);
    inner.update(message);
    let inner_hash = inner.finalize();

    // Outer hash: H(opad || inner_hash) - Streaming, Zero Heap Allocation!
    let mut outer = Sha256Hasher::new();
    outer.update(&opad);
    outer.update(&inner_hash);
    outer.finalize()
}

/// HKDF-Extract using SHA-256 (RFC 5869).
pub fn hkdf_extract(salt: &[u8], ikm: &[u8]) -> [u8; 32] {
    if salt.is_empty() {
        let zero_salt = [0u8; 32];
        hmac_sha256(&zero_salt, ikm)
    } else {
        hmac_sha256(salt, ikm)
    }
}

/// HKDF-Expand using SHA-256 (RFC 5869) with ZERO heap allocation.
pub fn hkdf_expand(prk: &[u8; 32], info: &[u8], out: &mut [u8]) -> Result<()> {
    let mut t = [0u8; 32];
    let mut counter = 1u8;
    let mut offset = 0;

    let mut k_pad = [0u8; 64];
    k_pad[..32].copy_from_slice(prk);

    let mut ipad = [0u8; 64];
    let mut opad = [0u8; 64];
    for i in 0..64 {
        ipad[i] = k_pad[i] ^ 0x36;
        opad[i] = k_pad[i] ^ 0x5c;
    }

    while offset < out.len() {
        // Inner hash: H(ipad || T(prev) || info || counter) - Zero Heap Allocation!
        let mut inner = Sha256Hasher::new();
        inner.update(&ipad);
        if offset > 0 {
            inner.update(&t);
        }
        inner.update(info);
        inner.update(&[counter]);
        let inner_hash = inner.finalize();

        // Outer hash: H(opad || inner_hash) - Zero Heap Allocation!
        let mut outer = Sha256Hasher::new();
        outer.update(&opad);
        outer.update(&inner_hash);
        t = outer.finalize();

        let to_copy = (out.len() - offset).min(32);
        out[offset..offset + to_copy].copy_from_slice(&t[..to_copy]);
        offset += to_copy;

        counter = counter
            .checked_add(1)
            .ok_or(PipeError::CryptoError("HKDF overflow"))?;
    }
    Ok(())
}
// ChaCha20 In-Place Keystream Masking (RFC 8439)
// ============================================================================

/// In-place ChaCha20 XOR stream cipher keystream application for steganography.
///
/// Automatically delegates to wide-vector SIMD implementations (AVX-512, AVX2) in `crypto_accel`.
#[inline(always)]
pub fn chacha20_xor(key: &[u8; 32], nonce: &[u8; 12], counter: u32, data: &mut [u8]) {
    crate::crypto_accel::chacha20_xor(key, nonce, counter, data);
}
// ============================================================================
// REALITY Handshake & Steganography Primitives
// ============================================================================

/// Derived cryptographic session keys for authenticated REALITY connections.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct RealityKeys {
    /// Authentication key used for HMAC tag validation.
    pub auth_key: [u8; 32],
    /// Steganography / tunnel cipher session key.
    pub session_key: [u8; 32],
    /// Initialization vector / nonce.
    pub iv: [u8; 12],
}

/// Decision reached upon inspection of the ClientHello.
#[derive(Debug, PartialEq, Eq)]
pub enum RealityDecision {
    /// Validated authentic REALITY client with derived keys.
    Authenticated {
        /// Derived cryptographic keys.
        keys: RealityKeys,
        /// Ephemeral client public key extracted from handshake.
        peer_pubkey: [u8; 32],
        /// Matching short ID (up to 8 bytes).
        short_id: [u8; 8],
    },
    /// Authentication failed or active probe detected; transparently splice to decoy.
    DecoyFallback {
        /// SNI hostname from ClientHello (if present).
        target_sni: Option<String>,
        /// Byte length of the raw TLS record to splice.
        raw_len: usize,
    },
}

/// Zero-copy parser and in-place mutator for TLS 1.3 ClientHello records.
pub struct RealityClientHello<'a> {
    raw: &'a mut [u8],
    #[allow(dead_code)]
    handshake_len: usize,
    random_offset: usize,
    session_id_offset: usize,
    session_id_len: usize,
    sni: Option<String>,
    key_share: Option<[u8; 32]>,
}

impl<'a> RealityClientHello<'a> {
    /// Zero-copy parses a raw byte slice containing a TLS 1.3 ClientHello record.
    pub fn parse(raw: &'a mut [u8]) -> Result<Self> {
        let total_len = raw.len();
        if total_len < 44 {
            return Err(PipeError::BufferUnderflow {
                expected: 44,
                received: total_len,
            });
        }

        // 1. TLS Record Header: [0]=0x16 (Handshake), [1..3]=0x0301/0x0303, [3..5]=Record length
        if raw[0] != 0x16 {
            return Err(PipeError::InvalidTlsHandshake(
                "Not a TLS handshake record (type != 0x16)",
            ));
        }

        let record_len = u16::from_be_bytes([raw[3], raw[4]]) as usize;
        if total_len < 5 + record_len {
            return Err(PipeError::BufferUnderflow {
                expected: 5 + record_len,
                received: total_len,
            });
        }

        // 2. Handshake message: [5]=0x01 (ClientHello), [6..9]=u24 length
        if raw[5] != 0x01 {
            return Err(PipeError::InvalidTlsHandshake(
                "Not a ClientHello message (type != 0x01)",
            ));
        }

        let handshake_len =
            ((raw[6] as usize) << 16) | ((raw[7] as usize) << 8) | (raw[8] as usize);
        // TLS 1.3 §5.1: the handshake message occupies the *entire* record
        // body, so `handshake_len + 4 <= record_len` must hold. Without this
        // check, a malformed datagram could claim a shorter handshake and
        // still be scanned past its declared boundary during extension
        // parsing, letting attacker-controlled bytes drive the SNI / KeyShare
        // extraction.
        if handshake_len
            .checked_add(4)
            .is_none_or(|x| x > record_len)
        {
            return Err(PipeError::InvalidTlsHandshake(
                "handshake_len + 4 exceeds record_len",
            ));
        }
        let random_offset = 11; // 5 (rec hdr) + 4 (hs hdr) + 2 (legacy ver)
        if total_len < random_offset + 32 + 1 {
            return Err(PipeError::BufferUnderflow {
                expected: random_offset + 33,
                received: total_len,
            });
        }

        let session_id_len_offset = random_offset + 32;
        let session_id_len = raw[session_id_len_offset] as usize;
        let session_id_offset = session_id_len_offset + 1;

        if total_len < session_id_offset + session_id_len + 2 {
            return Err(PipeError::BufferUnderflow {
                expected: session_id_offset + session_id_len + 2,
                received: total_len,
            });
        }

        // 3. Skip Cipher Suites
        let cs_len_offset = session_id_offset + session_id_len;
        let cs_len = u16::from_be_bytes([raw[cs_len_offset], raw[cs_len_offset + 1]]) as usize;
        let comp_len_offset = cs_len_offset + 2 + cs_len;

        if total_len < comp_len_offset + 1 {
            return Err(PipeError::BufferUnderflow {
                expected: comp_len_offset + 1,
                received: total_len,
            });
        }

        // 4. Skip Compression Methods
        let comp_len = raw[comp_len_offset] as usize;
        let ext_len_offset = comp_len_offset + 1 + comp_len;

        let mut sni = None;
        let mut key_share = None;

        if total_len >= ext_len_offset + 2 {
            let ext_total_len =
                u16::from_be_bytes([raw[ext_len_offset], raw[ext_len_offset + 1]]) as usize;
            let mut curr = ext_len_offset + 2;
            let ext_end = (curr + ext_total_len).min(5 + record_len).min(total_len);

            while curr + 4 <= ext_end {
                let ext_type = u16::from_be_bytes([raw[curr], raw[curr + 1]]);
                let ext_len = u16::from_be_bytes([raw[curr + 2], raw[curr + 3]]) as usize;
                let ext_data_start = curr + 4;
                let ext_data_end = ext_data_start + ext_len;

                if ext_data_end > ext_end {
                    break;
                }

                match ext_type {
                    // SNI (Server Name Indication)
                    0x0000 => {
                        if ext_len > 5 {
                            let server_name_len = u16::from_be_bytes([
                                raw[ext_data_start + 3],
                                raw[ext_data_start + 4],
                            ]) as usize;
                            let host_start = ext_data_start + 5;
                            let host_end = host_start + server_name_len;
                            if host_end <= ext_data_end {
                                if let Ok(s) = core::str::from_utf8(&raw[host_start..host_end]) {
                                    sni = Some(s.to_string());
                                }
                            }
                        }
                    }
                    // Key Share (TLS 1.3)
                    0x0033 if ext_len >= 6 => {
                        // KeyShareClientHello: client_shares length (u16)
                        let mut ks_curr = ext_data_start + 2;
                        while ks_curr + 4 <= ext_data_end {
                            let group = u16::from_be_bytes([raw[ks_curr], raw[ks_curr + 1]]);
                            let klen =
                                u16::from_be_bytes([raw[ks_curr + 2], raw[ks_curr + 3]]) as usize;
                            let kstart = ks_curr + 4;
                            let kend = kstart + klen;
                            if kend > ext_data_end {
                                break;
                            }
                            // X25519 group ID = 0x001d, length = 32
                            if group == 0x001d && klen == 32 {
                                let mut pubk = [0u8; 32];
                                pubk.copy_from_slice(&raw[kstart..kend]);
                                key_share = Some(pubk);
                                break;
                            }
                            ks_curr = kend;
                        }
                    }
                    _ => {}
                }
                curr = ext_data_end;
            }
        }

        Ok(Self {
            raw,
            handshake_len,
            random_offset,
            session_id_offset,
            session_id_len,
            sni,
            key_share,
        })
    }

    /// Extracted Server Name Indication (SNI) string.
    #[inline(always)]
    pub fn sni(&self) -> Option<&str> {
        self.sni.as_deref()
    }

    /// Borrow the 32-byte TLS Random field.
    #[inline(always)]
    pub fn random(&self) -> &[u8; 32] {
        let slice = &self.raw[self.random_offset..self.random_offset + 32];
        slice.try_into().unwrap()
    }

    /// Mutably borrow the 32-byte TLS Random field for in-place steganography.
    #[inline(always)]
    pub fn random_mut(&mut self) -> &mut [u8; 32] {
        let slice = &mut self.raw[self.random_offset..self.random_offset + 32];
        slice.try_into().unwrap()
    }

    /// Borrow the Session ID slice.
    #[inline(always)]
    pub fn session_id(&self) -> &[u8] {
        &self.raw[self.session_id_offset..self.session_id_offset + self.session_id_len]
    }

    /// Mutably borrow the Session ID slice for in-place steganography.
    #[inline(always)]
    pub fn session_id_mut(&mut self) -> &mut [u8] {
        &mut self.raw[self.session_id_offset..self.session_id_offset + self.session_id_len]
    }

    /// Extracts the client's ephemeral X25519 public key.
    ///
    /// Inspects the 32-byte Session ID first, falling back to KeyShare extension, and then Random.
    pub fn extract_client_pubkey(&self) -> Result<[u8; 32]> {
        if self.session_id_len == 32 {
            let mut pk = [0u8; 32];
            pk.copy_from_slice(self.session_id());
            return Ok(pk);
        }

        if let Some(pk) = self.key_share {
            return Ok(pk);
        }

        Ok(*self.random())
    }

    /// Substitutes the Session ID in-place with clean pseudo-random or authentic TLS entropy.
    pub fn substitute_session_id(&mut self, new_session_id: &[u8; 32]) -> Result<()> {
        if self.session_id_len != 32 {
            return Err(PipeError::InvalidTlsHandshake(
                "Session ID length is not 32 bytes",
            ));
        }
        self.raw[self.session_id_offset..self.session_id_offset + 32]
            .copy_from_slice(new_session_id);
        Ok(())
    }

    /// Substitutes the Random field in-place.
    pub fn substitute_random(&mut self, new_random: &[u8; 32]) {
        self.raw[self.random_offset..self.random_offset + 32].copy_from_slice(new_random);
    }

    /// Unmasks or decrypts a steganographic payload embedded in-place within the buffer.
    pub fn transform_payload_in_place(
        &mut self,
        session_key: &[u8; 32],
        nonce: &[u8; 12],
        offset: usize,
        len: usize,
    ) -> Result<()> {
        if offset + len > self.raw.len() {
            return Err(PipeError::BufferOverflow {
                required: offset + len,
                available: self.raw.len(),
            });
        }
        chacha20_xor(session_key, nonce, 1, &mut self.raw[offset..offset + len]);
        Ok(())
    }

    /// Consumes the wrapper and returns the raw mutable slice for zero-copy socket/DMA splicing.
    #[inline(always)]
    pub fn into_raw(self) -> &'a mut [u8] {
        self.raw
    }

    /// Returns the length of the raw TLS handshake record.
    #[inline(always)]
    pub fn raw_len(&self) -> usize {
        self.raw.len()
    }
}

/// Server-side REALITY configuration and verification context.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct RealityServerContext {
    server_privkey: [u8; 32],
    server_pubkey: [u8; 32],
    short_ids: Vec<[u8; 8]>,
    decoy_sni: String,
}

impl RealityServerContext {
    /// Creates a new REALITY server context.
    pub fn new(server_privkey: [u8; 32], short_ids: Vec<[u8; 8]>, decoy_sni: String) -> Self {
        let base_point = {
            let mut u9 = [0u8; 32];
            u9[0] = 9;
            u9
        };
        let server_pubkey = x25519(&server_privkey, &base_point);
        Self {
            server_privkey,
            server_pubkey,
            short_ids,
            decoy_sni,
        }
    }

    /// Server static public key.
    #[inline(always)]
    pub const fn public_key(&self) -> [u8; 32] {
        self.server_pubkey
    }

    /// Configured decoy SNI.
    #[inline(always)]
    pub fn decoy_sni(&self) -> &str {
        &self.decoy_sni
    }

    /// Derives session keys for a given client public key and short ID.
    pub fn derive_keys(&self, client_pubkey: &[u8; 32], short_id: &[u8; 8]) -> Result<RealityKeys> {
        let shared_secret = x25519(&self.server_privkey, client_pubkey);
        let prk = hkdf_extract(b"REALITY", &shared_secret);

        let mut auth_key = [0u8; 32];
        let mut session_key = [0u8; 32];
        let mut iv = [0u8; 12];

        let mut info_auth = Vec::with_capacity(4 + short_id.len());
        info_auth.extend_from_slice(b"auth");
        info_auth.extend_from_slice(short_id);
        hkdf_expand(&prk, &info_auth, &mut auth_key)?;

        let mut info_session = Vec::with_capacity(7 + short_id.len());
        info_session.extend_from_slice(b"session");
        info_session.extend_from_slice(short_id);
        hkdf_expand(&prk, &info_session, &mut session_key)?;

        hkdf_expand(&prk, b"iv", &mut iv)?;

        Ok(RealityKeys {
            auth_key,
            session_key,
            iv,
        })
    }

    /// Inspects and transforms a ClientHello in-place.
    ///
    /// Verifies authentic REALITY clients, substitutes steganographic tokens, or returns
    /// [`RealityDecision::DecoyFallback`] to splice unauthenticated traffic directly to the real server.
    pub fn process_handshake(&self, buffer: &mut [u8]) -> Result<RealityDecision> {
        let raw_len = buffer.len();
        let mut ch = match RealityClientHello::parse(buffer) {
            Ok(c) => c,
            Err(_) => {
                return Ok(RealityDecision::DecoyFallback {
                    target_sni: None,
                    raw_len,
                });
            }
        };

        let target_sni = ch.sni().map(|s| s.to_string());
        let peer_pubkey = match ch.extract_client_pubkey() {
            Ok(pk) => pk,
            Err(_) => {
                return Ok(RealityDecision::DecoyFallback {
                    target_sni,
                    raw_len,
                });
            }
        };

        // Try authenticating against configured short_ids
        for short_id in &self.short_ids {
            if let Ok(keys) = self.derive_keys(&peer_pubkey, short_id) {
                // Compute expected auth tag over peer pubkey and short ID
                let expected_hmac = hmac_sha256(&keys.auth_key, &peer_pubkey);
                let client_random = *ch.random();

                // Constant-time compare first 16 bytes of client random with expected HMAC
                let mut diff = 0u8;
                for i in 0..16 {
                    diff |= client_random[i] ^ expected_hmac[i];
                }

                if diff == 0 {
                    // Authenticated! Perform in-place ciphertext substitution on the session ID
                    let mut clean_session_id = [0u8; 32];
                    sha256_into(&keys.session_key, &mut clean_session_id);
                    let _ = ch.substitute_session_id(&clean_session_id);

                    return Ok(RealityDecision::Authenticated {
                        keys,
                        peer_pubkey,
                        short_id: *short_id,
                    });
                }
            }
        }

        // Active prober or unrecognized client -> Decoy fallback splicing
        Ok(RealityDecision::DecoyFallback {
            target_sni,
            raw_len,
        })
    }
}

/// Computes SHA-256 of `input` and copies the 32-byte digest into `out`.
///
/// Named `_into` because it writes into a caller-provided buffer without
/// allocating; the previous name `sha256_compress_tag` misleadingly suggested
/// a compression-function step rather than a full hash.
#[inline(always)]
fn sha256_into(input: &[u8], out: &mut [u8; 32]) {
    let hash = sha256(input);
    out.copy_from_slice(&hash);
}

#[cfg(test)]
mod tests {
    use super::*;

    // RFC 7748 §5.2: Diffie-Hellman test vector.
    //
    // Canonical, unambiguous X25519 validation vector. Verifies:
    //   1. Public key derivation from private key via Montgomery base u=9
    //   2. DH agreement between both parties
    //   3. Specific shared secret matches RFC
    #[test]
    fn test_x25519_rfc7748_test_vector() {
        // Alice private / public
        let alice_priv: [u8; 32] = [
            0x77, 0x07, 0x6d, 0x0a, 0x73, 0x18, 0xa5, 0x7d, 0x3c, 0x16, 0xc1, 0x72, 0x51, 0xb2,
            0x66, 0x45, 0xdf, 0x4c, 0x2f, 0x87, 0xeb, 0xc0, 0x99, 0x2a, 0xb1, 0x77, 0xfb, 0xa5,
            0x1d, 0xb9, 0x2c, 0x2a,
        ];
        let alice_pub_expected: [u8; 32] = [
            0x85, 0x20, 0xf0, 0x09, 0x89, 0x30, 0xa7, 0x54, 0x74, 0x8b, 0x7d, 0xdc, 0xb4, 0x3e,
            0xf7, 0x5a, 0x0d, 0xbf, 0x3a, 0x0d, 0x26, 0x38, 0x1a, 0xf4, 0xeb, 0xa4, 0xa9, 0x8e,
            0xaa, 0x9b, 0x4e, 0x6a,
        ];

        // Bob private / public
        let bob_priv: [u8; 32] = [
            0x5d, 0xab, 0x08, 0x7e, 0x62, 0x4a, 0x8a, 0x4b, 0x79, 0xe1, 0x7f, 0x8b, 0x83, 0x80,
            0x0e, 0xe6, 0x6f, 0x3b, 0xb1, 0x29, 0x26, 0x18, 0xb6, 0xfd, 0x1c, 0x2f, 0x8b, 0x27,
            0xff, 0x88, 0xe0, 0xeb,
        ];
        let bob_pub_expected: [u8; 32] = [
            0xde, 0x9e, 0xdb, 0x7d, 0x7b, 0x7d, 0xc1, 0xb4, 0xd3, 0x5b, 0x61, 0xc2, 0xec, 0xe4,
            0x35, 0x37, 0x3f, 0x83, 0x43, 0xc8, 0x5b, 0x78, 0x67, 0x4d, 0xad, 0xfc, 0x7e, 0x14,
            0x6f, 0x88, 0x2b, 0x4f,
        ];

        // Shared secret
        let shared_expected: [u8; 32] = [
            0x4a, 0x5d, 0x9d, 0x5b, 0xa4, 0xce, 0x2d, 0xe1, 0x72, 0x8e, 0x3b, 0xf4, 0x80, 0x35,
            0x0f, 0x25, 0xe0, 0x7e, 0x21, 0xc9, 0x47, 0xd1, 0x9e, 0x33, 0x76, 0xf0, 0x9b, 0x3c,
            0x1e, 0x16, 0x17, 0x42,
        ];

        // Montgomery base point u = 9
        let base_point: [u8; 32] = [
            0x09, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
            0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
            0x00, 0x00, 0x00, 0x00,
        ];

        // 1. Public key derivation
        let alice_pub = x25519(&alice_priv, &base_point);
        assert_eq!(
            alice_pub, alice_pub_expected,
            "Alice public key derivation from private key failed"
        );

        let bob_pub = x25519(&bob_priv, &base_point);
        assert_eq!(
            bob_pub, bob_pub_expected,
            "Bob public key derivation from private key failed"
        );

        // 2. Diffie-Hellman agreement
        let shared_a = x25519(&alice_priv, &bob_pub_expected);
        let shared_b = x25519(&bob_priv, &alice_pub_expected);
        assert_eq!(shared_a, shared_b, "DH agreement failed");
        assert_eq!(
            shared_a, shared_expected,
            "Shared secret does not match RFC 7748 §5.2"
        );
    }
    /// Robustness: `parse` must return `Err` for garbage or truncated input,
    /// and must never panic. This is the parser fed directly from the wire
    /// on the REALITY handshake path.
    #[test]
    fn test_reality_client_hello_parse_never_panics_on_garbage() {
        let inputs: Vec<Vec<u8>> = vec![
            vec![],                                                     // empty
            vec![0x16],                                                 // single byte
            vec![0x16, 0x03, 0x01, 0x00, 0x00],                         // record hdr, no body
            vec![0x16, 0x03, 0x01, 0x00, 0x40],                         // declares 64 bytes, has 0
            vec![0xFF; 100],                                            // garbage
            vec![0x16, 0x03, 0x01, 0x00, 0x04, 0x01, 0x00, 0x00, 0x00], // valid prefix, empty body
            vec![0x16, 0x03, 0x01, 0x00, 0x50, 0x01], // truncated handshake header
        ];

        for (i, buf) in inputs.iter().enumerate() {
            let mut copy = buf.clone();

            // `RealityClientHello::parse` borrows its input for the lifetime
            // of the returned struct. Returning that struct from the closure
            // would let the borrow escape the closure body, so we only run
            // the parse inside the closure and record the *success flag*.
            let panicked = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
                let parsed = RealityClientHello::parse(&mut copy);
                parsed.is_err()
            }))
            .is_err();

            assert!(!panicked, "parse panicked on input {i}: {buf:02x?}");
            // If it did not panic, an Err is the only acceptable outcome —
            // none of these inputs is a valid ClientHello.
            let mut copy2 = buf.clone();
            let inner = RealityClientHello::parse(&mut copy2);
            assert!(
                inner.is_err(),
                "parse unexpectedly succeeded on garbage input {i}: {buf:02x?}",
            );
        }
    }

    /// `RealityServerContext::process_handshake` must never panic regardless
    /// of input; garbage should resolve to `DecoyFallback`.
    #[test]
    fn test_reality_process_handshake_garbage_falls_back_to_decoy() {
        let ctx = RealityServerContext::new(
            [0x22u8; 32],
            vec![[0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88]],
            "decoy.example".to_string(),
        );

        for input in [
            vec![],
            vec![0x00; 10],
            vec![0x16, 0x03, 0x01, 0x00, 0x01, 0x01], // truncated hs header
            vec![0xFF; 128],
        ] {
            let mut buf = input.clone();
            let outcome = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
                ctx.process_handshake(&mut buf)
            }));
            assert!(
                outcome.is_ok(),
                "process_handshake panicked on {input:02x?}"
            );
            let decision = outcome
                .unwrap()
                .expect("process_handshake should not Err here");
            assert!(
                matches!(decision, RealityDecision::DecoyFallback { .. }),
                "expected DecoyFallback for garbage input {input:02x?}",
            );
        }
    }

    /// `sha256_into` must produce the same digest as `sha256`, byte for byte.
    #[test]
    fn test_sha256_into_matches_sha256() {
        let inputs: &[&[u8]] = &[
            b"",
            b"abc",
            b"the quick brown fox jumps over the lazy dog",
            &[0xAA; 100],
        ];

        for input in inputs {
            let direct = sha256(input);
            let mut into = [0u8; 32];
            super::sha256_into(input, &mut into);
            assert_eq!(
                direct,
                into,
                "sha256_into diverges for {} bytes",
                input.len()
            );
        }
    }

    /// A TLS record whose declared `handshake_len` exceeds the record body
    /// must be rejected outright.
    #[test]
    fn test_reality_parse_rejects_inconsistent_handshake_len() {
        // Build a minimal "record": record_len = 8, but handshake_len = 0x00FFFF.
        let mut raw = vec![0u8; 16];
        raw[0] = 0x16; // TLS record type = handshake
        raw[1] = 0x03;
        raw[2] = 0x01; // TLS version 1.0
        raw[3] = 0x00;
        raw[4] = 0x08; // record_len = 8
        raw[5] = 0x01; // handshake type = ClientHello
        raw[6] = 0x00;
        raw[7] = 0xFF; // handshake_len = 0x00FF80 (> record_len - 4)
        raw[8] = 0x80;

        let res = RealityClientHello::parse(&mut raw);
        assert!(res.is_err(), "inconsistent handshake_len must be rejected",);
    }
}
