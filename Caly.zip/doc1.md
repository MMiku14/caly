# Caly 架构设计规范

**文档版本**: 2.0（修正版）  
**日期**: 2026-09-20  
**状态**: 设计冻结  
**文档编号**: AC-ARCH-001


## 第一章 设计目标与原则

### 1.1 项目定位

AetherCore 是面向下一代高性能网络代理场景的通用内核。其设计目标是在资源受限设备上提供防检测、低延迟、内存可控的代理能力，且加新协议不痛苦、升级不破坏配置。

### 1.2 量化指标

| 指标类别 | 目标值 | 测量条件 |
|---|---|---|
| 空载 RSS | < 15MB | Linux x86_64，stripped release |
| 二进制体积 | < 8MB | stripped aarch64 |
| P99.9 延迟 | 微秒级确定性 | 无 GC 停顿，无锁竞争 |
| 规则集就绪 | < 5ms | 50 万条规则，mmap 加载 |
| 每连接内存 | < 50KB | 稳态 1000 并发连接 |
| 协议扩展周期 | 1-2 天 | 从规范到可用实现 |

### 1.3 核心设计原则

**原则一：主路径永远用成熟技术。** Tokio、内核 TCP、rustls、bytes——生产验证的组件构成默认路径。加速技术通过 feature flag 隔离，可随时禁用。

**原则二：每个加速技术必须有回退路径。** io_uring 失败回退 epoll，Monoio 不可用回退 Tokio，mlock 失败降级 prefault。没有回退路径的优化是在赌博。

**原则三：协议核心与 I/O 彻底解耦。** 协议状态机是纯同步的，不感知 Socket，不依赖 async 运行时。I/O 由外层 Worker Loop 驱动。

**原则四：编译期确定，运行期检测。** 运行时选择、协议裁剪、内存大小在编译期确定；内核能力探测在启动时执行一次，结果缓存。

**原则五：控制面与数据面严格分离。** 配置解析、DNS 递归、指标导出在独立辅助线程中执行，不阻塞数据转发。

**原则六：量化验证，不凭直觉。** 每一步优化都用基准测试记录前后数据。无可测量提升则回退。


## 第二章 架构矛盾与修正决策

原设计文档（v1.0）存在 8 处顶层拓扑与底层物理机理之间的深层矛盾。本章逐条记录矛盾本质与修正决策。

### 2.1 I/O 运行时模型撕裂

**矛盾**：Tokio 的 Readiness 模型（`poll_read(&mut [u8])`，缓冲区所有权留在用户）与 Monoio 的 Completion 模型（`read(buf) -> (res, buf)`，所有权移交给内核）在缓冲区语义上根本不同。用 `Box<dyn AsyncStream>` 统一两者，必然引入内部中转缓冲区，io_uring 零拷贝优势被完全抵消。

**修正决策**：同一二进制内只链接一个运行时。主路径采用 Tokio `current_thread` 独立实例模式——每个物理核心上各启动一个单线程 Tokio 运行时，线程间 Share-Nothing。Linux 加速路径通过编译期 feature 隔离为 Monoio 单线程 Proactor，不与 Tokio 同时链接。

### 2.2 协议抽象名不副实

**矛盾**：原文档声称 Sans-IO，但 `ProxyAdapter::dial()` 返回 `Box<dyn AsyncStream>`，仍是流包装式 I/O 架构。真正的 Sans-IO 根本不应感知底层 Socket。

**修正决策**：协议层必须是纯同步、确定性的状态机。`ProtocolStateMachine` trait 只暴露 `on_network_input` / `poll_network_output` / `on_app_input` / `poll_app_output` / `handle_tick` 五个方法，完全不涉及 I/O。

### 2.3 零开销承诺失效

**矛盾**：声称编译期泛型单态化，代码却全是 `Box<dyn>`。动态分发破坏 CPU 分支预测，阻止 LLVM 跨层内联与逃逸分析。

**修正决策**：热路径用 `enum_dispatch` 替代 `Box<dyn>`。LLVM 将 `ConcreteStream` 的方法分发编译为 `match` 标量跳转，分支预测成功率接近 100%。冷路径保留 `Box<dyn>`。

### 2.4 体积与依赖不可调和

**矛盾**：BoringSSL 静态链接后达 3.5-5.5MB，OpenTelemetry 官方 SDK 膨胀 4-8MB，两者叠加突破 15-25MB，无法在 16MB Flash 嵌入式网关上烧录。

**修正决策**：默认 TLS 采用 rustls + aws-lc-rs（约 1.2MB）；生产构建禁用完整 OTel SDK，改用轻量 Prometheus Text 导出器；运行时编译期二选一；rkyv 禁用重型错误反思。最终产物控制在 5.2-6.5MB。

### 2.5 网络栈双轨混乱

**矛盾**：拓扑图写 Smoltcp 状态机，正文又强调使用内核 TCP 为主。Smoltcp 缺失 SACK 与 BBR，在高延迟丢包网络下吞吐量相比内核 TCP 暴跌 60% 以上。

**修正决策**：主路径完全依赖 Linux 内核 TCP。TUN/TProxy 场景通过内核 TProxy 或 NAT 重定向接入，不需要 smoltcp。QUIC 场景使用 quinn（QUIC 本身就是用户态协议）。smoltcp 仅作为 `no_std` 嵌入式实验性 feature，不纳入主路径。

### 2.6 splice(2) 落地边界

**矛盾**：Linux 的 splice(2) 不支持从 socket 直接拼接到 socket，必须走 Socket → Pipe → Socket。一旦涉及加解密或 Header 填充，就无法使用 splice(2)。

**修正决策**：细化为严格三级条件——仅 Direct 出站 + 无嗅探 + 无统计 + Linux 时启用 splice。其他场景走用户态 Slab 零拷贝中继。

### 2.7 底层优化副作用

**矛盾**：mlock 需要 CAP_IPC_LOCK 特权，容器中返回 EPERM 导致崩溃；AVX-512 在 Intel Xeon 上触发降频，其他标量任务性能下降 10-20%；SoA 转置开销大于 SIMD 收益。

**修正决策**：mlock 失败降级 prefault 写入；优先使用 AVX2/NEON，AVX-512 作为可选 feature；热路径保持 AoS，仅在批处理内部临时转置为 SoA。

### 2.8 rkyv mmap 安全隐患

**矛盾**：mmap 映射外部规则文件，文件截断时 CPU 访问缺页触发 SIGBUS，服务瞬间 Crash。rkyv 布局与编译器版本强绑定，字段微调即 UB。

**修正决策**：启动时 madvise(MADV_WILLNEED) 预触发物理页载入；对外部可写存储上的文件加 flock(LOCK_SH) 共享锁；文件头嵌入 rkyv 版本号 + 编译器版本 + 布局哈希；热更新采用双缓冲原子切换。


## 第三章 系统分层拓扑

```
╔══════════════════════════════════════════════════════════════════════════════╗
║                     Caly 系统分层架构                                   ║
╠══════════════════════════════════════════════════════════════════════════════╣
║                                                                              ║
║  第六层 ┌──────────────────────────────────────────────────────────────┐    ║
║         │              控制面 (Control Plane)                            │    ║
║         │    独立低优先级辅助线程 · 轻量 Prometheus 导出                 │    ║
║         │  ┌─────────┐ ┌─────────┐ ┌─────────┐ ┌─────────┐            │    ║
║         │  │配置解析  │ │REST API │ │指标采集  │ │DNS 递归  │            │    ║
║         │  │JSON/YAML│ │Clash兼容│ │Prometheus│ │DoH/DoT  │            │    ║
║         │  └────┬────┘ └────┬────┘ └────┬────┘ └────┬────┘            │    ║
║         │       └───────────┴───────────┴───────────┘                  │    ║
║         │                    ArcSwap<Epoch> 原子切换                    │    ║
║         └──────────────────────────────────────────────────────────────┘    ║
║                                      │                                       ║
║  第五层 ┌──────────────────────────────┼──────────────────────────────┐    ║
║         │              数据面 (Data Plane)                             │    ║
║         │      Thread-per-Core · Tokio current_thread 独立实例          │    ║
║         │                                                              │    ║
║         │  ┌────────────────────────────────────────────────────────┐ │    ║
║         │  │         Sans-IO 协议核心（纯同步状态机）                 │ │    ║
║         │  │  SOCKS5 / VLESS / SS2022 / Trojan / AnyTLS             │ │    ║
║         │  │  无 I/O · 无 async · 可穷举测试 · handle_tick 参数化    │ │    ║
║         │  └────────────────────────────────────────────────────────┘ │    ║
║         │                          │                                   │    ║
║         │  ┌──────────────────────┼──────────────────────────────┐   │    ║
║         │  │            Worker Loop（I/O 调度器）                  │   │    ║
║         │  │  Core 0/Core 1/Core 2 · 独立 LocalSet · 独立 Slab    │   │    ║
║         │  │  I/O 驱动编译期单选：tokio-epoll 或 monoio-uring     │   │    ║
║         │  └──────────────────────────────────────────────────────┘   │    ║
║         │                          │                                   │    ║
║         │  ┌──────────────────────┼──────────────────────────────┐   │    ║
║         │  │            L4 直通分流引擎                            │   │    ║
║         │  │  Direct + 无嗅探 + Linux → splice(2)                │   │    ║
║         │  │  其他 → 用户态 Slab 零拷贝中继                       │   │    ║
║         │  └──────────────────────────────────────────────────────┘   │    ║
║         └──────────────────────────────────────────────────────────────┘    ║
║                                      │                                       ║
║  第四层 ┌──────────────────────────────┼──────────────────────────────┐    ║
║         │              决策层 (Decision Plane)                          │    ║
║         │  ┌──────────────────┐            ┌──────────────────┐      │    ║
║         │  │  规则匹配引擎      │◄───────────►│  DNS 解析引擎     │      │    ║
║         │  │  域名: DAAC      │            │  UDP/DoH/DoT    │      │    ║
║         │  │  IP: Tree-Bitmap │            │  FakeIP 原子位图 │      │    ║
║         │  │  mmap + ArcSwap  │            │  双重过期回收    │      │    ║
║         │  └────────┬─────────┘            └────────┬─────────┘      │    ║
║         │           └──────────┬───────────────┬────┘                │    ║
║         │                      ▼               ▼                     │    ║
║         │              ┌───────────────────────────────┐             │    ║
║         │              │      Outbound 选择器           │             │    ║
║         │              └───────────────────────────────┘             │    ║
║         └──────────────────────────────────────────────────────────────┘    ║
║                                      │                                       ║
║  第三层 ┌──────────────────────────────┼──────────────────────────────┐    ║
║         │              协议与传输层 (Protocol & Transport)             │    ║
║         │  入站: SOCKS5 / HTTP / TProxy / TUN                         │    ║
║         │  出站: Direct / Block / SS2022 / VLESS / Trojan / Selector  │    ║
║         │  ┌────────────────────────────────────────────────────────┐ │    ║
║         │  │  可组合传输层（enum_dispatch 静态分发，零 vtable）       │ │    ║
║         │  │  ConcreteStream::Tcp / Tls / Ws / TlsWs / H2 / AnyTls │ │    ║
║         │  └────────────────────────────────────────────────────────┘ │    ║
║         └──────────────────────────────────────────────────────────────┘    ║
║                                      │                                       ║
║  第二层 ┌──────────────────────────────┼──────────────────────────────┐    ║
║         │              内存织物层 (Memory Fabric)                      │    ║
║         │  ByteSlab（2KB/16KB/64KB）· 编译期确定大小                    │    ║
║         │  mlock 优雅降级 · mimalloc 全局分配器 · 64B 对齐              │    ║
║         └──────────────────────────────────────────────────────────────┘    ║
║                                      │                                       ║
║  第一层 ┌──────────────────────────────┼──────────────────────────────┐    ║
║         │              硬件抽象层 (HAL)                                 │    ║
║         │  Linux: epoll/io_uring · macOS: kqueue · Windows: IOCP      │    ║
║         │  SIMD: AVX2/NEON 优先 · 运行时 CPU 特征检测分发              │    ║
║         └──────────────────────────────────────────────────────────────┘    ║
║                                                                              ║
╚══════════════════════════════════════════════════════════════════════════════╝
```


## 第四章 Cargo 工作空间结构

### 4.1 目录布局

```Caly/
├── Cargo.toml                          # workspace 根
├── README.md
├── ARCHITECTURE.md                     # 本文档
│
├── crates/
│   ├── ac-common/                      # 核心契约
│   │   ├── src/
│   │   │   ├── lib.rs
│   │   │   ├── protocol.rs             # ProtocolStateMachine trait
│   │   │   ├── transport.rs            # TransportStream enum
│   │   │   ├── metadata.rs             # SessionMetadata (272B)
│   │   │   ├── dns.rs                  # DnsResolver trait
│   │   │   ├── adapter.rs              # ProxyAdapter / InboundListener
│   │   │   └── error.rs
│   │   └── Cargo.toml
│   │
│   ├── ac-session/                     # 会话编排
│   │   ├── src/
│   │   │   ├── context.rs              # SessionContext
│   │   │   ├── guard.rs                # ConnectionGuard (RAII)
│   │   │   ├── pipeline.rs             # 元数据富化流水线
│   │   │   └── sniff.rs                # DPI 嗅探
│   │   └── Cargo.toml
│   │
│   ├── ac-rules/                       # 规则引擎
│   │   ├── src/
│   │   │   ├── engine.rs               # RuleEngine
│   │   │   ├── domain_trie.rs          # 双数组 AC 自动机
│   │   │   ├── ip_tree.rs              # Tree-Bitmap LPM
│   │   │   ├── logic.rs                # 逻辑组合
│   │   │   └── archive.rs              # rkyv + mmap + SHA256
│   │   └── build.rs                    # 离线规则编译
│   │
│   ├── ac-dns/                         # DNS 子系统
│   │   ├── src/
│   │   │   ├── resolver.rs
│   │   │   ├── cache.rs                # 分片 LRU + 乐观缓存
│   │   │   ├── fakeip.rs               # 原子位图 IP 池
│   │   │   ├── snooping.rs
│   │   │   └── upstream/
│   │   │       ├── udp.rs
│   │   │       ├── doh.rs
│   │   │       └── dot.rs
│   │   └── Cargo.toml
│   │
│   ├── ac-transport/                   # 可组合传输层
│   │   ├── src/
│   │   │   ├── stream.rs               # ConcreteStream enum_dispatch
│   │   │   ├── tls.rs
│   │   │   ├── ws.rs
│   │   │   ├── h2.rs
│   │   │   └── anytls.rs
│   │   └── Cargo.toml
│   │
│   ├── ac-inbound/                     # 入站协议
│   │   ├── src/
│   │   │   ├── socks5.rs
│   │   │   ├── http.rs
│   │   │   ├── tproxy.rs
│   │   │   └── tun.rs
│   │   └── Cargo.toml
│   │
│   ├── ac-outbound/                    # 出站协议
│   │   ├── src/
│   │   │   ├── direct.rs
│   │   │   ├── block.rs
│   │   │   ├── group.rs
│   │   │   ├── shadowsocks/
│   │   │   ├── vless/
│   │   │   ├── trojan/
│   │   │   └── hysteria2/
│   │   └── Cargo.toml
│   │
│   ├── ac-worker/                      # Worker Loop（I/O 调度器）
│   │   ├── src/
│   │   │   ├── loop.rs
│   │   │   ├── slab.rs                 # ByteSlab
│   │   │   ├── l4_splice.rs            # L4 直通
│   │   │   └── driver/
│   │   │       ├── tokio_driver.rs
│   │   │       └── monoio_driver.rs    # Linux feature
│   │   └── Cargo.toml
│   │
│   ├── ac-api/                         # 控制面
│   │   ├── src/
│   │   │   ├── routes.rs
│   │   │   ├── state.rs                # ArcSwap
│   │   │   ├── watcher.rs
│   │   │   └── metrics.rs              # 轻量 Prometheus
│   │   └── Cargo.toml
│   │
│   └── ac-app/                         # 二进制入口
│       ├── src/
│       │   ├── main.rs
│       │   └── bootstrap.rs
│       └── Cargo.toml
│
└── rules/                              # 规则集源文件
    ├── geosite.dat
    └── geoip.dat
```

### 4.2 依赖关系

```
                    ┌─────────────────┐
                    │    ac-app       │  ← 二进制入口
                    └────────┬────────┘
                             │
          ┌──────────────────┼──────────────────┐
          ▼                  ▼                  ▼
   ┌─────────────┐   ┌─────────────┐   ┌─────────────┐
   │  ac-api     │   │ ac-worker   │   │ ac-inbound  │
   └──────┬──────┘   └──────┬──────┘   └──────┬──────┘
          │                 │                  │
          │    ┌────────────┼──────────────────┘
          │    │            │
          ▼    ▼            ▼
   ┌─────────────────────────────────────────────────┐
   │         ac-rules + ac-dns + ac-session           │
   └──────────────────────┬──────────────────────────┘
                          │
          ┌───────────────┼───────────────┐
          ▼               ▼               ▼
   ┌─────────────┐ ┌─────────────┐ ┌─────────────┐
   │ac-transport │ │ac-outbound  │ │  ac-common  │
   └──────┬──────┘ └──────┬──────┘ └──────┬──────┘
          │               │               │
          └───────────────┴───────────────┘
                          │
                          ▼
                  ┌─────────────┐
                  │ ac-common   │  ← 核心契约
                  └─────────────┘
```

**依赖规则**：箭头方向 = 依赖方向，永远单向。`ac-common` 是唯一被所有 crate 依赖的底座。任何 crate 都不依赖 `ac-app` 和 `ac-api`。


## 第五章 核心 trait 契约

### 5.1 ProtocolStateMachine —— Sans-IO 协议核心

```rust
/// 纯 Sans-IO 协议状态机，零 I/O、零 async，可 100% 单元测试
pub trait ProtocolStateMachine {
    type Action;
    type Error;

    /// 接收外部流入的原始网络字节
    fn on_network_input(&mut self, data: &[u8]) -> Result<(), Self::Error>;

    /// 轮询协议待发送至网络的加密/封装数据（零拷贝切片借出）
    fn poll_network_output<'a>(&'a mut self, out_buf: &'a mut [u8]) -> Option<usize>;

    /// 接收应用层明文数据，准备加密封包
    fn on_app_input(&mut self, plaintext: &[u8]) -> Result<(), Self::Error>;

    /// 轮询解密后的明文应用层数据
    fn poll_app_output<'a>(&'a mut self, out_buf: &'a mut [u8]) -> Option<usize>;

    /// 推进时钟状态（用于超时检测，避免内部调用系统 Instant::now()）
    fn handle_tick(&mut self, now_ms: u64) -> Option<Self::Action>;
}
```

**关键约束**：
- 协议状态机**不感知底层 Socket**，只负责字节的输入输出
- 所有时间参数通过 `handle_tick(now_ms)` 传入，不在内部调用 `Instant::now()`
- I/O 调度器（Worker Loop）负责管理 TCP Socket、从 ByteSlab 获取 buffer、系统调用 read/write，然后将 buffer 喂入状态机
- 协议测试无需 mock 任何网络，直接断言 byte array 输入输出

### 5.2 TransportStream —— 静态分发传输层

```rust
use enum_dispatch::enum_dispatch;

#[enum_dispatch]
pub trait TransportStream: AsyncRead + AsyncWrite + Unpin + Send {}

/// 编译期已知的所有传输层分支组合，消除运行时 Box 堆分配
#[enum_dispatch(TransportStream)]
pub enum ConcreteStream {
    Tcp(tokio::net::TcpStream),
    Tls(tokio_rustls::client::TlsStream<tokio::net::TcpStream>),
    Ws(tokio_tungstenite::WebSocketStream<tokio::net::TcpStream>),
    TlsWs(tokio_tungstenite::WebSocketStream<
        tokio_rustls::client::TlsStream<tokio::net::TcpStream>
    >),
    H2(tokio::net::TcpStream),  // H2 包装待实现
    AnyTls(tokio::net::TcpStream),  // AnyTLS 包装待实现
}
```

**关键收益**：
- LLVM 将 `ConcreteStream` 的方法分发编译为简单的 `match` 标量跳转
- 分支预测成功率接近 100%
- 热循环中触发直接内联，消除 vtable 穿透

### 5.3 ProxyAdapter —— 出站协议统一接口

```rust
pub trait ProxyAdapter: Send + Sync {
    fn name(&self) -> &str;

    /// 建立出站连接。返回的流是 ConcreteStream，编译期确定类型
    fn dial(
        &self,
        metadata: &SessionMetadata,
    ) -> Result<ConcreteStream, ProxyError>;

    fn supports_udp(&self) -> bool { false }
}
```

**修正说明**：原 `async fn dial() -> Box<dyn AsyncStream>` 改为同步返回 `ConcreteStream`。I/O 的实际驱动由 Worker Loop 完成，`dial` 只负责构造传输层组合。

### 5.4 SessionMetadata —— 紧凑数据结构

```rust
/// 大小: 272 字节（meow-rs 验证）
pub struct SessionMetadata {
    pub src_addr: SocketAddr,           // 28 bytes
    pub dst_addr: SocketAddr,           // 28 bytes
    pub domain: SmolStr,                // 24 bytes (≤23B 栈内联)
    pub inbound: InboundTag,            // 8 bytes
    pub network: Network,               // 1 byte
    pub protocol: SniffedProto,         // 1 byte
    pub process: Option<SmolStr>,       // 24 bytes
    // ... 其余字段总计 272 字节
}
```

### 5.5 DnsResolver —— DNS 统一接口

```rust
pub trait DnsResolver: Send + Sync {
    /// 解析域名
    fn resolve(&self, domain: &str) -> Result<ResolveResult, DnsError>;

    /// FakeIP 反向查询
    fn lookup_fakeip(&self, ip: IpAddr) -> Option<SmolStr>;

    /// DNS Snooping 查询
    fn snoop(&self, ip: IpAddr, port: u16) -> Option<SmolStr>;
}

pub enum ResolveResult {
    RealIp(Vec<IpAddr>),
    FakeIp(IpAddr),
    NoSuchDomain,
}
```


## 第六章 端到端数据流

```
 客户端 / 内核 TUN
    │
    ▼
┌───────────────────────────────────────────────────────────────────────────────┐
│ 阶段 1: INGRESS                                                               │
│                                                                               │
│  ┌─────────────────────────────────────────────────────────────────────────┐ │
│  │  io_uring RECV_MULTISHOT → PBUF_RING 自动拾取缓冲区                      │ │
│  │  XDP/eBPF 预检 → 直连白名单 XDP_PASS 放行                                │ │
│  │  TUN 环形队列 → 报文直投 Slab                                            │ │
│  │  → PacketRef（不可变，物理报文引用）                                      │ │
│  └─────────────────────────────────────────────────────────────────────────┘ │
└───────────────────────────────────┬───────────────────────────────────────────┘
                                    │
                                    ▼
┌───────────────────────────────────────────────────────────────────────────────┐
│ 阶段 2: L3/L4 DE-ENCAPSULATION                                               │
│                                                                               │
│  内核 TCP 路径（主路径）:                                                      │
│    TProxy/NAT 重定向 → 内核 Netfilter → accept() → TcpStream                 │
│                                                                               │
│  协议握手状态机驱动:                                                           │
│    从 Slab 借出 SmallSlab(2KB) → 喂入 ProtocolStateMachine                    │
│    → 握手完成 → 实例化 SessionContext                                        │
│    → 记录五元组 + 线程本地上下文                                              │
└───────────────────────────────────┬───────────────────────────────────────────┘
                                    │
                                    ▼
┌───────────────────────────────────────────────────────────────────────────────┐
│ 阶段 3: SNIFFING & METADATA ENRICHMENT                                       │
│                                                                               │
│  ┌─────────────────────────────────────────────────────────────────────────┐ │
│  │  DPI 嗅探流水线（零拷贝切片扫描）                                         │ │
│  │                                                                         │ │
│  │  TLS ClientHello → SNI/ALPN（TCP 重组环形滑窗抗分片绕过）                │ │
│  │  QUIC Initial → VarInt/Crypto 帧（报文完整性校验）                       │ │
│  │  HTTP 1.1/2.0 → SIMD(AVX2/NEON) 并行扫描 :authority                     │ │
│  │                                                                         │ │
│  │  Fake-IP 反向映射: 198.18.0.0/15 → 原子哈希索引 → 恢复域名              │ │
│  │  DNS Snooping: 查询 DNS 缓存 → 恢复透明流量域名                          │ │
│  └─────────────────────────────────────────────────────────────────────────┘ │
└───────────────────────────────────┬───────────────────────────────────────────┘
                                    │
                                    ▼
┌───────────────────────────────────────────────────────────────────────────────┐
│ 阶段 4: ROUTING ARBITER                                                      │
│                                                                               │
│  ArcSwap 无锁读取（配置热重载不阻塞）                                          │
│                                                                               │
│  域名 → DAAC 自动机 → O(L) 匹配（与规则库规模解耦）                            │
│  IP   → Tree-Bitmap LPM → O(W/k) 匹配（IPv4 最多 4 次内存跳跃）               │
│  逻辑 → 扁平化决策图 → 单次函数调用                                           │
│                                                                               │
│  输出: OutboundHandle { adapter: Arc<dyn ProxyAdapter> }                     │
└───────────────────────────────────┬───────────────────────────────────────────┘
                                    │
                                    ▼
┌───────────────────────────────────────────────────────────────────────────────┐
│ 阶段 4.5: L4 直通检测                                                        │
│                                                                               │
│  ┌─────────────────────────────────────────────────────────────────────────┐ │
│  │  严格条件判断:                                                           │ │
│  │                                                                         │ │
│  │  ┌─────────────────────────────────┐                                    │ │
│  │  │ 1. 出站为 DIRECT（无 Framing）  │                                    │ │
│  │  │ 2. 无流量统计 / 无嗅探要求      │                                    │ │
│  │  │ 3. 运行在 Linux 平台            │                                    │ │
│  │  └───────────────┬─────────────────┘                                    │ │
│  │                  │                                                      │ │
│  │     ┌────────────┴────────────┐                                         │ │
│  │    YES                        NO                                        │ │
│  │     │                         │                                         │ │
│  │     ▼                         ▼                                         │ │
│  │  [Kernel Pipe Splice]   [用户态 Slab 零拷贝中继]                        │ │
│  │  • 内核分配固定环形 Pipe  • 从 Slab 借出 16KB MediumSlab                │ │
│  │  • 双向两对 splice(2)   • 单线程内 poll_read / poll_write              │ │
│  │  • 零用户态内存拷贝      • 支持加解密、协议封包、流量统计               │ │
│  │  • F_SETPIPE_SZ 调优    • 吞吐 +20-30%（splice 路径）                   │ │
│  └─────────────────────────────────────────────────────────────────────────┘ │
└───────────────────────────────────┬───────────────────────────────────────────┘
                                    │
                                    ▼
┌───────────────────────────────────────────────────────────────────────────────┐
│ 阶段 5: OUTBOUND DIAL & RELAY                                                │
│                                                                               │
│  连接池检查 → 命中复用 / 新建连接                                             │
│                                                                               │
│  ┌─────────────────────────────────────────────────────────────────────────┐ │
│  │  传输层组合（enum_dispatch 静态分发）                                    │ │
│  │                                                                         │ │
│  │  ConcreteStream::Tcp → Tls → Ws → 协议编码                             │ │
│  │                                                                         │ │
│  │  LLVM 编译为 match 标量跳转，分支预测成功率接近 100%                     │ │
│  └─────────────────────────────────────────────────────────────────────────┘ │
│                                                                               │
│  ┌─────────────────────────────────────────────────────────────────────────┐ │
│  │  Sans-IO 协议状态机驱动                                                  │ │
│  │                                                                         │ │
│  │  on_app_input(plaintext) → poll_network_output(buf)                    │ │
│  │  on_network_input(data) → poll_app_output(buf)                         │ │
│  └─────────────────────────────────────────────────────────────────────────┘ │
│                                                                               │
│  ┌─────────────────────────────────────────────────────────────────────────┐ │
│  │  IoSlice 向量化组装                                                     │ │
│  │                                                                         │ │
│  │  [协议头 | 认证签名 | 客户端载荷] → writev / io_uring SEND_ZC          │ │
│  │  物理内存分离，无需 Concat 拼接                                         │ │
│  └─────────────────────────────────────────────────────────────────────────┘ │
│                                                                               │
│  双向旁路中继:                                                                 │
│    入站流 ◄──────── copy_bidirectional（零拷贝）────────► 出站流             │
│    协议层退出数据干预，直至连接终止                                            │
└───────────────────────────────────┬───────────────────────────────────────────┘
                                    │
                                    ▼
┌───────────────────────────────────────────────────────────────────────────────┐
│ 阶段 6: TEARDOWN                                                             │
│                                                                               │
│  • ConnectionGuard::drop() → 释放 Slab → 关闭套接字                          │
│  • 更新 Prometheus 指标                                                       │
│  • 旧 Epoch 资源在最后连接关闭后自动 Drop                                    │
└───────────────────────────────────────────────────────────────────────────────┘
```


## 第七章 关键子系统设计

### 7.1 内存织物层

#### 7.1.1 ByteSlab 编译期静态内存区

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    编译期静态内存区（mlock 优雅降级）                          │
│                                                                              │
│  ┌────────────────────────────────────────────────────────────────────────┐ │
│  │  SmallSlab (2KB × N)    元数据 / 控制信令 / SOCKS5 握手     对齐: 64B   │ │
│  ├────────────────────────────────────────────────────────────────────────┤ │
│  │  MediumSlab (16KB × N)  常规 TCP/TLS 记录                  对齐: 64B   │ │
│  ├────────────────────────────────────────────────────────────────────────┤ │
│  │  LargeSlab (64KB × N)   巨帧 / UDP 批量聚合                对齐: 64B   │ │
│  └────────────────────────────────────────────────────────────────────────┘ │
│                                                                              │
│  分配模型: 编译期确定大小 → 运行期仅 "借出/归还" → 零 malloc/free            │
│  线程本地: 每个 Worker 独立持有 → 无跨线程竞争 → 无线程同步开销              │
│  归还机制: 数据写出完成后 → 原地归池 → 无内存碎片                           │
│                                                                              │
│  安全降级：                                                                  │
│    if let Err(e) = nix::sys::mman::mlock(ptr, size) {                       │
│        tracing::warn!("mlock 失败（无 CAP_IPC_LOCK 权限？），降级: {}", e); │
│        unsafe { std::ptr::write_bytes(ptr, 0, size); }  // prefault 预热    │
│    }                                                                         │
└─────────────────────────────────────────────────────────────────────────────┘
```

#### 7.1.2 mimalloc 全局分配器

用于非热路径（配置对象、连接状态、缓冲区元数据等）：
- 三级页本地分片空闲链表
- 多线程对象迁移比 tcmalloc/jemalloc 快 2.5 倍以上
- OS 页未使用时立即归还
- 长运行服务碎片抑制

### 7.2 规则引擎

#### 7.2.1 离线编译与运行时加载

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    规则引擎数据布局                                           │
│                                                                              │
│  离线编译阶段（构建时）:                                                       │
│  ┌────────────────────────────────────────────────────────────────────────┐ │
│  │  GeoIP/GeoSite 源数据 → 规则编译器                                     │ │
│  │  • 域名 → 双数组 AC 自动机（DAAC）                                    │ │
│  │  • IP   → Tree-Bitmap LPM                                             │ │
│  │  • 逻辑 → 扁平化决策图                                                 │ │
│  │  • 输出 → rkyv 归档 + SHA256 哈希头 + 版本号                          │ │
│  └────────────────────────────────────────────────────────────────────────┘ │
│                                                                              │
│  运行时加载阶段:                                                              │
│  ┌────────────────────────────────────────────────────────────────────────┐ │
│  │  1. 校验 SHA256 哈希头                                                  │ │
│  │  2. flock(LOCK_SH) 共享锁防止外部截断                                   │ │
│  │  3. madvise(MADV_WILLNEED) 预触发物理页载入                             │ │
│  │  4. mmap(规则归档文件) → 只读虚拟地址空间                               │ │
│  │  5. rkyv 指针强转 → 结构体只读引用（零反序列化）                        │ │
│  │  6. 校验 rkyv 版本 + 编译器版本 + 布局哈希                              │ │
│  │                                                                        │ │
│  │  加载耗时: 微秒至毫秒级（vs JSON 秒级至数十秒级）                      │ │
│  │  RSS 占用: 文件大小 + 极小元数据开销（vs 全量堆分配）                  │ │
│  └────────────────────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────────────────────┘
```

#### 7.2.2 双缓冲原子切换

规则热更新不修改原文件，而是生成新文件后通过 ArcSwap 原子切换 mmap 指针。旧 mmap 在最后一个读者离开后安全释放。这避免了 mmap 文件被修改导致的 SIGBUS 崩溃。

### 7.3 DNS 子系统

#### 7.3.1 FakeIP 原子位图池

FakeIP 池采用原子位图管理的紧凑环形虚拟地址池（198.18.0.0/15），常数时间复杂度分配和回收，分配时延低于 50 纳秒。

#### 7.3.2 双重过期回收

FakeDNS 的已知痛点是可能污染本地 DNS 缓存，导致代理关闭后网络不可用。AetherCore 采用双重过期机制：
- 虚拟 IP 在分配时绑定连接超时时间
- 全局 TTL 到期后 IP 自动归还池中
- 即使应用层连接未正确关闭，全局 TTL 保证 IP 最终回收

#### 7.3.3 DNS Snooping

允许 TProxy 监听器通过查询最近的 DNS 查询缓存来恢复连接的目标域名，作为 Fake-IP 的补充路径。

### 7.4 防检测传输层

防检测作为可热替换的传输层中间件，独立于协议实现：

| 层级 | 技术 | 说明 | 默认状态 |
|---|---|---|---|
| TLS 指纹伪装 | uTLS / BoringSSL | Chrome/Firefox/Safari 指纹 | 可选 feature |
| REALITY | TLS 1.3 外观借用 | 借用目标站点握手特征 | 可选 |
| AnyTLS | TLS-in-TLS 缓解 | 代理流量伪装成标准 TLS | 可选 |
| 流量整形 | 随机填充 | 对抗包大小/时序分析 | 默认启用 |

**关键约束**：防检测逻辑独立于协议实现，可以在不重启内核的情况下替换指纹模拟方案。

### 7.5 配置热重载

```
时间线 ──────────────────────────────────────────────────────────────►

  控制面                          数据面
    │                               │
    │  用户提交新配置                  │
    │──────┐                        │
    │      │ 解析JSON                 │
    │      │ 验证规则                  │
    │      │ 构建新规则树              │
    │      │ 构建新DNS配置             │
    │      ▼                        │
    │  Epoch N+1 构建完成             │
    │      │                        │
    │      │ ArcSwap.store()        │
    │      │ 原子指针交换             │
    │      ├───────────────────────►│
    │      │                        │
    │      │              新连接 ──► 绑定 Epoch N+1
    │      │              旧连接 ──► 继续用 Epoch N
    │      │                        │
    │      │                        │  旧连接全部关闭
    │      │◄───────────────────────┤  Epoch N Drop
    │      │  旧配置内存释放           │
```

**核心保证**：
- 热重载期间零连接中断
- 旧配置在最后一个连接关闭后自动释放
- 如果新配置构建失败，旧配置继续生效
- 配置构建在辅助运行时中执行，不阻塞数据面


## 第八章 Cargo Feature 矩阵

```toml
[features]
default = ["runtime-tokio", "inbound-socks5", "outbound-direct"]

# 运行时：编译期二选一，绝不混用
runtime-tokio = ["dep:tokio"]
runtime-monoio = ["dep:monoio"]  # Linux only

# 入站协议
inbound-socks5 = []
inbound-http = []
inbound-tproxy = []
inbound-tun = []

# 出站协议
outbound-direct = []
outbound-block = []
outbound-shadowsocks = ["dep:aes-gcm", "dep:chacha20poly1305"]
outbound-vless = ["dep:x25519"]
outbound-trojan = []
outbound-hysteria2 = ["dep:quinn"]

# 传输层
transport-tls = ["dep:rustls", "dep:aws-lc-rs"]
transport-ws = ["dep:tokio-tungstenite"]
transport-h2 = ["dep:h2"]
transport-anytls = []
transport-boring = ["dep:boring"]  # 可选指纹伪装，默认关闭

# 可观测性
metrics-prometheus = []
otel-otlp = ["dep:opentelemetry", "dep:opentelemetry-otlp"]  # 默认关闭

# 安全
rules-verify = []  # rkyv 完整校验，默认关闭使用 fast-fail

# 调试
debug-slab = []
```

### 8.1 编译配置

```toml
[profile.release]
opt-level = 3
lto = "fat"
codegen-units = 1
panic = "abort"
strip = true

[profile.release.package."*"]
opt-level = 3
```

### 8.2 体积红线保障

| 臃肿模块 | 替代/优化策略 | 预估体积缩减 |
|---|---|---|
| BoringSSL | 默认 rustls + aws-lc-rs，指纹伪装仅可选 | -3.5 MB |
| OpenTelemetry SDK | 轻量 Prometheus Text 导出器 | -2.8 MB |
| Monoio 混合 | 编译期二选一，绝不同时链接 | -1.5 MB |
| rkyv 验证 | fast-fail 校验，禁用重型错误反思 | -0.8 MB |

**最终产物**：stripped aarch64 稳定在 **5.2-6.5MB** 之间，达成 < 8MB 硬性指标。


## 第九章 架构特性对比

| 评估维度 | mihomo / Clash | sing-box | AetherCore |
|---|---|---|---|
| **开发语言** | Go, M:N 协程 | Go, 高并发定制 | Rust, 无 GC 确定性生命周期 |
| **I/O 模型** | 单全局 epoll/kqueue | epoll Reactor + Goroutine | Thread-per-Core + 编译期单选运行时 |
| **协议抽象** | 流包装式 | 流包装式 | Sans-IO 纯状态机 |
| **传输层分发** | 接口动态分发 | 接口动态分发 | enum_dispatch 静态分发 |
| **用户态协议栈** | gVisor Netstack | gVisor Netstack | 内核 TCP 为主 + QUIC |
| **内核过滤** | iptables/nftables | TProxy + Wintun | eBPF (Linux) + 用户态双擎 |
| **规则结构** | 嵌套链表 + Map | SRS 二进制 | rkyv mmap + DAAC + Tree-Bitmap |
| **规则就绪** | 秒级解析 | 启动快但堆指针膨胀 | 毫秒级映射 + 零堆分配 |
| **RSS 基线** | 60-120MB+ | 25-60MB | 5-15MB |
| **二进制体积** | 20-50MB | 20-40MB | 5.2-6.5MB |
| **P99.9 延迟** | 毫秒级波动 (GC) | 毫秒级波动 (GC+协程) | 微秒级确定性 |
| **扩展机制** | 外部子进程 | 编译期 Build Tags | Proxy-Wasm 控制面沙箱 |


## 第十章 架构风险与缓解

| 风险 | 表现 | 缓解措施 |
|---|---|---|
| Smoltcp 功能缺失 | 不支持 SACK/窗口缩放 | 主路径用内核 TCP，QUIC 用 quinn，smoltcp 仅实验性 feature |
| Monoio 维护状态 | 提交频率低于 Tokio | 隔离在独立 driver crate，迁移成本可控 |
| rkyv 版本兼容 | 归档格式不保证兼容 | 文件头嵌入版本号 + 布局哈希，不匹配时拒绝加载 |
| io_uring 内核依赖 | 需要 Linux 5.19+ | FusionDriver 运行时自动降级 |
| splice 协议头限制 | 无法处理加密/Framing | 严格三级条件判定，仅 Direct 走 splice |
| mlock 特权墙 | 容器中返回 EPERM | 优雅降级为 prefault 写入 |
| AVX-512 降频 | Intel Xeon 上触发降频 | 优先 AVX2/NEON，AVX-512 作为可选 feature |
| SIGBUS 崩溃 | mmap 文件被截断 | SHA256 校验 + flock 共享锁 + madvise 预缺页 |
| Sans-IO 状态机爆炸 | 复杂时序逻辑难以维护 | 允许协议实现内部使用 async，仅编解码层强制 Sans-IO |


## 第十一章 实施路线图

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                       AetherCore 实施演进路线                                 │
│                                                                              │
│  [第一阶段 (第 1-6 周)]: 统一抽象底座与轻量流转                               │
│   • 锁定 Tokio current_thread + Thread-per-Core 拓扑                         │
│   • 落地 272B SessionMetadata + 基础 ByteSlab (2KB/16KB)                     │
│   • 实现 Sans-IO SOCKS5 状态机 + Direct 出站                                 │
│   • 验收: curl 跑通，内存 RSS < 8MB，体积 < 4MB                              │
│                                                                              │
│  [第二阶段 (第 7-12 周)]: 高性能路由与 DNS 确定性体系                        │
│   • 离线构建工具: DAAC + Tree-Bitmap → rkyv 打包                            │
│   • 运行时 mmap 规则加载 + madvise 预缺页 + SHA256/flock 防 SIGBUS           │
│   • Fake-IP 原子位图池 (198.18.0.0/15) + 双重过期淘汰机制                     │
│   • 验收: 50万条规则载入耗时 < 5ms，无堆指针膨胀                             │
│                                                                              │
│  [第三阶段 (第 13-20 周)]: 防检测协议与单态化传输层                          │
│   • Sans-IO 版 Shadowsocks 2022 与 VLESS 编解码器                            │
│   • 静态 enum_dispatch 组合管道 (Tcp → Tls → Ws)                            │
│   • 引入 rustls，剔除重型 OTel，实现轻量 Prometheus Exporter                 │
│   • 验收: 跨协议组合零 Box 堆分配，端到端延迟确定性                          │
│                                                                              │
│  [第四阶段 (第 21-28 周)]: 内核旁路与硬件加速 (可选 Feature 演进)            │
│   • L4 Direct splice(2) 快速管道（严格条件判定）                             │
│   • AVX2 / NEON 关键切片操作手写 intrinsics（安全降级保障）                  │
│   • (可选) Linux 下 io_uring 的 PBUF_RING 驱动模块集成 (通过 Feature 隔离)   │
│   • 验收: 基准测试对比，无显著提升则回退                                     │
└─────────────────────────────────────────────────────────────────────────────┘
```


## 第十二章 编程技术规范

### 12.1 核心规范

| 规范编号 | 类别 | 规则 | 理由 |
|---|---|---|---|
| **A1** | SIMD | 热路径显式使用 `std::arch` intrinsics，优先 AVX2/NEON | AVX-512 降频风险，LLVM 自动向量化不可靠 |
| **A2** | 并发 | 热路径使用 Acquire/Release，禁止 SeqCst | 减少不必要的内存屏障 |
| **A3** | 布局 | 热路径保持 AoS（与硬件一致），仅在批处理内部临时转置为 SoA | 转置开销 > SIMD 收益 |
| **A4** | 内存 | Slab 池启动时 prefault；mlock 失败时优雅降级 | 容器特权墙 |
| **A5** | 拓扑 | Worker 线程绑定物理核心 | 消除缓存行颠簸 |
| **B1** | 池化 | 出站连接池缓存协议握手完成的连接 | 数据库连接池验证 |
| **B2** | 批处理 | 包接收采用批处理模式 | X2DP 2.3x 验证 |
| **B3** | 拷贝 | 仅 Direct + 无嗅探 + Linux 时走 splice | splice 协议头剥离限制 |
| **B4** | 配置 | 双缓冲原子切换 + SHA256/flock 防 SIGBUS | rkyv mmap 安全隐患 |
| **C1** | 分配 | 热路径零堆分配（SmolStr/SmallVec/Bytes） | meow-rs 272B 验证 |
| **C2** | 锁 | 热路径禁止 Mutex/RwLock，使用 ArcSwap/crossbeam | 无锁 10x+ 验证 |
| **C3** | 状态机 | 协议核心 Sans-IO，`ProtocolStateMachine` trait | Firezone connlib 验证 |
| **C4** | 序列化 | 规则集 rkyv + mmap + SHA256 校验 + fast-fail | SIGBUS 防护 |
| **C5** | 编译 | LTO fat + codegen-units=1 + PGO | Envoy +10% 验证 |
| **C6** | 依赖 | 每个协议独立 Cargo feature，运行时编译期二选一 | 8MB 体积红线 |
| **C7** | 分发 | 热路径使用 `enum_dispatch`，冷路径保留 `Box<dyn>` | 消除 vtable 开销 |
| **C8** | 协议 | `ProtocolStateMachine` 不感知 Socket，I/O 由 Worker Loop 驱动 | 可穷举测试 |

### 12.2 Rust 编码约束

```rust
// ─── 规范 1: 热路径零堆分配 ───────────────────────────────
// ❌ 禁止
fn handle_request(domain: String) -> Result<...> { ... }
// ✅ 强制
fn handle_request(domain: SmolStr) -> Result<...> { ... }

// ─── 规范 2: 缓冲区所有权租借模型 ─────────────────────────
// ❌ 禁止
async fn relay(shared: Arc<Mutex<Vec<u8>>>) { ... }
// ✅ 强制
async fn relay(buf: BytesMut) -> (usize, BytesMut) {
    let (result, buf) = stream.read(buf).await;
    (result.unwrap_or(0), buf)
}

// ─── 规范 3: 编译期静态内存区 ──────────────────────────────
// ❌ 禁止
let slab = Slab::new_dynamic();
// ✅ 强制
const SLAB_SIZE: usize = 4096;
static SLAB: SlabPool<SLAB_SIZE, 64> = SlabPool::new();

// ─── 规范 4: SIMD 操作强制对齐 ────────────────────────────
// ❌ 禁止
let data: &[u8] = &buf[1..];
// ✅ 强制
#[repr(align(64))]
struct AlignedBuffer { data: [u8; 65536] }

// ─── 规范 5: 锁的正确使用 ──────────────────────────────────
// ❌ 禁止
static RULES: RwLock<RuleTable> = RwLock::new(...);
// ✅ 强制
static RULES: ArcSwap<RuleTable> = ArcSwap::new(...);

// ─── 规范 6: Sans-IO 协议实现 ─────────────────────────────
// ❌ 禁止
async fn handle_socks5(stream: TcpStream) { ... }
// ✅ 强制
struct Socks5StateMachine { state: State }
impl ProtocolStateMachine for Socks5StateMachine { ... }

// ─── 规范 7: 错误处理 ────────────────────────────────────
// ❌ 禁止
let addr = metadata.dst_addr.unwrap();
// ✅ 强制
match metadata.dst_addr {
    Some(addr) => addr,
    None => return Err(ProxyError::MissingDestination),
}
```

### 12.3 关键依赖规范

| 依赖类型 | 推荐 crate | 禁用/替代 |
|---|---|---|
| 异步运行时 | tokio (主) / monoio (Linux feature) | 不绑定单一运行时 |
| 缓冲区 | bytes / bytes-handoff | 禁止 Vec\<u8\> 热路径 |
| 分配器 | mimalloc | 禁止系统默认 |
| 无锁结构 | crossbeam / ArcSwap | 禁止自研无锁队列 |
| 短字符串 | smol_str | 禁止 String 热路径 |
| 规则序列化 | rkyv + mmap | JSON 仅作默认回退 |
| QUIC | quinn | — |
| TLS | rustls + aws-lc-rs (主) / boring (指纹伪装) | — |
| 可观测性 | 轻量 Prometheus (主) / OTel (可选) | 默认关闭 OTel |


## 第十三章 优化收益汇总（已验证数据）

| 层级 | 技术措施 | 验证来源 | 量化收益 |
|---|---|---|---|
| **SIMD** | AVX-512 DPDK ACL | Intel 官方 | ACL 流查找 3x / L3转发 1.35x |
| **I/O** | io_uring 零拷贝 TCP 1500B | Linux LKML net-next | 114 Gbps (1.85x) |
| **I/O** | io_uring 零拷贝 TCP 9000B | Linux LKML net-next | 187 Gbps (2.76x) |
| **I/O** | DPDK vs 内核栈 | KTH 论文 | 约 19x 吞吐 |
| **I/O** | L4 splice(2) | novaedge | +20-30% 吞吐 / -50% 内存带宽 |
| **并发** | Thread-per-Core | AISIX 基准 | +54-88% RPS / p99 减半 |
| **并发** | Thread-per-Core 尾延迟 | glommio 基准 | P9999 降低 ~92% |
| **eBPF** | AF_XDP 往返延迟 | Ulysses 论文 | 6.5 μs |
| **eBPF** | XDP VXLAN 加速 | Ulysses 论文 | P99 降低 28.8% |
| **内存** | mimalloc vs tcmalloc | 官方基准 | 13% 加速 / 多线程迁移 2.5x+ |
| **内存** | rkyv + mmap | rkyv 官方文档 | 零反序列化 |
| **防检测** | AnyTLS-RS | 项目基准 | 性能提升 40-60% |
| **编译** | PGO | Envoy 实测 | +10% |


## 附录 A：术语表

| 术语 | 全称 | 说明 |
|---|---|---|
| Sans-IO | Sans Input/Output | 协议实现与 I/O 完全解耦的设计模式 |
| DAAC | Double-Array Aho-Corasick | 双数组 AC 自动机，域名匹配 O(L) |
| LPM | Longest Prefix Match | 最长前缀匹配，IP 路由查找 |
| Thread-per-Core | — | 每物理核心一个线程，无共享架构 |
| Proactor | — | 完成通知模型（io_uring），与 Reactor（就绪通知）相对 |
| SIGBUS | — | 内存映射文件被截断时内核发送的信号 |
| W^X | Write XOR Execute | 内存页不可同时可写和可执行 |
| PGO | Profile-Guided Optimization | 基于运行时 profile 的编译优化 |

## 附录 B：参考项目

| 项目 | 借鉴内容 |
|---|---|
| meow-rs | 272B SessionMetadata、SmolStr 短字符串内联、ArcSwap 无锁路由 |
| Firezone connlib | Sans-IO 纯状态机、单一 UDP socket 多路复用 |
| tokio-quiche | Actor 模型封装连接状态、通道通信 |
| Glommio | Thread-per-Core 尾延迟控制 |
| Monoio | FusionDriver 运行时自动检测 |
| rkyv | 零拷贝反序列化、相对指针 |
| AnyTLS-RS | TLS-in-TLS 指纹缓解 |
| novaedge | splice(2) L4 直通量化数据 |
| MicroWARP | 内核态传输卸载、800KB RSS |

---

**文档结束**

本文档为 caly 架构设计规范第一份，涵盖设计目标、架构矛盾修正、系统分层、Cargo 结构、核心 trait、数据流、关键子系统、Feature 矩阵、对比分析、风险缓解、路线图与编程规范。第二份文档将深入实现细节与代码模式，第三份文档将覆盖部署、配置与运维。
