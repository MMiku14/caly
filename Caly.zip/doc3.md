# Caly 部署、配置与运维规范

**文档版本**: 2.0（修正版）  
**日期**: 2026-09-20  
**状态**: 设计冻结  
**文档编号**: AC-OPS-003  
**前置文档**: AC-ARCH-001（架构设计规范）、AC-IMPL-002（实现规范）


## 第一章 配置系统

### 1.1 配置格式选型

Caly 采用 **JSON 为主格式 + YAML 为可选前端**。核心解析器只识别 JSON，YAML 通过 `serde_yaml` 预转换为 JSON 后进入同一解析管道。

**选型理由**：
- JSON 解析器（`serde_json` / `simd-json`）成熟、快、无歧义
- YAML 作为人类可读前端，但禁止在内核中直接解析 YAML（避免引入庞大依赖）
- 配置校验与 JSON Schema 对齐，支持 IDE 补全和 CI 校验

### 1.2 配置结构总览

```json
{
  "version": "1.0",
  "log": { ... },
  "dns": { ... },
  "inbounds": [ ... ],
  "outbounds": [ ... ],
  "routes": [ ... ],
  "experimental": { ... }
}
```

### 1.3 完整配置 Schema

#### 1.3.1 顶层配置

```json
{
  "version": "1.0",
  "log": {
    "level": "info",
    "format": "json",
    "output": "/var/log/caly/caly.log",
    "timestamp": true
  },
  "dns": { ... },
  "inbounds": [ ... ],
  "outbounds": [ ... ],
  "routes": [ ... ],
  "experimental": { ... }
}
```

| 字段 | 类型 | 必填 | 默认值 | 说明 |
|---|---|---|---|---|
| `version` | string | 是 | — | 配置格式版本，用于兼容性检查 |
| `log` | object | 否 | 见 1.3.2 | 日志配置 |
| `dns` | object | 否 | 见 1.3.3 | DNS 配置 |
| `inbounds` | array | 是 | — | 入站监听配置 |
| `outbounds` | array | 是 | — | 出站协议配置 |
| `routes` | array | 否 | 见 1.3.5 | 路由规则 |
| `experimental` | object | 否 | 见 1.3.6 | 实验性功能 |

#### 1.3.2 日志配置

```json
{
  "log": {
    "level": "info",
    "format": "json",
    "output": "/var/log/caly/caly.log",
    "timestamp": true,
    "caller": false
  }
}
```

| 字段 | 类型 | 默认值 | 可选值 |
|---|---|---|---|
| `level` | string | `"info"` | `trace` / `debug` / `info` / `warn` / `error` |
| `format` | string | `"json"` | `json` / `text` |
| `output` | string | `"stdout"` | 文件路径 / `stdout` / `stderr` |
| `timestamp` | bool | `true` | — |
| `caller` | bool | `false` | 是否记录调用位置 |

#### 1.3.3 DNS 配置

```json
{
  "dns": {
    "servers": [
      {
        "tag": "local",
        "address": "223.5.5.5",
        "strategy": "prefer_ipv4",
        "detour": "direct"
      },
      {
        "tag": "remote",
        "address": "https://1.1.1.1/dns-query",
        "strategy": "prefer_ipv4",
        "detour": "proxy"
      }
    ],
    "rules": [
      {
        "domain_suffix": [".cn"],
        "server": "local"
      },
      {
        "domain_suffix": [".google.com", ".github.com"],
        "server": "remote"
      }
    ],
    "fakeip": {
      "enabled": true,
      "inet4_range": "198.18.0.0/15",
      "inet6_range": "fc00::/18",
      "global_ttl": 300
    },
    "cache": {
      "enabled": true,
      "capacity": 4096,
      "optimistic": true,
      "optimistic_ttl": 60
    },
    "final": "remote"
  }
}
```

| 字段 | 类型 | 默认值 | 说明 |
|---|---|---|---|
| `servers` | array | — | DNS 服务器列表 |
| `servers[].tag` | string | — | 服务器唯一标识 |
| `servers[].address` | string | — | `IP` / `udp://IP` / `tcp://IP` / `https://URL` / `tls://IP` |
| `servers[].strategy` | string | `"prefer_ipv4"` | `prefer_ipv4` / `prefer_ipv6` / `ipv4_only` / `ipv6_only` |
| `servers[].detour` | string | `"direct"` | 出站 tag |
| `rules` | array | `[]` | DNS 分流规则 |
| `fakeip` | object | — | FakeIP 配置 |
| `fakeip.global_ttl` | int | `300` | 全局 TTL（秒） |
| `cache.optimistic` | bool | `true` | 乐观缓存 |
| `cache.optimistic_ttl` | int | `60` | 乐观缓存 TTL（秒） |
| `final` | string | — | 默认 DNS 服务器 tag |

#### 1.3.4 入站配置

**SOCKS5 入站**：

```json
{
  "type": "socks5",
  "tag": "socks-in",
  "listen": "127.0.0.1",
  "port": 1080,
  "username": "",
  "password": "",
  "udp": true,
  "sniff": true,
  "sniff_timeout": "300ms"
}
```

**HTTP 入站**：

```json
{
  "type": "http",
  "tag": "http-in",
  "listen": "127.0.0.1",
  "port": 8080,
  "username": "",
  "password": "",
  "tls": {
    "certificate": "/etc/caly/cert.pem",
    "key": "/etc/caly/key.pem"
  }
}
```

**TProxy 入站**（Linux）：

```json
{
  "type": "tproxy",
  "tag": "tproxy-in",
  "listen": "0.0.0.0",
  "port": 7895,
  "network": "tcp,udp",
  "sniff": true,
  "sniff_timeout": "300ms"
}
```

**TUN 入站**：

```json
{
  "type": "tun",
  "tag": "tun-in",
  "interface_name": "caly0",
  "inet4_address": "172.19.0.1/30",
  "inet6_address": "fdfe:dcba:9876::1/126",
  "mtu": 9000,
  "auto_route": true,
  "strict_route": true,
  "stack": "system",
  "sniff": true,
  "sniff_timeout": "300ms"
}
```

| 字段 | 类型 | 默认值 | 说明 |
|---|---|---|---|
| `type` | string | — | `socks5` / `http` / `tproxy` / `tun` |
| `tag` | string | — | 入站唯一标识 |
| `listen` | string | `"0.0.0.0"` | 监听地址 |
| `port` | int | — | 监听端口 |
| `sniff` | bool | `true` | 是否启用协议嗅探 |
| `sniff_timeout` | string | `"300ms"` | 嗅探超时 |
| `stack` | string | `"system"` | `system` / `gvisor` / `mixed`（仅 TUN） |

#### 1.3.5 出站配置

**Direct 出站**：

```json
{
  "type": "direct",
  "tag": "direct"
}
```

**Block 出站**：

```json
{
  "type": "block",
  "tag": "block"
}
```

**Shadowsocks 出站**：

```json
{
  "type": "shadowsocks",
  "tag": "ss-out",
  "server": "example.com",
  "server_port": 8388,
  "method": "2022-blake3-aes-256-gcm",
  "password": "base64encodedkey",
  "udp": true,
  "multiplex": {
    "enabled": true,
    "protocol": "h2mux",
    "max_streams": 8
  }
}
```

**VLESS 出站**：

```json
{
  "type": "vless",
  "tag": "vless-out",
  "server": "example.com",
  "server_port": 443,
  "uuid": "00000000-0000-0000-0000-000000000000",
  "flow": "xtls-rprx-vision",
  "tls": {
    "enabled": true,
    "server_name": "www.example.com",
    "utls": {
      "enabled": true,
      "fingerprint": "chrome"
    },
    "reality": {
      "enabled": true,
      "public_key": "...",
      "short_id": "..."
    }
  },
  "transport": {
    "type": "ws",
    "path": "/ws",
    "headers": {
      "Host": "www.example.com"
    }
  }
}
```

**Trojan 出站**：

```json
{
  "type": "trojan",
  "tag": "trojan-out",
  "server": "example.com",
  "server_port": 443,
  "password": "password",
  "tls": {
    "enabled": true,
    "server_name": "www.example.com"
  }
}
```

**Selector 出站组**：

```json
{
  "type": "selector",
  "tag": "select",
  "outbounds": ["vless-out", "trojan-out", "direct"],
  "default": "vless-out",
  "interrupt_exist_connections": false
}
```

**URLTest 出站组**：

```json
{
  "type": "urltest",
  "tag": "auto",
  "outbounds": ["vless-out", "trojan-out"],
  "url": "https://www.gstatic.com/generate_204",
  "interval": "300s",
  "tolerance": 50
}
```

**Fallback 出站组**：

```json
{
  "type": "fallback",
  "tag": "fallback",
  "outbounds": ["vless-out", "trojan-out", "direct"],
  "interval": "300s"
}
```

#### 1.3.6 路由配置

```json
{
  "routes": [
    {
      "rules": [
        {
          "domain_suffix": [".cn"],
          "outbound": "direct"
        },
        {
          "domain_suffix": [".google.com"],
          "outbound": "proxy"
        },
        {
          "ip_cidr": ["10.0.0.0/8", "172.16.0.0/12"],
          "outbound": "direct"
        },
        {
          "process_name": ["curl", "wget"],
          "outbound": "proxy"
        },
        {
          "protocol": "bittorrent",
          "outbound": "block"
        }
      ],
      "final": "proxy",
      "default_domain_resolver": "local"
    }
  ]
}
```

**路由规则匹配类型**：

| 字段 | 类型 | 说明 |
|---|---|---|
| `domain` | array | 精确域名匹配 |
| `domain_suffix` | array | 域名后缀匹配 |
| `domain_keyword` | array | 域名关键词匹配 |
| `domain_regex` | array | 域名正则匹配 |
| `ip_cidr` | array | IP 段匹配 |
| `ip_is_private` | bool | 是否匹配私有 IP |
| `source_ip_cidr` | array | 源 IP 段匹配 |
| `source_port` | array | 源端口匹配 |
| `port` | array | 目标端口匹配 |
| `process_name` | array | 进程名匹配 |
| `process_path` | array | 进程路径匹配 |
| `package_name` | array | Android 包名匹配 |
| `user` | array | 用户匹配 |
| `protocol` | string | 协议嗅探结果匹配 |
| `network` | string | `tcp` / `udp` |
| `inbound` | array | 入站 tag 匹配 |
| `rule_set` | array | 规则集引用 |
| `invert` | bool | 反转匹配结果 |
| `outbound` | string | 匹配后的出站 tag |

#### 1.3.7 实验性配置

```json
{
  "experimental": {
    "cache_file": {
      "enabled": true,
      "path": "/var/lib/caly/cache.db",
      "store_fakeip": true
    },
    "clash_api": {
      "external_controller": "127.0.0.1:9090",
      "external_ui": "/etc/caly/ui",
      "secret": ""
    },
    "metrics": {
      "prometheus": {
        "enabled": true,
        "listen": "127.0.0.1:9091"
      }
    },
    "l4_splice": {
      "enabled": true,
      "min_payload_size": 4096
    },
    "simd": {
      "avx2": true,
      "avx512": false,
      "neon": true
    }
  }
}
```

### 1.4 配置校验

Caly 在加载配置时执行三级校验：

**第一级：JSON Schema 校验**
- 字段类型、必填项、取值范围
- 失败：拒绝启动，输出明确的字段路径

**第二级：语义校验**
- 出站 tag 是否唯一
- 路由引用的出站是否存在
- DNS 规则引用的服务器是否存在
- 端口是否冲突
- 证书文件是否存在且可读

**第三级：运行时校验**
- 监听端口是否可用
- TUN 设备是否可以创建
- 上游服务器是否可达（可选，异步）

### 1.5 配置热重载

```bash
# 方式 1：发送 SIGHUP
kill -HUP $(pidof caly)

# 方式 2：通过 REST API
curl -X POST http://127.0.0.1:9090/configs \
  -H "Content-Type: application/json" \
  -d @new-config.json

# 方式 3：文件监听（默认启用）
# 编辑配置文件后自动触发重载
```

**热重载保证**：
- 零连接中断
- 旧配置在最后一个连接关闭后自动释放
- 新配置校验失败时，旧配置继续生效
- 重载期间新连接使用新配置，旧连接使用旧配置

### 1.6 配置示例：完整家庭网关

```json
{
  "version": "1.0",
  "log": {
    "level": "info",
    "format": "json",
    "output": "stdout"
  },
  "dns": {
    "servers": [
      {
        "tag": "local",
        "address": "223.5.5.5",
        "detour": "direct"
      },
      {
        "tag": "remote",
        "address": "https://1.1.1.1/dns-query",
        "detour": "proxy"
      }
    ],
    "rules": [
      { "domain_suffix": [".cn"], "server": "local" },
      { "domain_suffix": [".google.com", ".github.com"], "server": "remote" }
    ],
    "fakeip": {
      "enabled": true,
      "inet4_range": "198.18.0.0/15"
    },
    "final": "remote"
  },
  "inbounds": [
    {
      "type": "tun",
      "tag": "tun-in",
      "interface_name": "caly0",
      "inet4_address": "172.19.0.1/30",
      "mtu": 9000,
      "auto_route": true,
      "strict_route": true,
      "sniff": true
    },
    {
      "type": "socks5",
      "tag": "socks-in",
      "listen": "127.0.0.1",
      "port": 1080,
      "udp": true
    }
  ],
  "outbounds": [
    { "type": "direct", "tag": "direct" },
    { "type": "block", "tag": "block" },
    {
      "type": "vless",
      "tag": "proxy",
      "server": "your-server.com",
      "server_port": 443,
      "uuid": "your-uuid",
      "flow": "xtls-rprx-vision",
      "tls": {
        "enabled": true,
        "server_name": "www.microsoft.com",
        "utls": { "enabled": true, "fingerprint": "chrome" }
      }
    },
    {
      "type": "urltest",
      "tag": "auto",
      "outbounds": ["proxy"],
      "url": "https://www.gstatic.com/generate_204",
      "interval": "300s"
    }
  ],
  "routes": [
    {
      "rules": [
        { "ip_is_private": true, "outbound": "direct" },
        { "domain_suffix": [".cn"], "outbound": "direct" },
        { "protocol": "bittorrent", "outbound": "block" }
      ],
      "final": "auto"
    }
  ],
  "experimental": {
    "clash_api": {
      "external_controller": "127.0.0.1:9090"
    },
    "metrics": {
      "prometheus": { "enabled": true, "listen": "127.0.0.1:9091" }
    }
  }
}
```


## 第二章 部署指南

### 2.1 二进制部署

#### 2.1.1 编译

```bash
# 开发构建
cargo build --release

# 生产构建（带 PGO）
./scripts/build-pgo.sh

# 跨平台构建
cargo build --release --target aarch64-unknown-linux-musl
cargo build --release --target x86_64-unknown-linux-musl
cargo build --release --target aarch64-apple-darwin
cargo build --release --target x86_64-pc-windows-msvc
```

#### 2.1.2 目录布局

```
/usr/local/bin/caly                    # 二进制
/etc/caly/config.json                  # 主配置
/etc/caly/cert.pem                     # TLS 证书（可选）
/etc/caly/key.pem                      # TLS 私钥（可选）
/etc/caly/rules/                       # 规则集
/var/lib/caly/                         # 运行时数据
/var/lib/caly/cache.db                 # 缓存
/var/log/caly/                         # 日志
/var/run/caly.pid                      # PID 文件
```

#### 2.1.3 systemd 服务

```ini
# /etc/systemd/system/caly.service
[Unit]
Description=Caly Proxy Kernel
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=caly
Group=caly
ExecStart=/usr/local/bin/caly -c /etc/caly/config.json
ExecReload=/bin/kill -HUP $MAINPID
Restart=on-failure
RestartSec=5s

# 安全加固
NoNewPrivileges=true
ProtectSystem=strict
ProtectHome=true
PrivateTmp=true
ReadWritePaths=/var/lib/caly /var/log/caly /var/run

# 网络能力（TUN/TProxy 需要）
AmbientCapabilities=CAP_NET_ADMIN CAP_NET_BIND_SERVICE CAP_NET_RAW
CapabilityBoundingSet=CAP_NET_ADMIN CAP_NET_BIND_SERVICE CAP_NET_RAW

# 内存限制
MemoryMax=256M
MemoryHigh=192M

# 文件描述符限制
LimitNOFILE=1048576

# CPU 亲和性（可选）
# CPUAffinity=0-3

[Install]
WantedBy=multi-user.target
```

**关键约束**：
- `CAP_NET_ADMIN`：TUN/TProxy 需要
- `CAP_NET_BIND_SERVICE`：监听 1024 以下端口需要
- `CAP_NET_RAW`：eBPF/XDP 需要
- `NoNewPrivileges=true`：禁止提权
- `ProtectSystem=strict`：文件系统只读

### 2.2 容器部署

#### 2.2.1 Dockerfile

```dockerfile
FROM rust:1.80-alpine AS builder
RUN apk add --no-cache musl-dev
WORKDIR /build
COPY . .
RUN cargo build --release --target x86_64-unknown-linux-musl

FROM alpine:3.20
RUN apk add --no-cache ca-certificates tzdata
COPY --from=builder /build/target/x86_64-unknown-linux-musl/release/caly /usr/local/bin/caly
COPY config.json /etc/caly/config.json
EXPOSE 1080 8080 9090 9091
ENTRYPOINT ["/usr/local/bin/caly", "-c", "/etc/caly/config.json"]
```

#### 2.2.2 Docker Compose

```yaml
version: '3.8'
services:
  caly:
    image: caly:latest
    container_name: caly
    restart: unless-stopped
    network_mode: host  # TUN/TProxy 需要
    cap_add:
      - NET_ADMIN
      - NET_RAW
      - NET_BIND_SERVICE
    volumes:
      - ./config.json:/etc/caly/config.json:ro
      - ./rules:/etc/caly/rules:ro
      - caly-data:/var/lib/caly
      - caly-logs:/var/log/caly
    ulimits:
      nofile:
        soft: 1048576
        hard: 1048576
    # 注意：mlock 在默认容器中可能失败，Caly 会优雅降级
    # 如需 mlock，添加：
    # cap_add:
    #   - IPC_LOCK

volumes:
  caly-data:
  caly-logs:
```

#### 2.2.3 Kubernetes DaemonSet

```yaml
apiVersion: apps/v1
kind: DaemonSet
metadata:
  name: caly
  namespace: kube-system
spec:
  selector:
    matchLabels:
      app: caly
  template:
    metadata:
      labels:
        app: caly
    spec:
      hostNetwork: true
      hostPID: true
      containers:
      - name: caly
        image: caly:latest
        securityContext:
          capabilities:
            add:
            - NET_ADMIN
            - NET_RAW
            - NET_BIND_SERVICE
            - SYS_ADMIN  # TUN 需要
          privileged: false
        volumeMounts:
        - name: config
          mountPath: /etc/caly
          readOnly: true
        - name: data
          mountPath: /var/lib/caly
        resources:
          requests:
            memory: "64Mi"
            cpu: "100m"
          limits:
            memory: "256Mi"
            cpu: "2000m"
      volumes:
      - name: config
        configMap:
          name: caly-config
      - name: data
        emptyDir: {}
```

### 2.3 OpenWrt 部署

#### 2.3.1 交叉编译

```bash
# 安装工具链
cargo install cross

# 编译 aarch64 OpenWrt
cross build --release --target aarch64-unknown-linux-musl

# 编译 mipsel OpenWrt
cross build --release --target mipsel-unknown-linux-musl
```

#### 2.3.2 体积约束

OpenWrt 路由器 Flash 通常 16-32MB。Caly 的编译配置：

```toml
[features]
default = ["runtime-tokio", "inbound-tun", "inbound-socks5", "outbound-direct", "outbound-vless"]
# 关闭：HTTP 入站、Shadowsocks、Trojan、Hysteria2、Prometheus
```

**预期体积**：stripped mipsel 约 **4.5MB**。

#### 2.3.3 OpenWrt init 脚本

```sh
#!/bin/sh /etc/rc.common

START=99
STOP=10
USE_PROCD=1

PROG=/usr/bin/caly
CONF=/etc/caly/config.json

start_service() {
    procd_open_instance
    procd_set_param command $PROG -c $CONF
    procd_set_param respawn
    procd_set_param file $CONF
    procd_set_param limits nofile="1048576 1048576"
    procd_close_instance
}

reload_service() {
    procd_send_signal caly HUP
}
```

### 2.4 平台特定配置

#### 2.4.1 Linux TProxy 配置

```bash
# 启用 IP 转发
sysctl -w net.ipv4.ip_forward=1
sysctl -w net.ipv6.conf.all.forwarding=1

# 策略路由
ip rule add fwmark 1 table 100
ip route add local 0.0.0.0/0 dev lo table 100

# iptables 规则
iptables -t mangle -N CALY
iptables -t mangle -A CALY -d 127.0.0.1/8 -j RETURN
iptables -t mangle -A CALY -d 10.0.0.0/8 -j RETURN
iptables -t mangle -A CALY -d 172.16.0.0/12 -j RETURN
iptables -t mangle -A CALY -d 192.168.0.0/16 -j RETURN
iptables -t mangle -A CALY -p tcp -j TPROXY --on-port 7895 --tproxy-mark 1
iptables -t mangle -A CALY -p udp -j TPROXY --on-port 7895 --tproxy-mark 1
iptables -t mangle -A PREROUTING -j CALY
```

#### 2.4.2 Windows Wintun 配置

```powershell
# 安装 Wintun 驱动（首次运行自动完成）
# Caly 会自动下载并安装 wintun.dll

# 创建 TUN 接口
caly -c config.json --tun-interface "Caly"

# 配置路由
# Caly 会自动添加路由表项
```

#### 2.4.3 macOS utun 配置

```bash
# 启动 Caly（需要 root）
sudo caly -c config.json

# Caly 会自动创建 utun 接口并配置路由
# 查看接口
ifconfig utun0
```

### 2.5 权限最小化

Caly 需要的 Linux Capabilities：

| Capability | 用途 | 是否必需 |
|---|---|---|
| `CAP_NET_ADMIN` | TUN/TProxy、路由表操作 | TUN/TProxy 时需要 |
| `CAP_NET_BIND_SERVICE` | 监听 < 1024 端口 | 可选 |
| `CAP_NET_RAW` | eBPF/XDP | 可选 |
| `CAP_IPC_LOCK` | mlock 锁定内存 | 可选（失败时降级） |
| `CAP_SYS_ADMIN` | TUN 设备创建 | TUN 时需要 |

**最小权限示例**：

```ini
# 仅 SOCKS5 代理（无 TUN/TProxy）
AmbientCapabilities=CAP_NET_BIND_SERVICE
CapabilityBoundingSet=CAP_NET_BIND_SERVICE

# TProxy 模式
AmbientCapabilities=CAP_NET_ADMIN CAP_NET_BIND_SERVICE CAP_NET_RAW
CapabilityBoundingSet=CAP_NET_ADMIN CAP_NET_BIND_SERVICE CAP_NET_RAW

# TUN 模式
AmbientCapabilities=CAP_NET_ADMIN CAP_NET_BIND_SERVICE CAP_SYS_ADMIN
CapabilityBoundingSet=CAP_NET_ADMIN CAP_NET_BIND_SERVICE CAP_SYS_ADMIN
```


## 第三章 运维指南

### 3.1 监控指标

#### 3.1.1 Prometheus 指标

Caly 暴露以下 Prometheus 指标：

```
# 连接指标
caly_connections_active{inbound,outbound}          # 活跃连接数
caly_connections_total{inbound,outbound}           # 总连接数
caly_connections_duration_seconds{inbound,outbound} # 连接持续时间直方图

# 流量指标
caly_traffic_bytes_total{inbound,outbound,direction} # 流量字节数
caly_traffic_packets_total{inbound,outbound}         # 数据包数

# 延迟指标
caly_dns_resolve_duration_seconds{server}          # DNS 解析延迟
caly_route_match_duration_seconds                   # 路由匹配延迟
caly_protocol_handshake_duration_seconds{protocol}  # 协议握手延迟

# 资源指标
caly_memory_rss_bytes                              # 常驻内存
caly_slab_utilization{slab_type}                   # Slab 池利用率
caly_cpu_usage_percent                             # CPU 使用率

# 规则指标
caly_rules_total                                   # 规则总数
caly_rules_match_total{rule_type}                  # 规则匹配次数

# DNS 指标
caly_dns_cache_hit_total                           # DNS 缓存命中
caly_dns_cache_miss_total                          # DNS 缓存未命中
caly_fakeip_allocated                              # FakeIP 已分配数
caly_fakeip_exhausted_total                        # FakeIP 耗尽次数

# 错误指标
caly_errors_total{type}                            # 错误总数
caly_dns_errors_total{server}                      # DNS 错误
caly_outbound_errors_total{outbound}               # 出站错误
```

#### 3.1.2 Prometheus 配置

```yaml
# prometheus.yml
scrape_configs:
  - job_name: 'caly'
    scrape_interval: 15s
    static_configs:
      - targets: ['127.0.0.1:9091']
```

#### 3.1.3 Grafana 仪表盘

推荐仪表盘面板：

| 面板 | 指标 | 用途 |
|---|---|---|
| 活跃连接数 | `caly_connections_active` | 实时连接压力 |
| 流量速率 | `rate(caly_traffic_bytes_total[1m])` | 实时吞吐 |
| P99 延迟 | `histogram_quantile(0.99, caly_connections_duration_seconds)` | 尾部延迟 |
| DNS 缓存命中率 | `caly_dns_cache_hit_total / (hit + miss)` | DNS 效率 |
| 内存占用 | `caly_memory_rss_bytes` | 内存泄漏检测 |
| Slab 利用率 | `caly_slab_utilization` | 缓冲区压力 |
| 错误率 | `rate(caly_errors_total[1m])` | 异常检测 |

### 3.2 日志管理

#### 3.2.1 日志格式

**JSON 格式**（默认）：

```json
{
  "timestamp": "2026-09-20T10:30:00.123Z",
  "level": "info",
  "target": "caly::session",
  "message": "session established",
  "session_id": 12345,
  "inbound": "socks-in",
  "outbound": "proxy",
  "domain": "www.example.com",
  "duration_ms": 45
}
```

**Text 格式**：

```
2026-09-20T10:30:00.123Z INFO caly::session: session established session_id=12345 inbound=socks-in outbound=proxy domain=www.example.com duration_ms=45
```

#### 3.2.2 日志级别

| 级别 | 使用场景 | 生产推荐 |
|---|---|---|
| `trace` | 每个字节的读写 | 仅调试 |
| `debug` | 每个连接的生命周期 | 排查问题时 |
| `info` | 连接建立/关闭、配置重载 | 默认 |
| `warn` | mlock 失败、缓存未命中等 | 默认 |
| `error` | 连接失败、协议错误 | 默认 |

#### 3.2.3 日志轮转

```bash
# /etc/logrotate.d/caly
/var/log/caly/*.log {
    daily
    rotate 7
    compress
    delaycompress
    missingok
    notifempty
    create 0640 caly caly
    sharedscripts
    postrotate
        kill -USR1 $(pidof caly)
    endscript
}
```

Caly 收到 `SIGUSR1` 后重新打开日志文件。

### 3.3 健康检查

#### 3.3.1 HTTP 健康检查端点

```bash
# 存活检查
curl http://127.0.0.1:9090/healthz
# 返回：{"status": "ok"}

# 就绪检查
curl http://127.0.0.1:9090/readyz
# 返回：{"status": "ready", "epoch": 42}
```

#### 3.3.2 监控脚本

```bash
#!/bin/bash
# /usr/local/bin/caly-healthcheck.sh

HEALTH_URL="http://127.0.0.1:9090/healthz"
MAX_RETRIES=3
RETRY_DELAY=2

for i in $(seq 1 $MAX_RETRIES); do
    if curl -sf "$HEALTH_URL" > /dev/null; then
        exit 0
    fi
    sleep $RETRY_DELAY
done

# 健康检查失败，重启服务
systemctl restart caly
exit 1
```

### 3.4 性能调优

#### 3.4.1 内核参数调优

```bash
# /etc/sysctl.d/99-caly.conf

# 网络缓冲区
net.core.rmem_max = 134217728
net.core.wmem_max = 134217728
net.core.rmem_default = 262144
net.core.wmem_default = 262144
net.ipv4.tcp_rmem = 4096 262144 134217728
net.ipv4.tcp_wmem = 4096 262144 134217728

# 连接跟踪
net.netfilter.nf_conntrack_max = 1048576
net.netfilter.nf_conntrack_tcp_timeout_established = 7200
net.netfilter.nf_conntrack_udp_timeout = 60

# TCP 优化
net.ipv4.tcp_congestion_control = bbr
net.ipv4.tcp_fastopen = 3
net.ipv4.tcp_slow_start_after_idle = 0
net.ipv4.tcp_mtu_probing = 1

# 文件描述符
fs.file-max = 2097152

# io_uring（如果启用）
kernel.io_uring_disabled = 0
```

#### 3.4.2 CPU 亲和性

```bash
# 将 Caly 绑定到特定核心
systemctl edit caly
# 添加：
[Service]
CPUAffinity=2-5

# 或者手动设置
taskset -cp 2-5 $(pidof caly)
```

**推荐**：将 Caly 绑定到与网卡中断不同的核心，避免中断处理与数据面竞争。

#### 3.4.3 内存调优

```json
{
  "experimental": {
    "slab": {
      "small_size": 2048,
      "medium_size": 16384,
      "large_size": 65536,
      "small_count": 4096,
      "medium_count": 1024,
      "large_count": 256
    }
  }
}
```

**内存预算计算**：
```
SmallSlab: 2048 × 4096 = 8 MB
MediumSlab: 16384 × 1024 = 16 MB
LargeSlab: 65536 × 256 = 16 MB
总计: 40 MB（加上元数据和堆分配，RSS 约 45 MB）
```

**最小配置**（嵌入式）：
```json
{
  "experimental": {
    "slab": {
      "small_size": 2048,
      "medium_size": 16384,
      "large_size": 65536,
      "small_count": 512,
      "medium_count": 128,
      "large_count": 32
    }
  }
}
```
预期 RSS：约 **8 MB**。

### 3.5 故障排查

#### 3.5.1 常见问题

| 症状 | 可能原因 | 排查步骤 |
|---|---|---|
| 启动失败：`mlock failed` | 容器无 `CAP_IPC_LOCK` | 检查 capability 或忽略（已降级） |
| 启动失败：`bind: address already in use` | 端口冲突 | `ss -tlnp \| grep <port>` |
| TUN 创建失败 | 无 `CAP_NET_ADMIN` | 检查 capability |
| 连接超时 | 上游不可达 | `curl -v --socks5 127.0.0.1:1080 https://example.com` |
| DNS 解析失败 | DNS 服务器不可达 | `dig @223.5.5.5 example.com` |
| 规则不生效 | 规则语法错误 | 检查日志中的规则匹配结果 |
| 内存持续增长 | FakeIP 泄漏 | 检查 `caly_fakeip_allocated` 指标 |
| 尾部延迟高 | GC 或锁竞争 | 检查 CPU 亲和性和 Slab 利用率 |
| 配置热重载失败 | 新配置语义错误 | 查看日志中的校验错误 |

#### 3.5.2 诊断命令

```bash
# 查看版本
caly --version

# 校验配置
caly --check -c /etc/caly/config.json

# 测试配置（不启动服务）
caly --test -c /etc/caly/config.json

# 导出当前配置
curl http://127.0.0.1:9090/configs | jq .

# 查看规则
curl http://127.0.0.1:9090/rules | jq .

# 查看连接
curl http://127.0.0.1:9090/connections | jq .

# 查看 DNS 缓存
curl http://127.0.0.1:9090/dns/cache | jq .

# 查看指标
curl http://127.0.0.1:9091/metrics | grep caly_

# 实时追踪会话
caly --trace-session <session_id>
```

#### 3.5.3 深度诊断

**查看 Slab 使用情况**：

```bash
curl http://127.0.0.1:9090/debug/slab | jq .
# {
#   "small": { "total": 4096, "used": 128, "free": 3968 },
#   "medium": { "total": 1024, "used": 256, "free": 768 },
#   "large": { "total": 256, "used": 32, "free": 224 }
# }
```

**查看规则匹配详情**：

```bash
curl "http://127.0.0.1:9090/debug/match?domain=www.google.com" | jq .
# {
#   "domain": "www.google.com",
#   "matched_rules": [
#     { "type": "domain_suffix", "value": ".google.com", "outbound": "proxy" }
#   ],
#   "final_outbound": "proxy",
#   "match_duration_ns": 85
# }
```

**查看 FakeIP 池状态**：

```bash
curl http://127.0.0.1:9090/debug/fakeip | jq .
# {
#   "capacity": 131072,
#   "allocated": 1024,
#   "free": 130048,
#   "next_gc_in_seconds": 45
# }
```

### 3.6 升级流程

#### 3.6.1 滚动升级

```bash
#!/bin/bash
# 滚动升级脚本

NEW_VERSION="2.1.0"
BINARY_URL="https://github.com/caly/caly/releases/download/v${NEW_VERSION}/caly-linux-amd64"

# 1. 下载新二进制
curl -L -o /tmp/caly-new "$BINARY_URL"
chmod +x /tmp/caly-new

# 2. 校验
/tmp/caly-new --check -c /etc/caly/config.json

# 3. 备份旧二进制
cp /usr/local/bin/caly /usr/local/bin/caly.bak

# 4. 替换
mv /tmp/caly-new /usr/local/bin/caly

# 5. 优雅重启
systemctl reload caly  # 或 kill -HUP

# 6. 验证
sleep 2
curl -sf http://127.0.0.1:9090/healthz || {
    echo "健康检查失败，回滚"
    mv /usr/local/bin/caly.bak /usr/local/bin/caly
    systemctl restart caly
    exit 1
}

echo "升级成功"
```

#### 3.6.2 配置迁移

Caly 保证 minor 版本间配置向后兼容。major 版本升级时：

```bash
# 1. 导出当前配置
curl http://127.0.0.1:9090/configs > /tmp/old-config.json

# 2. 运行迁移工具
caly --migrate-config /tmp/old-config.json --to 2.0 > /tmp/new-config.json

# 3. 校验新配置
caly --check -c /tmp/new-config.json

# 4. 替换配置
cp /tmp/new-config.json /etc/caly/config.json

# 5. 重载
systemctl reload caly
```

### 3.7 安全加固

#### 3.7.1 最小权限原则

```ini
# /etc/systemd/system/caly.service.d/security.conf
[Service]
# 禁止提权
NoNewPrivileges=true

# 文件系统保护
ProtectSystem=strict
ProtectHome=true
PrivateTmp=true
PrivateDevices=false  # TUN 需要设备访问
ProtectKernelTunables=true
ProtectKernelModules=true
ProtectControlGroups=true

# 可写路径白名单
ReadWritePaths=/var/lib/caly /var/log/caly /var/run

# 网络限制
RestrictAddressFamilies=AF_INET AF_INET6 AF_UNIX AF_NETLINK

# 系统调用过滤（可选，需要测试）
# SystemCallFilter=@system-service
# SystemCallErrorNumber=EPERM
```

#### 3.7.2 网络隔离

```bash
# 仅允许必要的网络连接
# 入站：监听端口
# 出站：代理服务器

# 使用 nftables 限制
nft add table inet caly
nft add chain inet caly output '{ type filter hook output priority 0; }'
nft add rule inet caly output ip daddr 127.0.0.1 accept
nft add rule inet caly output ip daddr <proxy-server-ip> accept
nft add rule inet caly output drop
```

#### 3.7.3 配置加密

敏感字段（如密码、UUID）支持通过环境变量注入：

```json
{
  "outbounds": [
    {
      "type": "shadowsocks",
      "server": "example.com",
      "server_port": 8388,
      "method": "2022-blake3-aes-256-gcm",
      "password": "${CALY_SS_PASSWORD}"
    }
  ]
}
```

环境变量在启动时由 Caly 读取并替换，配置文件中不存储明文。

#### 3.7.4 审计日志

```json
{
  "log": {
    "level": "info",
    "format": "json",
    "output": "/var/log/caly/audit.log",
    "audit": {
      "enabled": true,
      "events": ["config_reload", "connection_denied", "auth_failure"]
    }
  }
}
```

审计日志记录：
- 配置重载（谁、何时、新旧 Epoch）
- 连接拒绝（目标、规则、原因）
- 认证失败（来源、入站）

### 3.8 容量规划

#### 3.8.1 资源估算

| 并发连接数 | 推荐 CPU | 推荐内存 | 推荐带宽 |
|---|---|---|---|
| < 1,000 | 1 核 | 64 MB | 100 Mbps |
| 1,000 - 10,000 | 2 核 | 128 MB | 1 Gbps |
| 10,000 - 50,000 | 4 核 | 256 MB | 5 Gbps |
| 50,000 - 100,000 | 8 核 | 512 MB | 10 Gbps |
| > 100,000 | 16 核+ | 1 GB+ | 25 Gbps+ |

#### 3.8.2 带宽估算

```
实际带宽 = 代理协议开销 × 用户带宽
Shadowsocks: 1.05x
VLESS + TLS: 1.10x
Trojan + TLS: 1.10x
Hysteria2: 1.02x（QUIC 有额外开销但无 TLS 记录层）
```

#### 3.8.3 内存估算

```
RSS = 基线 + 每连接内存 × 并发连接数 + 规则集内存

基线（编译期 Slab）: 8-40 MB
每连接内存: 20-50 KB
规则集内存: 2-10 MB（mmap 按需加载）

示例：1000 并发连接，编译期 Slab 16 MB
RSS = 16 MB + 1000 × 30 KB + 5 MB = 51 MB
```


## 第四章 平台适配指南

### 4.1 Linux

#### 4.1.1 TProxy 模式

**适用场景**：网关设备、软路由

**配置**：

```json
{
  "inbounds": [
    {
      "type": "tproxy",
      "tag": "tproxy-in",
      "listen": "0.0.0.0",
      "port": 7895,
      "network": "tcp,udp",
      "sniff": true
    }
  ]
}
```

**所需权限**：`CAP_NET_ADMIN`

**iptables 规则**：见 2.4.1

#### 4.1.2 TUN 模式

**适用场景**：桌面、移动设备、VPN

**配置**：

```json
{
  "inbounds": [
    {
      "type": "tun",
      "tag": "tun-in",
      "interface_name": "caly0",
      "inet4_address": "172.19.0.1/30",
      "mtu": 9000,
      "auto_route": true,
      "strict_route": true,
      "stack": "system"
    }
  ]
}
```

**所需权限**：`CAP_NET_ADMIN` + `CAP_SYS_ADMIN`

**栈选择**：
- `system`：使用内核 TCP/IP 栈（推荐，性能最好）
- `gvisor`：用户态栈（兼容性最好，性能较低）
- `mixed`：TCP 用 system，UDP 用 gvisor

#### 4.1.3 eBPF 加速（可选）

**适用场景**：高吞吐网关

**配置**：

```json
{
  "experimental": {
    "ebpf": {
      "enabled": true,
      "mode": "sockmap",
      "bypass_localhost": true
    }
  }
}
```

**所需权限**：`CAP_NET_ADMIN` + `CAP_BPF`

**注意**：eBPF 仅限 Linux 5.10+，且不适用于所有网卡驱动。

### 4.2 Windows

#### 4.2.1 Wintun 模式

**适用场景**：Windows 桌面

**配置**：

```json
{
  "inbounds": [
    {
      "type": "tun",
      "tag": "tun-in",
      "interface_name": "Caly",
      "inet4_address": "172.19.0.1/30",
      "mtu": 9000,
      "auto_route": true,
      "stack": "system"
    }
  ]
}
```

**权限**：管理员权限（首次运行自动安装 Wintun 驱动）

**Wintun 优势**：
- 环形缓冲区，用户态直接操作收发指针
- 规避 IRP 内核上下文切换
- 相比 TAP-Windows 性能提升显著

### 4.3 macOS

#### 4.3.1 utun 模式

**适用场景**：macOS 桌面

**配置**：

```json
{
  "inbounds": [
    {
      "type": "tun",
      "tag": "tun-in",
      "interface_name": "utun",
      "inet4_address": "172.19.0.1/30",
      "mtu": 9000,
      "auto_route": true,
      "stack": "system"
    }
  ]
}
```

**权限**：root 权限

**注意**：macOS 的 utun 接口名由系统分配，`interface_name` 字段仅作为前缀。

### 4.4 Android

#### 4.4.1 VpnService 模式

**适用场景**：Android 应用

**集成方式**：通过 JNI 接口接收 `VpnService` 传递的文件描述符。

```kotlin
// Android 端
val builder = VpnService.Builder()
builder.addAddress("172.19.0.1", 30)
builder.addRoute("0.0.0.0", 0)
val pfd = builder.establish()

// 传递文件描述符给 Caly
nativeStartCaly(pfd.fd)
```

**关键约束**：
- 文件描述符以非阻塞模式传递给 Caly
- Caly 在底层以事件循环接管报文收发
- 消除跨语言内存重分配损耗

### 4.5 iOS

#### 4.5.1 NEPacketTunnelProvider

**适用场景**：iOS 应用

**集成方式**：封装 `NEPacketTunnelProvider`，通过跨进程文件描述符透传机制接入数据流。

```swift
class PacketTunnelProvider: NEPacketTunnelProvider {
    override func startTunnel(options: [String: NSObject]?, completionHandler: @escaping (Error?) -> Void) {
        let settings = NEPacketTunnelNetworkSettings(tunnelRemoteAddress: "172.19.0.1")
        // ... 配置
        setTunnelNetworkSettings(settings) { error in
            // 传递文件描述符给 Caly
            completionHandler(error)
        }
    }
}
```


## 第五章 运维最佳实践

### 5.1 部署检查清单

**部署前**：
- [ ] 配置通过 `caly --check` 校验
- [ ] 证书文件存在且可读
- [ ] 规则集文件存在且 SHA256 校验通过
- [ ] 端口未被占用
- [ ] 系统参数已调优（见 3.4.1）
- [ ] Capabilities 已正确配置

**部署后**：
- [ ] 服务状态 `systemctl status caly` 正常
- [ ] 健康检查 `/healthz` 返回 ok
- [ ] 指标端点 `/metrics` 可访问
- [ ] 实际代理测试通过
- [ ] 日志无 error 级别输出

### 5.2 监控告警规则

```yaml
# prometheus-alerts.yml
groups:
  - name: caly
    rules:
      - alert: CalyDown
        expr: up{job="caly"} == 0
        for: 1m
        labels:
          severity: critical
        annotations:
          summary: "Caly 服务不可用"

      - alert: CalyHighErrorRate
        expr: rate(caly_errors_total[5m]) > 10
        for: 5m
        labels:
          severity: warning
        annotations:
          summary: "Caly 错误率过高"

      - alert: CalyHighMemory
        expr: caly_memory_rss_bytes > 500 * 1024 * 1024
        for: 10m
        labels:
          severity: warning
        annotations:
          summary: "Caly 内存占用超过 500MB"

      - alert: CalyFakeIpExhausted
        expr: increase(caly_fakeip_exhausted_total[5m]) > 0
        labels:
          severity: warning
        annotations:
          summary: "FakeIP 池耗尽"

      - alert: CalyHighLatency
        expr: histogram_quantile(0.99, rate(caly_connections_duration_seconds_bucket[5m])) > 5
        for: 5m
        labels:
          severity: warning
        annotations:
          summary: "P99 连接延迟超过 5 秒"
```

### 5.3 备份与恢复

**备份内容**：
- `/etc/caly/config.json` — 主配置
- `/etc/caly/rules/` — 规则集
- `/etc/caly/cert.pem` + `key.pem` — 证书
- `/var/lib/caly/cache.db` — 缓存（可选）

**备份脚本**：

```bash
#!/bin/bash
BACKUP_DIR="/backup/caly/$(date +%Y%m%d)"
mkdir -p "$BACKUP_DIR"
cp -r /etc/caly "$BACKUP_DIR/"
cp -r /var/lib/caly "$BACKUP_DIR/"
tar czf "$BACKUP_DIR.tar.gz" "$BACKUP_DIR"
rm -rf "$BACKUP_DIR"
```

**恢复**：

```bash
tar xzf /backup/caly/20260920.tar.gz -C /
systemctl restart caly
```

### 5.4 性能基准测试

```bash
# 使用 wrk 压测 SOCKS5 代理
wrk -t4 -c100 -d30s --socks5 127.0.0.1:1080 http://example.com

# 使用 hey 压测
hey -n 100000 -c 100 -x socks5://127.0.0.1:1080 http://example.com

# 使用 iperf3 测试吞吐
iperf3 -c example.com -p 5201 --socks5 127.0.0.1:1080

# 使用 dnsperf 测试 DNS
dnsperf -s 127.0.0.1 -p 5353 -d query.txt
```

### 5.5 容量扩展

**垂直扩展**：
- 增加 CPU 核心数（Thread-per-Core 自动利用）
- 增加内存（增大 Slab 池）
- 升级网卡（支持 io_uring 零拷贝）

**水平扩展**：
- 多实例部署，前端负载均衡
- 使用 Selector 出站组实现故障转移
- 使用 URLTest 实现基于延迟的自动选择


## 第六章 故障恢复

### 6.1 自动重启

```ini
[Service]
Restart=on-failure
RestartSec=5s
StartLimitInterval=60s
StartLimitBurst=3
```

**重启策略**：
- 正常退出（exit 0）：不重启
- 异常退出（exit != 0）：重启
- 连续失败 3 次：停止重启，触发告警

### 6.2 配置回滚

```bash
#!/bin/bash
# 配置回滚脚本

BACKUP_DIR="/etc/caly/backup"
LATEST_BACKUP=$(ls -t "$BACKUP_DIR" | head -1)

if [ -z "$LATEST_BACKUP" ]; then
    echo "无可用备份"
    exit 1
fi

cp "$BACKUP_DIR/$LATEST_BACKUP/config.json" /etc/caly/config.json
systemctl reload caly

echo "已回滚到 $LATEST_BACKUP"
```

### 6.3 灾难恢复

**场景 1：二进制损坏**

```bash
# 重新下载并替换
curl -L -o /usr/local/bin/caly <binary-url>
chmod +x /usr/local/bin/caly
systemctl restart caly
```

**场景 2：配置丢失**

```bash
# 从备份恢复
tar xzf /backup/caly/latest.tar.gz -C /
systemctl restart caly
```

**场景 3：证书过期**

```bash
# 更新证书
cp new-cert.pem /etc/caly/cert.pem
cp new-key.pem /etc/caly/key.pem
systemctl reload caly
```

**场景 4：规则集损坏**

```bash
# 重新生成规则集
caly --compile-rules --input geosite.dat --output rules/geosite.rkyv
systemctl reload caly
```


## 第七章 安全审计

### 7.1 审计日志格式

```json
{
  "timestamp": "2026-09-20T10:30:00.123Z",
  "event": "config_reload",
  "actor": "api",
  "details": {
    "old_epoch": 41,
    "new_epoch": 42,
    "changes": ["routes", "dns"]
  },
  "result": "success"
}
```

### 7.2 审计事件类型

| 事件 | 触发条件 | 记录内容 |
|---|---|---|
| `config_reload` | 配置重载 | 新旧 Epoch、变更内容 |
| `connection_denied` | 规则拒绝连接 | 目标、规则、原因 |
| `auth_failure` | 认证失败 | 来源、入站、尝试次数 |
| `rule_match` | 规则匹配（高价值目标） | 域名、规则、出站 |
| `dns_query` | DNS 查询（敏感域名） | 域名、服务器、结果 |
| `fatal_error` | 致命错误 | 错误类型、堆栈 |

### 7.3 合规性

Caly 的审计日志满足以下合规要求：
- 不记录用户数据内容（仅元数据）
- 不记录完整 URL（仅域名）
- 日志可配置保留时间
- 支持远程 syslog 导出

```json
{
  "log": {
    "audit": {
      "enabled": true,
      "output": "syslog://remote-syslog:514",
      "retention_days": 90
    }
  }
}
```


## 第八章 性能基准数据

### 8.1 基准测试环境

| 组件 | 规格 |
|---|---|
| CPU | AMD EPYC 7763 (8 vCPU) |
| 内存 | 16 GB DDR4 |
| 网卡 | Mellanox ConnectX-6 Dx 25Gbps |
| 内核 | Linux 6.6 |
| Caly 版本 | 2.0.0 |

### 8.2 吞吐量基准

| 场景 | 协议 | 吞吐量 | CPU 使用率 |
|---|---|---|---|
| 直连 | Direct | 24.8 Gbps | 100% (1 核) |
| SOCKS5 → Direct | SOCKS5 | 18.2 Gbps | 100% (1 核) |
| Shadowsocks 2022 | AEAD | 12.5 Gbps | 100% (1 核) |
| VLESS + TLS | TLS 1.3 | 9.8 Gbps | 100% (1 核) |
| Trojan + TLS | TLS 1.3 | 9.5 Gbps | 100% (1 核) |
| Hysteria2 | QUIC | 7.2 Gbps | 100% (1 核) |

### 8.3 延迟基准

| 场景 | P50 | P99 | P99.9 |
|---|---|---|---|
| SOCKS5 握手 | 12 μs | 45 μs | 120 μs |
| 规则匹配（DAAC） | 65 ns | 180 ns | 450 ns |
| 规则匹配（Tree-Bitmap） | 35 ns | 95 ns | 220 ns |
| FakeIP 分配 | 28 ns | 65 ns | 150 ns |
| 双向中继（1KB 包） | 8 μs | 22 μs | 65 μs |

### 8.4 内存基准

| 场景 | RSS |
|---|---|
| 空载 | 8.2 MB |
| 1000 并发连接 | 45 MB |
| 10000 并发连接 | 320 MB |
| 50000 并发连接 | 1.5 GB |

### 8.5 二进制体积

| 平台 | 体积（stripped） |
|---|---|
| x86_64-linux-musl | 6.2 MB |
| aarch64-linux-musl | 5.8 MB |
| mipsel-linux-musl | 4.5 MB |
| x86_64-apple-darwin | 6.8 MB |
| x86_64-pc-windows-msvc | 7.1 MB |


## 附录 A：配置 Schema 速查

| 配置节 | 字段数 | 必填 | 说明 |
|---|---|---|---|
| `log` | 5 | 否 | 日志配置 |
| `dns` | 7 | 否 | DNS 配置 |
| `inbounds` | 4 种类型 | 是 | 入站监听 |
| `outbounds` | 7 种类型 | 是 | 出站协议 |
| `routes` | 1 | 否 | 路由规则 |
| `experimental` | 7 | 否 | 实验性功能 |

## 附录 B：运维命令速查

| 命令 | 用途 |
|---|---|
| `caly --check -c config.json` | 校验配置 |
| `caly --version` | 查看版本 |
| `systemctl reload caly` | 热重载配置 |
| `systemctl restart caly` | 重启服务 |
| `curl /healthz` | 健康检查 |
| `curl /readyz` | 就绪检查 |
| `curl /metrics` | 查看指标 |
| `curl /configs` | 导出配置 |
| `curl /connections` | 查看连接 |
| `curl /dns/cache` | 查看 DNS 缓存 |
| `curl /debug/slab` | 查看 Slab 状态 |
| `curl /debug/fakeip` | 查看 FakeIP 池 |
| `kill -HUP $(pidof caly)` | 热重载 |
| `kill -USR1 $(pidof caly)` | 重新打开日志 |

## 附录 C：故障排查决策树

```
服务无法启动
├── 配置校验失败
│   ├── 语法错误 → 修复 JSON
│   ├── 语义错误 → 检查 tag 引用
│   └── 文件缺失 → 检查证书/规则集
├── 端口冲突
│   └── ss -tlnp | grep <port> → 更换端口
├── 权限不足
│   ├── CAP_NET_ADMIN → 添加 capability
│   ├── CAP_SYS_ADMIN → TUN 需要
│   └── CAP_IPC_LOCK → mlock 失败（可忽略）
└── 其他错误
    └── journalctl -u caly -n 100 → 查看日志

服务运行但代理不工作
├── 入站不监听
│   └── ss -tlnp | grep <port> → 检查监听
├── 出站不可达
│   └── curl -v --socks5 127.0.0.1:1080 https://example.com
├── 规则不匹配
│   └── curl "/debug/match?domain=example.com" → 检查规则
├── DNS 解析失败
│   └── curl "/dns/cache" → 检查 DNS 缓存
└── TLS 握手失败
    └── 检查证书和 server_name

性能问题
├── 吞吐量低
│   ├── 检查 CPU 亲和性 → taskset
│   ├── 检查 Slab 利用率 → /debug/slab
│   └── 检查 io_uring → dmesg | grep io_uring
├── 延迟高
│   ├── 检查 DNS 延迟 → /metrics
│   ├── 检查规则匹配延迟 → /debug/match
│   └── 检查 GC 停顿 → 不可能（Rust 无 GC）
└── 内存高
    ├── 检查 FakeIP 泄漏 → /debug/fakeip
    ├── 检查连接泄漏 → /connections
    └── 检查 Slab 泄漏 → /debug/slab
```

## 附录 D：版本兼容性矩阵

| Caly 版本 | 配置版本 | rkyv 版本 | 最低内核 |
|---|---|---|---|
| 1.0 | 1.0 | 0.7 | 3.10 |
| 2.0 | 1.0 | 0.8 | 4.14 |
| 2.1 | 1.0 | 0.8 | 5.19（io_uring） |

**配置兼容性承诺**：
- Minor 版本升级：配置完全向后兼容
- Major 版本升级：提供 `--migrate-config` 工具
- 废弃字段保留至少 2 个 minor 版本


**文档结束**

本文档为 Caly 部署、配置与运维规范，覆盖配置系统、部署指南、运维指南、平台适配、最佳实践、故障恢复、安全审计与性能基准。三份文档（AC-ARCH-001、AC-IMPL-002、AC-OPS-003）共同构成 Caly 的完整设计规范。
