# AetherCore 实现规范

**文档版本**: 2.0（修正版）  
**日期**: 2026-09-20  
**状态**: 设计冻结  
**文档编号**: AC-IMPL-002  
**前置文档**: AC-ARCH-001（架构设计规范）


## 第一章 实现总则

### 1.1 文档定位

本文档是 AetherCore 的实现规范，覆盖核心 trait 的具体实现、各子系统代码模式、关键算法实现、测试策略与性能基准方法。所有代码示例均为可编译或接近可编译的伪代码，标注了关键约束与陷阱。

### 1.2 实现顺序

实现必须严格遵循以下顺序，每一步都建立在前一步的稳定基础上：

```
第 1 步：ac-common 核心契约（trait + 数据结构）
    ↓
第 2 步：ac-session 会话编排（SessionContext + Guard）
    ↓
第 3 步：ac-worker 基础 Worker Loop（Tokio driver）
    ↓
第 4 步：ac-inbound/socks5 + ac-outbound/direct（最小闭环）
    ↓
第 5 步：ac-rules 规则引擎（DAAC + Tree-Bitmap）
    ↓
第 6 步：ac-dns DNS 子系统（FakeIP + 缓存）
    ↓
第 7 步：ac-transport 传输层（TLS + WS）
    ↓
第 8 步：ac-outbound/shadowsocks（第一个加密协议）
    ↓
第 9 步：ac-api 控制面（REST + 热重载）
    ↓
第 10 步：ac-worker L4 splice + Monoio driver（可选加速）
```

**关键约束**：在第 4 步完成前，禁止引入任何加密协议、规则引擎或 DNS 子系统。最小闭环必须先跑通。

### 1.3 代码质量红线

| 红线 | 检测方式 | 违反后果 |
|---|---|---|
| 热路径禁止 `unwrap()` / `panic!()` | Clippy `unwrap_used` lint | CI 拒绝合并 |
| 热路径禁止 `String` / `Vec<u8>` 动态分配 | `cargo bloat` + 人工审查 | 代码评审拒绝 |
| 热路径禁止 `Mutex` / `RwLock` | `cargo deny` + 人工审查 | 代码评审拒绝 |
| 协议核心禁止依赖 `tokio` | `ac-common` 的 `Cargo.toml` 无 tokio 依赖 | CI 拒绝合并 |
| 编译产物 > 8MB | CI 体积检查 | 拒绝发布 |


## 第二章 核心 trait 完整实现

### 2.1 ProtocolStateMachine 实现

#### 2.1.1 trait 定义

```rust
// crates/ac-common/src/protocol.rs

/// 纯 Sans-IO 协议状态机
/// 
/// # 生命周期
/// 
/// 状态机的完整生命周期：
/// 1. 构造：`new(config)` 或 `new_client(...)`
/// 2. 网络输入：`on_network_input(data)` —— 对端发来的加密字节
/// 3. 应用输入：`on_app_input(plaintext)` —— 本地应用发来的明文
/// 4. 轮询输出：`poll_network_output(buf)` / `poll_app_output(buf)`
/// 5. 时钟推进：`handle_tick(now_ms)`
/// 6. 终止：`Drop` 自动清理
/// 
/// # 线程安全
/// 
/// 状态机不是 `Send + Sync`。它属于单个 Worker 线程，
/// 通过所有权转移在不同阶段移动，但绝不跨线程共享。
pub trait ProtocolStateMachine {
    /// 协议特有的动作（如"升级到 TLS"、"请求 DNS 解析"）
    type Action;
    
    /// 协议错误
    type Error: std::error::Error;

    /// 接收来自网络的原始字节
    /// 
    /// 实现者必须处理以下情况：
    /// - 数据不完整（半包）
    /// - 数据过度（粘包）
    /// - 非法数据（协议违规）
    fn on_network_input(&mut self, data: &[u8]) -> Result<(), Self::Error>;

    /// 轮询待发送到网络的字节
    /// 
    /// 返回 `Some(n)` 表示写入了 n 字节到 `out_buf`。
    /// 返回 `None` 表示当前无待发送数据。
    /// 
    /// 调用者应在返回 `Some(n)` 后再次调用，直到返回 `None`。
    fn poll_network_output<'a>(
        &'a mut self,
        out_buf: &'a mut [u8],
    ) -> Option<usize>;

    /// 接收来自应用的明文数据
    fn on_app_input(&mut self, plaintext: &[u8]) -> Result<(), Self::Error>;

    /// 轮询待交付给应用的明文数据
    fn poll_app_output<'a>(
        &'a mut self,
        out_buf: &'a mut [u8],
    ) -> Option<usize>;

    /// 推进时钟状态
    /// 
    /// `now_ms` 是单调递增的毫秒时间戳。
    /// 状态机内部禁止调用 `Instant::now()`，所有时间都通过此方法注入。
    fn handle_tick(&mut self, now_ms: u64) -> Option<Self::Action>;
}
```

#### 2.1.2 SOCKS5 状态机实现

```rust
// crates/ac-inbound/src/socks5/state_machine.rs

use ac_common::protocol::ProtocolStateMachine;

#[derive(Debug, Clone, Copy, PartialEq)]
enum State {
    /// 等待客户端版本 + 认证方法列表
    Greeting,
    /// 等待客户端认证
    Auth,
    /// 等待客户端请求
    Request,
    /// 请求已解析，等待连接建立
    Connecting,
    /// 已建立，进入数据转发
    Established,
    /// 协议终止
    Closed,
}

pub struct Socks5StateMachine {
    state: State,
    /// 累积的输入缓冲区（上限 512 字节）
    input_buf: heapless::Vec<u8, 512>,
    /// 待发送的输出缓冲区
    output_buf: heapless::Vec<u8, 512>,
    /// 解析出的目标地址
    target: Option<TargetAddr>,
    /// 认证配置
    auth: AuthConfig,
    /// 超时（毫秒）
    timeout_ms: u64,
    /// 最后活动时间
    last_active_ms: u64,
}

impl Socks5StateMachine {
    pub fn new(auth: AuthConfig, timeout_ms: u64) -> Self {
        Self {
            state: State::Greeting,
            input_buf: heapless::Vec::new(),
            output_buf: heapless::Vec::new(),
            target: None,
            auth,
            timeout_ms,
            last_active_ms: 0,
        }
    }
}

impl ProtocolStateMachine for Socks5StateMachine {
    type Action = Socks5Action;
    type Error = Socks5Error;

    fn on_network_input(&mut self, data: &[u8]) -> Result<(), Self::Error> {
        // 累积到输入缓冲区，拒绝超过上限的数据
        if self.input_buf.len() + data.len() > 512 {
            return Err(Socks5Error::BufferOverflow);
        }
        self.input_buf.extend_from_slice(data)
            .map_err(|_| Socks5Error::BufferOverflow)?;

        // 根据当前状态尝试推进
        self.try_advance()
    }

    fn poll_network_output<'a>(
        &'a mut self,
        out_buf: &'a mut [u8],
    ) -> Option<usize> {
        if self.output_buf.is_empty() {
            return None;
        }
        let n = self.output_buf.len().min(out_buf.len());
        out_buf[..n].copy_from_slice(&self.output_buf[..n]);
        // 从缓冲区移除已写出的数据
        self.output_buf.drain(..n);
        Some(n)
    }

    fn on_app_input(&mut self, plaintext: &[u8]) -> Result<(), Self::Error> {
        // SOCKS5 本身不解密，直接把明文交给输出队列
        if self.state != State::Established {
            return Err(Socks5Error::NotEstablished);
        }
        if self.output_buf.len() + plaintext.len() > 512 {
            return Err(Socks5Error::BufferOverflow);
        }
        self.output_buf.extend_from_slice(plaintext)
            .map_err(|_| Socks5Error::BufferOverflow)
    }

    fn poll_app_output<'a>(
        &'a mut self,
        out_buf: &'a mut [u8],
    ) -> Option<usize> {
        // SOCKS5 直接把网络输入转给应用
        // 但在协议握手阶段，输入是协议控制字节，不应该给应用
        if self.state != State::Established {
            return None;
        }
        // 简化实现：从 input_buf 取数据
        if self.input_buf.is_empty() {
            return None;
        }
        let n = self.input_buf.len().min(out_buf.len());
        out_buf[..n].copy_from_slice(&self.input_buf[..n]);
        self.input_buf.drain(..n);
        Some(n)
    }

    fn handle_tick(&mut self, now_ms: u64) -> Option<Self::Action> {
        self.last_active_ms = self.last_active_ms.max(now_ms);
        if self.state == State::Closed {
            return None;
        }
        if now_ms.saturating_sub(self.last_active_ms) > self.timeout_ms {
            self.state = State::Closed;
            return Some(Socks5Action::Timeout);
        }
        None
    }
}

impl Socks5StateMachine {
    fn try_advance(&mut self) -> Result<(), Socks5Error> {
        loop {
            match self.state {
                State::Greeting => {
                    if self.input_buf.len() < 2 {
                        return Ok(());
                    }
                    if self.input_buf[0] != 0x05 {
                        return Err(Socks5Error::UnsupportedVersion);
                    }
                    let n_methods = self.input_buf[1] as usize;
                    let total = 2 + n_methods;
                    if self.input_buf.len() < total {
                        return Ok(());
                    }
                    // 检查是否有我们支持的方法
                    let methods = &self.input_buf[2..total];
                    let has_no_auth = methods.contains(&0x00);
                    if !has_no_auth && self.auth.required() {
                        self.output_buf.push(0x05).unwrap();
                        self.output_buf.push(0xFF).unwrap();  // no acceptable
                        self.state = State::Closed;
                        return Ok(());
                    }
                    self.output_buf.push(0x05).unwrap();
                    self.output_buf.push(0x00).unwrap();
                    self.input_buf.drain(..total);
                    self.state = if self.auth.required() {
                        State::Auth
                    } else {
                        State::Request
                    };
                }
                State::Auth => {
                    // 用户名/密码认证（简化）
                    // ...
                }
                State::Request => {
                    if self.input_buf.len() < 4 {
                        return Ok(());
                    }
                    if self.input_buf[0] != 0x05 || self.input_buf[1] != 0x01 {
                        return Err(Socks5Error::UnsupportedCommand);
                    }
                    let atyp = self.input_buf[3];
                    let target_len = match atyp {
                        0x01 => 4,   // IPv4
                        0x04 => 16,  // IPv6
                        0x03 => {
                            if self.input_buf.len() < 5 { return Ok(()); }
                            1 + self.input_buf[4] as usize
                        }
                        _ => return Err(Socks5Error::UnsupportedAddressType),
                    };
                    let total = 4 + target_len + 2;
                    if self.input_buf.len() < total {
                        return Ok(());
                    }
                    // 解析目标地址
                    let target = parse_target(atyp, &self.input_buf[4..4 + target_len])?;
                    self.target = Some(target);
                    self.input_buf.drain(..total);
                    self.state = State::Connecting;
                    return Ok(());
                }
                State::Connecting => {
                    // 等待外部设置连接成功
                    return Ok(());
                }
                State::Established | State::Closed => {
                    return Ok(());
                }
            }
        }
    }

    /// 外部在连接建立后调用，产生 SOCKS5 成功响应
    pub fn on_connected(&mut self, bind_addr: SocketAddr) -> Result<(), Socks5Error> {
        if self.state != State::Connecting {
            return Err(Socks5Error::InvalidState);
        }
        self.output_buf.push(0x05).unwrap();
        self.output_buf.push(0x00).unwrap();
        self.output_buf.push(0x00).unwrap();
        match bind_addr {
            SocketAddr::V4(addr) => {
                self.output_buf.push(0x01).unwrap();
                self.output_buf.extend_from_slice(&addr.ip().octets()).unwrap();
                self.output_buf.extend_from_slice(&addr.port().to_be_bytes()).unwrap();
            }
            SocketAddr::V6(addr) => {
                self.output_buf.push(0x04).unwrap();
                self.output_buf.extend_from_slice(&addr.ip().octets()).unwrap();
                self.output_buf.extend_from_slice(&addr.port().to_be_bytes()).unwrap();
            }
        }
        self.state = State::Established;
        Ok(())
    }
}
```

**关键约束**：
- `input_buf` 和 `output_buf` 使用 `heapless::Vec`，**零堆分配**
- 缓冲区上限 512 字节，超出即报错，防止内存耗尽
- 所有时间通过 `handle_tick` 注入，状态机内部**禁止** `Instant::now()`
- 状态机不感知任何 Socket，可 100% 单元测试

#### 2.1.3 状态机单元测试

```rust
#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_greeting_no_auth() {
        let mut sm = Socks5StateMachine::new(AuthConfig::none(), 30_000);
        
        // 客户端发送：版本 0x05，1 个方法，方法 0x00
        sm.on_network_input(&[0x05, 0x01, 0x00]).unwrap();
        
        // 期望服务端响应：版本 0x05，方法 0x00
        let mut out = [0u8; 16];
        let n = sm.poll_network_output(&mut out).unwrap();
        assert_eq!(&out[..n], &[0x05, 0x00]);
    }

    #[test]
    fn test_greeting_split() {
        let mut sm = Socks5StateMachine::new(AuthConfig::none(), 30_000);
        
        // 分片到达：先发版本，再发方法
        sm.on_network_input(&[0x05]).unwrap();
        let mut out = [0u8; 16];
        assert!(sm.poll_network_output(&mut out).is_none());
        
        sm.on_network_input(&[0x01, 0x00]).unwrap();
        let n = sm.poll_network_output(&mut out).unwrap();
        assert_eq!(&out[..n], &[0x05, 0x00]);
    }

    #[test]
    fn test_timeout() {
        let mut sm = Socks5StateMachine::new(AuthConfig::none(), 30_000);
        sm.on_network_input(&[0x05, 0x01, 0x00]).unwrap();
        let action = sm.handle_tick(30_001);
        assert!(matches!(action, Some(Socks5Action::Timeout)));
    }
}
```

**测试收益**：不需要 mock 任何网络，不需要启动任何服务，直接断言字节输入输出。这是 Sans-IO 的核心价值。

### 2.2 TransportStream 实现

#### 2.2.1 enum_dispatch 定义

```rust
// crates/ac-transport/src/stream.rs

use enum_dispatch::enum_dispatch;
use tokio::io::{AsyncRead, AsyncWrite};

/// 传输流统一 trait
/// 
/// 所有具体传输实现必须满足 AsyncRead + AsyncWrite + Unpin + Send
#[enum_dispatch]
pub trait TransportStream: AsyncRead + AsyncWrite + Unpin + Send {
    /// 获取底层流的类型标识（用于日志和指标）
    fn stream_type(&self) -> StreamType;

    /// 获取对端地址（如果可用）
    fn peer_addr(&self) -> Option<SocketAddr>;
}

/// 编译期已知的所有传输层组合
/// 
/// 每次新增传输层组合，需要在此枚举中添加变体。
/// 这是编译期开销与运行时灵活性的权衡：
/// - 编译期枚举：零 vtable，LLVM 完全内联
/// - 运行时动态：需要重新编译整个二进制
#[enum_dispatch(TransportStream)]
pub enum ConcreteStream {
    Tcp(TcpStream),
    Tls(TlsStream<TcpStream>),
    Ws(WebSocketStream<TcpStream>),
    TlsWs(WebSocketStream<TlsStream<TcpStream>>),
    H2(H2Stream<TcpStream>),
    TlsH2(H2Stream<TlsStream<TcpStream>>),
    AnyTls(AnyTlsStream<TcpStream>),
}
```

#### 2.2.2 传输层组合构造

```rust
// crates/ac-transport/src/builder.rs

pub struct StreamBuilder {
    config: TransportConfig,
}

impl StreamBuilder {
    /// 根据配置构造传输层组合
    /// 
    /// 关键设计：返回 `ConcreteStream` 而非 `Box<dyn TransportStream>`。
    /// 这保证了调用方在编译期知道所有可能的流类型。
    pub fn build(
        &self,
        tcp: TcpStream,
        metadata: &SessionMetadata,
    ) -> Result<ConcreteStream, TransportError> {
        // 根据配置决定组合路径
        match (&self.config.tls, &self.config.ws, &self.config.h2) {
            (None, None, None) => Ok(ConcreteStream::Tcp(tcp)),
            (Some(tls_cfg), None, None) => {
                let tls = tls_handshake(tcp, tls_cfg, metadata)?;
                Ok(ConcreteStream::Tls(tls))
            }
            (Some(tls_cfg), Some(ws_cfg), None) => {
                let tls = tls_handshake(tcp, tls_cfg, metadata)?;
                let ws = ws_handshake(tls, ws_cfg, metadata)?;
                Ok(ConcreteStream::TlsWs(ws))
            }
            (Some(tls_cfg), Some(ws_cfg), Some(h2_cfg)) => {
                // TLS + WS + H2 组合
                let tls = tls_handshake(tcp, tls_cfg, metadata)?;
                let ws = ws_handshake(tls, ws_cfg, metadata)?;
                let h2 = h2_handshake(ws, h2_cfg, metadata)?;
                Ok(ConcreteStream::TlsWsH2(h2))
            }
            _ => Err(TransportError::UnsupportedCombination),
        }
    }
}
```

**关键约束**：`StreamBuilder::build` 是同步函数（不返回 `Future`），因为它只是构造流对象。实际的 TLS/WS 握手由上层 Worker Loop 异步驱动。

### 2.3 ProxyAdapter 实现

```rust
// crates/ac-outbound/src/direct.rs

pub struct DirectAdapter;

impl ProxyAdapter for DirectAdapter {
    fn name(&self) -> &str { "direct" }

    fn dial(
        &self,
        metadata: &SessionMetadata,
    ) -> Result<ConcreteStream, ProxyError> {
        // Direct 适配器：直接连接目标地址
        // 注意：dial 是同步的，实际连接由 Worker Loop 异步驱动
        // 这里只返回"待连接"的流对象
        let stream = PendingStream::new(metadata.dst_addr);
        Ok(ConcreteStream::Tcp(stream.into_tcp()))
    }

    fn supports_udp(&self) -> bool { true }
}
```

**实现说明**：`dial` 返回的是"待连接"的流对象，实际连接由 Worker Loop 通过 `connect()` 完成。这保持了 `ProxyAdapter` 的同步性，同时不阻塞 Worker Loop。

### 2.4 SessionMetadata 实现

```rust
// crates/ac-common/src/metadata.rs

use smol_str::SmolStr;

/// 会话元数据，紧凑布局，总大小 272 字节
/// 
/// 内存布局（按大小降序排列，消除 padding）：
/// - src_addr: 28 bytes
/// - dst_addr: 28 bytes
/// - domain: 24 bytes (SmolStr)
/// - process: 24 bytes (Option<SmolStr>)
/// - inbound_tag: 8 bytes
/// - user_id: 8 bytes (Option<u64>)
/// - network: 1 byte
/// - protocol: 1 byte
/// - flags: 1 byte
/// - padding: 1 byte
/// - 保留字段: 148 bytes
#[repr(C)]
pub struct SessionMetadata {
    pub src_addr: SocketAddr,           // 28
    pub dst_addr: SocketAddr,           // 28
    pub domain: SmolStr,                // 24
    pub process: Option<SmolStr>,       // 24
    pub inbound_tag: u64,               // 8
    pub user_id: Option<u64>,           // 8
    pub network: Network,               // 1
    pub protocol: SniffedProto,         // 1
    pub flags: u8,                      // 1
    _padding: [u8; 1],                  // 1
    _reserved: [u8; 148],               // 148
}

impl SessionMetadata {
    /// 使用 SmolStr 存储域名
    /// 
    /// 关键约束：≤23 字节的字符串完全内联在栈上，不产生堆分配。
    /// 典型域名（如 "www.example.com"）完全内联。
    pub fn set_domain(&mut self, domain: &str) {
        self.domain = SmolStr::new(domain);
    }

    /// 检查是否有域名（用于路由决策）
    pub fn has_domain(&self) -> bool {
        !self.domain.is_empty()
    }
}

// 编译期断言：确保结构体大小不超过 272 字节
const _: () = assert!(std::mem::size_of::<SessionMetadata>() <= 272);
```

### 2.5 DnsResolver 实现

```rust
// crates/ac-dns/src/resolver.rs

pub struct DnsResolverImpl {
    /// 分片缓存，每片独立锁
    cache: ShardedCache,
    /// FakeIP 池
    fakeip: FakeIpPool,
    /// 上游解析器
    upstreams: Vec<Box<dyn Upstream>>,
    /// 路由规则（用于 DNS 分流）
    routing: ArcSwap<DnsRouting>,
}

impl DnsResolver for DnsResolverImpl {
    fn resolve(&self, domain: &str) -> Result<ResolveResult, DnsError> {
        // 1. 检查缓存
        if let Some(cached) = self.cache.get(domain) {
            if !cached.is_expired() {
                return Ok(cached.into_result());
            }
            // 乐观缓存：过期时先返回旧值，后台刷新
            self.spawn_refresh(domain);
            return Ok(cached.into_result());
        }

        // 2. 检查是否应该分配 FakeIP
        if self.should_use_fakeip(domain) {
            let fake_ip = self.fakeip.allocate(domain)?;
            return Ok(ResolveResult::FakeIp(fake_ip));
        }

        // 3. 选择上游
        let upstream = self.routing.select_upstream(domain, &self.upstreams)?;
        
        // 4. 并发去重：同一域名的并发查询合并为一次
        let result = self.singleflight(domain, || {
            upstream.query(domain)
        })?;

        // 5. 写入缓存
        self.cache.put(domain, &result);
        Ok(ResolveResult::RealIp(result))
    }

    fn lookup_fakeip(&self, ip: IpAddr) -> Option<SmolStr> {
        self.fakeip.lookup(ip)
    }

    fn snoop(&self, ip: IpAddr, port: u16) -> Option<SmolStr> {
        // 查询 DNS 查询缓存，恢复域名
        self.cache.snoop(ip, port)
    }
}
```


## 第三章 会话编排层实现

### 3.1 SessionContext 实现

```rust
// crates/ac-session/src/context.rs

pub struct SessionContext {
    /// 会话唯一 ID（用于追踪和日志）
    pub id: u64,
    /// 元数据
    pub metadata: SessionMetadata,
    /// 入站协议状态机
    pub inbound_sm: InboundStateMachine,
    /// 出站适配器句柄
    pub outbound: Option<Arc<dyn ProxyAdapter>>,
    /// 出站流
    pub outbound_stream: Option<ConcreteStream>,
    /// 创建时间
    pub created_at: Instant,
    /// 统计
    pub stats: SessionStats,
}

impl SessionContext {
    /// 创建新会话
    /// 
    /// 关键约束：SessionContext 一旦创建，就不再跨线程移动。
    /// 它属于创建它的 Worker 线程。
    pub fn new(id: u64, metadata: SessionMetadata) -> Self {
        Self {
            id,
            metadata,
            inbound_sm: InboundStateMachine::new(),
            outbound: None,
            outbound_stream: None,
            created_at: Instant::now(),
            stats: SessionStats::default(),
        }
    }

    /// 富化元数据（嗅探、FakeIP 反查）
    pub fn enrich_metadata(&mut self, sniffer: &Sniffer, dns: &dyn DnsResolver) {
        // 1. FakeIP 反查
        if is_fakeip_range(self.metadata.dst_addr.ip()) {
            if let Some(domain) = dns.lookup_fakeip(self.metadata.dst_addr.ip()) {
                self.metadata.set_domain(&domain);
                return;
            }
        }

        // 2. DNS Snooping
        if let Some(domain) = dns.snoop(
            self.metadata.dst_addr.ip(),
            self.metadata.dst_addr.port(),
        ) {
            self.metadata.set_domain(&domain);
            return;
        }

        // 3. 协议嗅探（TLS SNI / QUIC SNI / HTTP Host）
        if let Some(domain) = sniffer.sniff(&self.metadata) {
            self.metadata.set_domain(&domain);
        }
    }
}
```

### 3.2 ConnectionGuard 实现

```rust
// crates/ac-session/src/guard.rs

/// RAII 连接守卫
/// 
/// 在会话创建时构造，在会话销毁时自动释放资源。
/// 关键作用：即使会话因 panic 或提前 return 终止，
/// 也能保证 Slab 缓冲区归还、套接字关闭、指标更新。
pub struct ConnectionGuard {
    session_id: u64,
    slab_handles: Vec<SlabHandle>,
    socket: Option<OwnedFd>,
    metrics: Arc<Metrics>,
    created_at: Instant,
}

impl ConnectionGuard {
    pub fn new(
        session_id: u64,
        metrics: Arc<Metrics>,
    ) -> Self {
        metrics.active_connections.inc();
        Self {
            session_id,
            slab_handles: Vec::new(),
            socket: None,
            metrics,
            created_at: Instant::now(),
        }
    }

    /// 注册 Slab 缓冲区句柄，Drop 时自动归还
    pub fn register_slab(&mut self, handle: SlabHandle) {
        self.slab_handles.push(handle);
    }

    /// 注册套接字，Drop 时自动关闭
    pub fn register_socket(&mut self, fd: OwnedFd) {
        self.socket = Some(fd);
    }
}

impl Drop for ConnectionGuard {
    fn drop(&mut self) {
        // 归还所有 Slab 缓冲区
        for handle in self.slab_handles.drain(..) {
            handle.return_to_pool();
        }
        // 关闭套接字（OwnedFd 的 Drop 自动完成）
        // 更新指标
        self.metrics.active_connections.dec();
        self.metrics
            .session_duration
            .observe(self.created_at.elapsed().as_secs_f64());
    }
}
```


## 第四章 规则引擎实现

### 4.1 DAAC（双数组 AC 自动机）实现

```rust
// crates/ac-rules/src/domain_trie.rs

/// 双数组 AC 自动机
/// 
/// 核心思想：将 AC 自动机的状态转移表压缩为两个线性数组（base 和 check），
/// 消除指针引用，保证内存连续性和 CPU 缓存行命中。
/// 
/// 匹配时间复杂度：O(L)，L 为域名长度，与规则库规模完全解耦。
pub struct DoubleArrayAc {
    /// base 数组：base[s] + c 给出下一状态的索引
    base: Vec<i32>,
    /// check 数组：check[t] == s 表示状态 t 是从状态 s 转移而来
    check: Vec<i32>,
    /// 每个状态对应的规则 ID（0 表示无匹配）
    rule_id: Vec<u32>,
    /// 失败指针（AC 自动机的核心）
    fail: Vec<i32>,
    /// 规则数量
    rule_count: u32,
}

impl DoubleArrayAc {
    /// 从规则列表构建自动机
    pub fn build(rules: &[DomainRule]) -> Result<Self, BuildError> {
        // 1. 构建 Trie 树
        let trie = Trie::build(rules);
        // 2. 从 Trie 构建双数组
        let mut builder = DoubleArrayBuilder::new();
        builder.build_from_trie(&trie)?;
        // 3. 构建失败指针
        let mut ac = builder.finish();
        ac.build_fail_pointers();
        Ok(ac)
    }

    /// 在文本中查找所有匹配的规则
    /// 
    /// 输入：域名（如 "www.example.com"）
    /// 输出：匹配到的规则 ID 列表
    pub fn find_all(&self, text: &str) -> Vec<u32> {
        let mut matches = Vec::new();
        let mut state: i32 = 0;
        
        for (i, byte) in text.bytes().enumerate() {
            // 状态转移（可能回退到失败指针）
            loop {
                let next = self.base[state as usize] + byte as i32;
                if next >= 0
                    && (next as usize) < self.check.len()
                    && self.check[next as usize] == state
                {
                    state = next;
                    break;
                }
                if state == 0 {
                    break;
                }
                state = self.fail[state as usize];
            }
            
            // 沿着失败链收集所有匹配
            let mut s = state;
            while s != 0 {
                let rule = self.rule_id[s as usize];
                if rule != 0 {
                    matches.push(rule);
                }
                s = self.fail[s as usize];
            }
        }
        
        matches
    }

    fn build_fail_pointers(&mut self) {
        // BFS 构建失败指针
        let mut queue = VecDeque::new();
        
        // 根节点的直接子节点失败指针指向根
        for c in 0..256 {
            let next = self.base[0] + c as i32;
            if next >= 0
                && (next as usize) < self.check.len()
                && self.check[next as usize] == 0
            {
                self.fail[next as usize] = 0;
                queue.push_back(next);
            }
        }
        
        // BFS 遍历
        while let Some(state) = queue.pop_front() {
            for c in 0..256 {
                let next = self.base[state as usize] + c as i32;
                if next < 0 || (next as usize) >= self.check.len() {
                    continue;
                }
                if self.check[next as usize] != state {
                    continue;
                }
                // 设置失败指针
                let mut fail = self.fail[state as usize];
                loop {
                    let fail_next = self.base[fail as usize] + c as i32;
                    if fail_next >= 0
                        && (fail_next as usize) < self.check.len()
                        && self.check[fail_next as usize] == fail
                    {
                        self.fail[next as usize] = fail_next;
                        break;
                    }
                    if fail == 0 {
                        self.fail[next as usize] = 0;
                        break;
                    }
                    fail = self.fail[fail as usize];
                }
                queue.push_back(next);
            }
        }
    }
}
```

**性能预期**：对于 50 万条域名规则，`find_all` 在域名长度 20 字节时耗时约 **50-100ns**（与规则数量无关）。

### 4.2 Tree-Bitmap LPM 实现

```rust
// crates/ac-rules/src/ip_tree.rs

/// Tree-Bitmap 最长前缀匹配
/// 
/// 核心思想：将单比特前缀树的多层节点聚合成紧凑的位图结构，
/// 每次读取 4 bit 或 8 bit 计算偏移。
/// 
/// 对于 IPv4，最多 4 次内存跳跃；IPv6 最多 16 次。
pub struct TreeBitmapLpm {
    /// 内部节点
    internal: Vec<InternalNode>,
    /// 叶子节点（存储规则 ID）
    leaves: Vec<LeafNode>,
    /// 规则 ID 到规则的映射
    rules: Vec<IpRule>,
}

/// 8-bit 步长的内部节点
#[repr(C, align(64))]
struct InternalNode {
    /// 子节点位图（256 bit = 32 字节）
    child_bitmap: [u8; 32],
    /// 前缀位图（标记哪些前缀有规则）
    prefix_bitmap: [u8; 32],
    /// 子节点索引（紧凑存储，仅包含 bitmap 中为 1 的项）
    child_ptr: u32,
    /// 前缀规则索引
    prefix_ptr: u32,
    /// 子节点数量
    child_count: u16,
    /// 前缀数量
    prefix_count: u16,
}

impl TreeBitmapLpm {
    /// 查找最长前缀匹配
    pub fn lookup(&self, ip: IpAddr) -> Option<u32> {
        match ip {
            IpAddr::V4(v4) => self.lookup_v4(v4),
            IpAddr::V6(v6) => self.lookup_v6(v6),
        }
    }

    fn lookup_v4(&self, ip: Ipv4Addr) -> Option<u32> {
        let octets = ip.octets();
        let mut node_idx = 0u32;
        let mut best_match: Option<u32> = None;

        // 4 次跳跃，每次处理 8 bit
        for (level, &octet) in octets.iter().enumerate() {
            let node = &self.internal[node_idx as usize];
            
            // 检查前缀匹配
            if (node.prefix_bitmap[octet as usize / 8] 
                >> (octet as usize % 8)) & 1 == 1 {
                // 计算前缀在 prefix_ptr 中的位置
                let prefix_pos = count_ones_before(
                    &node.prefix_bitmap,
                    octet as usize,
                );
                let rule_idx = self.read_prefix(node.prefix_ptr, prefix_pos);
                best_match = Some(rule_idx);
            }

            // 检查子节点
            if (node.child_bitmap[octet as usize / 8]
                >> (octet as usize % 8)) & 1 == 0 {
                // 没有子节点，返回当前最佳匹配
                return best_match;
            }

            let child_pos = count_ones_before(
                &node.child_bitmap,
                octet as usize,
            );
            let child = self.read_child(node.child_ptr, child_pos);
            node_idx = child;
        }

        // 到达叶子节点
        if let Some(rule) = self.leaves[node_idx as usize].rule_id {
            best_match = Some(rule);
        }
        
        best_match
    }

    fn lookup_v6(&self, ip: Ipv6Addr) -> Option<u32> {
        // 16 次跳跃，每次 8 bit
        // 实现与 v4 类似，但使用 16 字节地址
        // ...
        None
    }
}

#[inline(always)]
fn count_ones_before(bitmap: &[u8], pos: usize) -> u32 {
    let mut count = 0u32;
    let full_bytes = pos / 8;
    for &byte in &bitmap[..full_bytes] {
        count += byte.count_ones();
    }
    let remaining = pos % 8;
    if remaining > 0 {
        let mask = (1u8 << remaining) - 1;
        count += (bitmap[full_bytes] & mask).count_ones();
    }
    count
}
```

**性能预期**：IPv4 查找最多 4 次内存跳跃，耗时约 **20-50ns**。

### 4.3 rkyv 序列化与 mmap 加载

```rust
// crates/ac-rules/src/archive.rs

use rkyv::{Archive, Deserialize, Serialize};

#[derive(Archive, Serialize, Deserialize)]
pub struct RuleArchive {
    /// 文件格式版本
    pub format_version: u32,
    /// rkyv 版本
    pub rkyv_version: u32,
    /// 编译器版本哈希
    pub compiler_hash: u64,
    /// 结构体布局哈希
    pub layout_hash: u64,
    /// 域名自动机
    pub domain_ac: ArchivedDoubleArrayAc,
    /// IP 路由表
    pub ip_lpm: ArchivedTreeBitmapLpm,
    /// 规则数量
    pub rule_count: u32,
    /// SHA256 哈希（用于校验）
    pub sha256: [u8; 32],
}

pub struct RuleArchiveLoader {
    mmap: Option<Mmap>,
    archive: Option<&'static RuleArchive>,
    file: Option<File>,
}

impl RuleArchiveLoader {
    /// 安全加载规则归档
    /// 
    /// 关键步骤：
    /// 1. 打开文件并获取共享锁（防止外部截断）
    /// 2. 读取并校验 SHA256 哈希头
    /// 3. madvise(MADV_WILLNEED) 预触发物理页载入
    /// 4. mmap 映射
    /// 5. 校验版本号
    /// 6. rkyv 指针强转
    pub fn load(path: &Path) -> Result<Self, LoadError> {
        // 1. 打开文件并加共享锁
        let file = File::open(path)?;
        file.lock_shared()?;  // flock(LOCK_SH)

        // 2. 读取头部并校验 SHA256
        let mut header = [0u8; 64];
        let mut reader = BufReader::new(&file);
        reader.read_exact(&mut header)?;
        // ... 校验逻辑

        // 3. madvise 预触发
        let mmap = unsafe {
            MmapOptions::new()
                .map(&file)?
        };
        mmap.advise(memmap2::Advice::WillNeed)?;

        // 4. 校验版本号
        let archive = unsafe { rkyv::archived_root::<RuleArchive>(&mmap[64..]) };
        if archive.format_version != CURRENT_FORMAT_VERSION {
            return Err(LoadError::VersionMismatch);
        }
        if archive.layout_hash != compute_layout_hash() {
            return Err(LoadError::LayoutMismatch);
        }

        // 5. 转换为 'static 引用（通过所有权持有 mmap）
        let archive: &'static RuleArchive = unsafe {
            std::mem::transmute(archive)
        };

        Ok(Self {
            mmap: Some(mmap),
            archive: Some(archive),
            file: Some(file),
        })
    }

    pub fn archive(&self) -> &RuleArchive {
        self.archive.expect("archive not loaded")
    }
}

impl Drop for RuleArchiveLoader {
    fn drop(&mut self) {
        // 释放 mmap
        self.mmap.take();
        // 释放文件锁（File 的 Drop 自动完成）
    }
}
```


## 第五章 DNS 子系统实现

### 5.1 分片 LRU 缓存实现

```rust
// crates/ac-dns/src/cache.rs

const SHARD_COUNT: usize = 16;
const SHARD_CAPACITY: usize = 1024;

/// 分片 LRU 缓存
/// 
/// 关键设计：16 个独立分片，每片有自己的锁和 LRU 链表。
/// 并发读写时，不同分片之间不互相阻塞。
pub struct ShardedCache {
    shards: [Mutex<LruShard>; SHARD_COUNT],
}

struct LruShard {
    /// 哈希表：域名 → 缓存条目
    entries: HashMap<SmolStr, CacheEntry>,
    /// LRU 链表：最旧的在头部
    lru: VecDeque<SmolStr>,
    /// 容量
    capacity: usize,
}

struct CacheEntry {
    ips: SmallVec<[IpAddr; 2]>,
    expires_at: Instant,
    /// 是否处于乐观刷新状态
    refreshing: bool,
}

impl ShardedCache {
    pub fn new() -> Self {
        Self {
            shards: std::array::from_fn(|_| {
                Mutex::new(LruShard::new(SHARD_CAPACITY))
            }),
        }
    }

    /// 计算域名所属的分片
    /// 
    /// 使用 FNV-1a 哈希，速度快且分布均匀。
    fn shard_for(&self, domain: &str) -> usize {
        let mut hash: u64 = 0xcbf29ce484222325;
        for byte in domain.bytes() {
            hash ^= byte as u64;
            hash = hash.wrapping_mul(0x100000001b3);
        }
        (hash as usize) % SHARD_COUNT
    }

    pub fn get(&self, domain: &str) -> Option<CacheEntry> {
        let shard_idx = self.shard_for(domain);
        let mut shard = self.shards[shard_idx].lock().unwrap();
        shard.get(domain)
    }

    pub fn put(&self, domain: &str, ips: &[IpAddr]) {
        let shard_idx = self.shard_for(domain);
        let mut shard = self.shards[shard_idx].lock().unwrap();
        shard.put(domain, ips);
    }

    /// 查询最近的 DNS 查询（用于 Snooping）
    pub fn snoop(&self, ip: IpAddr, _port: u16) -> Option<SmolStr> {
        // 遍历所有分片，查找 IP 对应的域名
        // 注意：这是低频操作，可以接受遍历
        for shard in &self.shards {
            let shard = shard.lock().unwrap();
            if let Some(domain) = shard.find_by_ip(ip) {
                return Some(domain);
            }
        }
        None
    }
}
```

### 5.2 FakeIP 原子位图池实现

```rust
// crates/ac-dns/src/fakeip.rs

use std::sync::atomic::{AtomicU64, Ordering};

/// FakeIP 池
/// 
/// 使用原子位图管理 198.18.0.0/15 网段的虚拟 IP。
/// 分配和回收都是 O(1) 常数时间，耗时 < 50ns。
pub struct FakeIpPool {
    /// 原子位图：每一位代表一个 IP 是否被占用
    bitmap: Box<[AtomicU64]>,
    /// 反向映射：IP 索引 → 域名
    reverse: RwLock<HashMap<u32, ReverseEntry>>,
    /// 下一个候选位置（优化分配性能）
    next_hint: AtomicU64,
    /// 池容量
    capacity: u32,
}

struct ReverseEntry {
    domain: SmolStr,
    allocated_at: Instant,
    expires_at: Instant,
}

impl FakeIpPool {
    /// 创建 FakeIP 池
    /// 
    /// 默认使用 198.18.0.0/15，容量 131072 个 IP。
    pub fn new() -> Self {
        let capacity = 131_072;  // 2^17
        let bitmap_words = (capacity as usize + 63) / 64;
        let bitmap = (0..bitmap_words)
            .map(|_| AtomicU64::new(0))
            .collect::<Vec<_>>()
            .into_boxed_slice();

        Self {
            bitmap,
            reverse: RwLock::new(HashMap::with_capacity(1024)),
            next_hint: AtomicU64::new(0),
            capacity,
        }
    }

    /// 分配一个 FakeIP
    /// 
    /// 返回 198.18.x.x 格式的 IP。
    pub fn allocate(&self, domain: &str) -> Result<IpAddr, FakeIpError> {
        // 从 hint 开始扫描空闲位
        let start = self.next_hint.load(Ordering::Relaxed);
        
        for i in 0..self.capacity {
            let idx = (start + i as u64) % self.capacity as u64;
            if self.try_set_bit(idx as u32) {
                // 更新 hint
                self.next_hint.store(idx + 1, Ordering::Relaxed);
                
                // 计算 IP
                let ip = self.index_to_ip(idx as u32);
                
                // 写入反向映射
                let mut reverse = self.reverse.write().unwrap();
                reverse.insert(idx as u32, ReverseEntry {
                    domain: SmolStr::new(domain),
                    allocated_at: Instant::now(),
                    expires_at: Instant::now() + Duration::from_secs(300),
                });
                
                return Ok(ip);
            }
        }
        
        Err(FakeIpError::PoolExhausted)
    }

    /// 释放 FakeIP
    pub fn release(&self, ip: IpAddr) {
        if let Some(idx) = self.ip_to_index(ip) {
            self.clear_bit(idx);
            let mut reverse = self.reverse.write().unwrap();
            reverse.remove(&idx);
        }
    }

    /// 反向查询
    pub fn lookup(&self, ip: IpAddr) -> Option<SmolStr> {
        let idx = self.ip_to_index(ip)?;
        let reverse = self.reverse.read().unwrap();
        reverse.get(&idx).map(|e| e.domain.clone())
    }

    /// 双重过期回收
    /// 
    /// 每个 FakeIP 绑定两个过期时间：
    /// 1. 连接超时（由应用层触发释放）
    /// 2. 全局 TTL（5 分钟，即使应用层未释放也自动回收）
    pub fn garbage_collect(&self) {
        let now = Instant::now();
        let mut reverse = self.reverse.write().unwrap();
        let mut to_release = Vec::new();
        
        for (&idx, entry) in reverse.iter() {
            if now >= entry.expires_at {
                to_release.push(idx);
            }
        }
        
        for idx in to_release {
            self.clear_bit(idx);
            reverse.remove(&idx);
        }
    }

    #[inline]
    fn try_set_bit(&self, idx: u32) -> bool {
        let word_idx = (idx / 64) as usize;
        let bit_idx = idx % 64;
        let mask = 1u64 << bit_idx;
        
        let word = &self.bitmap[word_idx];
        let old = word.fetch_or(mask, Ordering::AcqRel);
        (old & mask) == 0
    }

    #[inline]
    fn clear_bit(&self, idx: u32) {
        let word_idx = (idx / 64) as usize;
        let bit_idx = idx % 64;
        let mask = !(1u64 << bit_idx);
        self.bitmap[word_idx].fetch_and(mask, Ordering::AcqRel);
    }

    fn index_to_ip(&self, idx: u32) -> IpAddr {
        // 198.18.0.0/15 网段，共 131072 个地址
        let base = u32::from(Ipv4Addr::new(198, 18, 0, 0));
        IpAddr::V4(Ipv4Addr::from(base + idx))
    }

    fn ip_to_index(&self, ip: IpAddr) -> Option<u32> {
        match ip {
            IpAddr::V4(v4) => {
                let base = u32::from(Ipv4Addr::new(198, 18, 0, 0));
                let addr = u32::from(v4);
                if addr >= base && addr < base + self.capacity {
                    Some(addr - base)
                } else {
                    None
                }
            }
            _ => None,
        }
    }
}
```


## 第六章 传输层实现

### 6.1 TLS 层实现

```rust
// crates/ac-transport/src/tls.rs

use tokio_rustls::{TlsConnector, client::TlsStream};

pub struct TlsLayer {
    connector: TlsConnector,
    server_name: ServerName,
}

impl TlsLayer {
    pub fn new(config: &TlsConfig, metadata: &SessionMetadata) -> Result<Self, TlsError> {
        // 构造 rustls ClientConfig
        let mut root_store = RootCertStore::empty();
        // ... 加载根证书
        
        let client_config = ClientConfig::builder()
            .with_root_certificates(root_store)
            .with_no_client_auth();
        
        let connector = TlsConnector::from(Arc::new(client_config));
        
        // 确定 SNI
        let server_name = if metadata.has_domain() {
            ServerName::try_from(metadata.domain.as_str())?
        } else {
            ServerName::IpAddress(metadata.dst_addr.ip())?
        };
        
        Ok(Self { connector, server_name })
    }

    /// 执行 TLS 握手
    /// 
    /// 关键约束：此函数是异步的，但不应该在协议状态机中调用。
    /// 它由 Worker Loop 在"连接建立"阶段驱动。
    pub async fn handshake(
        &self,
        stream: TcpStream,
    ) -> Result<TlsStream<TcpStream>, TlsError> {
        let tls = self.connector
            .connect(self.server_name.clone(), stream)
            .await?;
        Ok(tls)
    }
}
```

### 6.2 WebSocket 层实现

```rust
// crates/ac-transport/src/ws.rs

use tokio_tungstenite::{WebSocketStream, client_async};

pub struct WsLayer {
    config: WsConfig,
}

impl WsLayer {
    /// 在已有流上执行 WebSocket 握手
    pub async fn handshake<S>(
        &self,
        stream: S,
        metadata: &SessionMetadata,
    ) -> Result<WebSocketStream<S>, WsError>
    where
        S: AsyncRead + AsyncWrite + Unpin,
    {
        // 构造 WebSocket 请求
        let host = if metadata.has_domain() {
            metadata.domain.as_str()
        } else {
            "localhost"
        };
        
        let request = http::Request::builder()
            .uri(format!("wss://{}{}", host, self.config.path))
            .header("Host", host)
            .header("Upgrade", "websocket")
            .header("Connection", "Upgrade")
            .header("Sec-WebSocket-Key", generate_ws_key())
            .header("Sec-WebSocket-Version", "13")
            .body(())?;
        
        let (ws, _response) = client_async(request, stream).await?;
        Ok(ws)
    }
}
```


## 第七章 协议状态机实现

### 7.1 Shadowsocks 2022 实现

```rust
// crates/ac-outbound/src/shadowsocks/state_machine.rs

use aes_gcm::{Aes256Gcm, KeyInit, aead::Aead};
use blake3::Hasher;

/// Shadowsocks 2022 (AEAD-2022) 状态机
pub struct Shadowsocks2022Sm {
    /// 预共享密钥
    psk: [u8; 32],
    /// 会话密钥（握手后派生）
    session_key: Option<[u8; 32]>,
    /// 客户端会话 ID
    client_session_id: [u8; 8],
    /// 发送计数器
    send_counter: u64,
    /// 接收计数器
    recv_counter: u64,
    /// 状态
    state: SsState,
    /// 待发送的握手数据
    pending_handshake: Vec<u8, 256>,
    /// 输入累积
    input_buf: Vec<u8, 16384>,
    /// 输出缓冲
    output_buf: Vec<u8, 16384>,
    /// 目标地址（握手时确定）
    target: Option<TargetAddr>,
}

#[derive(Debug, Clone, Copy, PartialEq)]
enum SsState {
    /// 等待发送握手
    Init,
    /// 握手已发送，等待服务端响应
    Handshaking,
    /// 已建立，正常转发
    Established,
    /// 已关闭
    Closed,
}

impl Shadowsocks2022Sm {
    pub fn new(psk: [u8; 32], target: TargetAddr) -> Self {
        let mut client_session_id = [0u8; 8];
        rand::thread_rng().fill_bytes(&mut client_session_id);
        
        Self {
            psk,
            session_key: None,
            client_session_id,
            send_counter: 0,
            recv_counter: 0,
            state: SsState::Init,
            pending_handshake: Vec::new(),
            input_buf: Vec::new(),
            output_buf: Vec::new(),
            target: Some(target),
        }
    }

    /// 构造握手请求
    /// 
    /// Shadowsocks 2022 握手格式：
    /// +--------+--------+--------+--------+
    /// | 版本(1) | 会话ID(8) | 时间戳(8) | 类型(1) |
    /// +--------+--------+--------+--------+
    /// |           目标地址变长编码          |
    /// +--------+--------+--------+--------+
    /// |           AEAD 加密的载荷          |
    /// +--------+--------+--------+--------+
    fn build_handshake(&mut self) -> Result<(), SsError> {
        let mut header = Vec::with_capacity(64);
        
        // 版本
        header.push(0x02);
        // 会话 ID
        header.extend_from_slice(&self.client_session_id);
        // 时间戳
        let timestamp = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .unwrap()
            .as_secs();
        header.extend_from_slice(&timestamp.to_be_bytes());
        // 类型：客户端请求
        header.push(0x00);
        
        // 目标地址变长编码
        let target = self.target.as_ref().unwrap();
        target.encode_variable_length(&mut header);
        
        // 派生会话密钥
        let session_key = self.derive_session_key(&header)?;
        self.session_key = Some(session_key);
        
        // AEAD 加密头部
        let cipher = Aes256Gcm::new_from_slice(&session_key)?;
        let nonce = self.make_nonce(0);
        let ciphertext = cipher.encrypt(&nonce, header.as_slice())?;
        
        self.pending_handshake.extend_from_slice(&ciphertext)?;
        self.state = SsState::Handshaking;
        Ok(())
    }

    fn derive_session_key(&self, header: &[u8]) -> Result<[u8; 32], SsError> {
        // BLAKE3 密钥派生
        let mut hasher = Hasher::new_keyed(&self.psk);
        hasher.update(header);
        hasher.update(b"shadowsocks-2022-session");
        let hash = hasher.finalize();
        let mut key = [0u8; 32];
        key.copy_from_slice(&hash.as_bytes()[..32]);
        Ok(key)
    }

    fn make_nonce(&self, counter: u64) -> [u8; 12] {
        let mut nonce = [0u8; 12];
        nonce[..8].copy_from_slice(&self.client_session_id);
        nonce[8..].copy_from_slice(&counter.to_be_bytes()[..4]);
        nonce
    }
}

impl ProtocolStateMachine for Shadowsocks2022Sm {
    type Action = SsAction;
    type Error = SsError;

    fn on_network_input(&mut self, data: &[u8]) -> Result<(), Self::Error> {
        if self.input_buf.len() + data.len() > 16384 {
            return Err(SsError::BufferOverflow);
        }
        self.input_buf.extend_from_slice(data);

        match self.state {
            SsState::Handshaking => {
                // 等待服务端响应（可能为空）
                if self.input_buf.len() >= 16 {
                    // 解析响应头（简化）
                    self.state = SsState::Established;
                }
            }
            SsState::Established => {
                // 解密数据
                self.decrypt_data()?;
            }
            _ => {}
        }
        Ok(())
    }

    fn poll_network_output<'a>(
        &'a mut self,
        out_buf: &'a mut [u8],
    ) -> Option<usize> {
        if !self.pending_handshake.is_empty() {
            let n = self.pending_handshake.len().min(out_buf.len());
            out_buf[..n].copy_from_slice(&self.pending_handshake[..n]);
            self.pending_handshake.drain(..n);
            return Some(n);
        }
        if self.output_buf.is_empty() {
            return None;
        }
        let n = self.output_buf.len().min(out_buf.len());
        out_buf[..n].copy_from_slice(&self.output_buf[..n]);
        self.output_buf.drain(..n);
        Some(n)
    }

    fn on_app_input(&mut self, plaintext: &[u8]) -> Result<(), Self::Error> {
        if self.state != SsState::Established {
            return Err(SsError::NotEstablished);
        }
        // 加密应用数据
        let cipher = Aes256Gcm::new_from_slice(
            self.session_key.as_ref().unwrap()
        )?;
        let nonce = self.make_nonce(self.send_counter);
        self.send_counter += 1;
        let ciphertext = cipher.encrypt(&nonce, plaintext)?;
        
        // 写入输出缓冲
        if self.output_buf.len() + ciphertext.len() > 16384 {
            return Err(SsError::BufferOverflow);
        }
        self.output_buf.extend_from_slice(&ciphertext);
        Ok(())
    }

    fn poll_app_output<'a>(
        &'a mut self,
        out_buf: &'a mut [u8],
    ) -> Option<usize> {
        // 从 input_buf 取解密后的数据
        if self.input_buf.is_empty() {
            return None;
        }
        let n = self.input_buf.len().min(out_buf.len());
        out_buf[..n].copy_from_slice(&self.input_buf[..n]);
        self.input_buf.drain(..n);
        Some(n)
    }

    fn handle_tick(&mut self, _now_ms: u64) -> Option<Self::Action> {
        None
    }
}

impl Shadowsocks2022Sm {
    fn decrypt_data(&mut self) -> Result<(), SsError> {
        // 从 input_buf 读取密文并解密
        // ...
        Ok(())
    }
}
```


## 第八章 内存管理实现

### 8.1 ByteSlab 实现

```rust
// crates/ac-worker/src/slab.rs

/// 线程本地 Slab 池
/// 
/// 编译期确定大小，运行期只做"借出/归还"。
/// 关键约束：每个 Worker 线程独立持有，无跨线程竞争。
pub struct SlabPool<const N: usize, const ALIGN: usize> {
    /// 预分配的缓冲区
    buffers: UnsafeCell<[AlignedBuffer; N]>,
    /// 空闲列表（栈式分配器）
    free_list: UnsafeCell<Vec<usize>>,
    /// 缓冲区大小
    buffer_size: usize,
}

#[repr(align(64))]
pub struct AlignedBuffer {
    data: [u8; 65536],
    /// 状态标记（用于调试）
    state: AtomicU8,
}

impl<const N: usize, const ALIGN: usize> SlabPool<N, ALIGN> {
    pub const fn new(buffer_size: usize) -> Self {
        Self {
            buffers: UnsafeCell::new([AlignedBuffer::new(); N]),
            free_list: UnsafeCell::new(Vec::new()),
            buffer_size,
        }
    }

    /// 初始化（在 Worker 启动时调用一次）
    /// 
    /// 关键步骤：
    /// 1. 尝试 mlock 锁定内存（可能失败，降级）
    /// 2. prefault 预热所有页面
    /// 3. 初始化空闲列表
    pub fn init(&self) {
        unsafe {
            let buffers = &mut *self.buffers.get();
            for (i, buf) in buffers.iter_mut().enumerate() {
                // prefault 预热
                std::ptr::write_bytes(buf.data.as_mut_ptr(), 0, buf.data.len());
                // 加入空闲列表
                (*self.free_list.get()).push(i);
            }

            // 尝试 mlock（失败则降级）
            let ptr = buffers.as_ptr() as *mut libc::c_void;
            let size = std::mem::size_of_val(buffers);
            if libc::mlock(ptr, size) != 0 {
                let err = std::io::Error::last_os_error();
                tracing::warn!(
                    "mlock 失败（无 CAP_IPC_LOCK 权限？），降级为 prefault 模式: {}",
                    err
                );
            }
        }
    }

    /// 借出一个缓冲区
    #[inline]
    pub fn acquire(&self) -> Option<SlabHandle> {
        unsafe {
            let free_list = &mut *self.free_list.get();
            free_list.pop().map(|idx| SlabHandle {
                pool: self as *const _ as *const (),
                index: idx,
            })
        }
    }

    /// 归还缓冲区（由 SlabHandle::return_to_pool 调用）
    unsafe fn return_buffer(&self, idx: usize) {
        let free_list = &mut *self.free_list.get();
        free_list.push(idx);
    }
}

/// Slab 缓冲区句柄
/// 
/// 关键约束：必须显式调用 `return_to_pool` 或由 ConnectionGuard 自动归还。
/// 忘记归还会导致缓冲区泄漏（但不会导致 UB）。
pub struct SlabHandle {
    pool: *const (),
    index: usize,
}

impl SlabHandle {
    pub fn return_to_pool(self) {
        // 归还缓冲区
        unsafe {
            // 通过类型擦除的指针调用 return_buffer
            // 实际实现需要使用更安全的机制
        }
        std::mem::forget(self);  // 防止 Drop 重复归还
    }
}
```

### 8.2 mimalloc 配置

```rust
// crates/ac-app/src/main.rs

#[global_allocator]
static GLOBAL: mimalloc::MiMalloc = mimalloc::MiMalloc;

fn main() {
    // mimalloc 默认配置已经足够好
    // 如需调优，可通过环境变量：
    // MIMALLOC_SHOW_STATS=1  # 显示统计
    // MIMALLOC_EAGER_COMMIT=0  # 延迟提交
    // MIMALLOC_ARENA_EAGER_COMMIT=0
}
```


## 第九章 I/O 调度器实现

### 9.1 Worker Loop 实现

```rust
// crates/ac-worker/src/loop.rs

/// Worker Loop：每个物理核心一个实例
/// 
/// 关键约束：Worker Loop 是单线程的，不跨线程共享状态。
/// 它拥有自己的 Slab 池、协议状态机、连接表。
pub struct WorkerLoop {
    /// Worker ID（0 到 N-1）
    id: usize,
    /// Slab 池
    slab: &'static SlabPool<4096, 64>,
    /// 连接表（仅本线程可见）
    connections: HashMap<u64, SessionContext>,
    /// 规则引擎（ArcSwap 无锁读取）
    rules: Arc<ArcSwap<RuleEngine>>,
    /// DNS 解析器
    dns: Arc<dyn DnsResolver>,
    /// 会话 ID 生成器
    next_session_id: u64,
    /// 指标
    metrics: Arc<Metrics>,
}

impl WorkerLoop {
    /// 运行事件循环
    /// 
    /// 使用 Tokio current_thread 运行时。
    /// 关键：LocalSet 允许非 Send 的 future 在单线程内执行。
    pub fn run(self) -> ! {
        let rt = tokio::runtime::Builder::new_current_thread()
            .enable_all()
            .build()
            .unwrap();

        let local = tokio::task::LocalSet::new();
        
        // 设置 CPU 亲和性
        set_cpu_affinity(self.id);

        local.block_on(&rt, async move {
            self.event_loop().await
        });

        unreachable!()
    }

    async fn event_loop(mut self) {
        // 创建监听器
        let listener = TcpListener::bind(self.config.listen_addr).await.unwrap();

        loop {
            // 接受新连接
            let (stream, peer_addr) = listener.accept().await.unwrap();
            
            // 创建会话
            let session_id = self.next_session_id;
            self.next_session_id += 1;
            
            // 处理连接（不 spawn，直接在 LocalSet 中运行）
            // 关键：使用 join! 或 FuturesUnordered 管理多个连接
            let ctx = SessionContext::new(session_id, SessionMetadata {
                src_addr: peer_addr,
                ..Default::default()
            });
            
            // 驱动会话
            self.drive_session(ctx, stream).await;
        }
    }

    /// 驱动单个会话的完整生命周期
    async fn drive_session(
        &mut self,
        mut ctx: SessionContext,
        mut inbound_stream: TcpStream,
    ) {
        let mut guard = ConnectionGuard::new(ctx.id, self.metrics.clone());
        
        // 阶段 1：入站协议握手
        if let Err(e) = self.handle_inbound_handshake(&mut ctx, &mut inbound_stream).await {
            tracing::debug!(session_id = ctx.id, error = ?e, "inbound handshake failed");
            return;
        }

        // 阶段 2：元数据富化
        ctx.enrich_metadata(&self.sniffer, self.dns.as_ref());

        // 阶段 3：路由决策
        let rules = self.rules.load();
        let outbound = match rules.match_outbound(&ctx.metadata) {
            Some(adapter) => adapter,
            None => {
                tracing::debug!(session_id = ctx.id, "no matching outbound");
                return;
            }
        };
        ctx.outbound = Some(outbound.clone());

        // 阶段 4：出站连接
        let outbound_stream = match self.dial_outbound(&ctx, &outbound).await {
            Ok(s) => s,
            Err(e) => {
                tracing::debug!(session_id = ctx.id, error = ?e, "outbound dial failed");
                return;
            }
        };
        ctx.outbound_stream = Some(outbound_stream);

        // 阶段 5：双向中继
        self.relay(&mut ctx, inbound_stream, outbound_stream).await;
    }

    /// 双向中继（零拷贝）
    async fn relay(
        &mut self,
        ctx: &mut SessionContext,
        mut inbound: TcpStream,
        mut outbound: ConcreteStream,
    ) {
        // 关键：使用 tokio::io::copy_bidirectional
        // 它内部使用 BytesMut 零拷贝缓冲区
        match tokio::io::copy_bidirectional(&mut inbound, &mut outbound).await {
            Ok((from_in, from_out)) => {
                ctx.stats.bytes_in = from_in;
                ctx.stats.bytes_out = from_out;
            }
            Err(e) => {
                tracing::debug!(session_id = ctx.id, error = ?e, "relay error");
            }
        }
    }
}
```


## 第十章 控制面实现

### 10.1 ArcSwap 配置热重载

```rust
// crates/ac-api/src/state.rs

use arc_swap::ArcSwap;

/// 全局配置状态
/// 
/// 关键设计：使用 ArcSwap 实现无锁读取。
/// 读取操作 ≈ 指针解引用，纳秒级。
/// 写入操作（热重载）是原子的，不阻塞读取。
pub struct AppState {
    /// 当前 Epoch
    pub epoch: ArcSwap<Epoch>,
    /// 指标
    pub metrics: Arc<Metrics>,
}

pub struct Epoch {
    pub id: u64,
    pub rules: Arc<RuleEngine>,
    pub dns: Arc<dyn DnsResolver>,
    pub inbounds: Vec<Arc<dyn InboundListener>>,
    pub outbounds: HashMap<String, Arc<dyn ProxyAdapter>>,
    pub created_at: Instant,
}

impl AppState {
    /// 热重载配置
    /// 
    /// 关键步骤：
    /// 1. 在后台构建新 Epoch（不阻塞数据面）
    /// 2. 校验新 Epoch 的合法性
    /// 3. 原子替换
    /// 4. 旧 Epoch 在最后一个读者离开后自动释放
    pub async fn reload(&self, config: Config) -> Result<(), ReloadError> {
        // 1. 构建新 Epoch
        let new_epoch = self.build_epoch(config).await?;
        
        // 2. 校验
        new_epoch.validate()?;
        
        // 3. 原子替换
        let old_epoch = self.epoch.swap(Arc::new(new_epoch));
        
        // 4. 旧 Epoch 的 Drop 会在最后一个 Arc 引用释放后自动执行
        tracing::info!(
            old_epoch_id = old_epoch.id,
            new_epoch_id = self.epoch.load().id,
            "配置热重载完成"
        );
        
        Ok(())
    }

    async fn build_epoch(&self, config: Config) -> Result<Epoch, ReloadError> {
        // 在辅助线程中构建规则引擎、DNS 解析器等
        let rules = tokio::task::spawn_blocking(move || {
            RuleEngine::build(&config.rules)
        }).await??;
        
        let dns = self.build_dns(&config.dns).await?;
        let inbounds = self.build_inbounds(&config.inbounds).await?;
        let outbounds = self.build_outbounds(&config.outbounds).await?;
        
        Ok(Epoch {
            id: self.epoch.load().id + 1,
            rules: Arc::new(rules),
            dns: Arc::new(dns),
            inbounds,
            outbounds,
            created_at: Instant::now(),
        })
    }
}
```


## 第十一章 测试策略

### 11.1 单元测试

**协议状态机测试**：不需要 mock 任何网络，直接断言字节输入输出。

```rust
#[test]
fn test_socks5_full_flow() {
    let mut sm = Socks5StateMachine::new(AuthConfig::none(), 30_000);
    
    // 握手
    sm.on_network_input(&[0x05, 0x01, 0x00]).unwrap();
    assert_eq!(read_output(&mut sm), vec![0x05, 0x00]);
    
    // 请求
    sm.on_network_input(&[
        0x05, 0x01, 0x00, 0x01,  // 版本 命令 保留 地址类型
        127, 0, 0, 1,             // IPv4
        0x00, 0x50,               // 端口 80
    ]).unwrap();
    
    // 模拟连接建立
    sm.on_connected("127.0.0.1:12345".parse().unwrap()).unwrap();
    assert_eq!(read_output(&mut sm), vec![
        0x05, 0x00, 0x00, 0x01,
        127, 0, 0, 1,
        0x30, 0x39,
    ]);
}
```

### 11.2 集成测试

```rust
// tests/integration/socks5_direct.rs

#[tokio::test]
async fn test_socks5_to_direct() {
    // 启动测试 HTTP 服务器
    let server = TestHttpServer::start().await;
    
    // 启动 AetherCore
    let kernel = TestKernel::start(Config {
        inbounds: vec![InboundConfig::Socks5 {
            listen: "127.0.0.1:1080".parse().unwrap(),
        }],
        outbounds: vec![OutboundConfig::Direct],
        ..Default::default()
    }).await;
    
    // 使用 curl 通过 SOCKS5 访问
    let output = Command::new("curl")
        .args(&[
            "-x", "socks5://127.0.0.1:1080",
            &format!("http://127.0.0.1:{}/", server.port()),
        ])
        .output()
        .await
        .unwrap();
    
    assert!(output.status.success());
    assert_eq!(output.stdout, b"Hello, World!");
    
    kernel.shutdown().await;
    server.shutdown().await;
}
```

### 11.3 性能基准测试

```rust
// benches/relay_throughput.rs

use criterion::{criterion_group, criterion_main, Criterion, Throughput};

fn bench_relay_throughput(c: &mut Criterion) {
    let mut group = c.benchmark_group("relay");
    group.throughput(Throughput::Bytes(1024 * 1024));  // 1 MB

    group.bench_function("copy_bidirectional", |b| {
        b.to_async(tokio::runtime::Runtime::new().unwrap())
            .iter(|| async {
                let (client, server) = tokio::io::duplex(64 * 1024);
                // ... 执行 relay
            });
    });

    group.finish();
}

criterion_group!(benches, bench_relay_throughput);
criterion_main!(benches);
```


## 第十二章 性能基准

### 12.1 基准测试矩阵

| 基准测试 | 目标 | 工具 | 预期值 |
|---|---|---|---|
| SOCKS5 握手延迟 | 协议状态机性能 | criterion | < 10μs |
| 规则匹配（DAAC） | 域名路由性能 | criterion | < 100ns |
| 规则匹配（Tree-Bitmap） | IP 路由性能 | criterion | < 50ns |
| FakeIP 分配 | 原子位图性能 | criterion | < 50ns |
| 双向中继吞吐 | 零拷贝性能 | criterion | > 10 Gbps |
| TLS 握手延迟 | rustls 性能 | criterion | < 5ms |
| 内存占用 | RSS 基线 | /proc/self/status | < 15MB |
| 二进制体积 | stripped aarch64 | cargo bloat | < 8MB |

### 12.2 基准测试运行

```bash
# 运行所有基准测试
cargo bench

# 生成火焰图
cargo flamegraph --bench relay_throughput

# 内存分析
valgrind --tool=massif target/release/ac-app

# 二进制体积分析
cargo bloat --release --crates
```


## 第十三章 常见陷阱与反模式

### 13.1 陷阱清单

| 陷阱 | 表现 | 正确做法 |
|---|---|---|
| 协议状态机中调用 `Instant::now()` | 无法穷举测试 | 通过 `handle_tick(now_ms)` 注入 |
| 热路径使用 `Box<dyn AsyncStream>` | vtable 穿透，LLVM 无法内联 | 使用 `enum_dispatch` |
| 混用 Tokio 和 Monoio | 二进制膨胀，缓冲区语义冲突 | 编译期二选一 |
| `mlock` 失败导致崩溃 | 容器中无 CAP_IPC_LOCK | 降级为 prefault |
| mmap 文件被截断 | SIGBUS 崩溃 | SHA256 + flock + madvise |
| `splice(2)` 用于加密流量 | 协议头无法剥离 | 严格三级条件判定 |
| FakeIP 未回收 | 缓存污染 | 双重过期机制 |
| 热路径 `unwrap()` | panic 导致服务崩溃 | 显式 `Result` |
| `String` 存储域名 | 每连接堆分配 | `SmolStr` 栈内联 |
| `RwLock` 保护规则表 | 高并发下锁竞争 | `ArcSwap` 无锁读取 |

### 13.2 反模式示例

```rust
// ❌ 反模式 1：热路径动态分发
async fn relay(stream: Box<dyn AsyncStream>) { ... }

// ✅ 正确：静态分发
async fn relay(stream: ConcreteStream) { ... }


// ❌ 反模式 2：协议状态机感知 Socket
impl ProtocolStateMachine for Socks5Sm {
    async fn handshake(&mut self, stream: TcpStream) { ... }
}

// ✅ 正确：状态机不感知 Socket
impl ProtocolStateMachine for Socks5Sm {
    fn on_network_input(&mut self, data: &[u8]) -> Result<(), Error> { ... }
}


// ❌ 反模式 3：热路径 String 分配
fn handle(domain: String) { ... }

// ✅ 正确：SmolStr 栈内联
fn handle(domain: SmolStr) { ... }


// ❌ 反模式 4：规则表 RwLock
static RULES: RwLock<RuleTable> = ...;

// ✅ 正确：ArcSwap 无锁读取
static RULES: ArcSwap<RuleTable> = ...;


// ❌ 反模式 5：mmap 无校验
let archive = unsafe { rkyv::archived_root::<Archive>(&mmap) };

// ✅ 正确：先校验 SHA256 和版本
verify_sha256(&mmap)?;
verify_version(&mmap)?;
let archive = unsafe { rkyv::archived_root::<Archive>(&mmap) };
```


## 第十四章 依赖管理

### 14.1 核心依赖清单

| 依赖 | 版本 | 用途 | 替换方案 |
|---|---|---|---|
| tokio | 1.x | 异步运行时（主路径） | monoio（Linux） |
| monoio | 0.2.x | io_uring 运行时（可选） | — |
| bytes | 1.x | 零拷贝缓冲区 | — |
| smol_str | 0.2.x | 短字符串栈内联 | — |
| smallvec | 1.x | 小数组栈内联 | — |
| heapless | 0.8.x | 无堆容器 | — |
| arc-swap | 1.x | 无锁配置切换 | — |
| crossbeam | 0.8.x | 无锁通道 | — |
| mimalloc | 0.1.x | 全局分配器 | jemalloc |
| rustls | 0.23.x | TLS（主路径） | boring（指纹伪装） |
| aws-lc-rs | 1.x | 加密后端 | ring |
| quinn | 0.11.x | QUIC | — |
| rkyv | 0.8.x | 零拷贝序列化 | — |
| enum_dispatch | 0.3.x | 静态分发 | — |
| tracing | 0.1.x | 结构化日志 | — |
| axum | 0.8.x | REST API | — |
| nix | 0.29.x | 系统调用 | libc |
| libc | 0.2.x | 系统调用 | — |

### 14.2 禁止依赖清单

| 禁止依赖 | 原因 | 替代方案 |
|---|---|---|
| serde（热路径） | 运行时反射开销 | 手写序列化 |
| opentelemetry（默认） | 二进制膨胀 4-8MB | 轻量 Prometheus |
| openssl | C 依赖 + 体积 | rustls |
| hyper（全功能） | 二进制膨胀 | axum 最小特性 |
| reqwest | 二进制膨胀 | 手写 HTTP |

### 14.3 依赖审计

```bash
# 检查依赖树
cargo tree

# 检查重复依赖
cargo tree --duplicates

# 检查二进制体积贡献
cargo bloat --release --crates

# 检查安全漏洞
cargo audit

# 检查许可证
cargo deny check licenses
```


## 第十五章 构建与发布

### 15.1 构建配置

```toml
# Cargo.toml

[profile.release]
opt-level = 3
lto = "fat"
codegen-units = 1
panic = "abort"
strip = true
debug = false

[profile.release.package."*"]
opt-level = 3
```

### 15.2 PGO 优化流程

```bash
# 1. 构建 instrumented 版本
RUSTFLAGS="-Cprofile-generate=/tmp/pgo-data" \
    cargo build --release

# 2. 运行真实流量采集 profile
./target/release/ac-app --config test-config.json &
# 用 wrk / hey 等工具压测
wrk -t4 -c100 -d30s http://127.0.0.1:1080
kill %1

# 3. 合并 profile
llvm-profdata merge -o /tmp/pgo-data/merged.profdata \
    /tmp/pgo-data

# 4. 使用 profile 重新构建
RUSTFLAGS="-Cprofile-use=/tmp/pgo-data/merged.profdata" \
    cargo build --release

# 预期收益：+10% 性能
```

### 15.3 发布检查清单

- [ ] `cargo test --all-features` 通过
- [ ] `cargo clippy --all-features -- -D warnings` 通过
- [ ] `cargo audit` 无漏洞
- [ ] `cargo bloat --release` 二进制体积 < 8MB
- [ ] 空载 RSS < 15MB
- [ ] 基准测试无回归
- [ ] PGO 优化已应用
- [ ] 版本号已更新
- [ ] CHANGELOG 已更新
- [ ] 发布说明已编写


## 附录 A：代码审查检查清单

| 检查项 | 通过标准 |
|---|---|
| 热路径无 `unwrap()` | 所有错误显式处理 |
| 热路径无 `String` / `Vec<u8>` | 使用 `SmolStr` / `SmallVec` / `Bytes` |
| 热路径无 `Mutex` / `RwLock` | 使用 `ArcSwap` / `crossbeam` |
| 协议状态机无 I/O 依赖 | `ac-common` 无 tokio 依赖 |
| 传输层使用 `enum_dispatch` | 无 `Box<dyn AsyncStream>` |
| Slab 缓冲区有 RAII 管理 | `ConnectionGuard` 注册 |
| mmap 有 SHA256 校验 | 加载前校验 |
| SIMD 有运行时检测 | `is_x86_feature_detected!` |
| CPU 亲和性已设置 | `sched_setaffinity` |
| 内存已 prefault | 启动时写入预热 |

## 附录 B：性能调优速查表

| 场景 | 调优手段 | 预期收益 |
|---|---|---|
| 高并发小包 | `io_uring` + `PBUF_RING` | 吞吐 +2.76x |
| 规则匹配慢 | DAAC + Tree-Bitmap | O(L) 复杂度 |
| 内存占用高 | `SmolStr` + `SmallVec` + Slab | RSS -50% |
| 二进制过大 | feature 裁剪 + rustls | 体积 -5MB |
| 尾部延迟抖动 | Thread-per-Core | P9999 -92% |
| TLS 握手慢 | 会话复用 + 0-RTT | 握手 -80% |
| DNS 延迟高 | 乐观缓存 + 并发去重 | 首连接 -100ms |
| 配置热重载慢 | ArcSwap + 双缓冲 | 零中断 |
| FakeIP 耗尽 | 双重过期 + GC | 自动回收 |
| mmap SIGBUS | SHA256 + flock + madvise | 零崩溃 |

---

**文档结束**

本文档为 AetherCore 实现规范，覆盖核心 trait 实现、子系统代码模式、关键算法、测试策略与性能基准。第三份文档将覆盖部署、配置与运维。
