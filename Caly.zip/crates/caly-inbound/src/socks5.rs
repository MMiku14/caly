//! Pure Sans-IO SOCKS5 protocol state machine (RFC 1928, RFC 1929) with 1024-byte buffers.

use caly_common::error::Socks5Error;
use caly_common::protocol::ProtocolStateMachine;
use smol_str::SmolStr;
use std::net::{IpAddr, Ipv4Addr, Ipv6Addr, SocketAddr};

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
#[repr(u8)]
pub enum Socks5Command {
    Connect = 0x01,
    Bind = 0x02,
    UdpAssociate = 0x03,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum TargetAddr {
    Ip(SocketAddr),
    Domain(SmolStr, u16),
}

impl TargetAddr {
    #[inline]
    pub fn port(&self) -> u16 {
        match self {
            TargetAddr::Ip(addr) => addr.port(),
            TargetAddr::Domain(_, port) => *port,
        }
    }
}

#[derive(Debug, Clone, Default)]
pub struct AuthConfig {
    pub required: bool,
    pub username: Option<SmolStr>,
    pub password: Option<SmolStr>,
}

impl AuthConfig {
    pub fn none() -> Self {
        Self {
            required: false,
            username: None,
            password: None,
        }
    }

    pub fn new(username: &str, password: &str) -> Self {
        Self {
            required: true,
            username: Some(SmolStr::new(username)),
            password: Some(SmolStr::new(password)),
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum State {
    Greeting,
    Auth,
    Request,
    Connecting,
    Established,
    Closed,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum Socks5Action {
    Connect(TargetAddr),
    UdpAssociate(TargetAddr),
    Timeout,
}

/// 协议缓冲区容量。
///
/// 修复（Round 28）：从 1024 → 4096。
///
/// 1024 字节的假设是"协议头 + 少量余量足够"。但这条假设在两类场景
/// 下会失效：
///
///   1. **请求流水线（Pipelining）**：客户端在单次 write 里发送
///      Greeting + Auth + Request + 首批应用数据。SOCKS5 最坏协议头
///      是 `257 (greeting) + 513 (auth) + 262 (request) = 1032` 字节，
///      只要带上任何 early data 就超限。旧实现在 on_network_input 里
///      直接 `BufferOverflow` → `on_error(0x01)` → 关闭连接。
///      **正常客户端被误判为恶意**。
///
///   2. **TCP 批量推送**：Linux loopback 一次 read 可返回 64KB，
///      远超 MTU。即使对端分片，中间设备也可能 aggregation。
///
/// 4096 覆盖最坏协议头 1032 + 3064 字节 early data。剩余早期数据
/// 由 worker 层的 `early_data_vec`（上限 64KB）接手。
///
/// 内存代价：每个 Socks5StateMachine 实例占 8KB（之前 2KB）。
/// 实例只在握手期存活，握手完成后立即 drop。1000 QPS × 50ms 握手
/// = 峰值 50 个并发实例 ≈ 400KB 瞬时内存。可接受。
const PROTO_BUF_CAP: usize = 4096;

pub struct Socks5StateMachine {
    pub state: State,
    input_buf: heapless::Vec<u8, PROTO_BUF_CAP>,
    output_buf: heapless::Vec<u8, PROTO_BUF_CAP>,
    pub target: Option<TargetAddr>,
    pub command: Option<Socks5Command>,
    auth: AuthConfig,
    #[allow(dead_code)]
    timeout_ms: u64,
}

impl Socks5StateMachine {
    pub fn new(auth: AuthConfig, timeout_ms: u64) -> Self {
        Self {
            state: State::Greeting,
            input_buf: heapless::Vec::new(),
            output_buf: heapless::Vec::new(),
            target: None,
            command: None,
            auth,
            timeout_ms,
        }
    }

    #[inline]
    pub fn on_network_input(&mut self, data: &[u8]) -> Result<(), Socks5Error> {
        ProtocolStateMachine::on_network_input(self, data)
    }

    #[inline]
    pub fn poll_network_output<'a>(&'a mut self, out_buf: &'a mut [u8]) -> Option<usize> {
        ProtocolStateMachine::poll_network_output(self, out_buf)
    }

    #[inline]
    pub fn on_app_input(&mut self, plaintext: &[u8]) -> Result<(), Socks5Error> {
        ProtocolStateMachine::on_app_input(self, plaintext)
    }

    #[inline]
    pub fn poll_app_output<'a>(&'a mut self, out_buf: &'a mut [u8]) -> Option<usize> {
        ProtocolStateMachine::poll_app_output(self, out_buf)
    }

    #[inline]
    pub fn handle_tick(&mut self, now_ms: u64) -> Option<Socks5Action> {
        ProtocolStateMachine::handle_tick(self, now_ms)
    }

    pub fn on_connected(&mut self, bind_addr: SocketAddr) -> Result<(), Socks5Error> {
        if self.state != State::Connecting {
            return Err(Socks5Error::InvalidState);
        }
        let needed = match bind_addr {
            SocketAddr::V4(_) => 10,
            SocketAddr::V6(_) => 22,
        };
        if self.output_buf.len() + needed > PROTO_BUF_CAP {
            return Err(Socks5Error::BufferOverflow);
        }
        let _ = self.output_buf.push(0x05);
        let _ = self.output_buf.push(0x00); // SUCCESS
        let _ = self.output_buf.push(0x00); // RSV
        match bind_addr {
            SocketAddr::V4(v4) => {
                let _ = self.output_buf.push(0x01);
                let _ = self.output_buf.extend_from_slice(&v4.ip().octets());
                let _ = self.output_buf.extend_from_slice(&v4.port().to_be_bytes());
            }
            SocketAddr::V6(v6) => {
                let _ = self.output_buf.push(0x04);
                let _ = self.output_buf.extend_from_slice(&v6.ip().octets());
                let _ = self.output_buf.extend_from_slice(&v6.port().to_be_bytes());
            }
        }
        self.state = State::Established;
        Ok(())
    }

    pub fn on_error(&mut self, rep: u8) {
        self.output_buf.clear();
        let _ = self.output_buf.push(0x05);
        let _ = self.output_buf.push(rep);
        let _ = self.output_buf.push(0x00);
        let _ = self.output_buf.push(0x01);
        let _ = self.output_buf.extend_from_slice(&[0, 0, 0, 0]);
        let _ = self.output_buf.extend_from_slice(&[0, 0]);
        self.state = State::Closed;
    }

    fn try_advance(&mut self) -> Result<Option<Socks5Action>, Socks5Error> {
        loop {
            match self.state {
                State::Greeting => {
                    if self.input_buf.len() < 2 {
                        return Ok(None);
                    }
                    if self.input_buf[0] != 0x05 {
                        self.on_error(0x01);
                        return Err(Socks5Error::UnsupportedVersion);
                    }
                    let n_methods = self.input_buf[1] as usize;
                    if n_methods == 0 {
                        self.output_buf.clear();
                        let _ = self.output_buf.push(0x05);
                        let _ = self.output_buf.push(0xFF);
                        self.state = State::Closed;
                        return Err(Socks5Error::NoAcceptableAuth);
                    }
                    let total = 2 + n_methods;
                    if self.input_buf.len() < total {
                        return Ok(None);
                    }
                    let methods = &self.input_buf[2..total];
                    let has_no_auth = methods.contains(&0x00);
                    let has_user_pass = methods.contains(&0x02);
                    if self.auth.required {
                        if !has_user_pass {
                            self.output_buf.clear();
                            let _ = self.output_buf.push(0x05);
                            let _ = self.output_buf.push(0xFF);
                            self.state = State::Closed;
                            return Err(Socks5Error::NoAcceptableAuth);
                        }
                        let _ = self.output_buf.push(0x05);
                        let _ = self.output_buf.push(0x02);
                        drain_front(&mut self.input_buf, total);
                        self.state = State::Auth;
                    } else {
                        if !has_no_auth {
                            self.output_buf.clear();
                            let _ = self.output_buf.push(0x05);
                            let _ = self.output_buf.push(0xFF);
                            self.state = State::Closed;
                            return Err(Socks5Error::NoAcceptableAuth);
                        }
                        let _ = self.output_buf.push(0x05);
                        let _ = self.output_buf.push(0x00);
                        drain_front(&mut self.input_buf, total);
                        self.state = State::Request;
                    }
                }
                State::Auth => {
                    if self.input_buf.len() < 2 {
                        return Ok(None);
                    }
                    if self.input_buf[0] != 0x01 {
                        self.on_error(0x01);
                        return Err(Socks5Error::UnsupportedVersion);
                    }
                    let ulen = self.input_buf[1] as usize;
                    if self.input_buf.len() < 2 + ulen + 1 {
                        return Ok(None);
                    }
                    let plen = self.input_buf[2 + ulen] as usize;
                    let total = 2 + ulen + 1 + plen;
                    if self.input_buf.len() < total {
                        return Ok(None);
                    }
                    let u_bytes = &self.input_buf[2..2 + ulen];
                    let p_bytes = &self.input_buf[3 + ulen..total];
                    let user_match = self.auth.username.as_ref().is_some_and(|u| u.as_bytes() == u_bytes);
                    let pass_match = self.auth.password.as_ref().is_some_and(|p| p.as_bytes() == p_bytes);
                    if user_match && pass_match {
                        let _ = self.output_buf.push(0x01);
                        let _ = self.output_buf.push(0x00);
                        drain_front(&mut self.input_buf, total);
                        self.state = State::Request;
                    } else {
                        let _ = self.output_buf.push(0x01);
                        let _ = self.output_buf.push(0x01);
                        self.state = State::Closed;
                        return Err(Socks5Error::NoAcceptableAuth);
                    }
                }
                State::Request => {
                    if self.input_buf.len() < 4 {
                        return Ok(None);
                    }
                    if self.input_buf[0] != 0x05 {
                        self.on_error(0x01);
                        return Err(Socks5Error::UnsupportedVersion);
                    }
                    let cmd_byte = self.input_buf[1];
                    let cmd = match cmd_byte {
                        0x01 => Socks5Command::Connect,
                        0x02 => Socks5Command::Bind,
                        0x03 => Socks5Command::UdpAssociate,
                        _ => {
                            self.on_error(0x07);
                            return Err(Socks5Error::UnsupportedCommand);
                        }
                    };
                    if self.input_buf[2] != 0x00 {
                        self.on_error(0x01);
                        return Err(Socks5Error::InvalidState);
                    }
                    let atyp = self.input_buf[3];
                    let (addr_len, is_domain) = match atyp {
                        0x01 => (4, false),
                        0x04 => (16, false),
                        0x03 => {
                            if self.input_buf.len() < 5 {
                                return Ok(None);
                            }
                            let d_len = self.input_buf[4] as usize;
                            if d_len == 0 {
                                self.on_error(0x08);
                                return Err(Socks5Error::MalformedAddress);
                            }
                            (1 + d_len, true)
                        }
                        _ => {
                            self.on_error(0x08);
                            return Err(Socks5Error::UnsupportedAddressType);
                        }
                    };
                    let total = 4 + addr_len + 2;
                    if self.input_buf.len() < total {
                        return Ok(None);
                    }
                    let port_offset = 4 + addr_len;
                    let port = ((self.input_buf[port_offset] as u16) << 8)
                        | (self.input_buf[port_offset + 1] as u16);
                    let target = if is_domain {
                        let d_len = self.input_buf[4] as usize;
                        let d_bytes = &self.input_buf[5..5 + d_len];
                        let domain = std::str::from_utf8(d_bytes)
                            .map_err(|_| Socks5Error::MalformedAddress)?;
                        let clean_domain = domain.trim().trim_end_matches('.');
                        TargetAddr::Domain(SmolStr::new(clean_domain.to_ascii_lowercase()), port)
                    } else if atyp == 0x01 {
                        let ip = Ipv4Addr::new(
                            self.input_buf[4],
                            self.input_buf[5],
                            self.input_buf[6],
                            self.input_buf[7],
                        );
                        TargetAddr::Ip(SocketAddr::new(IpAddr::V4(ip), port))
                    } else {
                        let mut octets = [0u8; 16];
                        octets.copy_from_slice(&self.input_buf[4..20]);
                        let ip = Ipv6Addr::from(octets);
                        TargetAddr::Ip(SocketAddr::new(IpAddr::V6(ip), port))
                    };
                    drain_front(&mut self.input_buf, total);
                    self.target = Some(target.clone());
                    self.command = Some(cmd);
                    self.state = State::Connecting;
                    return match cmd {
                        Socks5Command::Connect => Ok(Some(Socks5Action::Connect(target))),
                        Socks5Command::UdpAssociate => Ok(Some(Socks5Action::UdpAssociate(target))),
                        Socks5Command::Bind => {
                            self.on_error(0x07);
                            Err(Socks5Error::UnsupportedCommand)
                        }
                    };
                }
                State::Connecting | State::Established | State::Closed => {
                    return Ok(None);
                }
            }
        }
    }
}

impl ProtocolStateMachine for Socks5StateMachine {
    type Action = Socks5Action;
    type Error = Socks5Error;

    fn on_network_input(&mut self, data: &[u8]) -> Result<(), Self::Error> {
        if self.input_buf.len() + data.len() > PROTO_BUF_CAP {
            self.on_error(0x01);
            return Err(Socks5Error::BufferOverflow);
        }
        let _ = self.input_buf.extend_from_slice(data);
        let _ = self.try_advance()?;
        Ok(())
    }

    fn poll_network_output<'a>(&'a mut self, out_buf: &'a mut [u8]) -> Option<usize> {
        if self.output_buf.is_empty() {
            return None;
        }
        let n = self.output_buf.len().min(out_buf.len());
        out_buf[..n].copy_from_slice(&self.output_buf[..n]);
        drain_front(&mut self.output_buf, n);
        Some(n)
    }

    fn on_app_input(&mut self, plaintext: &[u8]) -> Result<(), Self::Error> {
        if self.state != State::Established {
            return Err(Socks5Error::NotEstablished);
        }
        if self.output_buf.len() + plaintext.len() > PROTO_BUF_CAP {
            return Err(Socks5Error::BufferOverflow);
        }
        let _ = self.output_buf.extend_from_slice(plaintext);
        Ok(())
    }

    fn poll_app_output<'a>(&'a mut self, out_buf: &'a mut [u8]) -> Option<usize> {
        if self.input_buf.is_empty() {
            return None;
        }
        let n = self.input_buf.len().min(out_buf.len());
        out_buf[..n].copy_from_slice(&self.input_buf[..n]);
        drain_front(&mut self.input_buf, n);
        Some(n)
    }

    fn handle_tick(&mut self, _now_ms: u64) -> Option<Self::Action> {
        None
    }
}

#[inline]
fn drain_front<T: Copy, const N: usize>(vec: &mut heapless::Vec<T, N>, count: usize) {
    if count >= vec.len() {
        vec.clear();
    } else {
        vec.as_mut_slice().copy_within(count.., 0);
        let new_len = vec.len() - count;
        vec.truncate(new_len);
    }
}
