//! HTTP Proxy inbound protocol handler supporting CONNECT tunnels, IPv6 brackets, and early data preservation.

use caly_common::error::CalyError;
use smol_str::SmolStr;

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum HttpRequestType {
    Connect { host: SmolStr, port: u16, header_end: usize },
    Forward { method: SmolStr, uri: SmolStr, header_end: usize },
}

pub struct HttpInbound;

const CONNECT_RESPONSE: &[u8] = b"HTTP/1.1 200 Connection Established
Proxy-Agent: Caly/1.0

";
const NOT_IMPLEMENTED_501: &[u8] = b"HTTP/1.1 501 Not Implemented
Content-Length: 0
Connection: close

";
const BAD_REQUEST_400: &[u8] = b"HTTP/1.1 400 Bad Request
Content-Length: 0
Connection: close

";

impl HttpInbound {
    pub fn parse_request(buf: &[u8]) -> Result<Option<HttpRequestType>, CalyError> {
        let (header_bytes, header_end) = match find_header_end(buf) {
            Some((hb, end)) => (hb, end),
            None => return Ok(None),
        };

        let header_str = std::str::from_utf8(header_bytes)
            .map_err(|_| CalyError::Config("HTTP header is not valid UTF-8".to_string()))?;
        let first_line = header_str
            .lines()
            .next()
            .ok_or_else(|| CalyError::Config("Empty HTTP request line".to_string()))?;

        let mut parts = first_line.split_whitespace();
        let method = parts.next().ok_or_else(|| CalyError::Config("Missing method".into()))?;
        let uri = parts.next().ok_or_else(|| CalyError::Config("Missing URI".into()))?;
        let _version = parts.next().ok_or_else(|| CalyError::Config("Missing HTTP version".into()))?;

        if method.eq_ignore_ascii_case("CONNECT") {
            let (host, port) = parse_host_port(uri)?;
            return Ok(Some(HttpRequestType::Connect {
                host: SmolStr::new(host.to_ascii_lowercase()),
                port,
                header_end,
            }));
        }

        Ok(Some(HttpRequestType::Forward {
            method: SmolStr::new(method),
            uri: SmolStr::new(uri),
            header_end,
        }))
    }

    #[inline]
    pub fn build_connect_response() -> &'static [u8] {
        CONNECT_RESPONSE
    }

    #[inline]
    pub fn build_501_response() -> &'static [u8] {
        NOT_IMPLEMENTED_501
    }

    #[inline]
    pub fn build_400_response() -> &'static [u8] {
        BAD_REQUEST_400
    }
}

fn find_header_end(buf: &[u8]) -> Option<(&[u8], usize)> {
    if let Some(pos) = buf.windows(4).position(|w| w == b"

") {
        return Some((&buf[..pos], pos + 4));
    }
    if let Some(pos) = buf.windows(2).position(|w| w == b"

") {
        return Some((&buf[..pos], pos + 2));
    }
    None
}

fn parse_host_port(uri: &str) -> Result<(&str, u16), CalyError> {
    if uri.starts_with('[') {
        if let Some(close_bracket) = uri.find(']') {
            let host = &uri[1..close_bracket];
            let remainder = &uri[close_bracket + 1..];
            let port = if let Some(stripped) = remainder.strip_prefix(':') {
                stripped.parse::<u16>().map_err(|_| CalyError::Config("Invalid port in IPv6 CONNECT".to_string()))?
            } else {
                443
            };
            return Ok((host, port));
        } else {
            return Err(CalyError::Config("Malformed IPv6 literal in CONNECT URI".to_string()));
        }
    }
    if let Some(colon_pos) = uri.rfind(':') {
        let host = &uri[..colon_pos];
        let port_str = &uri[colon_pos + 1..];
        let port = port_str.parse::<u16>().map_err(|_| CalyError::Config("Invalid port in CONNECT URI".to_string()))?;
        Ok((host, port))
    } else {
        Ok((uri, 443))
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_connect_ipv4_and_early_data() {
        let req = b"CONNECT example.com:443 HTTP/1.1
Host: example.com

EARLY_DATA";
        let parsed = HttpInbound::parse_request(req).unwrap().unwrap();
        match parsed {
            HttpRequestType::Connect { host, port, header_end } => {
                assert_eq!(host.as_str(), "example.com");
                assert_eq!(port, 443);
                assert_eq!(&req[header_end..], b"EARLY_DATA");
            }
            _ => panic!("Expected CONNECT"),
        }
    }

    #[test]
    fn test_connect_ipv6_bracketed() {
        let req = b"CONNECT [2001:db8::1]:8443 HTTP/1.1

";
        let parsed = HttpInbound::parse_request(req).unwrap().unwrap();
        match parsed {
            HttpRequestType::Connect { host, port, .. } => {
                assert_eq!(host.as_str(), "2001:db8::1");
                assert_eq!(port, 8443);
            }
            _ => panic!("Expected CONNECT"),
        }
    }

    #[test]
    fn test_forward_request() {
        let req = b"GET http://example.com/path HTTP/1.1
Host: example.com

";
        let parsed = HttpInbound::parse_request(req).unwrap().unwrap();
        match parsed {
            HttpRequestType::Forward { method, uri, .. } => {
                assert_eq!(method.as_str(), "GET");
                assert!(uri.as_str().contains("example.com"));
            }
            _ => panic!("Expected Forward"),
        }
    }
}
