//! Fuzz tests for inbound protocol parsers (SOCKS5 + HTTP).
//!
//! 这两个解析器直接面对客户端首包，任何 panic 都会杀死一个 worker
//! 线程（甚至整个进程，如果 panic=abort）。

use caly_inbound::http::HttpInbound;
use caly_inbound::socks5::Socks5StateMachine;
use caly_inbound::AuthConfig;

struct XorShift64(u64);

impl XorShift64 {
    fn new(seed: u64) -> Self {
        Self(if seed == 0 { 0x9E37_79B9_7F4A_7C15 } else { seed })
    }
    fn next_u64(&mut self) -> u64 {
        let mut x = self.0;
        x ^= x << 13;
        x ^= x >> 7;
        x ^= x << 17;
        self.0 = x;
        x
    }
    fn fill(&mut self, buf: &mut [u8]) {
        for chunk in buf.chunks_mut(8) {
            let v = self.next_u64().to_le_bytes();
            let n = chunk.len();
            chunk.copy_from_slice(&v[..n]);
        }
    }
    fn range(&mut self, max: usize) -> usize {
        if max == 0 { 0 } else { (self.next_u64() as usize) % max }
    }
}

const SEED_SOCKS: u64 = 0x00C4_1D00_50C5_0001;
const SEED_HTTP: u64 = 0x00C4_1D00_4747_0001;

// ═══════════════════════════════════════════════════════════════
// SOCKS5
// ═══════════════════════════════════════════════════════════════

#[test]
fn fuzz_socks5_random_bytes_no_panic() {
    let mut rng = XorShift64::new(SEED_SOCKS);
    for _ in 0..10_000 {
        let mut sm = Socks5StateMachine::new(AuthConfig::none(), 30_000);
        // 随机分片喂入
        let chunks = rng.range(8) + 1;
        for _ in 0..chunks {
            let len = rng.range(256);
            let mut buf = vec![0u8; len];
            rng.fill(&mut buf);
            if sm.on_network_input(&buf).is_err() {
                break;
            }
            // 尽量清空 output，避免 output_buf 溢出误伤
            let mut out = [0u8; 1024];
            while sm.poll_network_output(&mut out).is_some() {}
        }
    }
}

#[test]
fn fuzz_socks5_buffer_overflow_rejected() {
    // 持续喂大块数据，验证缓冲区上限（1024 字节）会被守住，
    // 而不是发生整数溢出或 heapless 内部 panic。
    let mut rng = XorShift64::new(SEED_SOCKS ^ 0xF00D);
    for _ in 0..2_000 {
        let mut sm = Socks5StateMachine::new(AuthConfig::none(), 30_000);
        let mut fed = 0usize;
        // 头部故意不是 0x05，让状态机停在 Greeting
        for _ in 0..64 {
            let mut buf = vec![0u8; 512];
            rng.fill(&mut buf);
            buf[0] = 0x04; // 非 SOCKS5 版本 → 立刻报错退出
            match sm.on_network_input(&buf) {
                Ok(()) => fed += buf.len(),
                Err(_) => break,
            }
            let mut out = [0u8; 2048];
            while sm.poll_network_output(&mut out).is_some() {}
        }
        let _ = fed;
    }
}

#[test]
fn fuzz_socks5_valid_prefix_random_tail() {
    // 有效的 0x05 greeting 前缀 + 随机尾部。
    // 触发 Greeting → Request 状态后的解析路径。
    let mut rng = XorShift64::new(SEED_SOCKS ^ 0x1234_5678);
    for _ in 0..10_000 {
        let mut sm = Socks5StateMachine::new(AuthConfig::none(), 30_000);
        let _ = sm.on_network_input(&[0x05, 0x01, 0x00]);
        let mut out = [0u8; 64];
        while sm.poll_network_output(&mut out).is_some() {}

        let len = rng.range(512);
        let mut tail = vec![0u8; len];
        rng.fill(&mut tail);
        let _ = sm.on_network_input(&tail);
    }
}

// ═══════════════════════════════════════════════════════════════
// HTTP
// ═══════════════════════════════════════════════════════════════

#[test]
fn fuzz_http_parse_random_bytes_no_panic() {
    let mut rng = XorShift64::new(SEED_HTTP);
    for _ in 0..20_000 {
        let len = rng.range(2048);
        let mut buf = vec![0u8; len];
        rng.fill(&mut buf);
        let _ = HttpInbound::parse_request(&buf);
    }
}

#[test]
fn fuzz_http_parse_connect_variants() {
    // 生成各种 CONNECT 变体：合法、畸形、IPv6、超长 host 等
    let mut rng = XorShift64::new(SEED_HTTP ^ 0xA5A5);
    for _ in 0..10_000 {
        let mut req = b"CONNECT ".to_vec();
        // 随机 host 字符（含 : / [ ] % 空格 等）
        let host_len = rng.range(64) + 1;
        for _ in 0..host_len {
            let b = (rng.next_u64() & 0xFF) as u8;
            // 过滤掉 NUL（避免破坏 header 语义）
            req.push(if b == 0 { b'A' } else { b });
        }
        req.extend_from_slice(b" HTTP/1.1\r\n\r\n");
        let _ = HttpInbound::parse_request(&req);
    }
}

#[test]
fn fuzz_http_parse_no_terminator() {
    // 永远不完整的请求头（无 \r\n\r\n）
    let mut rng = XorShift64::new(SEED_HTTP ^ 0xBEEF);
    for _ in 0..5_000 {
        let len = rng.range(256);
        let mut buf = vec![0u8; len];
        rng.fill(&mut buf);
        // 过滤掉可能产生 header_end 的字节序列（几乎不可能，但保守）
        for b in buf.iter_mut() {
            if *b == b'\n' { *b = b'X'; }
            if *b == b'\r' { *b = b'Y'; }
        }
        let r = HttpInbound::parse_request(&buf).unwrap();
        assert!(r.is_none(), "无 \\r\\n\\r\\n 应返回 Ok(None)");
    }
}
