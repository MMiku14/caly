//! Fuzz tests for rule matching lookups.
//!
//! 覆盖三个热路径：
//!   - ReverseDomainTrie::lookup（每次连接至少一次）
//!   - TreeBitmapLpm::lookup（每次纯 IP 连接一次）
//!   - RuleEngine::match_outbound（完整路由决策）

use caly_common::metadata::{Network, SessionMetadata};
use caly_rules::domain_trie::ReverseDomainTrie;
use caly_rules::engine::RuleEngine;
use caly_rules::ip_tree::TreeBitmapLpm;
use caly_rules::logic::{RuleCondition, RuleItem};
use std::net::SocketAddr;
use std::str::FromStr;

struct XorShift64(u64);

impl XorShift64 {
    fn new(seed: u64) -> Self {
        Self(if seed == 0 { 0x9E37_79B9_7F4A_7C15 } else { seed })
    }
    fn next_u64(&mut self) -> u64 {
        let mut x = self.0;
        x ^= x << 13;
        x ^= x >> 7;
        x ^= x << 17;
        self.0 = x;
        x
    }
    fn fill(&mut self, buf: &mut [u8]) {
        for chunk in buf.chunks_mut(8) {
            let v = self.next_u64().to_le_bytes();
            let n = chunk.len();
            chunk.copy_from_slice(&v[..n]);
        }
    }
    fn range(&mut self, max: usize) -> usize {
        if max == 0 { 0 } else { (self.next_u64() as usize) % max }
    }
}

const SEED_RULES: u64 = 0x00C4_1D00_1234_0001;

// ═══════════════════════════════════════════════════════════════
// ReverseDomainTrie
// ═══════════════════════════════════════════════════════════════

#[test]
fn fuzz_domain_trie_random_query() {
    let mut trie = ReverseDomainTrie::new();
    for i in 0..128u32 {
        trie.insert(&format!("host{}.example.com", i), i % 2 == 0, i);
        trie.insert(&format!(".suffix{}", i), false, i + 1000);
    }
    trie.seal();

    let mut rng = XorShift64::new(SEED_RULES);
    for _ in 0..20_000 {
        let len = rng.range(256);
        let mut bytes = vec![0u8; len];
        rng.fill(&mut bytes);
        // UTF-8 lossy 转换：允许任意字节（用 \u{FFFD} 替换非法序列）
        // Trie 内部按字节处理，不依赖合法 UTF-8。
        let s = String::from_utf8_lossy(&bytes);
        let _ = trie.lookup(&s);
    }
}

#[test]
fn fuzz_domain_trie_deep_labels() {
    // 接近 MAX_LABEL_DEPTH = 128 的域名
    let mut rng = XorShift64::new(SEED_RULES ^ 0xDEED_EEFF);
    for _ in 0..1_000 {
        let depth = 100 + rng.range(50);  // 100..150
        // 修复（Round 24）：Vec<char> 没有 .join() —— 标准库只为
        // Vec<S: AsRef<str>> / Vec<&str> 提供 join。改为先转 String。
        let s: String = (0..depth)
            .map(|_| {
                let b = (rng.next_u64() & 0xFF) as u8;
                (((b % 26) + b'a') as char).to_string()
            })
            .collect::<Vec<String>>()
            .join(".");
        let _ = trie_lookup_standalone(&s);
    }
}

fn trie_lookup_standalone(domain: &str) -> Option<u32> {
    let mut t = ReverseDomainTrie::new();
    t.insert("example.com", true, 1);
    t.seal();
    t.lookup(domain).map(|m| m.rule_id)
}

// ═══════════════════════════════════════════════════════════════
// TreeBitmapLpm
// ═══════════════════════════════════════════════════════════════

#[test]
fn fuzz_ip_tree_random_lookup() {
    let mut lpm = TreeBitmapLpm::new();
    lpm.insert(ipnet::IpNet::from_str("0.0.0.0/0").unwrap(), 1);
    lpm.insert(ipnet::IpNet::from_str("10.0.0.0/8").unwrap(), 2);
    lpm.insert(ipnet::IpNet::from_str("10.1.0.0/16").unwrap(), 3);
    lpm.insert(ipnet::IpNet::from_str("2001:db8::/32").unwrap(), 4);
    lpm.insert(ipnet::IpNet::from_str("2001:db8:1::/48").unwrap(), 5);

    let mut rng = XorShift64::new(SEED_RULES ^ 0x0001_0000);
    for _ in 0..20_000 {
        let v4 = (rng.next_u64() as u32).to_be_bytes();
        let ip = std::net::IpAddr::V4(std::net::Ipv4Addr::from(v4));
        let _ = lpm.lookup(ip);

        let v6 = rng.next_u64() as u128 | ((rng.next_u64() as u128) << 64);
        let ip6 = std::net::IpAddr::V6(std::net::Ipv6Addr::from(v6));
        let _ = lpm.lookup(ip6);
    }
}

// ═══════════════════════════════════════════════════════════════
// RuleEngine（端到端）
// ═══════════════════════════════════════════════════════════════

#[test]
fn fuzz_rule_engine_random_metadata() {
    let engine = RuleEngine::new(
        vec![
            RuleItem::new(RuleCondition::DomainSuffix(".cn".into()), "direct"),
            RuleItem::new(RuleCondition::Domain("example.com".into()), "block"),
            RuleItem::new(RuleCondition::IpCidr("10.0.0.0/8".parse().unwrap()), "direct"),
            RuleItem::new(RuleCondition::IpIsPrivate, "direct"),
            RuleItem::new(RuleCondition::Port(443), "proxy"),
            RuleItem::new(RuleCondition::Network(Network::Udp), "udp-out"),
        ],
        "fallback",
    );

    let mut rng = XorShift64::new(SEED_RULES ^ 0xE2E);
    for _ in 0..20_000 {
        let mut meta = SessionMetadata::default();

        // 随机域名（可能合法、可能乱码）
        let dlen = rng.range(64);
        if dlen > 0 {
            let mut bytes = vec![0u8; dlen];
            rng.fill(&mut bytes);
            let s = String::from_utf8_lossy(&bytes);
            meta.set_domain(&s);
        }

        // 随机目的地址
        let v4 = (rng.next_u64() as u32).to_be_bytes();
        let port = (rng.next_u64() & 0xFFFF) as u16;
        meta.dst_addr = SocketAddr::from((
            std::net::Ipv4Addr::from(v4),
            port,
        ));

        meta.network = match rng.range(3) {
            0 => Network::Tcp,
            1 => Network::Udp,
            _ => Network::Both,
        };

        let _ = engine.match_outbound(&meta);
    }
}
