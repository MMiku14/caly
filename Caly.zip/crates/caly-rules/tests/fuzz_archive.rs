//! Fuzz tests for the rule archive loader.
//!
//! 归档文件是外部输入（可被攻击者替换 / 磁盘损坏 / 版本不兼容），
//! `ArchiveLoader::load` 必须对任意字节保持 no-panic。
//!
//! 覆盖场景：
//!   1. 完全随机字节（可能碰巧命中 MAGIC）
//!   2. 正确 MAGIC + 随机尾部（走更深解析路径）
//!   3. 正确 MAGIC + 长度截断（header 未满）
//!   4. 正确头部 + 损坏 checksum
//!   5. 正确头部 + 正确 checksum + 损坏 payload

use caly_rules::ArchiveLoader;
use std::io::Write;

struct XorShift64(u64);

impl XorShift64 {
    fn new(seed: u64) -> Self {
        Self(if seed == 0 { 0x9E37_79B9_7F4A_7C15 } else { seed })
    }
    fn next_u64(&mut self) -> u64 {
        let mut x = self.0;
        x ^= x << 13;
        x ^= x >> 7;
        x ^= x << 17;
        self.0 = x;
        x
    }
    fn fill(&mut self, buf: &mut [u8]) {
        for chunk in buf.chunks_mut(8) {
            let v = self.next_u64().to_le_bytes();
            let n = chunk.len();
            chunk.copy_from_slice(&v[..n]);
        }
    }
    fn range(&mut self, max: usize) -> usize {
        if max == 0 { 0 } else { (self.next_u64() as usize) % max }
    }
}

// 4 位分组，通过 clippy::unusual_byte_groupings
const SEED_ARCHIVE: u64 = 0x00C4_1D00_A2C1_0001;

fn temp_path(tag: &str) -> std::path::PathBuf {
    use std::time::{SystemTime, UNIX_EPOCH};
    let pid = std::process::id();
    let nanos = SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_nanos();
    std::env::temp_dir().join(format!("caly-fuzz-archive-{tag}-{pid}-{nanos}.bin"))
}

fn write_tmp(tag: &str, bytes: &[u8]) -> std::path::PathBuf {
    let path = temp_path(tag);
    if let Ok(mut f) = std::fs::File::create(&path) {
        let _ = f.write_all(bytes);
        let _ = f.sync_all();
    }
    path
}

#[test]
fn fuzz_archive_random_bytes() {
    let mut rng = XorShift64::new(SEED_ARCHIVE);
    for _ in 0..500 {
        let len = rng.range(4096);
        let mut buf = vec![0u8; len];
        rng.fill(&mut buf);
        // 1/4 概率强制命中 MAGIC，走更深路径
        if rng.range(4) == 0 && buf.len() >= 4 {
            buf[0..4].copy_from_slice(b"CALY");
        }
        let path = write_tmp("rand", &buf);
        let _ = ArchiveLoader::load(&path);
        let _ = std::fs::remove_file(&path);
    }
}

#[test]
fn fuzz_archive_truncated_header() {
    // 正确 MAGIC 但长度 < 64（HEADER_SIZE）。
    let mut rng = XorShift64::new(SEED_ARCHIVE ^ 0xA5A5_A5A5_A5A5_A5A5);
    for _ in 0..300 {
        let len = rng.range(64);
        let mut buf = vec![0u8; len];
        rng.fill(&mut buf);
        if buf.len() >= 4 {
            buf[0..4].copy_from_slice(b"CALY");
        }
        let path = write_tmp("trunc", &buf);
        let _ = ArchiveLoader::load(&path);
        let _ = std::fs::remove_file(&path);
    }
}

#[test]
fn fuzz_archive_full_header_random_payload() {
    // 构造一个 header：
    //   magic = "CALY"
    //   version = 4 (LE u32)
    //   endian = 0
    //   padding
    //   payload_len = 随机值
    //   sha256 = 32 字节随机
    // 然后追加随机 payload。绝大多数情况会因 checksum 失败拒绝，
    // 但少数会命中"checksum 正确"路径（如果 payload_len = 0）。
    let mut rng = XorShift64::new(SEED_ARCHIVE ^ 0xC0DE_C0DE_C0DE_C0DE);
    for _ in 0..500 {
        let mut buf = vec![0u8; 64];
        buf[0..4].copy_from_slice(b"CALY");
        buf[4..8].copy_from_slice(&4u32.to_le_bytes());   // version 4
        buf[8] = 0;                                       // little-endian
        buf[9] = 4;                                       // align = 16 (trailing_zeros = 4)
        // 10..12 padding
        let payload_len = rng.range(512) as u64;
        buf[12..20].copy_from_slice(&payload_len.to_le_bytes());
        // 20..52 sha256（随机，让校验失败）
        let mut sha = [0u8; 32];
        rng.fill(&mut sha);
        buf[20..52].copy_from_slice(&sha);
        // 52..64 padding

        let mut payload = vec![0u8; payload_len as usize];
        rng.fill(&mut payload);
        buf.extend_from_slice(&payload);

        let path = write_tmp("hdr", &buf);
        let _ = ArchiveLoader::load(&path);
        let _ = std::fs::remove_file(&path);
    }
}
