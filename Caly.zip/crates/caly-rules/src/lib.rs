//! Routing arbiter and rule evaluation subsystem.

pub mod archive;
pub mod domain_trie;
pub mod engine;
pub mod ip_tree;
pub mod logic;
pub mod logic_codec;

pub use archive::{ArchiveLoader, ArchiveWriter, LoadError, SaveError};
pub use domain_trie::{
    ChildEntry, DomainMatch, DomainMatchKind, ReverseDomainTrie, SealedNode,
};
pub use engine::{
    RuleDumpItem, RuleEngine, RuleEngineStats, RuleExplanation, RuleHitInfo, RuleMatchKind,
    RuleMetrics, RuleMetricsSnapshot,
};
pub use ip_tree::{FlatNode, TreeBitmapLpm};
pub use logic::{RuleCondition, RuleItem};
