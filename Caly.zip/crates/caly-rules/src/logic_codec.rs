//! Binary serialization codec for RuleCondition in little-endian format.

use crate::logic::RuleCondition;
use byteorder::{ByteOrder, LittleEndian};
use caly_common::metadata::{Network, SniffedProto};
use smol_str::SmolStr;

const TAG_DOMAIN: u8 = 0;
const TAG_DOMAIN_SUFFIX: u8 = 1;
const TAG_DOMAIN_KEYWORD: u8 = 2;
const TAG_IP_CIDR: u8 = 3;
const TAG_IP_IS_PRIVATE: u8 = 4;
const TAG_SOURCE_IP_CIDR: u8 = 5;
const TAG_PORT: u8 = 6;
const TAG_PORT_RANGE: u8 = 7;
const TAG_SOURCE_PORT: u8 = 8;
const TAG_PROCESS_NAME: u8 = 9;
const TAG_PROTOCOL: u8 = 10;
const TAG_NETWORK: u8 = 11;
const TAG_INBOUND: u8 = 12;
const TAG_SNIFF_SOURCE: u8 = 13;
const TAG_AND: u8 = 14;
const TAG_OR: u8 = 15;
const TAG_NOT: u8 = 16;

#[derive(Debug)]
pub enum CodecError {
    Truncated(&'static str),
    UnknownTag(u8),
    InvalidUtf8,
    InvalidNetwork(u8),
    InvalidIpFamily(u8),
    InvalidIpPrefix(u8),
    TooManySubconditions(u32),
}

impl std::fmt::Display for CodecError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            CodecError::Truncated(ctx) => write!(f, "truncated: {}", ctx),
            CodecError::UnknownTag(t) => write!(f, "unknown tag: {}", t),
            CodecError::InvalidUtf8 => write!(f, "invalid UTF-8"),
            CodecError::InvalidNetwork(v) => write!(f, "invalid network byte: {}", v),
            CodecError::InvalidIpFamily(v) => write!(f, "invalid IP family byte: {}", v),
            CodecError::InvalidIpPrefix(p) => write!(f, "invalid prefix length: {}", p),
            CodecError::TooManySubconditions(n) => write!(f, "too many subconditions: {}", n),
        }
    }
}

impl std::error::Error for CodecError {}

const MAX_SUBCONDITIONS: u32 = 4096;
const MAX_DEPTH: usize = 32;

pub fn write_condition(buf: &mut Vec<u8>, cond: &RuleCondition) {
    match cond {
        RuleCondition::Domain(s) => {
            buf.push(TAG_DOMAIN);
            write_smol_str(buf, s);
        }
        RuleCondition::DomainSuffix(s) => {
            buf.push(TAG_DOMAIN_SUFFIX);
            write_smol_str(buf, s);
        }
        RuleCondition::DomainKeyword(s) => {
            buf.push(TAG_DOMAIN_KEYWORD);
            write_smol_str(buf, s);
        }
        RuleCondition::IpCidr(net) => {
            buf.push(TAG_IP_CIDR);
            write_ipnet(buf, net);
        }
        RuleCondition::IpIsPrivate => {
            buf.push(TAG_IP_IS_PRIVATE);
        }
        RuleCondition::SourceIpCidr(net) => {
            buf.push(TAG_SOURCE_IP_CIDR);
            write_ipnet(buf, net);
        }
        RuleCondition::Port(p) => {
            buf.push(TAG_PORT);
            buf.extend_from_slice(&p.to_le_bytes());
        }
        RuleCondition::PortRange(a, b) => {
            buf.push(TAG_PORT_RANGE);
            buf.extend_from_slice(&a.to_le_bytes());
            buf.extend_from_slice(&b.to_le_bytes());
        }
        RuleCondition::SourcePort(p) => {
            buf.push(TAG_SOURCE_PORT);
            buf.extend_from_slice(&p.to_le_bytes());
        }
        RuleCondition::ProcessName(s) => {
            buf.push(TAG_PROCESS_NAME);
            write_smol_str(buf, s);
        }
        RuleCondition::Protocol(p) => {
            buf.push(TAG_PROTOCOL);
            buf.push(*p as u8);
        }
        RuleCondition::Network(n) => {
            buf.push(TAG_NETWORK);
            buf.push(*n as u8);
        }
        RuleCondition::Inbound(t) => {
            buf.push(TAG_INBOUND);
            buf.extend_from_slice(&t.to_le_bytes());
        }
        RuleCondition::SniffSource(s) => {
            buf.push(TAG_SNIFF_SOURCE);
            buf.push(*s);
        }
        RuleCondition::And(list) => {
            buf.push(TAG_AND);
            buf.extend_from_slice(&(list.len() as u32).to_le_bytes());
            for c in list {
                write_condition(buf, c);
            }
        }
        RuleCondition::Or(list) => {
            buf.push(TAG_OR);
            buf.extend_from_slice(&(list.len() as u32).to_le_bytes());
            for c in list {
                write_condition(buf, c);
            }
        }
        RuleCondition::Not(inner) => {
            buf.push(TAG_NOT);
            write_condition(buf, inner);
        }
    }
}

fn write_smol_str(buf: &mut Vec<u8>, s: &SmolStr) {
    let bytes = s.as_bytes();
    buf.extend_from_slice(&(bytes.len() as u16).to_le_bytes());
    buf.extend_from_slice(bytes);
}

fn write_ipnet(buf: &mut Vec<u8>, net: &ipnet::IpNet) {
    match net {
        ipnet::IpNet::V4(n) => {
            buf.push(4);
            buf.extend_from_slice(&n.network().octets());
            buf.push(n.prefix_len());
        }
        ipnet::IpNet::V6(n) => {
            buf.push(6);
            buf.extend_from_slice(&n.network().octets());
            buf.push(n.prefix_len());
        }
    }
}

pub fn read_condition(buf: &[u8], pos: usize) -> Result<(RuleCondition, usize), CodecError> {
    read_condition_depth(buf, pos, 0)
}

fn read_condition_depth(
    buf: &[u8],
    mut pos: usize,
    depth: usize,
) -> Result<(RuleCondition, usize), CodecError> {
    if depth > MAX_DEPTH {
        return Err(CodecError::Truncated("max recursion depth exceeded"));
    }
    if pos >= buf.len() {
        return Err(CodecError::Truncated("condition tag"));
    }
    let tag = buf[pos];
    pos += 1;
    match tag {
        TAG_DOMAIN => {
            let (s, np) = read_smol_str(buf, pos)?;
            Ok((RuleCondition::Domain(s), np))
        }
        TAG_DOMAIN_SUFFIX => {
            let (s, np) = read_smol_str(buf, pos)?;
            Ok((RuleCondition::DomainSuffix(s), np))
        }
        TAG_DOMAIN_KEYWORD => {
            let (s, np) = read_smol_str(buf, pos)?;
            Ok((RuleCondition::DomainKeyword(s), np))
        }
        TAG_IP_CIDR => {
            let (net, np) = read_ipnet(buf, pos)?;
            Ok((RuleCondition::IpCidr(net), np))
        }
        TAG_IP_IS_PRIVATE => Ok((RuleCondition::IpIsPrivate, pos)),
        TAG_SOURCE_IP_CIDR => {
            let (net, np) = read_ipnet(buf, pos)?;
            Ok((RuleCondition::SourceIpCidr(net), np))
        }
        TAG_PORT => {
            if pos + 2 > buf.len() {
                return Err(CodecError::Truncated("port"));
            }
            let p = LittleEndian::read_u16(&buf[pos..pos + 2]);
            Ok((RuleCondition::Port(p), pos + 2))
        }
        TAG_PORT_RANGE => {
            if pos + 4 > buf.len() {
                return Err(CodecError::Truncated("port range"));
            }
            let a = LittleEndian::read_u16(&buf[pos..pos + 2]);
            let b = LittleEndian::read_u16(&buf[pos + 2..pos + 4]);
            Ok((RuleCondition::PortRange(a, b), pos + 4))
        }
        TAG_SOURCE_PORT => {
            if pos + 2 > buf.len() {
                return Err(CodecError::Truncated("source port"));
            }
            let p = LittleEndian::read_u16(&buf[pos..pos + 2]);
            Ok((RuleCondition::SourcePort(p), pos + 2))
        }
        TAG_PROCESS_NAME => {
            let (s, np) = read_smol_str(buf, pos)?;
            Ok((RuleCondition::ProcessName(s), np))
        }
        TAG_PROTOCOL => {
            if pos >= buf.len() {
                return Err(CodecError::Truncated("protocol"));
            }
            let v = buf[pos];
            Ok((RuleCondition::Protocol(SniffedProto::from_u8(v)), pos + 1))
        }
        TAG_NETWORK => {
            if pos >= buf.len() {
                return Err(CodecError::Truncated("network"));
            }
            let v = buf[pos];
            let net = Network::from_u8(v).ok_or(CodecError::InvalidNetwork(v))?;
            Ok((RuleCondition::Network(net), pos + 1))
        }
        TAG_INBOUND => {
            if pos + 8 > buf.len() {
                return Err(CodecError::Truncated("inbound"));
            }
            let t = LittleEndian::read_u64(&buf[pos..pos + 8]);
            Ok((RuleCondition::Inbound(t), pos + 8))
        }
        TAG_SNIFF_SOURCE => {
            if pos >= buf.len() {
                return Err(CodecError::Truncated("sniff source"));
            }
            let s = buf[pos];
            Ok((RuleCondition::SniffSource(s), pos + 1))
        }
        TAG_AND => {
            let (list, np) = read_condition_list(buf, pos, depth)?;
            Ok((RuleCondition::And(list), np))
        }
        TAG_OR => {
            let (list, np) = read_condition_list(buf, pos, depth)?;
            Ok((RuleCondition::Or(list), np))
        }
        TAG_NOT => {
            let (inner, np) = read_condition_depth(buf, pos, depth + 1)?;
            Ok((RuleCondition::Not(Box::new(inner)), np))
        }
        other => Err(CodecError::UnknownTag(other)),
    }
}

fn read_condition_list(
    buf: &[u8],
    mut pos: usize,
    depth: usize,
) -> Result<(Vec<RuleCondition>, usize), CodecError> {
    if pos + 4 > buf.len() {
        return Err(CodecError::Truncated("condition list count"));
    }
    let count = LittleEndian::read_u32(&buf[pos..pos + 4]);
    pos += 4;
    if count > MAX_SUBCONDITIONS {
        return Err(CodecError::TooManySubconditions(count));
    }
    let mut out = Vec::with_capacity(count as usize);
    for _ in 0..count {
        let (c, np) = read_condition_depth(buf, pos, depth + 1)?;
        out.push(c);
        pos = np;
    }
    Ok((out, pos))
}

fn read_smol_str(buf: &[u8], mut pos: usize) -> Result<(SmolStr, usize), CodecError> {
    if pos + 2 > buf.len() {
        return Err(CodecError::Truncated("smolstr len"));
    }
    let len = LittleEndian::read_u16(&buf[pos..pos + 2]) as usize;
    pos += 2;
    if pos + len > buf.len() {
        return Err(CodecError::Truncated("smolstr body"));
    }
    let s = std::str::from_utf8(&buf[pos..pos + len]).map_err(|_| CodecError::InvalidUtf8)?;
    Ok((SmolStr::new(s), pos + len))
}

fn read_ipnet(buf: &[u8], mut pos: usize) -> Result<(ipnet::IpNet, usize), CodecError> {
    if pos >= buf.len() {
        return Err(CodecError::Truncated("ipnet family"));
    }
    let family = buf[pos];
    pos += 1;
    match family {
        4 => {
            if pos + 5 > buf.len() {
                return Err(CodecError::Truncated("ipnet v4"));
            }
            let mut octets = [0u8; 4];
            octets.copy_from_slice(&buf[pos..pos + 4]);
            pos += 4;
            let prefix_len = buf[pos];
            pos += 1;
            let addr = std::net::Ipv4Addr::from(octets);
            let net = ipnet::Ipv4Net::new(addr, prefix_len)
                .map_err(|_| CodecError::InvalidIpPrefix(prefix_len))?;
            Ok((ipnet::IpNet::V4(net), pos))
        }
        6 => {
            if pos + 17 > buf.len() {
                return Err(CodecError::Truncated("ipnet v6"));
            }
            let mut octets = [0u8; 16];
            octets.copy_from_slice(&buf[pos..pos + 16]);
            pos += 16;
            let prefix_len = buf[pos];
            pos += 1;
            let addr = std::net::Ipv6Addr::from(octets);
            let net = ipnet::Ipv6Net::new(addr, prefix_len)
                .map_err(|_| CodecError::InvalidIpPrefix(prefix_len))?;
            Ok((ipnet::IpNet::V6(net), pos))
        }
        other => Err(CodecError::InvalidIpFamily(other)),
    }
}
