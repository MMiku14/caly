//! Reverse Domain Radix Trie for O(L * log k) exact and suffix lookups.

use std::borrow::Cow;
use std::collections::HashMap;

pub const NONE: u32 = u32::MAX;
pub const MAX_LABEL_DEPTH: usize = 128;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum DomainMatchKind {
    Exact,
    Suffix,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct DomainMatch {
    pub kind: DomainMatchKind,
    pub rule_id: u32,
}

#[repr(C)]
#[derive(Debug, Clone, Copy)]
pub struct SealedNode {
    pub label_idx: u32,
    pub children_start: u32,
    pub children_len: u32,
    pub depth: u32,
    pub exact_value: u32,
    pub suffix_value: u32,
}

const _: () = assert!(std::mem::size_of::<SealedNode>() == 24);

#[repr(C)]
#[derive(Debug, Clone, Copy, Default)]
pub struct ChildEntry {
    pub label_idx: u32,
    pub node_idx: u32,
}

const _: () = assert!(std::mem::size_of::<ChildEntry>() == 8);

#[derive(Debug)]
struct BuildNode {
    children: HashMap<Box<str>, BuildNode>,
    exact_value: u32,
    suffix_value: u32,
}

impl Default for BuildNode {
    #[inline]
    fn default() -> Self {
        Self {
            children: HashMap::new(),
            exact_value: NONE,
            suffix_value: NONE,
        }
    }
}

impl BuildNode {
    #[inline]
    fn new() -> Self {
        Self::default()
    }

    fn insert(&mut self, labels: &[&str], is_exact: bool, value: u32) {
        if labels.is_empty() {
            if is_exact {
                self.exact_value = value;
            } else {
                self.suffix_value = value;
            }
            return;
        }
        let child = self.children.entry(labels[0].into()).or_default();
        child.insert(&labels[1..], is_exact, value);
    }
}

#[derive(Debug, Default)]
pub struct ReverseDomainTrie {
    nodes: Vec<SealedNode>,
    children: Vec<ChildEntry>,
    labels: Vec<Box<str>>,
    sealed: bool,
    builder: Option<BuildNode>,
}

impl ReverseDomainTrie {
    pub fn new() -> Self {
        Self {
            nodes: Vec::new(),
            children: Vec::new(),
            labels: Vec::new(),
            sealed: false,
            builder: Some(BuildNode::new()),
        }
    }

    pub fn insert(&mut self, domain: &str, is_exact: bool, value: u32) {
        if self.sealed {
            panic!(
                "ReverseDomainTrie::insert called after seal; cannot modify sealed trie (domain={:?})",
                domain
            );
        }
        let normalized = normalize_domain(domain);
        if normalized.is_empty() {
            return;
        }
        let labels: Vec<&str> = normalized
            .split('.')
            .filter(|s| !s.is_empty())
            .rev()
            .collect();
        if labels.is_empty() || labels.len() > MAX_LABEL_DEPTH {
            return;
        }
        let b = self
            .builder
            .as_mut()
            .expect("invariant: builder must exist before seal");
        b.insert(&labels, is_exact, value);
    }

    pub fn seal(&mut self) {
        if self.sealed {
            return;
        }
        let root = self.builder.take().unwrap_or_default();
        self.nodes.clear();
        self.children.clear();
        self.labels.clear();
        self.seal_bfs(&root);
        self.sealed = true;
    }

    fn seal_bfs(&mut self, root: &BuildNode) {
        use std::collections::{HashMap, VecDeque};

        self.nodes.push(SealedNode {
            label_idx: NONE,
            children_start: 0,
            children_len: 0,
            depth: 0,
            exact_value: root.exact_value,
            suffix_value: root.suffix_value,
        });

        let mut queue = VecDeque::new();
        queue.push_back((0usize, root, 0u32));
        let mut label_map: HashMap<&str, u32> = HashMap::new();

        while let Some((parent_idx, build_node, depth)) = queue.pop_front() {
            if build_node.children.is_empty() {
                continue;
            }
            let mut sorted_children: Vec<(&str, &BuildNode)> = build_node
                .children
                .iter()
                .map(|(k, v)| (k.as_ref(), v))
                .collect();
            sorted_children.sort_by(|a, b| a.0.cmp(b.0));

            let children_start = self.children.len() as u32;
            let children_len = sorted_children.len() as u32;

            for (label, child_node) in sorted_children {
                let label_idx = match label_map.get(label) {
                    Some(&idx) => idx,
                    None => {
                        let idx = self.labels.len() as u32;
                        self.labels.push(label.into());
                        label_map.insert(label, idx);
                        idx
                    }
                };

                let child_node_idx = self.nodes.len();
                self.nodes.push(SealedNode {
                    label_idx,
                    children_start: 0,
                    children_len: 0,
                    depth: depth + 1,
                    exact_value: child_node.exact_value,
                    suffix_value: child_node.suffix_value,
                });
                self.children.push(ChildEntry {
                    label_idx,
                    node_idx: child_node_idx as u32,
                });
                queue.push_back((child_node_idx, child_node, depth + 1));
            }

            self.nodes[parent_idx].children_start = children_start;
            self.nodes[parent_idx].children_len = children_len;
        }
    }

    pub fn lookup(&self, domain: &str) -> Option<DomainMatch> {
        debug_assert!(self.sealed, "trie must be sealed before lookup");
        let normalized = normalize_domain(domain);
        if normalized.is_empty() || self.nodes.is_empty() {
            return None;
        }

        // 消除 Vec<&str> 分配：
        // 先 O(L) 扫描计数（不分配），再 rsplit 单次遍历匹配。
        //
        // 旧实现在每次 lookup 时构造一个 Vec<&str>。域名查询是热路径
        //（每个新建连接至少一次），一次堆分配 (~24B + 3-5 个 &str 槽位)
        // 在高 QPS 下累积成可观的分配器压力。
        //
        // rsplit 天然按 TLD → 子域顺序产出 label，与反向 Trie 结构对齐。
        // 连续点产生的空 label 用 `if label.is_empty() { continue; }` 跳过。
        let label_count = normalized
            .split('.')
            .filter(|s| !s.is_empty())
            .count();
        if label_count == 0 || label_count > MAX_LABEL_DEPTH {
            return None;
        }

        let mut cur = 0u32;
        let mut deepest_suffix: Option<DomainMatch> = None;
        let mut consumed = 0usize;

        for label in normalized.rsplit('.') {
            if label.is_empty() {
                continue;
            }
            let node = &self.nodes[cur as usize];
            let child = match self.find_child(node, label) {
                Some(c) => c,
                None => break,
            };
            cur = child;
            consumed += 1;
            let child_node = &self.nodes[cur as usize];
            if child_node.suffix_value != NONE {
                deepest_suffix = Some(DomainMatch {
                    kind: DomainMatchKind::Suffix,
                    rule_id: child_node.suffix_value,
                });
            }
        }

        let final_node = &self.nodes[cur as usize];
        if consumed == label_count && final_node.exact_value != NONE {
            return Some(DomainMatch {
                kind: DomainMatchKind::Exact,
                rule_id: final_node.exact_value,
            });
        }

        deepest_suffix
    }

    fn find_child(&self, node: &SealedNode, label: &str) -> Option<u32> {
        let start = node.children_start as usize;
        let len = node.children_len as usize;
        if len == 0 {
            return None;
        }
        let end = start.checked_add(len)?;
        if end > self.children.len() {
            return None;
        }
        let slice = &self.children[start..end];
        // 修复（Round 20）：加入 label_idx 边界检查。
        //
        // load_from_archive 会调用 verify_trie_structure 校验，但
        // 该函数在 release 构建下可能被裁剪（debug_assertions 分支）。
        // 且 find_child 会随每次域名查询被调用，任何越界索引都会在
        // 热路径上直接 panic（Abort），SIGSEGV 级别，无法恢复。
        //
        // 用 get() 替代 [] 索引：损坏归档返回 None（回落 final
        // outbound），而不是崩溃。
        match slice.binary_search_by(|entry| {
            match self.labels.get(entry.label_idx as usize) {
                Some(l) => l.as_ref().cmp(label),
                // 缺失 label 视为"不匹配任何查询" —— 用不可能匹配的
                // 哨兵值，保证 binary_search 得到一个稳定的 Err。
                None => std::cmp::Ordering::Greater,
            }
        }) {
            Ok(idx) => {
                // 二次边界检查：node_idx 可能被损坏数据越界。
                let node_idx = slice[idx].node_idx;
                if (node_idx as usize) < self.nodes.len() {
                    Some(node_idx)
                } else {
                    None
                }
            }
            Err(_) => None,
        }
    }

    pub fn is_sealed(&self) -> bool {
        self.sealed
    }

    pub fn node_count(&self) -> usize {
        self.nodes.len()
    }

    pub fn rule_count(&self) -> usize {
        self.nodes
            .iter()
            .filter(|n| n.exact_value != NONE || n.suffix_value != NONE)
            .count()
    }

    pub fn nodes_slice(&self) -> &[SealedNode] {
        &self.nodes
    }

    pub fn children_slice(&self) -> &[ChildEntry] {
        &self.children
    }

    pub fn labels_slice(&self) -> &[Box<str>] {
        &self.labels
    }

    pub fn from_parts(
        nodes: Vec<SealedNode>,
        children: Vec<ChildEntry>,
        labels: Vec<Box<str>>,
    ) -> Self {
        Self {
            nodes,
            children,
            labels,
            sealed: true,
            builder: None,
        }
    }
}

#[inline]
fn normalize_domain(domain: &str) -> Cow<'_, str> {
    let trimmed = domain
        .trim()
        .trim_start_matches('.')
        .trim_end_matches('.');
    if trimmed.bytes().any(|b| b.is_ascii_uppercase()) {
        Cow::Owned(trimmed.to_ascii_lowercase())
    } else {
        Cow::Borrowed(trimmed)
    }
}
