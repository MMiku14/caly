//! Patricia Trie Longest Prefix Match over Vec<FlatNode>.

use std::net::IpAddr;

pub const NULL_IDX: u32 = u32::MAX;

#[repr(C, align(16))]
#[derive(Debug, Clone, Copy)]
pub struct FlatNode {
    pub prefix: u128,
    pub rule_id: u32,
    pub left: u32,
    pub right: u32,
    pub prefix_len: u8,
    pub _pad: [u8; 3],
}

impl Default for FlatNode {
    fn default() -> Self {
        Self {
            prefix: 0,
            rule_id: u32::MAX,
            left: NULL_IDX,
            right: NULL_IDX,
            prefix_len: 0,
            _pad: [0; 3],
        }
    }
}

const _: () = assert!(std::mem::size_of::<FlatNode>() == 32);
const _: () = assert!(std::mem::align_of::<FlatNode>() == 16);

#[derive(Debug, Clone, Default)]
pub struct TreeBitmapLpm {
    v4_nodes: Vec<FlatNode>,
    v6_nodes: Vec<FlatNode>,
}

impl TreeBitmapLpm {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn insert(&mut self, net: ipnet::IpNet, rule_id: u32) {
        match net {
            ipnet::IpNet::V4(n) => {
                if self.v4_nodes.is_empty() {
                    self.v4_nodes.push(FlatNode::default());
                }
                let prefix = (u32::from(n.network()) as u128) << 96;
                let nodes = &mut self.v4_nodes;
                Self::insert_into(nodes, 0, prefix, n.prefix_len(), rule_id);
            }
            ipnet::IpNet::V6(n) => {
                if self.v6_nodes.is_empty() {
                    self.v6_nodes.push(FlatNode::default());
                }
                let prefix = u128::from(n.network());
                let nodes = &mut self.v6_nodes;
                Self::insert_into(nodes, 0, prefix, n.prefix_len(), rule_id);
            }
        }
    }

    #[inline]
    pub fn lookup(&self, ip: IpAddr) -> Option<u32> {
        match ip {
            IpAddr::V4(v4) => {
                if self.v4_nodes.is_empty() {
                    return None;
                }
                let addr = (u32::from(v4) as u128) << 96;
                Self::lookup_in(&self.v4_nodes, addr)
            }
            IpAddr::V6(v6) => {
                if self.v6_nodes.is_empty() {
                    return None;
                }
                let addr = u128::from(v6);
                Self::lookup_in(&self.v6_nodes, addr)
            }
        }
    }

    pub fn len(&self) -> usize {
        let v4 = self.v4_nodes.iter().filter(|n| n.rule_id != u32::MAX).count();
        let v6 = self.v6_nodes.iter().filter(|n| n.rule_id != u32::MAX).count();
        v4 + v6
    }

    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    pub fn nodes_v4(&self) -> &[FlatNode] {
        &self.v4_nodes
    }

    pub fn nodes_v6(&self) -> &[FlatNode] {
        &self.v6_nodes
    }

    pub fn from_parts(v4_nodes: Vec<FlatNode>, v6_nodes: Vec<FlatNode>) -> Self {
        Self { v4_nodes, v6_nodes }
    }

    fn insert_into(
        nodes: &mut Vec<FlatNode>,
        start_idx: u32,
        prefix: u128,
        prefix_len: u8,
        rule_id: u32,
    ) {
        let mut cur = start_idx as usize;
        loop {
            let cur_node = nodes[cur];
            if cur_node.rule_id == u32::MAX
                && cur_node.left == NULL_IDX
                && cur_node.right == NULL_IDX
            {
                nodes[cur].prefix = prefix;
                nodes[cur].prefix_len = prefix_len;
                nodes[cur].rule_id = rule_id;
                return;
            }

            let common = common_prefix_len(cur_node.prefix, prefix, cur_node.prefix_len.min(prefix_len));
            if common == cur_node.prefix_len && common == prefix_len {
                nodes[cur].rule_id = rule_id;
                return;
            }

            if common == cur_node.prefix_len {
                let bit = get_bit(prefix, cur_node.prefix_len);
                let child_idx = if bit { cur_node.right } else { cur_node.left };
                if child_idx == NULL_IDX {
                    let new_idx = nodes.len() as u32;
                    nodes.push(FlatNode {
                        prefix,
                        prefix_len,
                        rule_id,
                        left: NULL_IDX,
                        right: NULL_IDX,
                        _pad: [0; 3],
                    });
                    if bit {
                        nodes[cur].right = new_idx;
                    } else {
                        nodes[cur].left = new_idx;
                    }
                    return;
                } else {
                    cur = child_idx as usize;
                    continue;
                }
            }

            let old_prefix = cur_node.prefix;
            let old_len = cur_node.prefix_len;
            let old_rule = cur_node.rule_id;
            let old_left = cur_node.left;
            let old_right = cur_node.right;

            if common == prefix_len {
                let old_leaf_idx = nodes.len() as u32;
                nodes.push(FlatNode {
                    prefix: old_prefix,
                    prefix_len: old_len,
                    rule_id: old_rule,
                    left: old_left,
                    right: old_right,
                    _pad: [0; 3],
                });
                nodes[cur].prefix = prefix;
                nodes[cur].prefix_len = prefix_len;
                nodes[cur].rule_id = rule_id;
                let old_bit = get_bit(old_prefix, common);
                if old_bit {
                    nodes[cur].left = NULL_IDX;
                    nodes[cur].right = old_leaf_idx;
                } else {
                    nodes[cur].left = old_leaf_idx;
                    nodes[cur].right = NULL_IDX;
                }
                return;
            }

            let new_node_idx = nodes.len() as u32;
            let old_leaf_idx = nodes.len() as u32 + 1;
            nodes.push(FlatNode::default());
            nodes.push(FlatNode::default());

            nodes[cur].prefix = apply_mask(prefix, common);
            nodes[cur].prefix_len = common;
            nodes[cur].rule_id = u32::MAX;

            let old_bit = get_bit(old_prefix, common);
            nodes[old_leaf_idx as usize] = FlatNode {
                prefix: old_prefix,
                prefix_len: old_len,
                rule_id: old_rule,
                left: old_left,
                right: old_right,
                _pad: [0; 3],
            };
            nodes[new_node_idx as usize] = FlatNode {
                prefix,
                prefix_len,
                rule_id,
                left: NULL_IDX,
                right: NULL_IDX,
                _pad: [0; 3],
            };

            if old_bit {
                nodes[cur].right = old_leaf_idx;
                nodes[cur].left = new_node_idx;
            } else {
                nodes[cur].left = old_leaf_idx;
                nodes[cur].right = new_node_idx;
            }
            return;
        }
    }

    fn lookup_in(nodes: &[FlatNode], addr: u128) -> Option<u32> {
        let mut cur = 0usize;
        let mut best: Option<u32> = None;
        loop {
            // 修复（Round 21）：加入 cur 边界检查。
            //
            // 触发路径：`ArchiveLoader::load` 反序列化损坏的归档，
            // 或测试代码用 `TreeBitmapLpm::from_parts` 手工构造
            // 越界子节点索引。旧实现 `&nodes[cur]` 直接 panic，
            // release 构建下 panic=abort → 进程直接死。
            //
            // 正常 insert 后 seal 的 trie 不会触发此检查。返回 best
            // 保证"最长前缀匹配"的降级语义（能匹配多少算多少）。
            if cur >= nodes.len() {
                return best;
            }
            let node = &nodes[cur];
            if !prefix_matches(node.prefix, addr, node.prefix_len) {
                return best;
            }
            if node.rule_id != u32::MAX {
                best = Some(node.rule_id);
            }
            if node.prefix_len >= 128 {
                return best;
            }
            let bit = get_bit(addr, node.prefix_len);
            let next = if bit { node.right } else { node.left };
            if next == NULL_IDX {
                return best;
            }
            cur = next as usize;
        }
    }
}

#[inline(always)]
fn get_bit(addr: u128, idx: u8) -> bool {
    let shift = 127u32.saturating_sub(idx as u32);
    ((addr >> shift) & 1) != 0
}

#[inline(always)]
fn apply_mask(prefix: u128, len: u8) -> u128 {
    let clamped_len = len.min(128);
    if clamped_len == 0 {
        0
    } else if clamped_len == 128 {
        prefix
    } else {
        prefix & (!0u128 << (128 - clamped_len as u32))
    }
}

#[inline(always)]
fn prefix_matches(prefix: u128, addr: u128, len: u8) -> bool {
    let clamped_len = len.min(128);
    if clamped_len == 0 {
        return true;
    }
    if clamped_len == 128 {
        return prefix == addr;
    }
    let mask = !0u128 << (128 - clamped_len as u32);
    (prefix & mask) == (addr & mask)
}

#[inline(always)]
fn common_prefix_len(a: u128, b: u128, max: u8) -> u8 {
    if a == b {
        return max;
    }
    let xor = a ^ b;
    let first_diff = xor.leading_zeros() as u8;
    first_diff.min(max)
}
