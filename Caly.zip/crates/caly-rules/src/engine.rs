//! Routing engine combining Reverse Domain Radix Trie, Tree-Bitmap LPM, and composable logic rules.

use crate::domain_trie::ReverseDomainTrie;
use crate::ip_tree::TreeBitmapLpm;
use crate::logic::{RuleCondition, RuleItem};
use caly_common::metadata::SessionMetadata;
use smol_str::SmolStr;
use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::Arc;

#[derive(Debug)]
pub struct RuleMetrics {
    pub domain_hits: Vec<AtomicU64>,
    pub ip_hits: Vec<AtomicU64>,
    pub logic_hits: Vec<AtomicU64>,
    pub total_matched: AtomicU64,
    pub total_final: AtomicU64,
    pub explain_nanos_total: AtomicU64,
    pub explain_count: AtomicU64,
}

impl RuleMetrics {
    fn new(domain_count: usize, ip_count: usize, logic_count: usize) -> Self {
        Self {
            domain_hits: (0..domain_count).map(|_| AtomicU64::new(0)).collect(),
            ip_hits: (0..ip_count).map(|_| AtomicU64::new(0)).collect(),
            logic_hits: (0..logic_count).map(|_| AtomicU64::new(0)).collect(),
            total_matched: AtomicU64::new(0),
            total_final: AtomicU64::new(0),
            explain_nanos_total: AtomicU64::new(0),
            explain_count: AtomicU64::new(0),
        }
    }

    pub fn snapshot(&self) -> RuleMetricsSnapshot {
        RuleMetricsSnapshot {
            domain_hits: self.domain_hits.iter().map(|a| a.load(Ordering::Relaxed)).collect(),
            ip_hits: self.ip_hits.iter().map(|a| a.load(Ordering::Relaxed)).collect(),
            logic_hits: self.logic_hits.iter().map(|a| a.load(Ordering::Relaxed)).collect(),
            total_matched: self.total_matched.load(Ordering::Relaxed),
            total_final: self.total_final.load(Ordering::Relaxed),
            explain_nanos_total: self.explain_nanos_total.load(Ordering::Relaxed),
            explain_count: self.explain_count.load(Ordering::Relaxed),
        }
    }
}

#[derive(Debug, Clone)]
pub struct RuleMetricsSnapshot {
    pub domain_hits: Vec<u64>,
    pub ip_hits: Vec<u64>,
    pub logic_hits: Vec<u64>,
    pub total_matched: u64,
    pub total_final: u64,
    pub explain_nanos_total: u64,
    pub explain_count: u64,
}

impl RuleMetricsSnapshot {
    pub fn avg_explain_nanos(&self) -> u64 {
        self.explain_nanos_total
            .checked_div(self.explain_count)
            .unwrap_or(0)
    }
}

#[derive(Debug)]
pub struct RuleEngine {
    domain_trie: ReverseDomainTrie,
    domain_outbounds: Vec<SmolStr>,
    ip_tree: TreeBitmapLpm,
    ip_outbounds: Vec<SmolStr>,
    logic_rules: Vec<RuleItem>,
    final_outbound: SmolStr,
    pub metrics: Arc<RuleMetrics>,
}

impl RuleEngine {
    pub fn new(rules: Vec<RuleItem>, final_outbound: &str) -> Self {
        let mut domain_trie = ReverseDomainTrie::new();
        let mut domain_outbounds: Vec<SmolStr> = Vec::new();
        let mut ip_tree = TreeBitmapLpm::new();
        let mut ip_outbounds: Vec<SmolStr> = Vec::new();
        let mut logic_rules: Vec<RuleItem> = Vec::new();

        for rule in &rules {
            match &rule.condition {
                RuleCondition::Domain(d) => {
                    let idx = domain_outbounds.len() as u32;
                    domain_trie.insert(d.as_str(), true, idx);
                    domain_outbounds.push(rule.outbound.clone());
                }
                RuleCondition::DomainSuffix(s) => {
                    let idx = domain_outbounds.len() as u32;
                    domain_trie.insert(s.as_str(), false, idx);
                    domain_outbounds.push(rule.outbound.clone());
                }
                RuleCondition::IpCidr(net) => {
                    let idx = ip_outbounds.len() as u32;
                    ip_tree.insert(*net, idx);
                    ip_outbounds.push(rule.outbound.clone());
                }
                _ => logic_rules.push(rule.clone()),
            }
        }
        domain_trie.seal();

        let metrics = Arc::new(RuleMetrics::new(
            domain_outbounds.len(),
            ip_outbounds.len(),
            logic_rules.len(),
        ));

        Self {
            domain_trie,
            domain_outbounds,
            ip_tree,
            ip_outbounds,
            logic_rules,
            final_outbound: SmolStr::new(final_outbound),
            metrics,
        }
    }

    #[inline]
    pub fn match_outbound(&self, meta: &SessionMetadata) -> &str {
        // 1. Logic rules (port, protocol, process, complex combinations)
        for (i, rule) in self.logic_rules.iter().enumerate() {
            if rule.condition.matches(meta) {
                if let Some(c) = self.metrics.logic_hits.get(i) {
                    c.fetch_add(1, Ordering::Relaxed);
                }
                self.metrics.total_matched.fetch_add(1, Ordering::Relaxed);
                return rule.outbound.as_str();
            }
        }

        // 2. Domain Trie O(L * log k)
        if meta.has_domain() {
            if let Some(m) = self.domain_trie.lookup(meta.domain.as_str()) {
                let idx = m.rule_id as usize;
                if idx < self.domain_outbounds.len() {
                    if let Some(c) = self.metrics.domain_hits.get(idx) {
                        c.fetch_add(1, Ordering::Relaxed);
                    }
                    self.metrics.total_matched.fetch_add(1, Ordering::Relaxed);
                    return self.domain_outbounds[idx].as_str();
                }
            }
        }

        // 3. IP Patricia Trie
        if let Some(ridx) = self.ip_tree.lookup(meta.dst_addr.ip()) {
            let idx = ridx as usize;
            if idx < self.ip_outbounds.len() {
                if let Some(c) = self.metrics.ip_hits.get(idx) {
                    c.fetch_add(1, Ordering::Relaxed);
                }
                self.metrics.total_matched.fetch_add(1, Ordering::Relaxed);
                return self.ip_outbounds[idx].as_str();
            }
        }

        self.metrics.total_final.fetch_add(1, Ordering::Relaxed);
        self.final_outbound.as_str()
    }

    pub fn stats(&self) -> RuleEngineStats {
        RuleEngineStats {
            domain_rules: self.domain_outbounds.len(),
            ip_rules: self.ip_outbounds.len(),
            logic_rules: self.logic_rules.len(),
        }
    }

    pub fn explain(&self, meta: &SessionMetadata) -> RuleExplanation {
        let t0 = std::time::Instant::now();
        let result = self.explain_inner(meta);
        let elapsed = t0.elapsed().as_nanos() as u64;
        self.metrics
            .explain_nanos_total
            .fetch_add(elapsed, Ordering::Relaxed);
        self.metrics.explain_count.fetch_add(1, Ordering::Relaxed);
        result
    }

    pub fn explain_internal(&self, meta: &SessionMetadata) -> RuleExplanation {
        self.explain_inner(meta)
    }

    fn explain_inner(&self, meta: &SessionMetadata) -> RuleExplanation {
        for (i, rule) in self.logic_rules.iter().enumerate() {
            if rule.condition.matches(meta) {
                return RuleExplanation {
                    kind: RuleMatchKind::Logic,
                    index: Some(i),
                    condition: Some(rule.condition.clone()),
                    outbound: rule.outbound.to_string(),
                };
            }
        }
        if meta.has_domain() {
            if let Some(m) = self.domain_trie.lookup(meta.domain.as_str()) {
                let idx = m.rule_id as usize;
                if idx < self.domain_outbounds.len() {
                    return RuleExplanation {
                        kind: RuleMatchKind::Domain,
                        index: Some(idx),
                        condition: None,
                        outbound: self.domain_outbounds[idx].to_string(),
                    };
                }
            }
        }
        if let Some(ridx) = self.ip_tree.lookup(meta.dst_addr.ip()) {
            let idx = ridx as usize;
            if idx < self.ip_outbounds.len() {
                return RuleExplanation {
                    kind: RuleMatchKind::Ip,
                    index: Some(idx),
                    condition: None,
                    outbound: self.ip_outbounds[idx].to_string(),
                };
            }
        }
        RuleExplanation {
            kind: RuleMatchKind::Final,
            index: None,
            condition: None,
            outbound: self.final_outbound.to_string(),
        }
    }

    pub fn iter_all(&self) -> Vec<RuleDumpItem> {
        let mut out: Vec<RuleDumpItem> = Vec::new();
        for (i, rule) in self.logic_rules.iter().enumerate() {
            out.push(RuleDumpItem {
                kind: RuleMatchKind::Logic,
                index: i,
                condition: Some(rule.condition.clone()),
                outbound: rule.outbound.to_string(),
            });
        }
        for (i, outbound) in self.ip_outbounds.iter().enumerate() {
            out.push(RuleDumpItem {
                kind: RuleMatchKind::Ip,
                index: i,
                condition: None,
                outbound: outbound.to_string(),
            });
        }
        for (i, outbound) in self.domain_outbounds.iter().enumerate() {
            out.push(RuleDumpItem {
                kind: RuleMatchKind::Domain,
                index: i,
                condition: None,
                outbound: outbound.to_string(),
            });
        }
        out
    }

    pub fn top_hits(&self, limit: usize) -> Vec<RuleHitInfo> {
        let snap = self.metrics.snapshot();
        let mut items: Vec<RuleHitInfo> = Vec::new();
        for (i, hits) in snap.logic_hits.iter().enumerate() {
            if *hits > 0 {
                if let Some(rule) = self.logic_rules.get(i) {
                    items.push(RuleHitInfo {
                        kind: RuleMatchKind::Logic,
                        index: i,
                        hits: *hits,
                        condition: Some(rule.condition.clone()),
                        outbound: rule.outbound.to_string(),
                    });
                }
            }
        }
        for (i, hits) in snap.ip_hits.iter().enumerate() {
            if *hits > 0 {
                if let Some(outbound) = self.ip_outbounds.get(i) {
                    items.push(RuleHitInfo {
                        kind: RuleMatchKind::Ip,
                        index: i,
                        hits: *hits,
                        condition: None,
                        outbound: outbound.to_string(),
                    });
                }
            }
        }
        for (i, hits) in snap.domain_hits.iter().enumerate() {
            if *hits > 0 {
                if let Some(outbound) = self.domain_outbounds.get(i) {
                    items.push(RuleHitInfo {
                        kind: RuleMatchKind::Domain,
                        index: i,
                        hits: *hits,
                        condition: None,
                        outbound: outbound.to_string(),
                    });
                }
            }
        }
        items.sort_by_key(|a| std::cmp::Reverse(a.hits));
        items.truncate(limit);
        items
    }

    pub fn domain_parts(&self) -> (&ReverseDomainTrie, &[SmolStr]) {
        (&self.domain_trie, &self.domain_outbounds)
    }

    pub fn logic_rules(&self) -> &[RuleItem] {
        &self.logic_rules
    }

    pub fn lpm_nodes(&self) -> (&[crate::ip_tree::FlatNode], &[crate::ip_tree::FlatNode]) {
        (self.ip_tree.nodes_v4(), self.ip_tree.nodes_v6())
    }

    pub fn ip_outbounds(&self) -> &[SmolStr] {
        &self.ip_outbounds
    }

    pub fn final_outbound_str(&self) -> &str {
        self.final_outbound.as_str()
    }

    pub fn metrics_snapshot(&self) -> RuleMetricsSnapshot {
        self.metrics.snapshot()
    }

    pub fn from_archive_full_with_logic(
        domain_trie: ReverseDomainTrie,
        domain_outbounds: Vec<SmolStr>,
        ip_outbounds: Vec<SmolStr>,
        ip_tree: TreeBitmapLpm,
        final_outbound: String,
        logic_rules: Vec<RuleItem>,
    ) -> Self {
        let metrics = Arc::new(RuleMetrics::new(
            domain_outbounds.len(),
            ip_outbounds.len(),
            logic_rules.len(),
        ));
        Self {
            domain_trie,
            domain_outbounds,
            ip_tree,
            ip_outbounds,
            logic_rules,
            final_outbound: SmolStr::new(final_outbound),
            metrics,
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct RuleEngineStats {
    pub domain_rules: usize,
    pub ip_rules: usize,
    pub logic_rules: usize,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum RuleMatchKind {
    Domain,
    Ip,
    Logic,
    Final,
}

impl RuleMatchKind {
    pub fn as_str(&self) -> &'static str {
        match self {
            RuleMatchKind::Domain => "domain",
            RuleMatchKind::Ip => "ip",
            RuleMatchKind::Logic => "logic",
            RuleMatchKind::Final => "final",
        }
    }
}

#[derive(Debug, Clone)]
pub struct RuleExplanation {
    pub kind: RuleMatchKind,
    pub index: Option<usize>,
    pub condition: Option<RuleCondition>,
    pub outbound: String,
}

#[derive(Debug, Clone)]
pub struct RuleDumpItem {
    pub kind: RuleMatchKind,
    pub index: usize,
    pub condition: Option<RuleCondition>,
    pub outbound: String,
}

#[derive(Debug, Clone)]
pub struct RuleHitInfo {
    pub kind: RuleMatchKind,
    pub index: usize,
    pub hits: u64,
    pub condition: Option<RuleCondition>,
    pub outbound: String,
}
