//! Compiled rule archive serializer and deserializer with SHA256 integrity checks.

use crate::domain_trie::{ChildEntry, ReverseDomainTrie, SealedNode};
use crate::engine::RuleEngine;
use crate::ip_tree::FlatNode;
use crate::ip_tree::TreeBitmapLpm;
use crate::logic::RuleItem;
use crate::logic_codec::{read_condition, write_condition, CodecError};
use byteorder::{ByteOrder, LittleEndian};
use sha2::{Digest, Sha256};
use smol_str::SmolStr;
use std::fs::File;
use std::io::{BufWriter, Write};
use std::path::Path;
use thiserror::Error;

pub const MAGIC_CALY: [u8; 4] = *b"CALY";
pub const CURRENT_FORMAT_VERSION: u32 = 4;
pub const HEADER_SIZE: usize = 64;
pub const ALIGN: usize = 16;

#[derive(Error, Debug)]
pub enum LoadError {
    #[error("I/O error: {0}")]
    Io(#[from] std::io::Error),
    #[error("magic mismatch: not a Caly rule archive")]
    InvalidMagic,
    #[error("SHA256 checksum mismatch")]
    ChecksumMismatch,
    #[error("unsupported format version: {0}")]
    VersionMismatch(u32),
    #[error("file too small")]
    FileTooSmall,
    #[error("corrupt payload: {0}")]
    Corrupt(String),
}

#[derive(Error, Debug)]
pub enum SaveError {
    #[error("I/O error: {0}")]
    Io(#[from] std::io::Error),
    #[error("payload too large: {0} bytes")]
    PayloadTooLarge(usize),
}

impl From<CodecError> for LoadError {
    fn from(e: CodecError) -> Self {
        LoadError::Corrupt(format!("logic codec: {e}"))
    }
}

pub struct ArchiveWriter;

impl ArchiveWriter {
    pub fn save(engine: &RuleEngine, path: &Path) -> Result<(), SaveError> {
        let payload = Self::serialize(engine)?;
        let mut file = BufWriter::new(File::create(path)?);
        let mut hasher = Sha256::new();
        hasher.update(&payload);
        let checksum = hasher.finalize();

        let mut header = [0u8; HEADER_SIZE];
        header[0..4].copy_from_slice(&MAGIC_CALY);
        LittleEndian::write_u32(&mut header[4..8], CURRENT_FORMAT_VERSION);
        header[8] = 0; // little-endian
        header[9] = ALIGN.trailing_zeros() as u8;
        LittleEndian::write_u64(&mut header[12..20], payload.len() as u64);
        header[20..52].copy_from_slice(&checksum);

        file.write_all(&header)?;
        file.write_all(&payload)?;
        file.flush()?;
        Ok(())
    }

    fn serialize(engine: &RuleEngine) -> Result<Vec<u8>, SaveError> {
        let mut buf = Vec::with_capacity(1024 * 1024);
        let (domain_trie, domain_outbounds) = engine.domain_parts();

        #[cfg(debug_assertions)]
        {
            if domain_trie.is_sealed() {
                verify_trie_structure(
                    domain_trie.nodes_slice(),
                    domain_trie.children_slice(),
                    domain_trie.labels_slice(),
                )
                .expect("trie structure invalid before serialize");
            }
        }

        write_domain_trie(&mut buf, domain_trie, domain_outbounds);
        let (v4_nodes, v6_nodes) = engine.lpm_nodes();
        write_lpm(&mut buf, v4_nodes);
        write_lpm(&mut buf, v6_nodes);
        write_string_table(&mut buf, engine.ip_outbounds());
        write_string(&mut buf, engine.final_outbound_str());
        write_logic_rules(&mut buf, engine.logic_rules());
        Ok(buf)
    }
}

fn write_domain_trie(buf: &mut Vec<u8>, trie: &ReverseDomainTrie, outbounds: &[SmolStr]) {
    let nodes = trie.nodes_slice();
    buf.extend_from_slice(&(nodes.len() as u32).to_le_bytes());
    for n in nodes {
        buf.extend_from_slice(&n.label_idx.to_le_bytes());
        buf.extend_from_slice(&n.children_start.to_le_bytes());
        buf.extend_from_slice(&n.children_len.to_le_bytes());
        buf.extend_from_slice(&n.depth.to_le_bytes());
        buf.extend_from_slice(&n.exact_value.to_le_bytes());
        buf.extend_from_slice(&n.suffix_value.to_le_bytes());
    }

    let children = trie.children_slice();
    buf.extend_from_slice(&(children.len() as u32).to_le_bytes());
    for c in children {
        buf.extend_from_slice(&c.label_idx.to_le_bytes());
        buf.extend_from_slice(&c.node_idx.to_le_bytes());
    }

    let labels = trie.labels_slice();
    buf.extend_from_slice(&(labels.len() as u32).to_le_bytes());
    for l in labels {
        let bytes = l.as_bytes();
        buf.extend_from_slice(&(bytes.len() as u32).to_le_bytes());
        buf.extend_from_slice(bytes);
    }

    write_string_table(buf, outbounds);
}

fn write_lpm(buf: &mut Vec<u8>, nodes: &[FlatNode]) {
    buf.extend_from_slice(&(nodes.len() as u32).to_le_bytes());
    for node in nodes {
        buf.extend_from_slice(&node.prefix.to_le_bytes());
        buf.extend_from_slice(&node.rule_id.to_le_bytes());
        buf.extend_from_slice(&node.left.to_le_bytes());
        buf.extend_from_slice(&node.right.to_le_bytes());
        buf.push(node.prefix_len);
        buf.extend_from_slice(&node._pad);
    }
}

fn write_string_table(buf: &mut Vec<u8>, strings: &[SmolStr]) {
    buf.extend_from_slice(&(strings.len() as u32).to_le_bytes());
    for s in strings {
        let bytes = s.as_bytes();
        buf.extend_from_slice(&(bytes.len() as u32).to_le_bytes());
        buf.extend_from_slice(bytes);
    }
}

fn write_string(buf: &mut Vec<u8>, s: &str) {
    buf.extend_from_slice(&(s.len() as u32).to_le_bytes());
    buf.extend_from_slice(s.as_bytes());
}

#[derive(Debug)]
pub struct ArchiveLoader {
    engine: RuleEngine,
}

impl ArchiveLoader {
    pub fn load(path: &Path) -> Result<Self, LoadError> {
        let file = File::open(path)?;
        let metadata = file.metadata()?;
        if metadata.len() < HEADER_SIZE as u64 {
            return Err(LoadError::FileTooSmall);
        }

        #[cfg(unix)]
        {
            use std::os::unix::io::AsRawFd;
            let fd = file.as_raw_fd();
            let ret = unsafe { libc::flock(fd, libc::LOCK_SH | libc::LOCK_NB) };
            if ret != 0 {
                tracing::warn!(
                    "flock(LOCK_SH) failed on {:?}, continuing read-only",
                    path
                );
            }
        }

        let mmap = unsafe { memmap2::MmapOptions::new().map(&file)? };
        if mmap[0..4] != MAGIC_CALY {
            return Err(LoadError::InvalidMagic);
        }
        let version = LittleEndian::read_u32(&mmap[4..8]);
        if version != CURRENT_FORMAT_VERSION {
            return Err(LoadError::VersionMismatch(version));
        }
        let endian = mmap[8];
        if endian != 0 {
            return Err(LoadError::Corrupt(
                "big-endian archives not supported".into(),
            ));
        }
        let payload_len = LittleEndian::read_u64(&mmap[12..20]) as usize;
        if HEADER_SIZE + payload_len > mmap.len() {
            return Err(LoadError::FileTooSmall);
        }

        let expected = &mmap[20..52];
        let mut hasher = Sha256::new();
        hasher.update(&mmap[HEADER_SIZE..HEADER_SIZE + payload_len]);
        let actual = hasher.finalize();
        if expected != actual.as_slice() {
            return Err(LoadError::ChecksumMismatch);
        }

        #[cfg(target_os = "linux")]
        {
            let _ = mmap.advise(memmap2::Advice::WillNeed);
        }

        let payload = &mmap[HEADER_SIZE..HEADER_SIZE + payload_len];
        let engine = Self::deserialize(payload)?;
        Ok(Self { engine })
    }

    fn deserialize(payload: &[u8]) -> Result<RuleEngine, LoadError> {
        let mut cursor = 0usize;
        let (domain_trie, domain_outbounds, cursor2) = read_domain_trie(payload, cursor)?;
        cursor = cursor2;
        let (v4_nodes, cursor2) = read_lpm(payload, cursor)?;
        cursor = cursor2;
        let (v6_nodes, cursor2) = read_lpm(payload, cursor)?;
        cursor = cursor2;
        let (ip_outbounds, cursor2) = read_string_table(payload, cursor)?;
        cursor = cursor2;
        let (final_outbound, cursor2) = read_string(payload, cursor)?;
        cursor = cursor2;
        let (logic_rules, _cursor2) = read_logic_rules(payload, cursor)?;

        let lpm = TreeBitmapLpm::from_parts(v4_nodes, v6_nodes);
        Ok(RuleEngine::from_archive_full_with_logic(
            domain_trie,
            domain_outbounds,
            ip_outbounds,
            lpm,
            final_outbound,
            logic_rules,
        ))
    }

    pub fn engine(&self) -> &RuleEngine {
        &self.engine
    }

    pub fn into_engine(self) -> RuleEngine {
        self.engine
    }
}

const MAX_ARCHIVE_NODES: usize = 5_000_000;

fn verify_trie_structure(
    nodes: &[SealedNode],
    children: &[ChildEntry],
    labels: &[Box<str>],
) -> Result<(), LoadError> {
    use crate::domain_trie::NONE;
    if nodes.is_empty() {
        return Err(LoadError::Corrupt("domain trie has no nodes".into()));
    }
    if nodes[0].depth != 0 {
        return Err(LoadError::Corrupt(format!(
            "root node depth should be 0, got {}",
            nodes[0].depth
        )));
    }
    if nodes[0].label_idx != NONE {
        return Err(LoadError::Corrupt(format!(
            "root node label_idx should be NONE ({}), got {}",
            NONE, nodes[0].label_idx
        )));
    }

    for (i, node) in nodes.iter().enumerate() {
        let start = node.children_start as usize;
        let len = node.children_len as usize;
        let end = start.checked_add(len).ok_or_else(|| {
            LoadError::Corrupt(format!("node {} children range overflow", i))
        })?;
        if end > children.len() {
            return Err(LoadError::Corrupt(format!(
                "node {} children range [{}, {}) exceeds {} entries",
                i, start, end, children.len()
            )));
        }
        for (k, entry) in children.iter().enumerate().skip(start).take(len) {
            let child_idx = entry.node_idx as usize;
            if child_idx >= nodes.len() {
                return Err(LoadError::Corrupt(format!(
                    "child entry {} points to node {} out of {}",
                    k, child_idx, nodes.len()
                )));
            }
            if entry.label_idx as usize >= labels.len() {
                return Err(LoadError::Corrupt(format!(
                    "child entry {} label_idx {} out of {}",
                    k, entry.label_idx, labels.len()
                )));
            }
            let child = &nodes[child_idx];
            let expected_depth = node.depth + 1;
            if child.depth != expected_depth {
                return Err(LoadError::Corrupt(format!(
                    "child node {} depth {} != parent node {} depth {} + 1",
                    child_idx, child.depth, i, node.depth
                )));
            }
        }
    }
    Ok(())
}

fn read_domain_trie(
    buf: &[u8],
    mut pos: usize,
) -> Result<(ReverseDomainTrie, Vec<SmolStr>, usize), LoadError> {
    if pos + 4 > buf.len() {
        return Err(LoadError::Corrupt("domain trie nodes header".into()));
    }
    let node_count = LittleEndian::read_u32(&buf[pos..pos + 4]) as usize;
    pos += 4;
    if node_count > MAX_ARCHIVE_NODES {
        return Err(LoadError::Corrupt(format!(
            "domain trie node count too large: {node_count}"
        )));
    }
    const NODE_SIZE: usize = 24;
    if pos + node_count * NODE_SIZE > buf.len() {
        return Err(LoadError::Corrupt("domain trie nodes truncated".into()));
    }
    let mut nodes = Vec::with_capacity(node_count);
    for _ in 0..node_count {
        let label_idx = LittleEndian::read_u32(&buf[pos..pos + 4]);
        let children_start = LittleEndian::read_u32(&buf[pos + 4..pos + 8]);
        let children_len = LittleEndian::read_u32(&buf[pos + 8..pos + 12]);
        let depth = LittleEndian::read_u32(&buf[pos + 12..pos + 16]);
        let exact_value = LittleEndian::read_u32(&buf[pos + 16..pos + 20]);
        let suffix_value = LittleEndian::read_u32(&buf[pos + 20..pos + 24]);
        pos += NODE_SIZE;
        nodes.push(SealedNode {
            label_idx,
            children_start,
            children_len,
            depth,
            exact_value,
            suffix_value,
        });
    }

    if pos + 4 > buf.len() {
        return Err(LoadError::Corrupt("domain trie children header".into()));
    }
    let child_count = LittleEndian::read_u32(&buf[pos..pos + 4]) as usize;
    pos += 4;
    if child_count > MAX_ARCHIVE_NODES {
        return Err(LoadError::Corrupt(format!(
            "domain trie child count too large: {child_count}"
        )));
    }
    const CHILD_SIZE: usize = 8;
    if pos + child_count * CHILD_SIZE > buf.len() {
        return Err(LoadError::Corrupt("domain trie children truncated".into()));
    }
    let mut children = Vec::with_capacity(child_count);
    for _ in 0..child_count {
        let label_idx = LittleEndian::read_u32(&buf[pos..pos + 4]);
        let node_idx = LittleEndian::read_u32(&buf[pos + 4..pos + 8]);
        pos += CHILD_SIZE;
        children.push(ChildEntry { label_idx, node_idx });
    }

    let (labels, cursor) = read_box_str_vec(buf, pos)?;
    pos = cursor;
    let (outbounds, cursor) = read_string_table(buf, pos)?;
    pos = cursor;

    verify_trie_structure(&nodes, &children, &labels)?;
    let trie = ReverseDomainTrie::from_parts(nodes, children, labels);
    Ok((trie, outbounds, pos))
}

fn read_lpm(buf: &[u8], mut pos: usize) -> Result<(Vec<FlatNode>, usize), LoadError> {
    if pos + 4 > buf.len() {
        return Err(LoadError::Corrupt("lpm header".into()));
    }
    let count = LittleEndian::read_u32(&buf[pos..pos + 4]) as usize;
    pos += 4;
    if count > MAX_ARCHIVE_NODES {
        return Err(LoadError::Corrupt(format!("lpm node count too large: {count}")));
    }
    let node_size = std::mem::size_of::<FlatNode>();
    debug_assert_eq!(node_size, 32);
    if pos + count * node_size > buf.len() {
        return Err(LoadError::Corrupt("lpm nodes truncated".into()));
    }
    let mut nodes = Vec::with_capacity(count);
    for _ in 0..count {
        let prefix = u128::from_le_bytes(buf[pos..pos + 16].try_into().unwrap());
        let rule_id = LittleEndian::read_u32(&buf[pos + 16..pos + 20]);
        let left = LittleEndian::read_u32(&buf[pos + 20..pos + 24]);
        let right = LittleEndian::read_u32(&buf[pos + 24..pos + 28]);
        let prefix_len = buf[pos + 28];
        let mut pad = [0u8; 3];
        pad.copy_from_slice(&buf[pos + 29..pos + 32]);
        pos += node_size;
        nodes.push(FlatNode {
            prefix,
            rule_id,
            left,
            right,
            prefix_len,
            _pad: pad,
        });
    }
    Ok((nodes, pos))
}

fn read_string_table(buf: &[u8], pos: usize) -> Result<(Vec<SmolStr>, usize), LoadError> {
    read_string_vec(buf, pos)
}

fn read_box_str_vec(buf: &[u8], mut pos: usize) -> Result<(Vec<Box<str>>, usize), LoadError> {
    if pos + 4 > buf.len() {
        return Err(LoadError::Corrupt("box str table header".into()));
    }
    let count = LittleEndian::read_u32(&buf[pos..pos + 4]) as usize;
    pos += 4;
    if count > MAX_ARCHIVE_NODES {
        return Err(LoadError::Corrupt(format!("box str count too large: {count}")));
    }
    let mut out = Vec::with_capacity(count);
    for _ in 0..count {
        if pos + 4 > buf.len() {
            return Err(LoadError::Corrupt("box str len truncated".into()));
        }
        let len = LittleEndian::read_u32(&buf[pos..pos + 4]) as usize;
        pos += 4;
        if pos + len > buf.len() {
            return Err(LoadError::Corrupt("box str body truncated".into()));
        }
        let s = std::str::from_utf8(&buf[pos..pos + len])
            .map_err(|e| LoadError::Corrupt(format!("invalid utf8: {e}")))?;
        out.push(Box::<str>::from(s));
        pos += len;
    }
    Ok((out, pos))
}

fn read_string_vec(buf: &[u8], mut pos: usize) -> Result<(Vec<SmolStr>, usize), LoadError> {
    if pos + 4 > buf.len() {
        return Err(LoadError::Corrupt("string table header".into()));
    }
    let count = LittleEndian::read_u32(&buf[pos..pos + 4]) as usize;
    pos += 4;
    let mut out = Vec::with_capacity(count);
    for _ in 0..count {
        if pos + 4 > buf.len() {
            return Err(LoadError::Corrupt("string len truncated".into()));
        }
        let len = LittleEndian::read_u32(&buf[pos..pos + 4]) as usize;
        pos += 4;
        if pos + len > buf.len() {
            return Err(LoadError::Corrupt("string body truncated".into()));
        }
        let s = std::str::from_utf8(&buf[pos..pos + len])
            .map_err(|e| LoadError::Corrupt(format!("invalid utf8: {e}")))?;
        out.push(SmolStr::new(s));
        pos += len;
    }
    Ok((out, pos))
}

fn read_string(buf: &[u8], mut pos: usize) -> Result<(String, usize), LoadError> {
    if pos + 4 > buf.len() {
        return Err(LoadError::Corrupt("string len".into()));
    }
    let len = LittleEndian::read_u32(&buf[pos..pos + 4]) as usize;
    pos += 4;
    if pos + len > buf.len() {
        return Err(LoadError::Corrupt("string body".into()));
    }
    let s = std::str::from_utf8(&buf[pos..pos + len])
        .map_err(|e| LoadError::Corrupt(format!("invalid utf8: {e}")))?
        .to_string();
    Ok((s, pos + len))
}

fn write_logic_rules(buf: &mut Vec<u8>, rules: &[RuleItem]) {
    buf.extend_from_slice(&(rules.len() as u32).to_le_bytes());
    for rule in rules {
        write_condition(buf, &rule.condition);
        write_smol_str_raw(buf, rule.outbound.as_str());
    }
}

fn write_smol_str_raw(buf: &mut Vec<u8>, s: &str) {
    let bytes = s.as_bytes();
    buf.extend_from_slice(&(bytes.len() as u16).to_le_bytes());
    buf.extend_from_slice(bytes);
}

fn read_logic_rules(buf: &[u8], mut pos: usize) -> Result<(Vec<RuleItem>, usize), LoadError> {
    if pos + 4 > buf.len() {
        return Err(LoadError::Corrupt("logic rules count".into()));
    }
    let count = LittleEndian::read_u32(&buf[pos..pos + 4]) as usize;
    pos += 4;
    if count > MAX_ARCHIVE_NODES {
        return Err(LoadError::Corrupt(format!("logic rules count too large: {count}")));
    }
    let mut out = Vec::with_capacity(count);
    for _ in 0..count {
        let (condition, np) = read_condition(buf, pos)?;
        pos = np;
        let (outbound, np) = read_smol_str_raw(buf, pos)?;
        pos = np;
        out.push(RuleItem {
            condition,
            outbound: SmolStr::new(outbound),
        });
    }
    Ok((out, pos))
}

fn read_smol_str_raw(buf: &[u8], mut pos: usize) -> Result<(String, usize), LoadError> {
    if pos + 2 > buf.len() {
        return Err(LoadError::Corrupt("logic rule outbound len".into()));
    }
    let len = LittleEndian::read_u16(&buf[pos..pos + 2]) as usize;
    pos += 2;
    if pos + len > buf.len() {
        return Err(LoadError::Corrupt("logic rule outbound body".into()));
    }
    let s = std::str::from_utf8(&buf[pos..pos + len])
        .map_err(|e| LoadError::Corrupt(format!("invalid utf8: {e}")))?
        .to_string();
    Ok((s, pos + len))
}
