//! Composable matching criteria and routing rules with boundary-safe suffix matching and complete RFC IP classifications.

use caly_common::metadata::{Network, SessionMetadata, SniffedProto};
use smol_str::SmolStr;
use std::net::IpAddr;

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum RuleCondition {
    Domain(SmolStr),
    DomainSuffix(SmolStr),
    DomainKeyword(SmolStr),
    IpCidr(ipnet::IpNet),
    IpIsPrivate,
    SourceIpCidr(ipnet::IpNet),
    Port(u16),
    PortRange(u16, u16),
    SourcePort(u16),
    ProcessName(SmolStr),
    Protocol(SniffedProto),
    Network(Network),
    Inbound(u64),
    SniffSource(u8),
    And(Vec<RuleCondition>),
    Or(Vec<RuleCondition>),
    Not(Box<RuleCondition>),
}

impl RuleCondition {
    pub fn matches(&self, meta: &SessionMetadata) -> bool {
        match self {
            RuleCondition::Domain(d) => {
                let md = meta.domain.as_str().trim_end_matches('.');
                let rd = d.as_str().trim_end_matches('.');
                md.eq_ignore_ascii_case(rd)
            }
            RuleCondition::DomainSuffix(suffix) => {
                let s = suffix.as_str().trim_start_matches('.').trim_end_matches('.');
                if s.is_empty() {
                    false
                } else {
                    let d = meta.domain.as_str().trim_end_matches('.');
                    if d.eq_ignore_ascii_case(s) {
                        true
                    } else if d.len() > s.len() {
                        let prefix_end = d.len() - s.len();
                        if d.is_char_boundary(prefix_end) && d.as_bytes()[prefix_end - 1] == b'.' {
                            d[prefix_end..].eq_ignore_ascii_case(s)
                        } else {
                            false
                        }
                    } else {
                        false
                    }
                }
            }
            RuleCondition::DomainKeyword(kw) => {
                if kw.is_empty() {
                    false
                } else {
                    let kw_bytes = kw.as_bytes();
                    let d_bytes = meta.domain.as_bytes();
                    if d_bytes.len() < kw_bytes.len() {
                        false
                    } else {
                        d_bytes
                            .windows(kw_bytes.len())
                            .any(|w| w.eq_ignore_ascii_case(kw_bytes))
                    }
                }
            }
            RuleCondition::IpCidr(net) => net.contains(&meta.dst_addr.ip()),
            RuleCondition::IpIsPrivate => is_private_ip(meta.dst_addr.ip()),
            RuleCondition::SourceIpCidr(net) => net.contains(&meta.src_addr.ip()),
            RuleCondition::Port(p) => meta.dst_addr.port() == *p,
            RuleCondition::PortRange(start, end) => {
                let p = meta.dst_addr.port();
                p >= *start && p <= *end
            }
            RuleCondition::SourcePort(p) => meta.src_addr.port() == *p,
            RuleCondition::ProcessName(proc) => meta.process.as_ref() == Some(proc),
            RuleCondition::Protocol(proto) => meta.protocol == *proto,
            RuleCondition::Network(net) => net.matches(meta.network),
            RuleCondition::Inbound(tag) => meta.inbound_tag == *tag,
            RuleCondition::SniffSource(src) => {
                use caly_common::metadata::{is_sniffed_source, SNIFF_SRC_ANY};
                if *src == SNIFF_SRC_ANY {
                    is_sniffed_source(meta.sniff_source)
                } else {
                    meta.sniff_source == *src
                }
            }
            RuleCondition::And(sub) => sub.iter().all(|c| c.matches(meta)),
            RuleCondition::Or(sub) => sub.iter().any(|c| c.matches(meta)),
            RuleCondition::Not(sub) => !sub.matches(meta),
        }
    }
}

#[inline]
pub fn is_private_ip(ip: IpAddr) -> bool {
    match ip {
        IpAddr::V4(v4) => {
            let o = v4.octets();
            matches!(
                o,
                // RFC 1918
                [10, ..]
                    | [172, 16..=31, ..]
                    | [192, 168, ..]
                    // Loopback / Link-local / CGNAT
                    | [127, ..]
                    | [169, 254, ..]
                    | [100, 64..=127, ..]
                    // IETF Protocol Assignments (RFC 6890)
                    | [192, 0, 0, _]
                    // TEST-NET-1/2/3 (RFC 5737)
                    | [192, 0, 2, _]
                    | [198, 51, 100, _]
                    | [203, 0, 113, _]
                    // "this network" / Multicast / Reserved
                    | [0, ..]
                    | [224..=239, ..]
                    | [240..=255, ..]
            )
        }
        IpAddr::V6(v6) => {
            if let Some(v4) = v6.to_ipv4_mapped() {
                return is_private_ip(IpAddr::V4(v4));
            }
            let s = v6.segments();
            v6.is_loopback()
                || v6.is_unspecified()
                || (s[0] & 0xfe00) == 0xfc00 // ULA
                || (s[0] & 0xffc0) == 0xfe80 // Link-local
                || (s[0] & 0xff00) == 0xff00 // Multicast
        }
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct RuleItem {
    pub condition: RuleCondition,
    pub outbound: SmolStr,
}

impl RuleItem {
    pub fn new(condition: RuleCondition, outbound: &str) -> Self {
        Self {
            condition,
            outbound: SmolStr::new(outbound),
        }
    }
}
