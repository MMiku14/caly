//! Fuzz tests for the config parser + validator.
//!
//! 配置文件来自用户 / 运维脚本 / 热重载 API，格式错误不能导致 panic。
//! `serde_json` 本身是健壮的，但 `CalyConfig::validate` 里有大量语义
//! 检查（tag 引用、CIDR 解析、循环检测），这些必须对畸形输入鲁棒。

use caly_app::config::CalyConfig;

struct XorShift64(u64);

impl XorShift64 {
    fn new(seed: u64) -> Self {
        Self(if seed == 0 { 0x9E37_79B9_7F4A_7C15 } else { seed })
    }
    fn next_u64(&mut self) -> u64 {
        let mut x = self.0;
        x ^= x << 13;
        x ^= x >> 7;
        x ^= x << 17;
        self.0 = x;
        x
    }
    fn fill(&mut self, buf: &mut [u8]) {
        for chunk in buf.chunks_mut(8) {
            let v = self.next_u64().to_le_bytes();
            let n = chunk.len();
            chunk.copy_from_slice(&v[..n]);
        }
    }
    fn range(&mut self, max: usize) -> usize {
        if max == 0 { 0 } else { (self.next_u64() as usize) % max }
    }
}

const SEED_CONFIG: u64 = 0x00C4_1D00_C0F1_0001;

#[test]
fn fuzz_parse_random_bytes_as_json() {
    // 完全随机的字节，可能是合法 JSON、非法 JSON、UTF-8 破坏。
    let mut rng = XorShift64::new(SEED_CONFIG);
    for _ in 0..3_000 {
        let len = rng.range(2048);
        let mut bytes = vec![0u8; len];
        rng.fill(&mut bytes);
        let s = String::from_utf8_lossy(&bytes);
        if let Ok(cfg) = serde_json::from_str::<CalyConfig>(&s) {
            let _ = cfg.validate();
        }
    }
}

#[test]
fn fuzz_parse_minimal_valid_then_mutate() {
    // 从一个通过 validate 的最小配置出发，随机 mutate 字节。
    // 覆盖"结构大致正确但字段畸形"的中间路径 —— 这才是最可能暴露
    // validate 中越界 / 未处理分支的地方。
    let base = r#"{
        "version": "1.0",
        "inbounds": [{"type": "socks5", "tag": "in", "port": 1080}],
        "outbounds": [{"type": "direct", "tag": "direct"}]
    }"#;
    let mut rng = XorShift64::new(SEED_CONFIG ^ 0xC0FF_EE00_C0FF_EE00);
    for _ in 0..2_000 {
        let mut bytes = base.as_bytes().to_vec();
        let n_mut = rng.range(9);
        for _ in 0..n_mut {
            if bytes.is_empty() { break; }
            let idx = rng.range(bytes.len());
            bytes[idx] = (rng.next_u64() & 0xFF) as u8;
        }
        let s = String::from_utf8_lossy(&bytes);
        if let Ok(cfg) = serde_json::from_str::<CalyConfig>(&s) {
            let _ = cfg.validate();
        }
    }
}

#[test]
fn fuzz_parse_with_dns_and_routes() {
    // 稍微复杂一点的基础配置，覆盖 dns / routes 相关的校验分支。
    let base = r#"{
        "version": "1.0",
        "dns": {
            "servers": [{"tag": "local", "address": "1.1.1.1:53"}],
            "rules": [{"domain_suffix": [".cn"], "server": "local"}],
            "final": "local"
        },
        "inbounds": [{"type": "socks5", "tag": "in", "port": 1080}],
        "outbounds": [
            {"type": "direct", "tag": "direct"},
            {"type": "selector", "tag": "sel", "outbounds": ["direct"]}
        ],
        "routes": {"rules": [], "final": "direct"}
    }"#;
    let mut rng = XorShift64::new(SEED_CONFIG ^ 0x00D0_5E00_00D0_5E00);
    for _ in 0..2_000 {
        let mut bytes = base.as_bytes().to_vec();
        let n_mut = rng.range(13);
        for _ in 0..n_mut {
            if bytes.is_empty() { break; }
            let idx = rng.range(bytes.len());
            bytes[idx] = (rng.next_u64() & 0xFF) as u8;
        }
        let s = String::from_utf8_lossy(&bytes);
        if let Ok(cfg) = serde_json::from_str::<CalyConfig>(&s) {
            let _ = cfg.validate();
        }
    }
}
