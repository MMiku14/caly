//! End-to-end rule archive compilation and deserialization roundtrip tests.

use caly_app::bootstrap::build_rule_engine_from_json_public;
use caly_app::config::CalyConfig;
use caly_common::metadata::{Network, SessionMetadata};
use caly_rules::{ArchiveLoader, ArchiveWriter};
use std::net::{IpAddr, Ipv4Addr, SocketAddr};
use std::time::{SystemTime, UNIX_EPOCH};

fn temp_archive_path() -> std::path::PathBuf {
    let nanos = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap()
        .as_nanos();
    let pid = std::process::id();
    std::env::temp_dir().join(format!("caly-e2e-archive-{}-{}.bin", pid, nanos))
}

fn full_test_config() -> CalyConfig {
    let json = r#"{
        "version": "1.0",
        "inbounds": [{"type": "socks5", "tag": "s", "port": 1080}],
        "outbounds": [
            {"type": "direct", "tag": "direct"},
            {"type": "block", "tag": "block"}
        ],
        "routes": {
            "rules": [
                {"domain_suffix": [".cn", ".com.cn"], "outbound": "direct"},
                {"domain": ["example.com"], "outbound": "block"},
                {"domain_keyword": ["google"], "outbound": "block"},
                {"ip_cidr": ["10.0.0.0/8", "192.168.0.0/16"], "outbound": "direct"},
                {"port": [443, 8443], "outbound": "block"}
            ],
            "final": "direct"
        }
    }"#;
    serde_json::from_str(json).expect("test config")
}

fn meta_domain_port(domain: &str, port: u16) -> SessionMetadata {
    SessionMetadata {
        dst_addr: SocketAddr::new(IpAddr::V4(Ipv4Addr::new(1, 2, 3, 4)), port),
        network: Network::Tcp,
        domain: smol_str::SmolStr::new(domain),
        ..Default::default()
    }
}

fn meta_ip(ip: &str) -> SessionMetadata {
    SessionMetadata {
        dst_addr: SocketAddr::new(ip.parse().unwrap(), 0),
        network: Network::Tcp,
        ..Default::default()
    }
}

#[test]
fn test_e2e_archive_roundtrip_full() {
    let config = full_test_config();
    let original = build_rule_engine_from_json_public(&config).expect("build engine");
    let path = temp_archive_path();
    ArchiveWriter::save(&original, &path).expect("save archive");

    let file_size = std::fs::metadata(&path).expect("stat").len();
    assert!(file_size > 64, "archive file too small: {} bytes", file_size);

    let loaded = ArchiveLoader::load(&path)
        .expect("load archive")
        .into_engine();
    let _ = std::fs::remove_file(&path);

    let s1 = original.stats();
    let s2 = loaded.stats();
    assert_eq!(s1.domain_rules, s2.domain_rules);
    assert_eq!(s1.ip_rules, s2.ip_rules);
    assert_eq!(s1.logic_rules, s2.logic_rules);

    let domain_cases = [
        ("example.cn", 443, "block"),
        ("example.cn", 80, "direct"),
        ("www.example.cn", 80, "direct"),
        ("example.com.cn", 80, "direct"),
        ("example.com", 80, "block"),
        ("www.example.com", 80, "direct"),
        ("google.com", 80, "block"),
        ("other.com", 80, "direct"),
    ];
    for (domain, port, expected) in &domain_cases {
        let m = meta_domain_port(domain, *port);
        let got_orig = original.match_outbound(&m);
        let got_loaded = loaded.match_outbound(&m);
        assert_eq!(got_orig, got_loaded);
        assert_eq!(got_loaded, *expected);
    }

    let ip_cases = [
        ("10.1.2.3", "direct"),
        ("192.168.1.1", "direct"),
        ("8.8.8.8", "direct"),
    ];
    for (ip, expected) in &ip_cases {
        let m = meta_ip(ip);
        assert_eq!(original.match_outbound(&m), loaded.match_outbound(&m));
        assert_eq!(loaded.match_outbound(&m), *expected);
    }
}
