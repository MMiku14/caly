//! SOCKS5 to Direct integration tests.

use caly_app::bootstrap::start_kernel;
use caly_app::config::CalyConfig;
use std::net::SocketAddr;
use std::time::Duration;
use tokio::io::{AsyncReadExt, AsyncWriteExt};
use tokio::net::{TcpListener, TcpStream};

async fn find_free_port() -> u16 {
    let l = TcpListener::bind("127.0.0.1:0").await.unwrap();
    l.local_addr().unwrap().port()
}

async fn spawn_echo_server() -> SocketAddr {
    let listener = TcpListener::bind("127.0.0.1:0").await.unwrap();
    let addr = listener.local_addr().unwrap();
    tokio::spawn(async move {
        loop {
            let (mut stream, _) = match listener.accept().await {
                Ok(s) => s,
                Err(_) => break,
            };
            tokio::spawn(async move {
                let mut buf = [0u8; 4096];
                loop {
                    let n = match stream.read(&mut buf).await {
                        Ok(0) => break,
                        Ok(n) => n,
                        Err(_) => break,
                    };
                    if stream.write_all(&buf[..n]).await.is_err() {
                        break;
                    }
                }
            });
        }
    });
    addr
}

async fn wait_for_port(port: u16, timeout_ms: u64) -> bool {
    let deadline = tokio::time::Instant::now() + Duration::from_millis(timeout_ms);
    loop {
        if tokio::time::Instant::now() > deadline {
            return false;
        }
        if TcpStream::connect(("127.0.0.1", port)).await.is_ok() {
            return true;
        }
        tokio::time::sleep(Duration::from_millis(30)).await;
    }
}

fn config_with(socks_port: u16, rules_json: &str, final_tag: &str) -> CalyConfig {
    let json = format!(
        r#"{{
            "version": "1.0",
            "inbounds": [
                {{"type": "socks5", "tag": "socks-in", "listen": "127.0.0.1", "port": {}}}
            ],
            "outbounds": [
                {{"type": "direct", "tag": "direct"}},
                {{"type": "block", "tag": "block"}}
            ],
            "routes": {{"rules": {}, "final": "{}"}}
        }}"#,
        socks_port, rules_json, final_tag
    );
    serde_json::from_str(&json).expect("valid config json")
}

#[tokio::test(flavor = "multi_thread", worker_threads = 4)]
async fn test_socks5_to_direct_echo() {
    let echo_addr = spawn_echo_server().await;
    let socks_port = find_free_port().await;
    let config = config_with(socks_port, "[]", "direct");
    let app_state = start_kernel(config).await.expect("start kernel");
    assert!(wait_for_port(socks_port, 3000).await, "SOCKS5 port not ready");

    let mut client = TcpStream::connect(("127.0.0.1", socks_port)).await.unwrap();
    client.write_all(&[0x05, 0x01, 0x00]).await.unwrap();
    let mut reply = [0u8; 2];
    client.read_exact(&mut reply).await.unwrap();
    assert_eq!(reply, [0x05, 0x00], "greeting reply");

    let mut req = vec![0x05, 0x01, 0x00, 0x01];
    req.extend_from_slice(&[127, 0, 0, 1]);
    req.extend_from_slice(&echo_addr.port().to_be_bytes());
    client.write_all(&req).await.unwrap();
    let mut reply = [0u8; 10];
    client.read_exact(&mut reply).await.unwrap();
    assert_eq!(reply[0], 0x05, "version");
    assert_eq!(reply[1], 0x00, "CONNECT should succeed");

    client.write_all(b"hello world").await.unwrap();
    let mut buf = [0u8; 11];
    client.read_exact(&mut buf).await.unwrap();
    assert_eq!(&buf, b"hello world");

    drop(client);
    app_state.shutdown.notify_waiters();
    tokio::time::sleep(Duration::from_millis(500)).await;
}

#[tokio::test(flavor = "multi_thread", worker_threads = 4)]
async fn test_socks5_blocked_by_rule() {
    let echo_addr = spawn_echo_server().await;
    let socks_port = find_free_port().await;
    let rules = r#"[{"ip_is_private": true, "outbound": "block"}]"#;
    let config = config_with(socks_port, rules, "direct");
    let app_state = start_kernel(config).await.expect("start kernel");
    assert!(wait_for_port(socks_port, 3000).await);

    let mut client = TcpStream::connect(("127.0.0.1", socks_port)).await.unwrap();
    client.write_all(&[0x05, 0x01, 0x00]).await.unwrap();
    let mut r = [0u8; 2];
    client.read_exact(&mut r).await.unwrap();

    let mut req = vec![0x05, 0x01, 0x00, 0x01];
    req.extend_from_slice(&[127, 0, 0, 1]);
    req.extend_from_slice(&echo_addr.port().to_be_bytes());
    client.write_all(&req).await.unwrap();
    let mut r = [0u8; 10];
    client.read_exact(&mut r).await.unwrap();
    assert_ne!(r[1], 0x00, "block rule should reject, got REP=0x{:02x}", r[1]);

    drop(client);
    app_state.shutdown.notify_waiters();
    tokio::time::sleep(Duration::from_millis(500)).await;
}

#[tokio::test(flavor = "multi_thread", worker_threads = 4)]
async fn test_socks5_target_unreachable() {
    let socks_port = find_free_port().await;
    let config = config_with(socks_port, "[]", "direct");
    let app_state = start_kernel(config).await.expect("start kernel");
    assert!(wait_for_port(socks_port, 3000).await);

    let mut client = TcpStream::connect(("127.0.0.1", socks_port)).await.unwrap();
    client.write_all(&[0x05, 0x01, 0x00]).await.unwrap();
    let mut r = [0u8; 2];
    client.read_exact(&mut r).await.unwrap();

    let mut req = vec![0x05, 0x01, 0x00, 0x01];
    req.extend_from_slice(&[127, 0, 0, 1]);
    req.extend_from_slice(&1u16.to_be_bytes());
    client.write_all(&req).await.unwrap();
    let mut r = [0u8; 10];
    client.read_exact(&mut r).await.unwrap();
    assert_ne!(r[1], 0x00, "unreachable target should fail");

    drop(client);
    app_state.shutdown.notify_waiters();
    tokio::time::sleep(Duration::from_millis(500)).await;
}
