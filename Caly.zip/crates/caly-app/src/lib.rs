//! Caly application core library exposing bootstrap routines and configuration schemas.

pub mod bootstrap;
pub mod config;
pub mod dns_setup;
pub mod reload;
pub mod rules_setup;
pub mod selector_persist;
pub mod urltest;

pub use bootstrap::start_kernel;
pub use config::CalyConfig;
