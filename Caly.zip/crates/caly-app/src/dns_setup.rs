//! DNS resolver setup and FakeIP/private range conflict detection.
//!
//! 从 `crate::bootstrap` 拆分而来（Round 18 重构）。

#![allow(unused_imports)]

use crate::config::CalyConfig;
use arc_swap::ArcSwap;
use caly_api::metrics::PrometheusMetrics;
use caly_api::state::{AppState, Epoch};
use caly_common::dns::DnsResolver;
use caly_common::error::CalyError;
use caly_dns::resolver::{DnsResolverConfig, DnsResolverImpl, DnsRouteRule};
use caly_dns::upstream::{DnsStrategy, UpstreamServer};
use caly_outbound::block::BlockAdapter;
use caly_outbound::direct::DirectAdapter;
use caly_outbound::group::{FallbackAdapter, SelectorAdapter, UrlTestAdapter};
use caly_outbound::shadowsocks_adapter::ShadowsocksAdapter;
use caly_outbound::ProxyAdapter;
use caly_rules::engine::RuleEngine;
use caly_rules::logic::{RuleCondition, RuleItem};
use caly_session::guard::SessionMetricsTracker;
use caly_worker::loop_scheduler::WorkerLoop;
use smol_str::SmolStr;
use std::collections::HashMap;
use std::net::SocketAddr;
use std::sync::Arc;
use std::time::Instant;
use tokio::sync::Notify;

// ============================================================
// 以下定义从 bootstrap.rs 移动而来，逻辑保持不变
// ============================================================

pub fn warn_if_fakeip_overlaps_private(net: ipnet::Ipv4Net) {
    use caly_rules::logic::is_private_ip;
    use std::net::{IpAddr, Ipv4Addr};
    let first_u32 = u32::from(net.network());
    let host_bits = 32u32.saturating_sub(net.prefix_len() as u32);
    let host_mask = if host_bits == 0 {
        0u32
    } else {
        ((1u64 << host_bits) - 1) as u32
    };
    let last_u32 = first_u32 | host_mask;
    let first = IpAddr::V4(Ipv4Addr::from(first_u32));
    let last = IpAddr::V4(Ipv4Addr::from(last_u32));
    if is_private_ip(first) || is_private_ip(last) {
        tracing::warn!(
            net = %net,
            "fakeip.inet4_range overlaps with private IPv4 ranges;              rules using `ip_is_private: true` will misroute FakeIP traffic              to direct and break proxying. Consider 198.18.0.0/15              (RFC 2544 benchmark, excluded from private ranges)."
        );
    }
}

pub fn build_dns_resolver(config: &CalyConfig) -> Result<Arc<DnsResolverImpl>, CalyError> {
    let mut upstreams = Vec::new();
    let mut resolver_cfg = DnsResolverConfig::default();
    if let Some(ref dns) = config.dns {
        for s in &dns.servers {
            // 显式 match：DNS 地址解析失败必须打 warn。
            //
            // 旧实现在解析失败时**静默跳过**——用户配了
            // `"address": "https://1.1.1.1/dns-query"`（doc3.md §1.3.3
            // 声明的 DoH 形式）时，服务器会悄悄消失。如果这是唯一
            // 配置的 server，启动成功但所有 DNS 查询失败，用户完全
            // 无从下手。
            //
            // 我们区分两种失败：
            //   1. URL 形式（含 "://"）：DoH/DoT 尚未实现，明确告知
            //   2. 其他形式：非法 SocketAddr 格式，列出期望格式
            // tls:// DNS scheme detected — DoT (RFC 7858)
            // 格式：tls://IP:PORT 或 tls://IP:PORT#SNI
            if let Some(rest) = s.address.as_str().strip_prefix("tls://") {
                let (host_port, sni) = match rest.split_once('#') {
                    Some((hp, sn)) => (hp, sn.to_string()),
                    None => (rest, String::new()),
                };
                match host_port.parse::<SocketAddr>() {
                    Ok(addr) => {
                        let strategy = DnsStrategy::from_str_opt(&s.strategy).unwrap_or_else(|| {
                            tracing::warn!(
                                tag = %s.tag,
                                strategy = %s.strategy,
                                "unknown DNS strategy; falling back to prefer_ipv4"
                            );
                            DnsStrategy::PreferIpv4
                        });
                        let detour = if s.detour.is_empty() || s.detour == "direct" {
                            None
                        } else {
                            Some(s.detour.clone())
                        };
                        tracing::info!(
                            tag = %s.tag,
                            addr = %addr,
                            sni = %sni,
                            "DoT (DNS over TLS) upstream configured"
                        );
                        upstreams.push(UpstreamServer::new_dot(
                            &s.tag,
                            addr,
                            &sni,
                            strategy,
                            detour,
                        ));
                    }
                    Err(e) => {
                        tracing::warn!(
                            tag = %s.tag,
                            address = %s.address,
                            error = %e,
                            "invalid tls:// address (expected tls://IP:PORT[#SNI]); skipped"
                        );
                    }
                }
                continue;
            }

            let addr = match s.address.parse::<SocketAddr>() {
                Ok(a) => a,
                Err(_) => {
                    if s.address.contains("://") {
                        tracing::warn!(
                            tag = %s.tag,
                            address = %s.address,
                            "DoH/DoT URL forms (https://, tls://, quic://) are \
                             not yet implemented; this DNS server is skipped. \
                             Use a plain 'IP:PORT' address for now."
                        );
                    } else {
                        tracing::warn!(
                            tag = %s.tag,
                            address = %s.address,
                            "DNS server address is not a valid 'IP:PORT' \
                             SocketAddr; this DNS server is skipped. \
                             Examples: '223.5.5.5:53', '[2001:4860:4860::8888]:53'"
                        );
                    }
                    continue;
                }
            };

            let strategy = DnsStrategy::from_str_opt(&s.strategy).unwrap_or_else(|| {
                tracing::warn!(
                    tag = %s.tag,
                    strategy = %s.strategy,
                    "unknown DNS strategy; falling back to prefer_ipv4. \
                     Valid values: prefer_ipv4, prefer_ipv6, ipv4_only, ipv6_only"
                );
                DnsStrategy::PreferIpv4
            });

            // detour 传递：`detour` 字段默认 "direct"，空串或 "direct"
            // 视为"不指定 detour"。非 direct 时记录到 UpstreamServer，
            // 供未来 detour 路由实现使用。
            let detour = if s.detour.is_empty() || s.detour == "direct" {
                None
            } else {
                Some(s.detour.clone())
            };
            upstreams.push(UpstreamServer::new_with_strategy(
                &s.tag,
                addr,
                strategy,
                detour,
            ));
        }
        if let Some(ref cache) = dns.cache {
            resolver_cfg.cache_capacity = cache.capacity.max(16);
            resolver_cfg.optimistic = cache.optimistic;
            resolver_cfg.optimistic_ttl_secs = cache.optimistic_ttl;
        }
        for r in &dns.rules {
            resolver_cfg.dns_rules.push(DnsRouteRule {
                domain_suffix: r.domain_suffix.iter().map(SmolStr::new).collect(),
                domain_keyword: r.domain_keyword.iter().map(SmolStr::new).collect(),
                server_tag: SmolStr::new(&r.server),
            });
        }
        let final_tag = dns.r#final.as_str();
        let final_exists = dns.servers.iter().any(|s| s.tag == final_tag);
        if final_exists {
            resolver_cfg.final_server_tag = Some(SmolStr::new(final_tag));
        } else {
            tracing::debug!(
                final_tag = %final_tag,
                "dns.final references unknown server tag; falling back to sequential upstream attempts"
            );
        }
        if let Some(ref f) = dns.fakeip {
            resolver_cfg.fakeip_ttl_secs = f.global_ttl.max(1);
            match f.inet4_range.parse::<ipnet::Ipv4Net>() {
                Ok(net) => {
                    let is_default = net.addr() == std::net::Ipv4Addr::new(198, 18, 0, 0)
                        && net.prefix_len() == 15;
                    if !is_default {
                        resolver_cfg.fakeip_inet4_range =
                            Some((net.network(), net.prefix_len()));
                        warn_if_fakeip_overlaps_private(net);
                        tracing::info!(
                            inet4_range = %f.inet4_range,
                            "FakeIP pool using custom CIDR"
                        );
                    }
                }
                Err(e) => {
                    tracing::warn!(
                        inet4_range = %f.inet4_range,
                        error = %e,
                        "invalid fakeip.inet4_range; falling back to default 198.18.0.0/15"
                    );
                }
            }
        }
    }
    let fakeip_enabled = config
        .dns
        .as_ref()
        .and_then(|d| d.fakeip.as_ref())
        .map(|f| f.enabled)
        .unwrap_or(false);
    // 空 server 列表意味着所有非 FakeIP 查询必然失败。
    // 明确告知用户，避免"域名能解析" / "域名解析不了"这种
    // 无法定位的现象。
    if upstreams.is_empty() {
        let fakeip_configured = config
            .dns
            .as_ref()
            .and_then(|d| d.fakeip.as_ref())
            .map(|f| f.enabled)
            .unwrap_or(false);

        if fakeip_configured {
            tracing::warn!(
                "no valid DNS servers configured; all real-IP resolutions \
                 will fail. Only FakeIP allocation will succeed."
            );
        } else {
            tracing::warn!(
                "no valid DNS servers configured and FakeIP is disabled; \
                 every DNS resolution will fail. Add at least one \
                 `dns.servers[]` entry with `address: \"IP:PORT\"`."
            );
        }
    }

    Ok(Arc::new(DnsResolverImpl::new_with_config(
        upstreams,
        fakeip_enabled,
        resolver_cfg,
    )))
}
