//! Caly Proxy Kernel entry point.

use caly_app::bootstrap::start_kernel;
use caly_app::config::CalyConfig;
use clap::Parser;
use std::fs;
use std::path::PathBuf;

#[global_allocator]
static GLOBAL: mimalloc::MiMalloc = mimalloc::MiMalloc;

#[derive(Parser, Debug)]
#[command(
    name = "caly",
    version = env!("CARGO_PKG_VERSION"),
    about = "High-performance memory-efficient proxy kernel"
)]
struct Args {
    #[arg(short, long, default_value = "config.json")]
    config: PathBuf,

    #[arg(short = 't', long = "check", visible_alias = "test")]
    check: bool,

    #[arg(short = 'v', long)]
    verbose: bool,

    #[arg(long)]
    compile_rules: bool,

    #[arg(long)]
    rules_output: Option<PathBuf>,
}

#[tokio::main]
async fn main() -> Result<(), Box<dyn std::error::Error>> {
    let args = Args::parse();
    let raw_config = fs::read_to_string(&args.config).ok();
    let initial_level = raw_config.as_deref()
        .and_then(|s| serde_json::from_str::<serde_json::Value>(s).ok())
        .and_then(|v| v.get("log").and_then(|l| l.get("level")).and_then(|lv| lv.as_str().map(String::from)))
        .unwrap_or_else(|| "info".to_string());

    tracing_subscriber::fmt()
        .with_env_filter(
            tracing_subscriber::EnvFilter::try_from_default_env()
                .unwrap_or_else(|_| tracing_subscriber::EnvFilter::new(&initial_level)),
        )
        .init();

    tracing::info!(path = ?args.config, "Loading Caly configuration");

    let content = match fs::read_to_string(&args.config) {
        Ok(c) => c,
        Err(e) => {
            let is_default_path = args.config.as_os_str() == "config.json";
            if !is_default_path {
                tracing::error!(
                    path = ?args.config,
                    error = %e,
                    "failed to read config file (explicit path)"
                );
                return Err(format!("cannot read config file {:?}: {e}", args.config).into());
            }
            tracing::warn!(
                path = ?args.config,
                error = %e,
                "config file not found; starting with built-in minimal config (socks5:1080 -> direct)"
            );
            r#"{
                "version": "1.0",
                "inbounds": [{
                    "type": "socks5",
                    "tag": "socks-in",
                    "listen": "127.0.0.1",
                    "port": 1080
                }],
                "outbounds": [
                    { "type": "direct", "tag": "direct" },
                    { "type": "block", "tag": "block" }
                ],
                "routes": {
                    "rules": [
                        { "ip_is_private": true, "outbound": "direct" }
                    ],
                    "final": "direct"
                }
            }"#.to_string()
        }
    };

    let config: CalyConfig = serde_json::from_str(&content)?;

    if args.check {
        config.validate()?;
        if args.verbose {
            println!("=== Caly Configuration Summary ===");
            println!("version: {}", config.version);
            if let Some(ref log) = config.log {
                println!("log: level={} format={} output={}", log.level, log.format, log.output);
            }
            println!("
--- Inbounds ({}) ---", config.inbounds.len());
            for ib in &config.inbounds {
                println!("  [{}] {}://{}:{} udp={} sniff={}",
                    ib.tag, ib.r#type, ib.listen, ib.port, ib.udp, ib.sniff);
            }
            println!("
--- Outbounds ({}) ---", config.outbounds.len());
            for ob in &config.outbounds {
                match ob.r#type.as_str() {
                    "selector" => {
                        let cands = ob.outbounds.as_ref().map(|v| v.join(",")).unwrap_or_default();
                        println!("  [{}] selector -> [{}]", ob.tag, cands);
                    }
                    "shadowsocks" => {
                        println!("  [{}] shadowsocks {}:{} method={}",
                            ob.tag,
                            ob.server.as_deref().unwrap_or("?"),
                            ob.server_port.unwrap_or(0),
                            ob.method.as_deref().unwrap_or("?"));
                    }
                    other => println!("  [{}] {}", ob.tag, other),
                }
            }
            if let Some(ref routes) = config.routes {
                println!("
--- Routes (final = {}) ---", routes.r#final);
                for (i, r) in routes.rules.iter().enumerate() {
                    let mut conds: Vec<String> = Vec::new();
                    if let Some(ref d) = r.domain { conds.push(format!("domain={:?}", d)); }
                    if let Some(ref d) = r.domain_suffix { conds.push(format!("suffix={:?}", d)); }
                    if let Some(ref d) = r.domain_keyword { conds.push(format!("keyword={:?}", d)); }
                    if let Some(ref d) = r.ip_cidr { conds.push(format!("ip_cidr={:?}", d)); }
                    if r.ip_is_private == Some(true) { conds.push("ip_is_private".into()); }
                    if let Some(ref p) = r.port { conds.push(format!("port={:?}", p)); }
                    if let Some(ref p) = r.protocol { conds.push(format!("protocol={}", p)); }
                    if r.sniffed == Some(true) { conds.push("sniffed".into()); }
                    if r.user_set == Some(true) { conds.push("user_set".into()); }
                    println!("  #{:2} {} -> {}",
                        i + 1,
                        if conds.is_empty() { "(no condition)".to_string() } else { conds.join(" & ") },
                        r.outbound);
                }
            }
            if let Some(ref dns) = config.dns {
                println!("
--- DNS ---");
                println!("  servers: {}", dns.servers.len());
                for s in &dns.servers {
                    println!("    [{}] {} strategy={} detour={}",
                        s.tag, s.address, s.strategy, s.detour);
                }
                println!("  rules: {}", dns.rules.len());
                println!("  final: {}", dns.r#final);
                if let Some(ref f) = dns.fakeip {
                    println!("  fakeip: enabled={} range={} ttl={}",
                        f.enabled, f.inet4_range, f.global_ttl);
                }
            }
            if let Some(ref arch) = config.rule_archive {
                println!("
rule_archive: {}", arch);
            }
            println!("
=== Configuration is valid ===");
        } else {
            println!("Configuration is valid.");
        }
        return Ok(());
    }

    if args.compile_rules {
        config.validate()?;
        let output = args
            .rules_output
            .clone()
            .or_else(|| config.rule_archive.as_ref().map(PathBuf::from))
            .unwrap_or_else(|| PathBuf::from("rules.bin"));
        let engine = caly_app::bootstrap::build_rule_engine_from_json_public(&config)?;
        let stats = engine.stats();
        caly_rules::ArchiveWriter::save(&engine, &output)?;
        let file_size = std::fs::metadata(&output).map(|m| m.len()).unwrap_or(0);
        let size_human = if file_size >= 1024 * 1024 {
            format!("{:.2} MiB", file_size as f64 / (1024.0 * 1024.0))
        } else if file_size >= 1024 {
            format!("{:.2} KiB", file_size as f64 / 1024.0)
        } else {
            format!("{} B", file_size)
        };
        println!(
            "rules compiled to {:?}: domain={}, ip={}, logic={}, size={} ({} bytes)",
            output, stats.domain_rules, stats.ip_rules, stats.logic_rules, size_human, file_size
        );
        return Ok(());
    }

    let app_state = start_kernel(config).await?;

    let config_path = args.config.clone();

    #[cfg(unix)]
    {
        const MAX_CONFIG_SIZE: u64 = 4 * 1024 * 1024;
        use tokio::signal::unix::{signal, SignalKind};
        let mut hup = signal(SignalKind::hangup())
            .map_err(|e| format!("install SIGHUP handler failed: {e}"))?;
        let reload_state = app_state.clone();
        let path = config_path.clone();
        tokio::spawn(async move {
            loop {
                hup.recv().await;
                tracing::info!(path = ?path, "SIGHUP received; reloading configuration");
                match std::fs::metadata(&path) {
                    Ok(m) if m.len() > MAX_CONFIG_SIZE => {
                        tracing::warn!(
                            path = ?path,
                            size = m.len(),
                            limit = MAX_CONFIG_SIZE,
                            "config file too large; SIGHUP reload aborted"
                        );
                        continue;
                    }
                    Ok(_) => {}
                    Err(e) => {
                        tracing::warn!(path = ?path, error = %e, "cannot stat config file");
                        continue;
                    }
                }
                let content = match std::fs::read_to_string(&path) {
                    Ok(c) => c,
                    Err(e) => {
                        tracing::warn!(path = ?path, error = %e, "cannot read config file");
                        continue;
                    }
                };
                if let Err(e) = serde_json::from_str::<serde_json::Value>(&content) {
                    tracing::warn!(error = %e, "config file is not valid JSON; reload aborted");
                    continue;
                }
                match reload_state.reload_tx.try_send(caly_api::state::ReloadRequest {
                    config_json: content,
                }) {
                    Ok(()) => tracing::info!("SIGHUP reload request queued"),
                    Err(e) => tracing::warn!(
                        error = ?e,
                        "SIGHUP reload dropped: channel full or closed"
                    ),
                }
            }
        });
    }

    tokio::signal::ctrl_c().await?;
    tracing::info!("Received shutdown signal; graceful termination underway.");

    app_state.shutdown.notify_waiters();

    // Poll active connections with 50ms interval up to 8s deadline
    let drain_deadline = tokio::time::Instant::now() + std::time::Duration::from_secs(8);
    while tokio::time::Instant::now() < drain_deadline {
        if app_state.session_metrics.active_connections.load(std::sync::atomic::Ordering::Relaxed) == 0 {
            break;
        }
        tokio::time::sleep(std::time::Duration::from_millis(50)).await;
    }

    tracing::info!("Shutdown complete.");
    Ok(())
}
