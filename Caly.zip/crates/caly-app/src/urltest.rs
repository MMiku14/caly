//! URLTest active probing (HTTP HEAD over adapters).
//!
//! 从 `crate::bootstrap` 拆分而来（Round 18 重构）。

#![allow(unused_imports)]

use crate::config::CalyConfig;
use arc_swap::ArcSwap;
use caly_api::metrics::PrometheusMetrics;
use caly_api::state::{AppState, Epoch};
use caly_common::dns::DnsResolver;
use caly_common::error::CalyError;
use caly_dns::resolver::{DnsResolverConfig, DnsResolverImpl, DnsRouteRule};
use caly_dns::upstream::{DnsStrategy, UpstreamServer};
use caly_outbound::block::BlockAdapter;
use caly_outbound::direct::DirectAdapter;
use caly_outbound::group::{FallbackAdapter, SelectorAdapter, UrlTestAdapter};
use caly_outbound::shadowsocks_adapter::ShadowsocksAdapter;
use caly_outbound::ProxyAdapter;
use caly_rules::engine::RuleEngine;
use caly_rules::logic::{RuleCondition, RuleItem};
use caly_session::guard::SessionMetricsTracker;
use caly_worker::loop_scheduler::WorkerLoop;
use smol_str::SmolStr;
use std::collections::HashMap;
use std::net::SocketAddr;
use std::sync::Arc;
use std::time::Instant;
use tokio::sync::Notify;

// ============================================================
// 以下定义从 bootstrap.rs 移动而来，逻辑保持不变
// ============================================================

pub fn build_probe_targets() -> Vec<(SocketAddr, String)> {
    vec![
        (SocketAddr::from(([1, 1, 1, 1], 80)), "one.one.one.one".to_string()),
        (SocketAddr::from(([1, 0, 0, 1], 80)), "one.one.one.one".to_string()),
    ]
}

pub fn parse_duration_secs(s: &str) -> Option<u64> {
    let trimmed = s.trim();
    let secs = if let Some(n) = trimmed.strip_suffix("ms") {
        n.parse::<u64>().ok().map(|ms| (ms / 1000).max(1))
    } else if let Some(n) = trimmed.strip_suffix('s') {
        n.parse::<u64>().ok()
    } else if let Some(n) = trimmed.strip_suffix('m') {
        n.parse::<u64>().ok().map(|m| m * 60)
    } else {
        trimmed.parse::<u64>().ok()
    };
    match secs {
        Some(0) => Some(1),
        other => other,
    }
}

pub async fn url_test_probe_loop(
    adapter: Arc<UrlTestAdapter>,
    targets: Vec<(SocketAddr, String)>,
    interval_secs: u64,
) {
    let tag = adapter.name().to_string();
    tracing::info!(
        urltest = %tag,
        interval_secs,
        targets = targets.len(),
        "URLTest probe loop started"
    );
    let mut interval = tokio::time::interval(std::time::Duration::from_secs(interval_secs));
    interval.set_missed_tick_behavior(tokio::time::MissedTickBehavior::Skip);
    loop {
        interval.tick().await;
        let target_count = targets.len().max(1);
        for (i, candidate) in adapter.candidates_inner().iter().enumerate() {
            let name = candidate.name().to_string();
            let (target_addr, host_header) = &targets[i % target_count];
            let res = tokio::time::timeout(
                std::time::Duration::from_secs(5),
                probe_http_head(candidate.clone(), *target_addr, host_header),
            )
            .await;
            let latency_ms = match res {
                Ok(Ok(ms)) => ms.max(1),
                Ok(Err(e)) => {
                    tracing::debug!(urltest = %tag, candidate = %name, error = %e, "probe failed");
                    0
                }
                Err(_) => {
                    tracing::debug!(urltest = %tag, candidate = %name, "probe timed out");
                    0
                }
            };
            adapter.record_latency(&name, latency_ms);
        }
        if let Some(best) = adapter.current() {
            tracing::debug!(urltest = %tag, best = %best, "URLTest selected");
        }
    }
}

pub async fn probe_http_head(
    adapter: Arc<dyn ProxyAdapter>,
    target_addr: SocketAddr,
    host_header: &str,
) -> Result<u32, String> {
    use tokio::io::{AsyncReadExt, AsyncWriteExt};
    let meta = caly_common::metadata::SessionMetadata {
        dst_addr: target_addr,
        network: caly_common::metadata::Network::Tcp,
        ..Default::default()
    };
    let mut stream = adapter.dial(&meta).await.map_err(|e| e.to_string())?;
    let req = format!(
        "HEAD / HTTP/1.1
Host: {}
User-Agent: caly-probe/1.0
Connection: close

",
        host_header
    );
    let start = std::time::Instant::now();
    stream
        .write_all(req.as_bytes())
        .await
        .map_err(|e| format!("write: {e}"))?;
    stream.flush().await.map_err(|e| format!("flush: {e}"))?;
    let mut buf = [0u8; 64];
    let n = stream
        .read(&mut buf)
        .await
        .map_err(|e| format!("read: {e}"))?;
    if n == 0 {
        return Err("EOF".to_string());
    }
    Ok(start.elapsed().as_millis() as u32)
}
