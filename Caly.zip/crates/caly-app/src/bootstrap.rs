//! Kernel bootstrap orchestrator, multi-thread-per-core spawning, and runtime initialization.
//!
//! 本文件仅保留 `start_kernel` 和辅助函数。其余功能已拆分到
//! 独立模块（dns_setup / rules_setup / selector_persist / urltest / reload）。

use crate::config::CalyConfig;
use arc_swap::ArcSwap;
use caly_api::metrics::PrometheusMetrics;
use caly_api::state::{AppState, Epoch};
use caly_common::dns::DnsResolver;
use caly_common::error::CalyError;
use caly_outbound::block::BlockAdapter;
use caly_outbound::direct::DirectAdapter;
use caly_outbound::group::{FallbackAdapter, SelectorAdapter, UrlTestAdapter};
use caly_outbound::shadowsocks_adapter::ShadowsocksAdapter;
use caly_outbound::ProxyAdapter;
use caly_session::guard::SessionMetricsTracker;
use caly_worker::loop_scheduler::WorkerLoop;
use std::collections::HashMap;
use std::net::SocketAddr;
use std::sync::Arc;
use std::time::Instant;
use tokio::sync::Notify;

pub use crate::dns_setup::{build_dns_resolver, warn_if_fakeip_overlaps_private};
pub use crate::reload::reload_worker;
pub use crate::rules_setup::{
    build_rule_engine, build_rule_engine_from_json, build_rule_engine_from_json_public,
    parse_port_range,
};
pub use crate::selector_persist::{
    load_selector_state, save_selector_state, selector_state_path, SELECTOR_STATE_FILE,
};
pub use crate::urltest::{
    build_probe_targets, parse_duration_secs, probe_http_head, url_test_probe_loop,
};

// ============================================================
// 主入口
// ============================================================

pub async fn start_kernel(config: CalyConfig) -> Result<Arc<AppState>, CalyError> {
    config.validate()?;
    let dns_resolver = build_dns_resolver(&config)?;

    let mut outbounds_map: HashMap<String, Arc<dyn ProxyAdapter>> = HashMap::new();
    for ob in &config.outbounds {
        match ob.r#type.as_str() {
            "direct" => {
                outbounds_map.insert(ob.tag.clone(), Arc::new(DirectAdapter::new(&ob.tag)));
            }
            "block" => {
                outbounds_map.insert(ob.tag.clone(), Arc::new(BlockAdapter::new(&ob.tag)));
            }
            "shadowsocks" => {
                let server = ob.server.as_ref().ok_or_else(|| {
                    CalyError::Config(format!("shadowsocks '{}' missing 'server'", ob.tag))
                })?;
                let port = ob.server_port.ok_or_else(|| {
                    CalyError::Config(format!("shadowsocks '{}' missing 'server_port'", ob.tag))
                })?;
                let password = ob.password.as_ref().ok_or_else(|| {
                    CalyError::Config(format!("shadowsocks '{}' missing 'password'", ob.tag))
                })?;
                let server_addr: SocketAddr = format!("{}:{}", server, port)
                    .parse()
                    .map_err(|e| CalyError::Config(format!(
                        "shadowsocks '{}' invalid server addr: {e}", ob.tag
                    )))?;
                let psk = ShadowsocksAdapter::decode_psk(password)
                    .map_err(|e| CalyError::Config(format!(
                        "shadowsocks '{}': {e}", ob.tag
                    )))?;
                let tls_cfg = match ob.tls.as_ref() {
                    Some(t) => caly_outbound::shadowsocks_adapter::SsTlsConfig {
                        enabled: t.enabled,
                        server_name: t.server_name.clone(),
                        skip_verify: t.skip_verify,
                    },
                    None => caly_outbound::shadowsocks_adapter::SsTlsConfig::default(),
                };
                let adapter = ShadowsocksAdapter::new(&ob.tag, server_addr, psk, tls_cfg)
                    .map_err(|e| CalyError::Config(format!(
                        "shadowsocks '{}': {e}", ob.tag
                    )))?;
                outbounds_map.insert(ob.tag.clone(), Arc::new(adapter));
            }
            _ => {}
        }
    }

    let mut urltest_instances: Vec<Arc<UrlTestAdapter>> = Vec::new();
    for ob in &config.outbounds {
        match ob.r#type.as_str() {
            "selector" => {
                let names = ob.outbounds.clone().unwrap_or_default();
                let mut resolved: Vec<Arc<dyn ProxyAdapter>> = Vec::with_capacity(names.len());
                for name in &names {
                    if let Some(a) = outbounds_map.get(name) {
                        resolved.push(a.clone());
                    } else {
                        return Err(CalyError::Config(format!(
                            "selector '{}' references unknown outbound '{}'", ob.tag, name
                        )));
                    }
                }
                let inst = Arc::new(SelectorAdapter::new(&ob.tag, resolved));
                {
                    let tag_for_cb = ob.tag.clone();
                    let mut current_state: HashMap<String, String> = load_selector_state();
                    inst.set_on_change(move |_tag, name| {
                        let tag = tag_for_cb.clone();
                        let selected = name.to_string();
                        match tokio::runtime::Handle::try_current() {
                            Ok(handle) => {
                                handle.spawn_blocking(move || {
                                    let mut state = load_selector_state();
                                    state.insert(tag, selected);
                                    save_selector_state(&state);
                                });
                            }
                            Err(_) => {
                                let mut state = load_selector_state();
                                state.insert(tag, selected);
                                save_selector_state(&state);
                            }
                        }
                    });
                    if let Some(prev) = current_state.remove(&ob.tag) {
                        if inst.restore_selection(&prev) {
                            tracing::info!(tag = %ob.tag, selected = %prev, "selector state restored");
                        } else {
                            tracing::warn!(tag = %ob.tag, prev = %prev, "selector state ignored (candidate missing)");
                        }
                    }
                }
                outbounds_map.insert(ob.tag.clone(), inst as Arc<dyn ProxyAdapter>);
            }
            "urltest" => {
                let names = ob.outbounds.clone().unwrap_or_default();
                let mut resolved: Vec<Arc<dyn ProxyAdapter>> = Vec::with_capacity(names.len());
                for name in &names {
                    if let Some(a) = outbounds_map.get(name) {
                        resolved.push(a.clone());
                    } else {
                        return Err(CalyError::Config(format!(
                            "urltest '{}' references unknown outbound '{}'", ob.tag, name
                        )));
                    }
                }
                let inst = Arc::new(UrlTestAdapter::new(&ob.tag, resolved));
                urltest_instances.push(inst.clone());
                outbounds_map.insert(ob.tag.clone(), inst as Arc<dyn ProxyAdapter>);
            }
            "fallback" => {
                let names = ob.outbounds.clone().unwrap_or_default();
                let mut resolved: Vec<Arc<dyn ProxyAdapter>> = Vec::with_capacity(names.len());
                for name in &names {
                    if let Some(a) = outbounds_map.get(name) {
                        resolved.push(a.clone());
                    } else {
                        return Err(CalyError::Config(format!(
                            "fallback '{}' references unknown outbound '{}'", ob.tag, name
                        )));
                    }
                }
                let inst = Arc::new(FallbackAdapter::new(&ob.tag, resolved));
                outbounds_map.insert(ob.tag.clone(), inst as Arc<dyn ProxyAdapter>);
            }
            _ => {}
        }
    }

    let outbounds_arc = Arc::new(outbounds_map);
    let rule_engine = Arc::new(build_rule_engine(&config)?);
    let rules_swap = Arc::new(ArcSwap::new(rule_engine.clone()));
    let prometheus_metrics = Arc::new(PrometheusMetrics::new());
    let session_metrics = Arc::new(SessionMetricsTracker::new());
    let initial_epoch = Epoch {
        id: 1,
        rules: rule_engine,
        dns: dns_resolver.clone(),
        created_at: Instant::now(),
    };
    let (reload_tx, reload_rx) = tokio::sync::mpsc::channel::<caly_api::ReloadRequest>(1);
    let shutdown = Arc::new(Notify::new());
    let app_state = Arc::new(AppState::new(
        initial_epoch,
        prometheus_metrics.clone(),
        reload_tx,
        outbounds_arc.clone(),
        session_metrics.clone(),
        shutdown.clone(),
    ));

    {
        let state = app_state.clone();
        let rules_swap_for_reload = rules_swap.clone();
        tokio::spawn(async move {
            reload_worker(state, rules_swap_for_reload, reload_rx).await;
        });
    }

    {
        let dns = dns_resolver.clone();
        tokio::spawn(async move {
            let mut interval = tokio::time::interval(std::time::Duration::from_secs(30));
            interval.set_missed_tick_behavior(tokio::time::MissedTickBehavior::Skip);
            loop {
                interval.tick().await;
                dns.gc();
            }
        });
    }

    if !urltest_instances.is_empty() {
        let probe_targets = build_probe_targets();
        for inst in urltest_instances {
            let tag = inst.name();
            let interval_secs = config
                .outbounds
                .iter()
                .find(|o| o.tag == tag)
                .and_then(|o| o.interval.as_deref())
                .and_then(parse_duration_secs)
                .unwrap_or(300);
            let targets = probe_targets.clone();
            tokio::spawn(async move {
                url_test_probe_loop(inst, targets, interval_secs).await;
            });
        }
    }

    if let Some(ref exp) = config.experimental {
        if let Some(ref met) = exp.metrics {
            if let Some(ref prom) = met.prometheus {
                if prom.enabled {
                    if let Ok(addr) = prom.listen.parse::<SocketAddr>() {
                        let state = app_state.clone();
                        tokio::spawn(async move {
                            match tokio::net::TcpListener::bind(addr).await {
                                Ok(listener) => {
                                    tracing::info!(listen = %addr, "control plane HTTP server listening");
                                    caly_api::serve(state, listener).await;
                                }
                                Err(e) => {
                                    tracing::error!(listen = %addr, error = %e, "control plane bind failed");
                                }
                            }
                        });
                    }
                }
            }
        }
    }

    let cpus = num_cpus();
    tracing::info!(
        workers = cpus,
        inbounds = config.inbounds.len(),
        "Spawning worker loops (thread-per-core)"
    );

    let mut inbound_specs: Vec<Arc<caly_worker::loop_scheduler::InboundSpec>> =
        Vec::with_capacity(config.inbounds.len());
    for ib in &config.inbounds {
        let listen_ip = ib.listen.parse::<std::net::IpAddr>()
            .unwrap_or(std::net::IpAddr::V4(std::net::Ipv4Addr::LOCALHOST));
        let listen_addr = SocketAddr::new(listen_ip, ib.port);
        let auth = match (&ib.username, &ib.password) {
            (Some(u), Some(p)) if !u.is_empty() => {
                caly_inbound::socks5::AuthConfig::new(u, p)
            }
            _ => caly_inbound::socks5::AuthConfig::none(),
        };
        inbound_specs.push(Arc::new(caly_worker::loop_scheduler::InboundSpec {
            tag: ib.tag.clone(),
            listen_addr,
            auth,
            udp: ib.udp,
            sniff: ib.sniff,
        }));
    }

    for worker_id in 0..cpus {
        let worker = Arc::new(WorkerLoop::new(
            caly_worker::loop_scheduler::WorkerConfig {
                worker_id,
                worker_count: cpus,
                inbounds: inbound_specs.clone(),
                rules: rules_swap.clone(),
                dns: dns_resolver.clone(),
                outbounds: outbounds_arc.clone(),
                metrics: session_metrics.clone(),
                shutdown: shutdown.clone(),
            },
        ));
        let thread_name = format!("caly-worker-{}", worker_id);
        std::thread::Builder::new()
            .name(thread_name)
            .spawn(move || {
                let rt = match tokio::runtime::Builder::new_current_thread()
                    .enable_all()
                    .build()
                {
                    Ok(rt) => rt,
                    Err(e) => {
                        tracing::error!(worker_id, error = %e, "worker runtime build failed");
                        return;
                    }
                };
                let local = tokio::task::LocalSet::new();
                local.block_on(&rt, async move {
                    if let Err(e) = worker.run().await {
                        tracing::error!(
                            worker_id,
                            error = %e,
                            "worker loop terminated"
                        );
                    }
                });
            })?;
    }

    {
        let stats = rules_swap.load().stats();
        tracing::info!(
            domain_rules = stats.domain_rules,
            ip_rules = stats.ip_rules,
            logic_rules = stats.logic_rules,
            "rules loaded"
        );
        let mut inbound_list: Vec<String> = Vec::new();
        for ib in &config.inbounds {
            inbound_list.push(format!("{}://{}:{}", ib.r#type, ib.listen, ib.port));
        }
        tracing::info!(inbounds = ?inbound_list, "inbounds bound");
        let mut outbound_list: Vec<String> = Vec::new();
        for (tag, adapter) in outbounds_arc.iter() {
            outbound_list.push(format!("{}:{}", tag, adapter.adapter_type()));
        }
        tracing::info!(outbounds = ?outbound_list, "outbounds ready");
    }

    tracing::info!("Caly Kernel bootstrap completed successfully. All engines running.");
    Ok(app_state)
}

fn num_cpus() -> usize {
    std::thread::available_parallelism()
        .map(|n| n.get())
        .unwrap_or(1)
        .clamp(1, 64)
}


#[cfg(test)]
mod round18_tests {
    // Marker: caly-round18-tests
    use super::parse_port_range;

    #[test]
    fn test_port_range_single() {
        assert_eq!(parse_port_range("443"), Some((443, 443)));
    }

    #[test]
    fn test_port_range_normal() {
        assert_eq!(parse_port_range("1000-2000"), Some((1000, 2000)));
    }

    #[test]
    fn test_port_range_swapped_input_gets_normalized() {
        // 宽容：用户写 "2000-1000" 应交换而非拒绝
        assert_eq!(parse_port_range("2000-1000"), Some((1000, 2000)));
    }

    #[test]
    fn test_port_range_whitespace_tolerated() {
        assert_eq!(parse_port_range("  80  "), Some((80, 80)));
        assert_eq!(parse_port_range(" 80 - 90 "), Some((80, 90)));
    }

    #[test]
    fn test_port_range_boundaries() {
        assert_eq!(parse_port_range("0"), Some((0, 0)));
        assert_eq!(parse_port_range("65535"), Some((65535, 65535)));
        assert_eq!(parse_port_range("0-65535"), Some((0, 65535)));
    }

    #[test]
    fn test_port_range_rejects_invalid() {
        assert_eq!(parse_port_range(""), None);
        assert_eq!(parse_port_range("abc"), None);
        assert_eq!(parse_port_range("70000"), None);      // > u16::MAX
        assert_eq!(parse_port_range("100-"), None);
        assert_eq!(parse_port_range("-100"), None);
        assert_eq!(parse_port_range("100-200-300"), None);
    }
}
