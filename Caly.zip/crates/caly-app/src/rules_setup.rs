//! Rule engine construction and port range parsing helpers.
//!
//! 从 `crate::bootstrap` 拆分而来（Round 18 重构）。

#![allow(unused_imports)]

use crate::config::CalyConfig;
use arc_swap::ArcSwap;
use caly_api::metrics::PrometheusMetrics;
use caly_api::state::{AppState, Epoch};
use caly_common::dns::DnsResolver;
use caly_common::error::CalyError;
use caly_dns::resolver::{DnsResolverConfig, DnsResolverImpl, DnsRouteRule};
use caly_dns::upstream::{DnsStrategy, UpstreamServer};
use caly_outbound::block::BlockAdapter;
use caly_outbound::direct::DirectAdapter;
use caly_outbound::group::{FallbackAdapter, SelectorAdapter, UrlTestAdapter};
use caly_outbound::shadowsocks_adapter::ShadowsocksAdapter;
use caly_outbound::ProxyAdapter;
use caly_rules::engine::RuleEngine;
use caly_rules::logic::{RuleCondition, RuleItem};
use caly_session::guard::SessionMetricsTracker;
use caly_worker::loop_scheduler::WorkerLoop;
use smol_str::SmolStr;
use std::collections::HashMap;
use std::net::SocketAddr;
use std::sync::Arc;
use std::time::Instant;
use tokio::sync::Notify;

// ============================================================
// 以下定义从 bootstrap.rs 移动而来，逻辑保持不变
// ============================================================

pub fn build_rule_engine(config: &CalyConfig) -> Result<RuleEngine, CalyError> {
    if let Some(ref archive_path) = config.rule_archive {
        match caly_rules::ArchiveLoader::load(std::path::Path::new(archive_path)) {
            Ok(loader) => {
                tracing::info!(
                    path = %archive_path,
                    "rule archive loaded via mmap (zero-copy)"
                );
                return Ok(loader.into_engine());
            }
            Err(e) => {
                tracing::warn!(
                    path = %archive_path,
                    error = %e,
                    "rule archive load failed; falling back to JSON construction"
                );
            }
        }
    }
    build_rule_engine_from_json(config)
}

pub fn build_rule_engine_from_json_public(config: &CalyConfig) -> Result<RuleEngine, CalyError> {
    build_rule_engine_from_json(config)
}

pub fn parse_port_range(spec: &str) -> Option<(u16, u16)> {
    let s = spec.trim();
    if s.is_empty() {
        return None;
    }
    if let Some((lo_s, hi_s)) = s.split_once('-') {
        let lo = lo_s.trim().parse::<u16>().ok()?;
        let hi = hi_s.trim().parse::<u16>().ok()?;
        // 宽容处理：用户可能写 "2000-1000"，交换即可。
        Some(if lo <= hi { (lo, hi) } else { (hi, lo) })
    } else {
        let p = s.parse::<u16>().ok()?;
        Some((p, p))
    }
}

pub fn build_rule_engine_from_json(config: &CalyConfig) -> Result<RuleEngine, CalyError> {
    let mut rule_items = Vec::new();
    let mut final_tag = "direct".to_string();
    if let Some(ref routes) = config.routes {
        final_tag = routes.r#final.clone();
        for r in &routes.rules {
            if let Some(ref domains) = r.domain {
                for d in domains {
                    rule_items.push(RuleItem::new(
                        RuleCondition::Domain(SmolStr::new(d)),
                        &r.outbound,
                    ));
                }
            }
            if let Some(ref suffixes) = r.domain_suffix {
                for s in suffixes {
                    rule_items.push(RuleItem::new(
                        RuleCondition::DomainSuffix(SmolStr::new(s)),
                        &r.outbound,
                    ));
                }
            }
            if let Some(ref keywords) = r.domain_keyword {
                for k in keywords {
                    rule_items.push(RuleItem::new(
                        RuleCondition::DomainKeyword(SmolStr::new(k)),
                        &r.outbound,
                    ));
                }
            }
            if let Some(ref cidrs) = r.ip_cidr {
                for c in cidrs {
                    if let Ok(net) = c.parse::<ipnet::IpNet>() {
                        rule_items.push(RuleItem::new(RuleCondition::IpCidr(net), &r.outbound));
                    } else {
                        tracing::warn!(
                            cidr = %c,
                            outbound = %r.outbound,
                            "invalid ip_cidr in route rule; skipped"
                        );
                    }
                }
            }
            if let Some(ref cidrs) = r.source_ip_cidr {
                for c in cidrs {
                    if let Ok(net) = c.parse::<ipnet::IpNet>() {
                        rule_items.push(RuleItem::new(
                            RuleCondition::SourceIpCidr(net),
                            &r.outbound,
                        ));
                    } else {
                        tracing::warn!(
                            cidr = %c,
                            outbound = %r.outbound,
                            "invalid source_ip_cidr in route rule; skipped"
                        );
                    }
                }
            }
            if let Some(ref ports) = r.port {
                for p in ports {
                    rule_items.push(RuleItem::new(RuleCondition::Port(*p), &r.outbound));
                }
            }
            if let Some(ref ranges) = r.port_range {
                for spec in ranges {
                    match parse_port_range(spec) {
                        Some((lo, hi)) => {
                            rule_items.push(RuleItem::new(
                                RuleCondition::PortRange(lo, hi),
                                &r.outbound,
                            ));
                        }
                        None => {
                            tracing::warn!(
                                spec = %spec,
                                outbound = %r.outbound,
                                "invalid port_range in route rule (expected 'lo-hi' or 'p'); skipped"
                            );
                        }
                    }
                }
            }
            if let Some(ref ports) = r.source_port {
                for p in ports {
                    rule_items.push(RuleItem::new(
                        RuleCondition::SourcePort(*p),
                        &r.outbound,
                    ));
                }
            }
            if let Some(ref tags) = r.inbound {
                for t in tags {
                    rule_items.push(RuleItem::new(RuleCondition::Inbound(*t), &r.outbound));
                }
            }
            if let Some(ref net) = r.network {
                match net.parse::<caly_common::metadata::Network>() {
                    Ok(n) => rule_items.push(RuleItem::new(
                        RuleCondition::Network(n),
                        &r.outbound,
                    )),
                    Err(_) => {
                        tracing::warn!(
                            network = %net,
                            outbound = %r.outbound,
                            "invalid network in route rule (expected tcp/udp/both); skipped"
                        );
                    }
                }
            }
            if let Some(ref proto) = r.protocol {
                let p_lower = proto.to_ascii_lowercase();
                // 未知协议值**不**静默映射为 Unknown：
                // 旧实现的 `_ => Unknown` 会让拼错的协议名产生一条永不
                // 匹配的规则（因为嗅探成功时 protocol 会是 Tls/Http 等，
                // 不会是 Unknown）——用户的规则静默失效且无任何提示。
                //
                // 新行为：打 warn 并**跳过**该条规则。用户在启动日志里
                // 立刻看到问题，而不是在"为什么规则不生效"上浪费数小时。
                let sn = match p_lower.as_str() {
                    "http" | "http/1.1" => Some(caly_common::metadata::SniffedProto::Http),
                    "tls" => Some(caly_common::metadata::SniffedProto::Tls),
                    "quic" => Some(caly_common::metadata::SniffedProto::Quic),
                    "bittorrent" => Some(caly_common::metadata::SniffedProto::BitTorrent),
                    "dns" => Some(caly_common::metadata::SniffedProto::Dns),
                    "socks5" => Some(caly_common::metadata::SniffedProto::Socks5),
                    "websocket" | "ws" => Some(caly_common::metadata::SniffedProto::WebSocket),
                    // 显式 Unknown 是合法的（匹配未识别的协议）
                    "unknown" | "" => Some(caly_common::metadata::SniffedProto::Unknown),
                    _ => None,
                };
                match sn {
                    Some(proto_kind) => {
                        rule_items.push(RuleItem::new(
                            RuleCondition::Protocol(proto_kind),
                            &r.outbound,
                        ));
                    }
                    None => {
                        tracing::warn!(
                            protocol = %proto,
                            outbound = %r.outbound,
                            "unknown protocol value in route rule; rule skipped. \
                             Valid values: http, tls, quic, bittorrent, dns, \
                             socks5, websocket, unknown"
                        );
                    }
                }
            }
            if let Some(ref procs) = r.process_name {
                for p in procs {
                    if p.is_empty() {
                        tracing::warn!(
                            outbound = %r.outbound,
                            "empty process_name in route rule; entry skipped"
                        );
                        continue;
                    }
                    rule_items.push(RuleItem::new(
                        RuleCondition::ProcessName(SmolStr::new(p)),
                        &r.outbound,
                    ));
                }
            }
            if r.ip_is_private.unwrap_or(false) {
                rule_items.push(RuleItem::new(RuleCondition::IpIsPrivate, &r.outbound));
            }
            if r.sniffed == Some(true) {
                rule_items.push(RuleItem::new(
                    RuleCondition::SniffSource(caly_common::metadata::SNIFF_SRC_ANY),
                    &r.outbound,
                ));
            }
            if r.user_set == Some(true) {
                rule_items.push(RuleItem::new(
                    RuleCondition::SniffSource(caly_common::metadata::SNIFF_SRC_USER),
                    &r.outbound,
                ));
            }
        }
    }
    Ok(RuleEngine::new(rule_items, &final_tag))
}
