//! Selector state persistence (atomic file write).
//!
//! 从 `crate::bootstrap` 拆分而来（Round 18 重构）。

#![allow(unused_imports)]

use crate::config::CalyConfig;
use arc_swap::ArcSwap;
use caly_api::metrics::PrometheusMetrics;
use caly_api::state::{AppState, Epoch};
use caly_common::dns::DnsResolver;
use caly_common::error::CalyError;
use caly_dns::resolver::{DnsResolverConfig, DnsResolverImpl, DnsRouteRule};
use caly_dns::upstream::{DnsStrategy, UpstreamServer};
use caly_outbound::block::BlockAdapter;
use caly_outbound::direct::DirectAdapter;
use caly_outbound::group::{FallbackAdapter, SelectorAdapter, UrlTestAdapter};
use caly_outbound::shadowsocks_adapter::ShadowsocksAdapter;
use caly_outbound::ProxyAdapter;
use caly_rules::engine::RuleEngine;
use caly_rules::logic::{RuleCondition, RuleItem};
use caly_session::guard::SessionMetricsTracker;
use caly_worker::loop_scheduler::WorkerLoop;
use smol_str::SmolStr;
use std::collections::HashMap;
use std::net::SocketAddr;
use std::sync::Arc;
use std::time::Instant;
use tokio::sync::Notify;

// ============================================================
// 以下定义从 bootstrap.rs 移动而来，逻辑保持不变
// ============================================================

pub const SELECTOR_STATE_FILE: &str = "selector-state.json";

pub fn selector_state_path() -> std::path::PathBuf {
    let candidates = [
        std::path::PathBuf::from("/var/lib/caly"),
        std::path::PathBuf::from("."),
    ];
    for c in candidates {
        if c.exists() && c.is_dir() {
            return c.join(SELECTOR_STATE_FILE);
        }
    }
    std::path::PathBuf::from(SELECTOR_STATE_FILE)
}

pub fn load_selector_state() -> std::collections::HashMap<String, String> {
    let path = selector_state_path();
    match std::fs::read_to_string(&path) {
        Ok(s) => serde_json::from_str(&s).unwrap_or_default(),
        Err(_) => std::collections::HashMap::new(),
    }
}

pub fn save_selector_state(state: &std::collections::HashMap<String, String>) {
    let path = selector_state_path();
    let json = match serde_json::to_string_pretty(state) {
        Ok(s) => s,
        Err(e) => {
            tracing::warn!(error = %e, "failed to serialize selector state");
            return;
        }
    };
    let tmp_path = path.with_extension("json.tmp");
    let result = (|| -> std::io::Result<()> {
        use std::io::Write;
        {
            let mut f = std::fs::File::create(&tmp_path)?;
            f.write_all(json.as_bytes())?;
            f.sync_all()?;
        }
        std::fs::rename(&tmp_path, &path)?;
        #[cfg(unix)]
        {
            if let Some(dir) = path.parent() {
                if let Ok(d) = std::fs::File::open(dir) {
                    let _ = d.sync_all();
                }
            }
        }
        Ok(())
    })();
    if let Err(e) = result {
        tracing::warn!(path = ?path, error = %e, "failed to persist selector state");
        let _ = std::fs::remove_file(&tmp_path);
    }
}
