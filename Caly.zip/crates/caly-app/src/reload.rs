//! Background config hot-reload worker.
//!
//! 从 `crate::bootstrap` 拆分而来（Round 18 重构）。

#![allow(unused_imports)]

use crate::config::CalyConfig;
use crate::dns_setup::build_dns_resolver;
use crate::rules_setup::build_rule_engine;
use arc_swap::ArcSwap;
use caly_api::metrics::PrometheusMetrics;
use caly_api::state::{AppState, Epoch};
use caly_common::dns::DnsResolver;
use caly_common::error::CalyError;
use caly_dns::resolver::{DnsResolverConfig, DnsResolverImpl, DnsRouteRule};
use caly_dns::upstream::{DnsStrategy, UpstreamServer};
use caly_outbound::block::BlockAdapter;
use caly_outbound::direct::DirectAdapter;
use caly_outbound::group::{FallbackAdapter, SelectorAdapter, UrlTestAdapter};
use caly_outbound::shadowsocks_adapter::ShadowsocksAdapter;
use caly_outbound::ProxyAdapter;
use caly_rules::engine::RuleEngine;
use caly_rules::logic::{RuleCondition, RuleItem};
use caly_session::guard::SessionMetricsTracker;
use caly_worker::loop_scheduler::WorkerLoop;
use smol_str::SmolStr;
use std::collections::HashMap;
use std::net::SocketAddr;
use std::sync::Arc;
use std::time::Instant;
use tokio::sync::Notify;

// ============================================================
// 以下定义从 bootstrap.rs 移动而来，逻辑保持不变
// ============================================================

pub async fn reload_worker(
    state: Arc<AppState>,
    rules_swap: Arc<ArcSwap<RuleEngine>>,
    mut rx: tokio::sync::mpsc::Receiver<caly_api::ReloadRequest>,
) {
    tracing::info!("config reload worker started");
    while let Some(req) = rx.recv().await {
        let json = req.config_json.clone();
        let result = tokio::task::spawn_blocking(move || -> Result<_, String> {
            let config: CalyConfig = serde_json::from_str(&json)
                .map_err(|e| format!("JSON parse failed: {e}"))?;
            config.validate().map_err(|e| format!("validation failed: {e}"))?;
            let rules = build_rule_engine(&config).map_err(|e| format!("rules build: {e}"))?;
            let dns = build_dns_resolver(&config).map_err(|e| format!("dns build: {e}"))?;
            Ok((rules, dns as Arc<dyn DnsResolver>))
        })
        .await;
        match result {
            Ok(Ok((rules, dns))) => {
                // 关键修复（Round 20）：rules_swap 是 WorkerLoop 实际
                // 读取规则的句柄，必须同步更新。旧实现只更新了
                // AppState.epoch，worker 仍在使用启动时的旧规则 ——
                // 配置热重载对数据面完全无效。
                let rules_arc = Arc::new(rules);
                rules_swap.store(rules_arc.clone());
                let new_id = state.reload(rules_arc, dns);
                tracing::info!(new_epoch = new_id, "config reloaded via API");
            }
            Ok(Err(e)) => {
                tracing::warn!(error = %e, "config reload rejected; old config still active");
            }
            Err(e) => {
                tracing::error!(error = %e, "reload task join error");
            }
        }
    }
    tracing::warn!("config reload worker exited");
}
