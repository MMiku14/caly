//! Declarative configuration schema and multi-tier semantic validator.

use caly_common::error::CalyError;
use serde::{Deserialize, Serialize};
use std::collections::{HashMap, HashSet};
use std::net::SocketAddr;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CalyConfig {
    pub version: String,
    pub log: Option<LogConfig>,
    pub dns: Option<DnsConfig>,
    pub inbounds: Vec<InboundConfig>,
    pub outbounds: Vec<OutboundConfig>,
    pub routes: Option<RoutesConfig>,
    pub experimental: Option<ExperimentalConfig>,
    #[serde(default)]
    pub rule_archive: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct LogConfig {
    #[serde(default = "default_log_level")]
    pub level: String,
    #[serde(default = "default_log_format")]
    pub format: String,
    #[serde(default = "default_log_output")]
    pub output: String,
    #[serde(default = "default_true")]
    pub timestamp: bool,
    #[serde(default)]
    pub caller: bool,
}

fn default_log_level() -> String { "info".to_string() }
fn default_log_format() -> String { "json".to_string() }
fn default_log_output() -> String { "stdout".to_string() }
fn default_true() -> bool { true }

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DnsConfig {
    pub servers: Vec<DnsServerConfig>,
    #[serde(default)]
    pub rules: Vec<DnsRuleConfig>,
    pub fakeip: Option<FakeIpConfig>,
    pub cache: Option<DnsCacheConfig>,
    #[serde(default = "default_final_dns")]
    pub r#final: String,
}

fn default_final_dns() -> String { "local".to_string() }

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DnsServerConfig {
    pub tag: String,
    pub address: String,
    #[serde(default = "default_strategy")]
    pub strategy: String,
    #[serde(default = "default_direct")]
    pub detour: String,
}

fn default_strategy() -> String { "prefer_ipv4".to_string() }
fn default_direct() -> String { "direct".to_string() }

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DnsRuleConfig {
    #[serde(default)]
    pub domain_suffix: Vec<String>,
    #[serde(default)]
    pub domain_keyword: Vec<String>,
    pub server: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct FakeIpConfig {
    #[serde(default = "default_true")]
    pub enabled: bool,
    #[serde(default = "default_fakeip_inet4")]
    pub inet4_range: String,
    #[serde(default = "default_fakeip_ttl")]
    pub global_ttl: u64,
}

fn default_fakeip_inet4() -> String { "198.18.0.0/15".to_string() }
fn default_fakeip_ttl() -> u64 { 300 }

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DnsCacheConfig {
    #[serde(default = "default_true")]
    pub enabled: bool,
    #[serde(default = "default_cache_capacity")]
    pub capacity: usize,
    #[serde(default = "default_true")]
    pub optimistic: bool,
    #[serde(default = "default_optimistic_ttl")]
    pub optimistic_ttl: u64,
}

fn default_cache_capacity() -> usize { 4096 }
fn default_optimistic_ttl() -> u64 { 60 }

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct InboundConfig {
    pub r#type: String,
    pub tag: String,
    #[serde(default = "default_listen_addr")]
    pub listen: String,
    pub port: u16,
    #[serde(default = "default_true")]
    pub udp: bool,
    #[serde(default = "default_true")]
    pub sniff: bool,
    #[serde(default = "default_sniff_timeout")]
    pub sniff_timeout: String,
    pub username: Option<String>,
    pub password: Option<String>,
}

fn default_listen_addr() -> String { "127.0.0.1".to_string() }
fn default_sniff_timeout() -> String { "300ms".to_string() }

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct OutboundConfig {
    pub r#type: String,
    pub tag: String,
    pub server: Option<String>,
    pub server_port: Option<u16>,
    pub method: Option<String>,
    pub password: Option<String>,
    pub uuid: Option<String>,
    pub flow: Option<String>,
    pub outbounds: Option<Vec<String>>,
    pub url: Option<String>,
    pub interval: Option<String>,
    #[serde(default)]
    pub tls: Option<OutboundTlsConfig>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct OutboundTlsConfig {
    #[serde(default)]
    pub enabled: bool,
    #[serde(default)]
    pub server_name: Option<String>,
    #[serde(default)]
    pub skip_verify: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RoutesConfig {
    pub rules: Vec<RouteRuleItemConfig>,
    #[serde(default = "default_direct")]
    pub r#final: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RouteRuleItemConfig {
    pub domain: Option<Vec<String>>,
    pub domain_suffix: Option<Vec<String>>,
    pub domain_keyword: Option<Vec<String>>,
    pub ip_cidr: Option<Vec<String>>,
    pub ip_is_private: Option<bool>,
    pub port: Option<Vec<u16>>,
    pub protocol: Option<String>,
    #[serde(default)]
    pub sniffed: Option<bool>,
    #[serde(default)]
    pub user_set: Option<bool>,
    pub outbound: String,

    // ─── Round 10 补齐：以下规则类型 RuleCondition 早已定义，
    //     但 config 层缺失接口，用户按 doc3.md §1.3.6 写会被静默忽略。
    /// 源 IP 段匹配。每个元素是 CIDR 字符串（如 "192.168.1.0/24"）。
    /// 展开为多条独立的 SourceIpCidr 规则。
    #[serde(default)]
    pub source_ip_cidr: Option<Vec<String>>,
    /// 目标端口范围。每个元素是字符串 "lo-hi"（如 "1000-2000"），
    /// 也接受单端口 "443"。展开为多条 PortRange 规则。
    #[serde(default)]
    pub port_range: Option<Vec<String>>,
    /// 源端口匹配。每个元素是一个 u16。
    #[serde(default)]
    pub source_port: Option<Vec<u16>>,
    /// 入站 tag 数值 ID 匹配。
    #[serde(default)]
    pub inbound: Option<Vec<u64>>,
    /// 网络类型匹配："tcp" / "udp" / "both"（不区分大小写）。
    #[serde(default)]
    pub network: Option<String>,
    /// 进程名精确匹配（如 `"curl"` / `"firefox"`）。
    ///
    /// 依赖 `SessionMetadata::process` 字段。该字段当前**仅在通过
    /// `/api/v1/rules/check?process=curl` 显式查询时被填充**——worker
    /// 主路径尚未实现进程名探测（需要 eBPF / procfs 遍历，见后续轮次）。
    ///
    /// 因此，配置此字段不会让进程名规则在真实流量上生效，但：
    ///   1. 保证配置能通过解析（否则用户会认为 `--check` 通过了却从未生效）
    ///   2. 规则可通过诊断端点验证
    ///   3. 未来实现进程名探测时零成本启用
    ///
    /// 每个元素展开为一条独立的 ProcessName 规则。
    #[serde(default)]
    pub process_name: Option<Vec<String>>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ExperimentalConfig {
    pub clash_api: Option<ClashApiConfig>,
    pub metrics: Option<MetricsConfig>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ClashApiConfig {
    pub external_controller: String,
    pub secret: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MetricsConfig {
    pub prometheus: Option<PrometheusConfig>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PrometheusConfig {
    #[serde(default = "default_true")]
    pub enabled: bool,
    pub listen: String,
}

impl CalyConfig {
    pub fn validate(&self) -> Result<(), CalyError> {
        if !self.version.starts_with("1.") && self.version != "1" {
            return Err(CalyError::Config(format!(
                "Unsupported config version '{}'; this build supports 1.x",
                self.version
            )));
        }
        if self.inbounds.is_empty() {
            return Err(CalyError::Config("At least one inbound must be defined".to_string()));
        }
        if self.outbounds.is_empty() {
            return Err(CalyError::Config("At least one outbound must be defined".to_string()));
        }

        let mut outbound_tags: HashSet<&str> = HashSet::new();
        for ob in &self.outbounds {
            if !outbound_tags.insert(ob.tag.as_str()) {
                return Err(CalyError::Config(format!("Duplicate outbound tag: {}", ob.tag)));
            }
            if ob.r#type == "selector" {
                if let Some(ref candidates) = ob.outbounds {
                    if candidates.contains(&ob.tag) {
                        return Err(CalyError::Config(format!(
                            "Selector outbound '{}' cannot contain itself in candidate list",
                            ob.tag
                        )));
                    }
                }
            }
        }

        for ob in &self.outbounds {
            if matches!(ob.r#type.as_str(), "selector" | "urltest" | "fallback") {
                if let Some(ref candidates) = ob.outbounds {
                    for name in candidates {
                        if !outbound_tags.contains(name.as_str()) {
                            return Err(CalyError::Config(format!(
                                "{} outbound '{}' references unknown outbound '{}'",
                                ob.r#type, ob.tag, name
                            )));
                        }
                    }
                }
            }
        }

        let mut inbound_tags = HashSet::new();
        for ib in &self.inbounds {
            if !inbound_tags.insert(&ib.tag) {
                return Err(CalyError::Config(format!("Duplicate inbound tag: {}", ib.tag)));
            }
            if ib.port == 0 {
                return Err(CalyError::Config(format!("Inbound '{}' port cannot be 0", ib.tag)));
            }
        }

        if let Some(ref dns) = self.dns {
            let mut server_tags = HashSet::new();
            for s in &dns.servers {
                server_tags.insert(&s.tag);
                // 修复（Round 20）：接受 tls:// scheme。
                // build_dns_resolver 支持 "tls://IP:PORT[#SNI]" 格式的
                // DoT 上游，但 validate 只用 SocketAddr 校验，导致配置
                // 校验和实际构建行为不一致 —— 用户配了 DoT 会被拒绝启动。
                if !is_valid_dns_server_address(&s.address) {
                    return Err(CalyError::Config(format!(
                        "Invalid DNS server address '{}' for server '{}'; \
                         expected 'IP:PORT' or 'tls://IP:PORT[#SNI]'",
                        s.address, s.tag
                    )));
                }
            }
            for rule in &dns.rules {
                if !server_tags.contains(&rule.server) {
                    return Err(CalyError::Config(format!(
                        "DNS rule references non-existent server '{}'",
                        rule.server
                    )));
                }
            }
            if let Some(ref fakeip) = dns.fakeip {
                if fakeip.inet4_range.parse::<ipnet::Ipv4Net>().is_err() {
                    return Err(CalyError::Config(format!(
                        "Invalid FakeIP CIDR range: {}",
                        fakeip.inet4_range
                    )));
                }
            }
        }

        if let Some(ref routes) = self.routes {
            if !outbound_tags.contains(routes.r#final.as_str()) {
                return Err(CalyError::Config(format!(
                    "Routes final outbound tag '{}' not found in declared outbounds",
                    routes.r#final
                )));
            }
            for (idx, rule) in routes.rules.iter().enumerate() {
                if !outbound_tags.contains(rule.outbound.as_str()) {
                    return Err(CalyError::Config(format!(
                        "Rule #{} targets non-existent outbound: '{}'",
                        idx, rule.outbound
                    )));
                }
                if let Some(ref cidrs) = rule.ip_cidr {
                    for c in cidrs {
                        if c.parse::<ipnet::IpNet>().is_err() {
                            return Err(CalyError::Config(format!(
                                "Rule #{} contains invalid IP CIDR notation: '{}'",
                                idx, c
                            )));
                        }
                    }
                }
            }
        }

        validate_outbound_semantics(self)?;
        detect_outbound_cycles(self)?;
        tracing::info!("Configuration validated successfully (Tiers 1, 2, 3, 3.5)");
        Ok(())
    }
}

fn detect_outbound_cycles(config: &CalyConfig) -> Result<(), CalyError> {
    fn is_group_type(t: &str) -> bool {
        matches!(t, "selector" | "urltest" | "fallback")
    }

    let mut adj: HashMap<&str, Vec<&str>> = HashMap::new();
    for ob in &config.outbounds {
        if is_group_type(&ob.r#type) {
            if let Some(ref cands) = ob.outbounds {
                adj.insert(
                    ob.tag.as_str(),
                    cands.iter().map(|s| s.as_str()).collect(),
                );
            }
        }
    }

    #[derive(Copy, Clone, PartialEq)]
    enum Color {
        White,
        Gray,
        Black,
    }

    fn dfs<'a>(
        node: &'a str,
        adj: &HashMap<&'a str, Vec<&'a str>>,
        color: &mut HashMap<&'a str, Color>,
        path: &mut Vec<&'a str>,
    ) -> Result<(), String> {
        color.insert(node, Color::Gray);
        path.push(node);
        if let Some(neighbors) = adj.get(node) {
            for &next in neighbors {
                if !adj.contains_key(next) {
                    continue;
                }
                match color.get(next).copied().unwrap_or(Color::White) {
                    Color::Gray => {
                        let start = path.iter().position(|&x| x == next).unwrap_or(0);
                        let cycle: Vec<&str> = path[start..].to_vec();
                        return Err(format!(
                            "reference cycle detected: {} -> {}",
                            cycle.join(" -> "),
                            next
                        ));
                    }
                    Color::White => dfs(next, adj, color, path)?,
                    Color::Black => {}
                }
            }
        }
        path.pop();
        color.insert(node, Color::Black);
        Ok(())
    }

    let all_tags: Vec<&str> = adj.keys().copied().collect();
    let mut color: HashMap<&str, Color> =
        all_tags.iter().map(|&t| (t, Color::White)).collect();
    for &tag in &all_tags {
        let cur = color.get(tag).copied().unwrap_or(Color::White);
        if cur == Color::White {
            let mut path: Vec<&str> = Vec::new();
            dfs(tag, &adj, &mut color, &mut path)
                .map_err(|e| CalyError::Config(format!("outbound {}", e)))?;
        }
    }
    Ok(())
}

/// 判断 DNS server 地址字符串是否合法。
///
/// 当前支持：
///   - `"IP:PORT"`                     明文 UDP/TCP DNS
///   - `"tls://IP:PORT"`               DoT，SNI 默认取 IP
///   - `"tls://IP:PORT#SNI"`           DoT，显式 SNI
///
/// 未来扩展 DoH/DoQ 时在此处添加分支。
fn is_valid_dns_server_address(addr: &str) -> bool {
    if addr.parse::<SocketAddr>().is_ok() {
        return true;
    }
    if let Some(rest) = addr.strip_prefix("tls://") {
        let host_port = rest.split_once('#').map(|(hp, _)| hp).unwrap_or(rest);
        if host_port.parse::<SocketAddr>().is_ok() {
            return true;
        }
    }
    false
}

fn validate_outbound_semantics(config: &CalyConfig) -> Result<(), CalyError> {
    const SS_METHODS: &[&str] = &[
        "2022-blake3-aes-256-gcm",
    ];
    for ob in &config.outbounds {
        match ob.r#type.as_str() {
            "direct" | "block" => {}
            "shadowsocks" => {
                let server = ob.server.as_deref().ok_or_else(|| {
                    CalyError::Config(format!(
                        "shadowsocks outbound '{}' requires 'server'",
                        ob.tag
                    ))
                })?;
                let port = ob.server_port.ok_or_else(|| {
                    CalyError::Config(format!(
                        "shadowsocks outbound '{}' requires 'server_port'",
                        ob.tag
                    ))
                })?;
                if port == 0 {
                    return Err(CalyError::Config(format!(
                        "shadowsocks outbound '{}' port cannot be 0",
                        ob.tag
                    )));
                }
                if server.is_empty() {
                    return Err(CalyError::Config(format!(
                        "shadowsocks outbound '{}' server is empty",
                        ob.tag
                    )));
                }
                let method = ob.method.as_deref().unwrap_or("");
                if !SS_METHODS.contains(&method) {
                    return Err(CalyError::Config(format!(
                        "shadowsocks outbound '{}' unsupported method '{}'; supported: {:?}",
                        ob.tag, method, SS_METHODS
                    )));
                }
                let password = ob.password.as_deref().unwrap_or("");
                if password.is_empty() {
                    return Err(CalyError::Config(format!(
                        "shadowsocks outbound '{}' requires non-empty 'password'",
                        ob.tag
                    )));
                }
            }
            "selector" | "urltest" | "fallback" => {
                let candidates = ob.outbounds.as_ref().ok_or_else(|| {
                    CalyError::Config(format!(
                        "{} outbound '{}' requires 'outbounds' array",
                        ob.r#type, ob.tag
                    ))
                })?;
                if candidates.is_empty() {
                    return Err(CalyError::Config(format!(
                        "{} outbound '{}' has empty candidate list",
                        ob.r#type, ob.tag
                    )));
                }
            }
            other => {
                return Err(CalyError::Config(format!(
                    "unsupported outbound type '{}' for tag '{}'",
                    other, ob.tag
                )));
            }
        }
    }
    Ok(())
}


#[cfg(test)]
mod round18_tests {
    // Marker: caly-round18-tests
    use super::*;

    fn parse(json: &str) -> CalyConfig {
        serde_json::from_str(json).expect("valid test json")
    }

    #[test]
    fn test_route_rule_new_fields_all_parse() {
        // 覆盖 Round 10 + Round 12 新增的 6 个配置字段
        let cfg = parse(r#"{
            "version": "1.0",
            "inbounds": [{"type": "socks5", "tag": "in", "port": 1080}],
            "outbounds": [{"type": "direct", "tag": "direct"}],
            "routes": {
                "rules": [{
                    "source_ip_cidr": ["10.0.0.0/8", "192.168.0.0/16"],
                    "port_range": ["1000-2000", "443"],
                    "source_port": [12345],
                    "inbound": [1, 2],
                    "network": "udp",
                    "process_name": ["curl", "wget"],
                    "outbound": "direct"
                }],
                "final": "direct"
            }
        }"#);

        let rules = &cfg.routes.as_ref().expect("routes present").rules;
        assert_eq!(rules.len(), 1);
        let r = &rules[0];

        assert_eq!(
            r.source_ip_cidr.as_ref().map(|v| v.len()),
            Some(2),
            "source_ip_cidr 未正确反序列化"
        );
        assert_eq!(
            r.port_range.as_ref().map(|v| v.len()),
            Some(2),
            "port_range 未正确反序列化"
        );
        assert_eq!(
            r.source_port.as_ref().map(|v| v.len()),
            Some(1),
            "source_port 未正确反序列化"
        );
        assert_eq!(
            r.inbound.as_deref(),
            Some(&[1u64, 2][..]),
            "inbound 未正确反序列化"
        );
        assert_eq!(
            r.network.as_deref(),
            Some("udp"),
            "network 未正确反序列化"
        );
        assert_eq!(
            r.process_name.as_ref().map(|v| v.len()),
            Some(2),
            "process_name 未正确反序列化"
        );
    }

    #[test]
    fn test_route_rule_legacy_fields_still_work() {
        // 向后兼容：老的配置格式仍能解析 + 通过 validate
        let cfg = parse(r#"{
            "version": "1.0",
            "inbounds": [{"type": "socks5", "tag": "in", "port": 1080}],
            "outbounds": [{"type": "direct", "tag": "direct"}],
            "routes": {
                "rules": [{"domain_suffix": [".cn"], "outbound": "direct"}],
                "final": "direct"
            }
        }"#);
        cfg.validate().expect("legacy config must pass validate");
    }

    #[test]
    fn test_validate_rejects_unknown_group_candidate() {
        // Round 9 引入的候选 tag 存在性检查
        let cfg = parse(r#"{
            "version": "1.0",
            "inbounds": [{"type": "socks5", "tag": "in", "port": 1080}],
            "outbounds": [
                {"type": "direct", "tag": "direct"},
                {"type": "selector", "tag": "sel", "outbounds": ["direct", "missing"]}
            ]
        }"#);
        let err = cfg.validate().unwrap_err();
        let msg = format!("{err}");
        assert!(
            msg.contains("missing"),
            "错误信息应包含缺失的 tag 名，实际: {msg}"
        );
    }

    #[test]
    fn test_validate_rejects_outbound_cycle() {
        // Round 4 引入的循环检测
        let cfg = parse(r#"{
            "version": "1.0",
            "inbounds": [{"type": "socks5", "tag": "in", "port": 1080}],
            "outbounds": [
                {"type": "selector", "tag": "a", "outbounds": ["b"]},
                {"type": "selector", "tag": "b", "outbounds": ["a"]}
            ]
        }"#);
        assert!(cfg.validate().is_err());
    }
}
