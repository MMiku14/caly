//! Error types for Caly proxy kernel.

use thiserror::Error;

#[derive(Error, Debug)]
pub enum CalyError {
    #[error("I/O error: {0}")]
    Io(#[from] std::io::Error),
    #[error("Address parse error: {0}")]
    AddrParse(#[from] std::net::AddrParseError),
    #[error("Configuration error: {0}")]
    Config(String),
    #[error("DNS resolution error: {0}")]
    Dns(#[from] DnsError),
    #[error("Transport error: {0}")]
    Transport(#[from] TransportError),
    #[error("Outbound proxy error: {0}")]
    Proxy(#[from] ProxyError),
    #[error("SOCKS5 protocol error: {0}")]
    Socks5(#[from] Socks5Error),
    #[error("Rule engine error: {0}")]
    Rule(String),
}

#[derive(Error, Debug, Clone, PartialEq, Eq)]
pub enum DnsError {
    #[error("DNS query timed out for domain: {0}")]
    Timeout(String),
    #[error("No upstream DNS servers configured or available")]
    NoUpstream,
    #[error("Domain not found (NXDOMAIN): {0}")]
    NotFound(String),
    #[error("Fake-IP pool exhausted")]
    FakeIpExhausted,
    #[error("Upstream server error: {0}")]
    UpstreamFailed(String),
    #[error("Protocol parse error in DNS response: {0}")]
    ParseError(String),
    #[error("CNAME loop detected")]
    CnameLoop,
}

impl From<std::io::Error> for DnsError {
    fn from(err: std::io::Error) -> Self {
        DnsError::UpstreamFailed(err.to_string())
    }
}

#[derive(Error, Debug)]
pub enum TransportError {
    #[error("Underlying I/O failure: {0}")]
    Io(#[from] std::io::Error),
    #[error("TLS handshake failure: {0}")]
    TlsHandshake(String),
    #[error("WebSocket handshake failure: {0}")]
    WsHandshake(String),
    #[error("Connection timed out")]
    Timeout,
    #[error("Unsupported transport layer combination")]
    UnsupportedCombination,
    #[error("Connection reset by peer")]
    ConnectionReset,
}

#[derive(Error, Debug)]
pub enum ProxyError {
    #[error("Outbound target connection failed: {0}")]
    ConnectionFailed(String),
    #[error("Target connection rejected by policy/firewall")]
    Blocked,
    #[error("Outbound adapter not found: {0}")]
    NotFound(String),
    #[error("Outbound protocol handshake failed: {0}")]
    HandshakeFailed(String),
    #[error("Protocol unsupported by adapter: {0}")]
    Unsupported(String),
    #[error("Network unreachable")]
    NetworkUnreachable,
    #[error("Connection refused")]
    ConnectionRefused,
}

#[derive(Error, Debug, Clone, Copy, PartialEq, Eq)]
pub enum Socks5Error {
    #[error("Internal state buffer overflow")]
    BufferOverflow,
    #[error("Unsupported SOCKS version (must be 0x05)")]
    UnsupportedVersion,
    #[error("No acceptable authentication method supported")]
    NoAcceptableAuth,
    #[error("Unsupported SOCKS command")]
    UnsupportedCommand,
    #[error("Unsupported address type")]
    UnsupportedAddressType,
    #[error("Invalid protocol transition or state")]
    InvalidState,
    #[error("Connection not established")]
    NotEstablished,
    #[error("Connection timed out")]
    Timeout,
    #[error("Malformed address payload")]
    MalformedAddress,
}
