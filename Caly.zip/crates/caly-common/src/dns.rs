//! DNS resolver contracts and resolution models.

pub use crate::error::DnsError;
use async_trait::async_trait;
use smol_str::SmolStr;
use std::net::IpAddr;

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum ResolveResult {
    RealIp(Vec<IpAddr>),
    FakeIp(IpAddr),
    NoSuchDomain,
}

#[async_trait]
pub trait DnsResolver: Send + Sync {
    async fn resolve(&self, domain: &str) -> Result<ResolveResult, DnsError>;
    fn lookup_fakeip(&self, ip: IpAddr) -> Option<SmolStr>;
    fn snoop(&self, ip: IpAddr, port: u16) -> Option<SmolStr>;
    /// Garbage-collect expired entries from FakeIP and Snooper.
    fn gc(&self) {}
    /// Clear runtime caches (LRU DNS, Snooper), returning number of cleared entries.
    fn clear_cache(&self) -> usize {
        0
    }
}
