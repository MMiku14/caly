//! Sans-IO protocol state machine contract.

use std::error::Error;

pub trait ProtocolStateMachine {
    type Action;
    type Error: Error + Send + Sync + 'static;

    fn on_network_input(&mut self, data: &[u8]) -> Result<(), Self::Error>;
    fn poll_network_output<'a>(&'a mut self, out_buf: &'a mut [u8]) -> Option<usize>;
    fn on_app_input(&mut self, plaintext: &[u8]) -> Result<(), Self::Error>;
    fn poll_app_output<'a>(&'a mut self, out_buf: &'a mut [u8]) -> Option<usize>;
    fn handle_tick(&mut self, now_ms: u64) -> Option<Self::Action>;
}
