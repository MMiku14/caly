//! Compact session metadata with cache-line alignment and zero unnecessary heap allocations.

use smol_str::SmolStr;
use std::net::{IpAddr, Ipv4Addr, SocketAddr};
use std::str::FromStr;

pub const FLAG_NONE: u8 = 0;
pub const FLAG_TLS: u8 = 1 << 0;
pub const FLAG_FAKE_IP: u8 = 1 << 1;
pub const FLAG_UDP_ASSOCIATE: u8 = 1 << 2;
pub const FLAG_AUTHENTICATED: u8 = 1 << 3;
pub const FLAG_WEBSOCKET: u8 = 1 << 4;

/// Domain source attribution tracking
pub const SNIFF_SRC_NONE: u8 = 0;
pub const SNIFF_SRC_SNI: u8 = 1;
pub const SNIFF_SRC_FAKEIP: u8 = 2;
pub const SNIFF_SRC_DNS_SNOOP: u8 = 3;
pub const SNIFF_SRC_HTTP_HOST: u8 = 4;
pub const SNIFF_SRC_USER: u8 = 5;
/// Sentinel matching any sniffed source (excluding NONE and USER)
pub const SNIFF_SRC_ANY: u8 = 0xFF;

#[inline]
pub const fn is_sniffed_source(src: u8) -> bool {
    !matches!(src, SNIFF_SRC_NONE | SNIFF_SRC_USER)
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Default)]
#[repr(u8)]
pub enum Network {
    #[default]
    Tcp = 1,
    Udp = 2,
    Both = 3,
}

impl Network {
    #[inline]
    pub const fn from_u8(val: u8) -> Option<Self> {
        match val {
            1 => Some(Network::Tcp),
            2 => Some(Network::Udp),
            3 => Some(Network::Both),
            _ => None,
        }
    }

    #[inline]
    pub fn matches(&self, other: Network) -> bool {
        if *self == Network::Both || other == Network::Both {
            true
        } else {
            *self == other
        }
    }

    #[inline]
    pub fn is_tcp(&self) -> bool {
        matches!(self, Network::Tcp | Network::Both)
    }

    #[inline]
    pub fn is_udp(&self) -> bool {
        matches!(self, Network::Udp | Network::Both)
    }
}

impl FromStr for Network {
    type Err = ();
    fn from_str(s: &str) -> Result<Self, Self::Err> {
        if s.eq_ignore_ascii_case("tcp") {
            Ok(Network::Tcp)
        } else if s.eq_ignore_ascii_case("udp") {
            Ok(Network::Udp)
        } else if s.eq_ignore_ascii_case("both") || s.eq_ignore_ascii_case("all") {
            Ok(Network::Both)
        } else {
            Err(())
        }
    }
}

impl std::fmt::Display for Network {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Network::Tcp => write!(f, "tcp"),
            Network::Udp => write!(f, "udp"),
            Network::Both => write!(f, "tcp+udp"),
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Default)]
#[repr(u8)]
pub enum SniffedProto {
    #[default]
    Unknown = 0,
    Http = 1,
    Tls = 2,
    Quic = 3,
    BitTorrent = 4,
    Dns = 5,
    Socks5 = 6,
    WebSocket = 7,
}

impl SniffedProto {
    #[inline]
    pub const fn from_u8(val: u8) -> Self {
        match val {
            1 => SniffedProto::Http,
            2 => SniffedProto::Tls,
            3 => SniffedProto::Quic,
            4 => SniffedProto::BitTorrent,
            5 => SniffedProto::Dns,
            6 => SniffedProto::Socks5,
            7 => SniffedProto::WebSocket,
            _ => SniffedProto::Unknown,
        }
    }

    #[inline]
    pub fn is_known(&self) -> bool {
        *self != SniffedProto::Unknown
    }
}

impl std::fmt::Display for SniffedProto {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            SniffedProto::Unknown => write!(f, "unknown"),
            SniffedProto::Http => write!(f, "http"),
            SniffedProto::Tls => write!(f, "tls"),
            SniffedProto::Quic => write!(f, "quic"),
            SniffedProto::BitTorrent => write!(f, "bittorrent"),
            SniffedProto::Dns => write!(f, "dns"),
            SniffedProto::Socks5 => write!(f, "socks5"),
            SniffedProto::WebSocket => write!(f, "websocket"),
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Default)]
pub struct InboundTag(pub u64);

impl InboundTag {
    #[inline]
    pub const fn new(id: u64) -> Self {
        Self(id)
    }

    #[inline]
    pub const fn as_u64(&self) -> u64 {
        self.0
    }
}

impl std::fmt::Display for InboundTag {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "{}", self.0)
    }
}

impl From<u64> for InboundTag {
    #[inline]
    fn from(id: u64) -> Self {
        Self(id)
    }
}

impl std::ops::Deref for InboundTag {
    type Target = u64;
    #[inline]
    fn deref(&self) -> &Self::Target {
        &self.0
    }
}

#[repr(C)]
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct SessionMetadata {
    pub inbound_tag: u64,
    pub user_id: Option<u64>,
    pub pid: Option<u32>,
    pub uid: Option<u32>,
    pub src_addr: SocketAddr,
    pub dst_addr: SocketAddr,
    pub domain: SmolStr,
    pub process: Option<SmolStr>,
    pub alpn: Option<SmolStr>,
    pub network: Network,
    pub protocol: SniffedProto,
    pub l4_proto: u8,
    pub flags: u8,
    pub sniff_source: u8,
    pub _padding: [u8; 3],
    pub _reserved: [u8; 32],
}

impl Default for SessionMetadata {
    fn default() -> Self {
        Self {
            inbound_tag: 0,
            user_id: None,
            pid: None,
            uid: None,
            src_addr: SocketAddr::new(IpAddr::V4(Ipv4Addr::UNSPECIFIED), 0),
            dst_addr: SocketAddr::new(IpAddr::V4(Ipv4Addr::UNSPECIFIED), 0),
            domain: SmolStr::default(),
            process: None,
            alpn: None,
            network: Network::Tcp,
            protocol: SniffedProto::Unknown,
            l4_proto: 6, // TCP default
            flags: FLAG_NONE,
            sniff_source: SNIFF_SRC_NONE,
            _padding: [0; 3],
            _reserved: [0; 32],
        }
    }
}

impl SessionMetadata {
    pub fn new(src_addr: SocketAddr, dst_addr: SocketAddr, network: Network) -> Self {
        let l4_proto = match network {
            Network::Tcp => 6,
            Network::Udp => 17,
            Network::Both => 0,
        };
        Self {
            src_addr,
            dst_addr,
            network,
            l4_proto,
            ..Default::default()
        }
    }

    #[inline]
    pub fn set_domain(&mut self, raw_domain: &str) {
        let trimmed = raw_domain.trim();
        let stripped = trimmed.trim_end_matches('.');
        if stripped.is_empty() {
            self.domain = SmolStr::default();
            return;
        }
        if stripped.bytes().any(|b| b.is_ascii_uppercase()) {
            self.domain = SmolStr::new(stripped.to_ascii_lowercase());
        } else {
            self.domain = SmolStr::new(stripped);
        }
    }

    #[inline]
    pub fn has_domain(&self) -> bool {
        !self.domain.is_empty()
    }

    #[inline]
    pub fn set_process(&mut self, process: &str) {
        self.process = Some(SmolStr::new(process));
    }

    #[inline]
    pub fn set_alpn(&mut self, alpn: &str) {
        self.alpn = Some(SmolStr::new(alpn.to_ascii_lowercase()));
    }

    #[inline]
    pub fn set_flag(&mut self, flag: u8) {
        self.flags |= flag;
    }

    #[inline]
    pub fn clear_flag(&mut self, flag: u8) {
        self.flags &= !flag;
    }

    #[inline]
    pub fn has_flag(&self, flag: u8) -> bool {
        (self.flags & flag) != 0
    }

    #[inline]
    pub fn set_domain_with_source(&mut self, raw_domain: &str, source: u8) {
        self.set_domain(raw_domain);
        self.sniff_source = source;
    }

    #[inline]
    pub fn is_sniffed_domain(&self) -> bool {
        matches!(self.sniff_source, SNIFF_SRC_SNI | SNIFF_SRC_HTTP_HOST)
    }

    #[inline]
    pub fn is_fakeip_domain(&self) -> bool {
        self.sniff_source == SNIFF_SRC_FAKEIP
    }
}

const _: () = assert!(
    std::mem::size_of::<SessionMetadata>() <= 224,
    "SessionMetadata exceeds 224 bytes; consider reducing _reserved"
);
const _: () = assert!(std::mem::align_of::<SessionMetadata>() >= 8);

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_network_from_u8() {
        assert_eq!(Network::from_u8(1), Some(Network::Tcp));
        assert_eq!(Network::from_u8(2), Some(Network::Udp));
        assert_eq!(Network::from_u8(3), Some(Network::Both));
        assert_eq!(Network::from_u8(0), None);
        assert_eq!(Network::from_u8(4), None);
    }

    #[test]
    fn test_network_matches() {
        assert!(Network::Tcp.matches(Network::Tcp));
        assert!(!Network::Tcp.matches(Network::Udp));
        assert!(Network::Both.matches(Network::Tcp));
        assert!(Network::Tcp.matches(Network::Both));
    }

    #[test]
    fn test_set_domain_strips_trailing_dot() {
        let mut m = SessionMetadata::default();
        m.set_domain("example.com.");
        assert_eq!(m.domain.as_str(), "example.com");
    }

    #[test]
    fn test_set_domain_lowercases() {
        let mut m = SessionMetadata::default();
        m.set_domain("Example.COM");
        assert_eq!(m.domain.as_str(), "example.com");
    }

    #[test]
    fn test_set_domain_empty() {
        let mut m = SessionMetadata::default();
        m.set_domain("");
        assert!(!m.has_domain());
        m.set_domain("...");
        assert!(!m.has_domain());
    }

    #[test]
    fn test_sniff_source_helpers() {
        let mut m = SessionMetadata::default();
        assert!(!m.is_sniffed_domain());
        assert!(!m.is_fakeip_domain());
        m.set_domain_with_source("example.com", SNIFF_SRC_SNI);
        assert!(m.is_sniffed_domain());
        assert!(!m.is_fakeip_domain());
    }
}
