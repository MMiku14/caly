//! Core primitives, contracts, and zero-allocation metadata for Caly.

pub mod adapter;
pub mod dns;
pub mod error;
pub mod metadata;
pub mod protocol;
pub mod transport;

pub use adapter::InboundListener;
pub use dns::{DnsError, DnsResolver, ResolveResult};
pub use error::{CalyError, ProxyError, Socks5Error, TransportError};
pub use metadata::{
    is_sniffed_source, InboundTag, Network, SessionMetadata, SniffedProto, FLAG_AUTHENTICATED,
    FLAG_FAKE_IP, FLAG_NONE, FLAG_TLS, FLAG_UDP_ASSOCIATE, FLAG_WEBSOCKET, SNIFF_SRC_ANY,
    SNIFF_SRC_DNS_SNOOP, SNIFF_SRC_FAKEIP, SNIFF_SRC_HTTP_HOST, SNIFF_SRC_NONE, SNIFF_SRC_SNI,
    SNIFF_SRC_USER,
};
pub use protocol::ProtocolStateMachine;
pub use transport::{StreamType, TransportStream};
