//! Static-dispatch transport abstractions and concrete stream representations.

use std::net::SocketAddr;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum StreamType {
    Tcp,
    Tls,
    Ws,
    TlsWs,
    H2,
    TlsH2,
    AnyTls,
}

impl std::fmt::Display for StreamType {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            StreamType::Tcp => write!(f, "tcp"),
            StreamType::Tls => write!(f, "tls"),
            StreamType::Ws => write!(f, "ws"),
            StreamType::TlsWs => write!(f, "tls_ws"),
            StreamType::H2 => write!(f, "h2"),
            StreamType::TlsH2 => write!(f, "tls_h2"),
            StreamType::AnyTls => write!(f, "anytls"),
        }
    }
}

pub trait TransportStream: Send + Unpin {
    fn stream_type(&self) -> StreamType;
    fn peer_addr(&self) -> Option<SocketAddr>;
}
