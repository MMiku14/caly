//! Block outbound adapter: always rejects.

use crate::adapter::ProxyAdapter;
use async_trait::async_trait;
use caly_common::error::ProxyError;
use caly_common::metadata::SessionMetadata;
use caly_transport::ConcreteStream;

pub struct BlockAdapter {
    tag: String,
}

impl Default for BlockAdapter {
    fn default() -> Self {
        Self::new("block")
    }
}

impl BlockAdapter {
    pub fn new(tag: &str) -> Self {
        Self {
            tag: tag.to_string(),
        }
    }
}

#[async_trait]
impl ProxyAdapter for BlockAdapter {
    fn name(&self) -> &str {
        &self.tag
    }
    fn adapter_type(&self) -> &str {
        "block"
    }
    async fn dial(&self, _metadata: &SessionMetadata) -> Result<ConcreteStream, ProxyError> {
        Err(ProxyError::Blocked)
    }
}
