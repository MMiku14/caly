//! Failure tracking and circuit-breaker cooldown management.

use parking_lot::Mutex;
use std::collections::HashMap;
use std::time::{Duration, Instant};

pub const DEFAULT_FAILURE_COOLDOWN: Duration = Duration::from_secs(30);
const CLEANUP_THRESHOLD: usize = 32;

#[derive(Debug)]
pub struct FailoverState {
    cooldown: Duration,
    failed_until: Mutex<HashMap<String, Instant>>,
}

impl Default for FailoverState {
    fn default() -> Self {
        Self::new(DEFAULT_FAILURE_COOLDOWN)
    }
}

impl FailoverState {
    pub fn new(cooldown: Duration) -> Self {
        Self {
            cooldown,
            failed_until: Mutex::new(HashMap::new()),
        }
    }

    pub fn mark_failed(&self, name: &str) {
        let now = Instant::now();
        let mut m = self.failed_until.lock();
        m.insert(name.to_string(), now + self.cooldown);
        if m.len() > CLEANUP_THRESHOLD {
            m.retain(|_, t| now < *t);
        }
    }

    pub fn clear_failed(&self, name: &str) {
        self.failed_until.lock().remove(name);
    }

    pub fn is_in_cooldown(&self, name: &str) -> bool {
        let now = Instant::now();
        self.failed_until
            .lock()
            .get(name)
            .is_some_and(|t| now < *t)
    }

    pub fn reset(&self) -> usize {
        let mut m = self.failed_until.lock();
        let n = m.len();
        m.clear();
        n
    }

    pub fn snapshot(&self) -> Vec<(String, u64)> {
        let now = Instant::now();
        let m = self.failed_until.lock();
        let mut out: Vec<(String, u64)> = m
            .iter()
            .filter_map(|(name, t)| {
                if now < *t {
                    Some((name.clone(), t.duration_since(now).as_secs()))
                } else {
                    None
                }
            })
            .collect();
        out.sort_by(|a, b| a.0.cmp(&b.0));
        out
    }

    pub fn active_count(&self) -> usize {
        let now = Instant::now();
        self.failed_until
            .lock()
            .values()
            .filter(|t| now < **t)
            .count()
    }
}
