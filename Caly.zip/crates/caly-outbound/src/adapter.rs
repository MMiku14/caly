//! Outbound proxy adapter contract with async dial.

use async_trait::async_trait;
use caly_common::error::ProxyError;
use caly_common::metadata::SessionMetadata;
use caly_transport::ConcreteStream;

#[async_trait]
pub trait ProxyAdapter: Send + Sync {
    fn name(&self) -> &str;
    fn adapter_type(&self) -> &str;
    async fn dial(&self, metadata: &SessionMetadata) -> Result<ConcreteStream, ProxyError>;
    fn supports_udp(&self) -> bool {
        false
    }
    fn try_select(&self, _candidate: &str) -> Result<(), String> {
        Err(format!(
            "adapter '{}' (type '{}') does not support runtime select",
            self.name(),
            self.adapter_type()
        ))
    }
    fn candidates(&self) -> Option<Vec<String>> {
        None
    }
    fn current_selection(&self) -> Option<String> {
        None
    }
    fn latency_snapshot(&self) -> Vec<(String, u32)> {
        Vec::new()
    }
    fn cooldown_snapshot(&self) -> Vec<(String, u64)> {
        Vec::new()
    }
    fn reset_failures(&self) -> usize {
        0
    }
    fn on_state_changed(&self) {}
}
