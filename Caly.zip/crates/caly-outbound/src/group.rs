//! Outbound groups: Selector / URLTest / Fallback with real candidate adapters.

use crate::adapter::ProxyAdapter;
use crate::failover::FailoverState;
use async_trait::async_trait;
use caly_common::error::ProxyError;
use caly_common::metadata::SessionMetadata;
use caly_transport::ConcreteStream;
use parking_lot::{Mutex, RwLock};
use std::sync::atomic::{AtomicUsize, Ordering};
use std::sync::Arc;

pub type SelectorChangeCallback = Arc<dyn Fn(&str, &str) + Send + Sync>;
type SelectorChangeSlot = Option<SelectorChangeCallback>;

pub struct SelectorAdapter {
    tag: String,
    candidates: Vec<Arc<dyn ProxyAdapter>>,
    selected_index: AtomicUsize,
    on_change: Mutex<SelectorChangeSlot>,
    failover: FailoverState,
}

impl SelectorAdapter {
    pub fn new(tag: &str, candidates: Vec<Arc<dyn ProxyAdapter>>) -> Self {
        Self {
            tag: tag.to_string(),
            candidates,
            selected_index: AtomicUsize::new(0),
            on_change: Mutex::new(None),
            failover: FailoverState::default(),
        }
    }

    pub fn set_on_change<F>(&self, f: F)
    where
        F: Fn(&str, &str) + Send + Sync + 'static,
    {
        *self.on_change.lock() = Some(Arc::new(f));
    }

    pub fn restore_selection(&self, name: &str) -> bool {
        if let Some(pos) = self.candidates.iter().position(|c| c.name() == name) {
            self.selected_index.store(pos, Ordering::Release);
            true
        } else {
            false
        }
    }

    pub fn select(&self, name: &str) -> bool {
        if let Some(pos) = self.candidates.iter().position(|c| c.name() == name) {
            self.selected_index.store(pos, Ordering::Release);
            self.clear_failed(name);
            self.fire_on_change(name);
            true
        } else {
            false
        }
    }

    pub fn current(&self) -> Option<&str> {
        if self.candidates.is_empty() {
            return None;
        }
        let idx = self.selected_index.load(Ordering::Acquire) % self.candidates.len();
        self.candidates.get(idx).map(|c| c.name())
    }

    pub fn mark_failed(&self, name: &str) {
        self.failover.mark_failed(name);
    }

    pub fn clear_failed(&self, name: &str) {
        self.failover.clear_failed(name);
    }

    pub fn is_in_cooldown(&self, name: &str) -> bool {
        self.failover.is_in_cooldown(name)
    }

    pub fn cooldown_snapshot_inner(&self) -> Vec<(String, u64)> {
        self.failover.snapshot()
    }

    fn fire_on_change(&self, name: &str) {
        let cb = self.on_change.lock().clone();
        if let Some(cb) = cb {
            cb(&self.tag, name);
        }
    }
}

#[async_trait]
impl ProxyAdapter for SelectorAdapter {
    fn name(&self) -> &str {
        &self.tag
    }

    fn adapter_type(&self) -> &str {
        "selector"
    }

    fn supports_udp(&self) -> bool {
        self.candidates.iter().any(|c| c.supports_udp())
    }

    async fn dial(&self, metadata: &SessionMetadata) -> Result<ConcreteStream, ProxyError> {
        let n = self.candidates.len();
        if n == 0 {
            return Err(ProxyError::NotFound(format!(
                "selector '{}' has no candidates",
                self.tag
            )));
        }
        let start = self.selected_index.load(Ordering::Acquire) % n;
        let mut last_err: Option<ProxyError> = None;

        for offset in 0..n {
            let idx = (start + offset) % n;
            let candidate = &self.candidates[idx];
            let name = candidate.name().to_string();

            if offset > 0 && self.is_in_cooldown(&name) {
                tracing::debug!(
                    selector = %self.tag,
                    candidate = %name,
                    "skip candidate in cooldown"
                );
                continue;
            }

            match candidate.dial(metadata).await {
                Ok(s) => {
                    self.clear_failed(&name);
                    if offset > 0 {
                        tracing::info!(
                            selector = %self.tag,
                            failover_offset = offset,
                            temp_selected = %name,
                            "selector failover (temporary)"
                        );
                    }
                    return Ok(s);
                }
                Err(e) => {
                    tracing::debug!(
                        selector = %self.tag,
                        candidate = %name,
                        error = %e,
                        "candidate dial failed"
                    );
                    self.mark_failed(&name);
                    last_err = Some(e);
                }
            }
        }

        if last_err.is_none() && n > 0 {
            let fallback_candidate = &self.candidates[start];
            tracing::warn!(
                selector = %self.tag,
                candidate = %fallback_candidate.name(),
                "all candidates in cooldown; fallback to current selection"
            );
            return fallback_candidate.dial(metadata).await;
        }

        Err(last_err.unwrap_or_else(|| {
            ProxyError::NotFound(format!("selector '{}' exhausted all candidates", self.tag))
        }))
    }

    fn try_select(&self, candidate: &str) -> Result<(), String> {
        if self.select(candidate) {
            Ok(())
        } else {
            Err(format!(
                "candidate '{}' not found in selector '{}'",
                candidate, self.tag
            ))
        }
    }

    fn candidates(&self) -> Option<Vec<String>> {
        Some(self.candidates.iter().map(|c| c.name().to_string()).collect())
    }

    fn current_selection(&self) -> Option<String> {
        self.current().map(|s| s.to_string())
    }

    fn cooldown_snapshot(&self) -> Vec<(String, u64)> {
        self.cooldown_snapshot_inner()
    }

    fn reset_failures(&self) -> usize {
        self.failover.reset()
    }
}

pub struct UrlTestAdapter {
    tag: String,
    candidates: Vec<Arc<dyn ProxyAdapter>>,
    latencies_ms: RwLock<Vec<(String, u32)>>,
    best_index: AtomicUsize,
    failover: FailoverState,
}

impl UrlTestAdapter {
    pub fn new(tag: &str, candidates: Vec<Arc<dyn ProxyAdapter>>) -> Self {
        let lats: Vec<(String, u32)> = candidates
            .iter()
            .map(|c| (c.name().to_string(), 0u32))
            .collect();
        Self {
            tag: tag.to_string(),
            candidates,
            latencies_ms: RwLock::new(lats),
            best_index: AtomicUsize::new(0),
            failover: FailoverState::default(),
        }
    }

    pub fn record_latency(&self, candidate: &str, latency_ms: u32) {
        if latency_ms == 0 {
            self.failover.mark_failed(candidate);
        } else {
            self.failover.clear_failed(candidate);
        }

        let mut lats = self.latencies_ms.write();
        if let Some(entry) = lats.iter_mut().find(|(name, _)| name == candidate) {
            entry.1 = latency_ms;
        }

        let mut best: Option<(usize, u32)> = None;
        for (name, lat) in lats.iter() {
            if *lat == 0 || self.failover.is_in_cooldown(name) {
                continue;
            }
            if let Some(pos) = self.candidates.iter().position(|c| c.name() == name) {
                match best {
                    None => best = Some((pos, *lat)),
                    Some((_, cur_best)) if *lat < cur_best => best = Some((pos, *lat)),
                    _ => {}
                }
            }
        }
        drop(lats);

        if let Some((pos, _)) = best {
            self.best_index.store(pos, Ordering::Release);
        }
    }

    pub fn current(&self) -> Option<&str> {
        if self.candidates.is_empty() {
            return None;
        }
        let idx = self.best_index.load(Ordering::Acquire) % self.candidates.len();
        self.candidates.get(idx).map(|c| c.name())
    }

    pub fn latency_snapshot_inner(&self) -> Vec<(String, u32)> {
        self.latencies_ms.read().clone()
    }

    pub fn candidates_inner(&self) -> &[Arc<dyn ProxyAdapter>] {
        &self.candidates
    }

    pub fn mark_failed(&self, name: &str) {
        self.failover.mark_failed(name);
    }

    pub fn clear_failed(&self, name: &str) {
        self.failover.clear_failed(name);
    }

    pub fn is_in_cooldown(&self, name: &str) -> bool {
        self.failover.is_in_cooldown(name)
    }

    pub fn cooldown_snapshot_inner(&self) -> Vec<(String, u64)> {
        self.failover.snapshot()
    }
}

#[async_trait]
impl ProxyAdapter for UrlTestAdapter {
    fn name(&self) -> &str {
        &self.tag
    }

    fn adapter_type(&self) -> &str {
        "urltest"
    }

    fn supports_udp(&self) -> bool {
        self.candidates.iter().any(|c| c.supports_udp())
    }

    async fn dial(&self, metadata: &SessionMetadata) -> Result<ConcreteStream, ProxyError> {
        let n = self.candidates.len();
        if n == 0 {
            return Err(ProxyError::NotFound(format!(
                "urltest '{}' has no candidates",
                self.tag
            )));
        }
        let start = self.best_index.load(Ordering::Acquire) % n;
        let mut last_err: Option<ProxyError> = None;

        for offset in 0..n {
            let idx = (start + offset) % n;
            let candidate = &self.candidates[idx];
            let name = candidate.name().to_string();

            if offset > 0 && self.is_in_cooldown(&name) {
                tracing::debug!(
                    urltest = %self.tag,
                    candidate = %name,
                    "skip candidate in cooldown"
                );
                continue;
            }

            match candidate.dial(metadata).await {
                Ok(s) => {
                    self.clear_failed(&name);
                    if offset > 0 {
                        self.best_index.store(idx, Ordering::Release);
                        tracing::info!(
                            urltest = %self.tag,
                            failover_offset = offset,
                            new_best = %name,
                            "urltest failover"
                        );
                    }
                    return Ok(s);
                }
                Err(e) => {
                    tracing::debug!(
                        urltest = %self.tag,
                        candidate = %name,
                        error = %e,
                        "urltest candidate dial failed"
                    );
                    self.mark_failed(&name);
                    last_err = Some(e);
                }
            }
        }

        if last_err.is_none() && n > 0 {
            let fallback_candidate = &self.candidates[start];
            tracing::warn!(
                urltest = %self.tag,
                candidate = %fallback_candidate.name(),
                "all candidates in cooldown; fallback to best selection"
            );
            return fallback_candidate.dial(metadata).await;
        }

        Err(last_err.unwrap_or_else(|| {
            ProxyError::NotFound(format!("urltest '{}' exhausted all candidates", self.tag))
        }))
    }

    fn candidates(&self) -> Option<Vec<String>> {
        Some(self.candidates.iter().map(|c| c.name().to_string()).collect())
    }

    fn try_select(&self, candidate: &str) -> Result<(), String> {
        if let Some(pos) = self.candidates.iter().position(|c| c.name() == candidate) {
            self.best_index.store(pos, Ordering::Release);
            Ok(())
        } else {
            Err(format!("candidate '{}' not in urltest '{}'", candidate, self.tag))
        }
    }

    fn current_selection(&self) -> Option<String> {
        self.current().map(|s| s.to_string())
    }

    fn latency_snapshot(&self) -> Vec<(String, u32)> {
        self.latency_snapshot_inner()
    }

    fn cooldown_snapshot(&self) -> Vec<(String, u64)> {
        self.cooldown_snapshot_inner()
    }

    fn reset_failures(&self) -> usize {
        self.failover.reset()
    }
}

pub struct FallbackAdapter {
    tag: String,
    candidates: Vec<Arc<dyn ProxyAdapter>>,
    active_index: AtomicUsize,
    failover: FailoverState,
}

impl FallbackAdapter {
    pub fn new(tag: &str, candidates: Vec<Arc<dyn ProxyAdapter>>) -> Self {
        Self {
            tag: tag.to_string(),
            candidates,
            active_index: AtomicUsize::new(0),
            failover: FailoverState::default(),
        }
    }
}

#[async_trait]
impl ProxyAdapter for FallbackAdapter {
    fn name(&self) -> &str {
        &self.tag
    }

    fn adapter_type(&self) -> &str {
        "fallback"
    }

    fn supports_udp(&self) -> bool {
        self.candidates.iter().any(|c| c.supports_udp())
    }

    async fn dial(&self, metadata: &SessionMetadata) -> Result<ConcreteStream, ProxyError> {
        let n = self.candidates.len();
        if n == 0 {
            return Err(ProxyError::NotFound(format!(
                "fallback '{}' has no candidates",
                self.tag
            )));
        }

        let mut last_err: Option<ProxyError> = None;
        for (idx, candidate) in self.candidates.iter().enumerate() {
            let name = candidate.name().to_string();
            if self.failover.is_in_cooldown(&name) {
                continue;
            }
            match candidate.dial(metadata).await {
                Ok(s) => {
                    self.failover.clear_failed(&name);
                    self.active_index.store(idx, Ordering::Release);
                    return Ok(s);
                }
                Err(e) => {
                    self.failover.mark_failed(&name);
                    last_err = Some(e);
                }
            }
        }

        if let Some(candidate) = self.candidates.first() {
            return candidate.dial(metadata).await;
        }

        Err(last_err.unwrap_or_else(|| {
            ProxyError::NotFound(format!("fallback '{}' exhausted all candidates", self.tag))
        }))
    }

    fn candidates(&self) -> Option<Vec<String>> {
        Some(self.candidates.iter().map(|c| c.name().to_string()).collect())
    }

    fn current_selection(&self) -> Option<String> {
        let idx = self.active_index.load(Ordering::Acquire);
        self.candidates.get(idx).map(|c| c.name().to_string())
    }
}
