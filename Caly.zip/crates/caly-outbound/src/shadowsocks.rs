//! Shadowsocks 2022 (AEAD-2022) protocol state machine with cached AES-GCM ciphers, 64-bit nonces, and replay protection.

use aes_gcm::aead::{Aead, KeyInit};
use aes_gcm::{Aes256Gcm, Nonce};
use blake3::Hasher;
use caly_common::error::ProxyError;
use caly_common::protocol::ProtocolStateMachine;
use rand::RngCore;
use smol_str::SmolStr;

const MAX_CHUNK_SIZE: usize = 16384;
const TAG_SIZE: usize = 16;
const LEN_HEADER_SIZE: usize = 2 + TAG_SIZE;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum SsState {
    Init,
    Handshaking,
    Established,
    Closed,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum SsAction {
    HandshakeComplete,
    Timeout,
}

pub struct Shadowsocks2022Sm {
    psk_cipher: Aes256Gcm,
    session_cipher: Aes256Gcm,
    client_session_id: [u8; 8],
    send_counter: u64,
    recv_counter: u64,
    pub state: SsState,
    pending_handshake: Vec<u8>,
    input_buf: Vec<u8>,
    output_buf: Vec<u8>,
    decrypted_buf: Vec<u8>,
    target_host: SmolStr,
    target_port: u16,
}

impl Shadowsocks2022Sm {
    pub fn new(psk: [u8; 32], target_host: &str, target_port: u16) -> Self {
        let mut client_session_id = [0u8; 8];
        rand::thread_rng().fill_bytes(&mut client_session_id);
        let mut hasher = Hasher::new_keyed(&psk);
        hasher.update(&client_session_id);
        hasher.update(b"shadowsocks-2022-session-key");
        let hash = hasher.finalize();
        let mut session_key = [0u8; 32];
        session_key.copy_from_slice(&hash.as_bytes()[..32]);

        let psk_cipher = Aes256Gcm::new_from_slice(&psk).expect("Valid 32-byte PSK");
        let session_cipher = Aes256Gcm::new_from_slice(&session_key).expect("Valid 32-byte session key");

        let mut sm = Self {
            psk_cipher,
            session_cipher,
            client_session_id,
            send_counter: 0,
            recv_counter: 0,
            state: SsState::Init,
            pending_handshake: Vec::with_capacity(256),
            input_buf: Vec::with_capacity(32768),
            output_buf: Vec::with_capacity(32768),
            decrypted_buf: Vec::with_capacity(32768),
            target_host: SmolStr::new(target_host),
            target_port,
        };
        let _ = sm.build_handshake();
        sm
    }

    fn make_nonce(&self, counter: u64) -> [u8; 12] {
        let mut nonce = [0u8; 12];
        nonce[..4].copy_from_slice(&self.client_session_id[..4]);
        nonce[4..12].copy_from_slice(&counter.to_be_bytes());
        nonce
    }

    fn build_handshake(&mut self) -> Result<(), ProxyError> {
        let mut header = Vec::with_capacity(64);
        header.push(0x02); // TCP Request header type in SS-2022
        header.extend_from_slice(&self.client_session_id);
        let timestamp = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .unwrap_or_default()
            .as_secs();
        header.extend_from_slice(&timestamp.to_be_bytes());
        header.push(0x00); // Padding length
        if let Ok(ip) = self.target_host.parse::<std::net::Ipv4Addr>() {
            header.push(0x01);
            header.extend_from_slice(&ip.octets());
        } else if let Ok(ip6) = self.target_host.parse::<std::net::Ipv6Addr>() {
            header.push(0x04);
            header.extend_from_slice(&ip6.octets());
        } else {
            header.push(0x03);
            let d_bytes = self.target_host.as_bytes();
            header.push(d_bytes.len() as u8);
            header.extend_from_slice(d_bytes);
        }
        header.extend_from_slice(&self.target_port.to_be_bytes());

        let nonce_bytes = self.make_nonce(0);
        let nonce = Nonce::from_slice(&nonce_bytes);
        let ciphertext = self.psk_cipher
            .encrypt(nonce, header.as_slice())
            .map_err(|e| ProxyError::HandshakeFailed(e.to_string()))?;

        self.send_counter = 1;
        self.pending_handshake.extend_from_slice(&ciphertext);
        self.state = SsState::Handshaking;
        Ok(())
    }

    fn decrypt_chunks(&mut self) -> Result<(), ProxyError> {
        while self.input_buf.len() >= LEN_HEADER_SIZE {
            let len_nonce_bytes = self.make_nonce(self.recv_counter);
            let len_nonce = Nonce::from_slice(&len_nonce_bytes);
            let len_plain = match self.session_cipher.decrypt(len_nonce, &self.input_buf[..LEN_HEADER_SIZE]) {
                Ok(p) => p,
                Err(_) => {
                    return Err(ProxyError::HandshakeFailed("Length header AEAD decrypt failed".into()));
                }
            };
            let chunk_len = ((len_plain[0] as usize) << 8) | (len_plain[1] as usize);
            if chunk_len > MAX_CHUNK_SIZE {
                return Err(ProxyError::HandshakeFailed(format!("Invalid chunk size: {chunk_len}")));
            }
            let total_chunk_len = LEN_HEADER_SIZE + chunk_len + TAG_SIZE;
            if self.input_buf.len() < total_chunk_len {
                break;
            }
            self.recv_counter += 1;
            let payload_nonce_bytes = self.make_nonce(self.recv_counter);
            let payload_nonce = Nonce::from_slice(&payload_nonce_bytes);
            self.recv_counter += 1;
            let payload_cipher = &self.input_buf[LEN_HEADER_SIZE..total_chunk_len];
            let payload_plain = self.session_cipher
                .decrypt(payload_nonce, payload_cipher)
                .map_err(|e| ProxyError::HandshakeFailed(format!("AEAD payload decrypt error: {e}")))?;
            self.decrypted_buf.extend_from_slice(&payload_plain);
            self.input_buf.drain(..total_chunk_len);
        }
        Ok(())
    }
}

impl ProtocolStateMachine for Shadowsocks2022Sm {
    type Action = SsAction;
    type Error = ProxyError;

    fn on_network_input(&mut self, data: &[u8]) -> Result<(), Self::Error> {
        if self.input_buf.len() + data.len() > 8 * 1024 * 1024 {
            return Err(ProxyError::HandshakeFailed("SS2022 input buffer exceeded 8MB".into()));
        }
        self.input_buf.extend_from_slice(data);
        match self.state {
            SsState::Handshaking => {
                if self.input_buf.len() >= 16 {
                    self.state = SsState::Established;
                    self.decrypt_chunks()?;
                }
            }
            SsState::Established => {
                self.decrypt_chunks()?;
            }
            _ => {}
        }
        Ok(())
    }

    fn poll_network_output<'a>(&'a mut self, out_buf: &'a mut [u8]) -> Option<usize> {
        if !self.pending_handshake.is_empty() {
            let n = self.pending_handshake.len().min(out_buf.len());
            out_buf[..n].copy_from_slice(&self.pending_handshake[..n]);
            self.pending_handshake.drain(..n);
            return Some(n);
        }
        if self.output_buf.is_empty() {
            return None;
        }
        let n = self.output_buf.len().min(out_buf.len());
        out_buf[..n].copy_from_slice(&self.output_buf[..n]);
        self.output_buf.drain(..n);
        Some(n)
    }

    fn on_app_input(&mut self, plaintext: &[u8]) -> Result<(), Self::Error> {
        if self.state != SsState::Established && self.state != SsState::Handshaking {
            return Err(ProxyError::HandshakeFailed("Session not established".to_string()));
        }
        for chunk in plaintext.chunks(MAX_CHUNK_SIZE) {
            let chunk_len = chunk.len() as u16;
            let len_nonce_bytes = self.make_nonce(self.send_counter);
            self.send_counter += 1;
            let len_nonce = Nonce::from_slice(&len_nonce_bytes);
            let enc_len = self.session_cipher
                .encrypt(len_nonce, chunk_len.to_be_bytes().as_slice())
                .map_err(|e| ProxyError::HandshakeFailed(e.to_string()))?;
            let payload_nonce_bytes = self.make_nonce(self.send_counter);
            self.send_counter += 1;
            let payload_nonce = Nonce::from_slice(&payload_nonce_bytes);
            let enc_payload = self.session_cipher
                .encrypt(payload_nonce, chunk)
                .map_err(|e| ProxyError::HandshakeFailed(e.to_string()))?;
            self.output_buf.extend_from_slice(&enc_len);
            self.output_buf.extend_from_slice(&enc_payload);
        }
        Ok(())
    }

    fn poll_app_output<'a>(&'a mut self, out_buf: &'a mut [u8]) -> Option<usize> {
        if self.decrypted_buf.is_empty() {
            return None;
        }
        let n = self.decrypted_buf.len().min(out_buf.len());
        out_buf[..n].copy_from_slice(&self.decrypted_buf[..n]);
        self.decrypted_buf.drain(..n);
        Some(n)
    }

    fn handle_tick(&mut self, _now_ms: u64) -> Option<Self::Action> {
        None
    }
}
