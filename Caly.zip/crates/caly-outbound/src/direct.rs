//! Direct outbound adapter: raw TCP connect with TCP_NODELAY.

use crate::adapter::ProxyAdapter;
use async_trait::async_trait;
use caly_common::error::ProxyError;
use caly_common::metadata::SessionMetadata;
use caly_transport::ConcreteStream;
use tokio::net::TcpStream;

pub struct DirectAdapter {
    tag: String,
}

impl Default for DirectAdapter {
    fn default() -> Self {
        Self::new("direct")
    }
}

impl DirectAdapter {
    pub fn new(tag: &str) -> Self {
        Self {
            tag: tag.to_string(),
        }
    }
}

#[async_trait]
impl ProxyAdapter for DirectAdapter {
    fn name(&self) -> &str {
        &self.tag
    }
    fn adapter_type(&self) -> &str {
        "direct"
    }
    fn supports_udp(&self) -> bool {
        true
    }
    async fn dial(&self, metadata: &SessionMetadata) -> Result<ConcreteStream, ProxyError> {
        let addr = if metadata.dst_addr.ip().is_unspecified() && metadata.has_domain() {
            let host = metadata.domain.as_str();
            let port = metadata.dst_addr.port();

            // 系统 DNS 解析加超时：
            //
            // `tokio::net::lookup_host` 内部走 `getaddrinfo`，
            // 在 DNS 服务器故障 / 网络分区时**可能无限期挂起**
            //（受 libc resolv.conf 的 `timeout` / `attempts` 配置影响，
            //  默认行为可能达到 30+ 秒）。这会让整个会话被卡住。
            //
            // 5 秒是保守上限。正常 DNS 场景下 < 100ms。
            // 超时后返回 ConnectionFailed，交给上层映射为 SOCKS5/HTTP 错误。
            const DNS_LOOKUP_TIMEOUT: std::time::Duration =
                std::time::Duration::from_secs(5);

            let lookup = tokio::time::timeout(
                DNS_LOOKUP_TIMEOUT,
                tokio::net::lookup_host((host, port)),
            )
            .await;

            match lookup {
                Ok(Ok(mut iter)) => iter.next().ok_or_else(|| {
                    ProxyError::ConnectionFailed(format!(
                        "direct DNS resolved 0 addrs for {host}"
                    ))
                })?,
                Ok(Err(e)) => {
                    return Err(ProxyError::ConnectionFailed(format!(
                        "direct DNS lookup {host}: {e}"
                    )));
                }
                Err(_) => {
                    return Err(ProxyError::ConnectionFailed(format!(
                        "direct DNS lookup {host} timed out after 5s"
                    )));
                }
            }
        } else {
            metadata.dst_addr
        };

        // TCP 连接也加超时：某些网络路径下 SYN 可能长时间无响应。
        // 10 秒上限允许跨洲链路（正常 < 500ms）完成握手。
        const CONNECT_TIMEOUT: std::time::Duration =
            std::time::Duration::from_secs(10);

        let tcp = tokio::time::timeout(CONNECT_TIMEOUT, TcpStream::connect(addr))
            .await
            .map_err(|_| {
                ProxyError::ConnectionFailed(format!(
                    "TCP connect to {addr} timed out after 10s"
                ))
            })?
            .map_err(|e| ProxyError::ConnectionFailed(e.to_string()))?;

        let _ = tcp.set_nodelay(true);
        Ok(ConcreteStream::Tcp(tcp))
    }
}
