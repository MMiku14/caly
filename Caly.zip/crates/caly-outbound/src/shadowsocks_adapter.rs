//! Shadowsocks 2022 outbound adapter with TLS SNI and flexible PSK decoding.

use crate::adapter::ProxyAdapter;
use crate::shadowsocks::Shadowsocks2022Sm;
use async_trait::async_trait;
use base64::Engine;
use caly_common::error::ProxyError;
use caly_common::metadata::SessionMetadata;
use caly_transport::tls::TlsConnectorLayer;
use caly_transport::{wrap_sans_io, ConcreteStream};
use std::net::SocketAddr;
use tokio::net::TcpStream;

#[derive(Debug, Clone, Default)]
pub struct SsTlsConfig {
    pub enabled: bool,
    pub server_name: Option<String>,
    pub skip_verify: bool,
}

pub struct ShadowsocksAdapter {
    tag: String,
    server: SocketAddr,
    psk: [u8; 32],
    tls: SsTlsConfig,
    tls_layer: Option<TlsConnectorLayer>,
}

impl ShadowsocksAdapter {
    pub fn new(
        tag: &str,
        server: SocketAddr,
        psk: [u8; 32],
        tls: SsTlsConfig,
    ) -> Result<Self, String> {
        let tls_layer = if tls.enabled {
            Some(
                TlsConnectorLayer::new_with_options(tls.skip_verify)
                    .map_err(|e| format!("TLS layer init failed: {e}"))?,
            )
        } else {
            None
        };
        if tls.enabled && tls.skip_verify {
            tracing::warn!(
                tag,
                "SS TLS skip_verify is enabled; certificate validation disabled"
            );
        }
        Ok(Self {
            tag: tag.to_string(),
            server,
            psk,
            tls,
            tls_layer,
        })
    }

    pub fn decode_psk(raw: &str) -> Result<[u8; 32], String> {
        let trimmed = raw.trim();
        let engines = [
            &base64::engine::general_purpose::STANDARD,
            &base64::engine::general_purpose::STANDARD_NO_PAD,
            &base64::engine::general_purpose::URL_SAFE,
            &base64::engine::general_purpose::URL_SAFE_NO_PAD,
        ];
        for eng in engines {
            if let Ok(bytes) = eng.decode(trimmed) {
                if bytes.len() == 32 {
                    let mut key = [0u8; 32];
                    key.copy_from_slice(&bytes);
                    return Ok(key);
                }
            }
        }
        if trimmed.len() == 64 && trimmed.chars().all(|c| c.is_ascii_hexdigit()) {
            let mut key = [0u8; 32];
            for i in 0..32 {
                let byte = u8::from_str_radix(&trimmed[i * 2..i * 2 + 2], 16)
                    .map_err(|e| format!("hex decode error: {e}"))?;
                key[i] = byte;
            }
            return Ok(key);
        }
        Err(format!(
            "invalid SS2022 PSK: expected base64(32B) or 64-char hex, got {} chars",
            trimmed.len()
        ))
    }

    fn target_host(metadata: &SessionMetadata) -> String {
        if metadata.has_domain() {
            metadata.domain.as_str().to_string()
        } else {
            metadata.dst_addr.ip().to_string()
        }
    }
}

#[async_trait]
impl ProxyAdapter for ShadowsocksAdapter {
    fn name(&self) -> &str {
        &self.tag
    }

    fn adapter_type(&self) -> &str {
        "shadowsocks"
    }

    async fn dial(&self, metadata: &SessionMetadata) -> Result<ConcreteStream, ProxyError> {
        let tcp = TcpStream::connect(self.server)
            .await
            .map_err(|e| ProxyError::ConnectionFailed(format!("SS server connect: {e}")))?;
        let _ = tcp.set_nodelay(true);
        let host = Self::target_host(metadata);
        let port = metadata.dst_addr.port();

        if self.tls.enabled {
            let layer = self
                .tls_layer
                .as_ref()
                .ok_or_else(|| ProxyError::ConnectionFailed("TLS layer not initialized".into()))?;
            let sni = self
                .tls
                .server_name
                .clone()
                .unwrap_or_else(|| self.server.ip().to_string());
            let tls_stream = layer
                .handshake(&sni, tcp)
                .await
                .map_err(|e| ProxyError::ConnectionFailed(format!("TLS handshake: {e}")))?;
            let sm = Shadowsocks2022Sm::new(self.psk, &host, port);
            let wrapped = wrap_sans_io(tls_stream, sm);
            Ok(ConcreteStream::Ss2022(Box::new(wrapped)))
        } else {
            let sm = Shadowsocks2022Sm::new(self.psk, &host, port);
            let wrapped = wrap_sans_io(tcp, sm);
            Ok(ConcreteStream::Ss2022(Box::new(wrapped)))
        }
    }

    fn supports_udp(&self) -> bool {
        false
    }
}
