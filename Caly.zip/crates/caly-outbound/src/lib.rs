//! Outbound proxy adapters and protocol state machines.

pub mod adapter;
pub mod block;
pub mod direct;
pub mod failover;
pub mod group;
pub mod shadowsocks;
pub mod shadowsocks_adapter;

pub use adapter::ProxyAdapter;
pub use block::BlockAdapter;
pub use direct::DirectAdapter;
pub use failover::FailoverState;
pub use group::{FallbackAdapter, SelectorAdapter, UrlTestAdapter};
pub use shadowsocks::Shadowsocks2022Sm;
pub use shadowsocks_adapter::ShadowsocksAdapter;
