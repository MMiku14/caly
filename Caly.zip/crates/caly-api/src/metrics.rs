//! Lightweight zero-overhead Prometheus text-format exporter.

use std::sync::atomic::{AtomicU64, Ordering};
use std::time::Instant;

pub struct PrometheusMetrics {
    pub active_connections: AtomicU64,
    pub total_connections: AtomicU64,
    pub bytes_in_total: AtomicU64,
    pub bytes_out_total: AtomicU64,
    pub dns_queries_total: AtomicU64,
    pub dns_cache_hits: AtomicU64,
    pub dns_errors_total: AtomicU64,
    pub fakeip_allocated: AtomicU64,
    pub fakeip_released: AtomicU64,
    pub outbound_dial_errors: AtomicU64,
    pub outbound_blocked: AtomicU64,
    start_time: Instant,
}

impl Default for PrometheusMetrics {
    fn default() -> Self {
        Self::new()
    }
}

impl PrometheusMetrics {
    pub fn new() -> Self {
        Self {
            active_connections: AtomicU64::new(0),
            total_connections: AtomicU64::new(0),
            bytes_in_total: AtomicU64::new(0),
            bytes_out_total: AtomicU64::new(0),
            dns_queries_total: AtomicU64::new(0),
            dns_cache_hits: AtomicU64::new(0),
            dns_errors_total: AtomicU64::new(0),
            fakeip_allocated: AtomicU64::new(0),
            fakeip_released: AtomicU64::new(0),
            outbound_dial_errors: AtomicU64::new(0),
            outbound_blocked: AtomicU64::new(0),
            start_time: Instant::now(),
        }
    }

    pub fn render_prometheus(&self) -> String {
        self.render_prometheus_with_extra(None, None, None, None, None, None)
    }

    pub fn render_prometheus_with_extra(
        &self,
        rule_stats: Option<&caly_rules::RuleMetricsSnapshot>,
        outbound_hits: Option<&[(String, u64)]>,
        session_stats: Option<&caly_session::SessionMetricsSnapshot>,
        worker_limits: Option<&[(usize, usize)]>,
        cooldown_counts: Option<&[(String, usize)]>,
        worker_active: Option<&[(usize, u64)]>,
    ) -> String {
        let mut s = String::with_capacity(4096);
        let uptime = self.start_time.elapsed().as_secs();
        let active = self.active_connections.load(Ordering::Relaxed);
        let total = self.total_connections.load(Ordering::Relaxed);
        let bytes_in = self.bytes_in_total.load(Ordering::Relaxed);
        let bytes_out = self.bytes_out_total.load(Ordering::Relaxed);
        let dns_queries = self.dns_queries_total.load(Ordering::Relaxed);
        let dns_hits = self.dns_cache_hits.load(Ordering::Relaxed);
        let dns_errors = self.dns_errors_total.load(Ordering::Relaxed);
        let fakeip_alloc = self.fakeip_allocated.load(Ordering::Relaxed);
        let fakeip_release = self.fakeip_released.load(Ordering::Relaxed);
        let dial_errors = self.outbound_dial_errors.load(Ordering::Relaxed);
        let blocked = self.outbound_blocked.load(Ordering::Relaxed);

        s.push_str(&format!(
            "# HELP caly_uptime_seconds Process uptime in seconds\n\
             # TYPE caly_uptime_seconds gauge\n\
             caly_uptime_seconds {}\n\
             # HELP caly_active_connections Current active proxy connections\n\
             # TYPE caly_active_connections gauge\n\
             caly_active_connections {}\n\
             # HELP caly_total_connections Cumulative handled proxy connections\n\
             # TYPE caly_total_connections counter\n\
             caly_total_connections {}\n\
             # HELP caly_bytes_in_total Cumulative ingress bytes\n\
             # TYPE caly_bytes_in_total counter\n\
             caly_bytes_in_total {}\n\
             # HELP caly_bytes_out_total Cumulative egress bytes\n\
             # TYPE caly_bytes_out_total counter\n\
             caly_bytes_out_total {}\n\
             # HELP caly_dns_queries_total Cumulative DNS queries resolved\n\
             # TYPE caly_dns_queries_total counter\n\
             caly_dns_queries_total {}\n\
             # HELP caly_dns_cache_hits_total Cumulative DNS cache hit count\n\
             # TYPE caly_dns_cache_hits_total counter\n\
             caly_dns_cache_hits_total {}\n\
             # HELP caly_dns_errors_total Cumulative DNS resolution failures\n\
             # TYPE caly_dns_errors_total counter\n\
             caly_dns_errors_total {}\n\
             # HELP caly_fakeip_allocated_total FakeIP allocations\n\
             # TYPE caly_fakeip_allocated_total counter\n\
             caly_fakeip_allocated_total {}\n\
             # HELP caly_fakeip_released_total FakeIP releases\n\
             # TYPE caly_fakeip_released_total counter\n\
             caly_fakeip_released_total {}\n\
             # HELP caly_outbound_dial_errors_total Outbound dial failures\n\
             # TYPE caly_outbound_dial_errors_total counter\n\
             caly_outbound_dial_errors_total {}\n\
             # HELP caly_outbound_blocked_total Connections rejected by policy\n\
             # TYPE caly_outbound_blocked_total counter\n\
             caly_outbound_blocked_total {}\n",
            uptime, active, total, bytes_in, bytes_out, dns_queries, dns_hits,
            dns_errors, fakeip_alloc, fakeip_release, dial_errors, blocked
        ));

        if let Some(rs) = rule_stats {
            s.push_str(
                "# HELP caly_rule_hits_total Rule match count by category\n\
                 # TYPE caly_rule_hits_total counter\n",
            );
            let domain_sum: u64 = rs.domain_hits.iter().sum();
            let ip_sum: u64 = rs.ip_hits.iter().sum();
            let logic_sum: u64 = rs.logic_hits.iter().sum();
            s.push_str(&format!(
                "caly_rule_hits_total{{category=\"domain\"}} {}\n\
                 caly_rule_hits_total{{category=\"ip\"}} {}\n\
                 caly_rule_hits_total{{category=\"logic\"}} {}\n\
                 caly_rule_hits_total{{category=\"final\"}} {}\n",
                domain_sum, ip_sum, logic_sum, rs.total_final
            ));
            s.push_str(
                "# HELP caly_rule_match_total Total rule matches (including final fallback)\n\
                 # TYPE caly_rule_match_total counter\n",
            );
            s.push_str(&format!(
                "caly_rule_match_total{{result=\"matched\"}} {}\n\
                 caly_rule_match_total{{result=\"final\"}} {}\n",
                rs.total_matched, rs.total_final
            ));
        }

        if let Some(hits) = outbound_hits {
            s.push_str(
                "# HELP caly_outbound_dispatch_total Sessions dispatched per outbound\n\
                 # TYPE caly_outbound_dispatch_total counter\n",
            );
            for (tag, count) in hits {
                s.push_str(&format!(
                    "caly_outbound_dispatch_total{{tag=\"{}\"}} {}\n",
                    tag, count
                ));
            }
        }

        if let Some(limits) = worker_limits {
            s.push_str(
                "# HELP caly_worker_connection_limit Per-worker connection limit\n\
                 # TYPE caly_worker_connection_limit gauge\n",
            );
            for (worker_id, limit) in limits {
                s.push_str(&format!(
                    "caly_worker_connection_limit{{worker_id=\"{}\"}} {}\n",
                    worker_id, limit
                ));
            }
        }

        if let Some(worker_active_counts) = worker_active {
            s.push_str(
                "# HELP caly_worker_active_sessions Active sessions per worker\n\
                 # TYPE caly_worker_active_sessions gauge\n",
            );
            for (worker_id, count) in worker_active_counts {
                s.push_str(&format!(
                    "caly_worker_active_sessions{{worker_id=\"{}\"}} {}\n",
                    worker_id, count
                ));
            }
        }

        if let Some(counts) = cooldown_counts {
            s.push_str(
                "# HELP caly_proxy_cooldown_active Number of candidates in failure cooldown per proxy group\n\
                 # TYPE caly_proxy_cooldown_active gauge\n",
            );
            for (tag, n) in counts {
                s.push_str(&format!(
                    "caly_proxy_cooldown_active{{tag=\"{}\"}} {}\n",
                    tag, n
                ));
            }
        }

        if let Some(snap) = session_stats {
            s.push_str(
                "# HELP caly_active_sessions Current live sessions across all workers\n\
                 # TYPE caly_active_sessions gauge\n",
            );
            s.push_str(&format!("caly_active_sessions {}\n", snap.active));
            s.push_str(
                "# HELP caly_sessions_total Cumulative sessions accepted\n\
                 # TYPE caly_sessions_total counter\n",
            );
            s.push_str(&format!("caly_sessions_total {}\n", snap.total));
            s.push_str(
                "# HELP caly_session_bytes_in_total Cumulative bytes client->upstream\n\
                 # TYPE caly_session_bytes_in_total counter\n",
            );
            s.push_str(&format!("caly_session_bytes_in_total {}\n", snap.bytes_in));
            s.push_str(
                "# HELP caly_session_bytes_out_total Cumulative bytes upstream->client\n\
                 # TYPE caly_session_bytes_out_total counter\n",
            );
            s.push_str(&format!("caly_session_bytes_out_total {}\n", snap.bytes_out));
        }

        s
    }
}
