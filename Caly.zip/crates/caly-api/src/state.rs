//! Epoch state management and ArcSwap lock-free atomic hot-reloading.

use crate::metrics::PrometheusMetrics;
use arc_swap::ArcSwap;
use caly_common::dns::DnsResolver;
use caly_outbound::ProxyAdapter;
use caly_rules::RuleEngine;
use caly_session::guard::SessionMetricsTracker;
use std::collections::HashMap;
use std::sync::Arc;
use std::time::Instant;
use tokio::sync::Notify;

pub struct Epoch {
    pub id: u64,
    pub rules: Arc<RuleEngine>,
    pub dns: Arc<dyn DnsResolver>,
    pub created_at: Instant,
}

#[derive(Debug, Clone)]
pub struct ReloadRequest {
    pub config_json: String,
}

pub struct AppState {
    pub epoch: ArcSwap<Epoch>,
    pub metrics: Arc<PrometheusMetrics>,
    pub reload_tx: tokio::sync::mpsc::Sender<ReloadRequest>,
    pub outbounds: Arc<HashMap<String, Arc<dyn ProxyAdapter>>>,
    pub session_metrics: Arc<SessionMetricsTracker>,
    pub shutdown: Arc<Notify>,
}

impl AppState {
    pub fn new(
        initial_epoch: Epoch,
        metrics: Arc<PrometheusMetrics>,
        reload_tx: tokio::sync::mpsc::Sender<ReloadRequest>,
        outbounds: Arc<HashMap<String, Arc<dyn ProxyAdapter>>>,
        session_metrics: Arc<SessionMetricsTracker>,
        shutdown: Arc<Notify>,
    ) -> Self {
        Self {
            epoch: ArcSwap::new(Arc::new(initial_epoch)),
            metrics,
            reload_tx,
            outbounds,
            session_metrics,
            shutdown,
        }
    }

    /// 热重载（Round 20 修正）。
    ///
    /// 接收 `Arc<RuleEngine>` 而非裸 `RuleEngine`：
    ///   - WorkerLoop 持有的 `rules_swap` 与 Epoch 共享同一个 Arc，
    ///     避免克隆整棵规则 trie（50 万条规则可达数 MB）。
    ///   - 明确所有权路径，防止两侧各持一份相互独立的 RuleEngine
    ///     导致热重载只更新一侧。
    pub fn reload(&self, new_rules: Arc<RuleEngine>, new_dns: Arc<dyn DnsResolver>) -> u64 {
        let prev_id = self.epoch.load().id;
        let new_id = prev_id + 1;
        let new_epoch = Epoch {
            id: new_id,
            rules: new_rules,
            dns: new_dns,
            created_at: Instant::now(),
        };
        let _old = self.epoch.swap(Arc::new(new_epoch));
        new_id
    }
}
