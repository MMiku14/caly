//! High-performance asynchronous HTTP/1.1 server implementation for control plane.

use crate::routes::{handle_http_request, HttpResponse};
use crate::state::AppState;
use std::io;
use std::sync::Arc;
use std::time::Duration;
use tokio::io::{AsyncReadExt, AsyncWriteExt};
use tokio::net::{TcpListener, TcpStream};

const MAX_HEADER_SIZE: usize = 16 * 1024;
const MAX_REQUEST_LINE_SIZE: usize = 8 * 1024;
const MAX_BODY_SIZE: usize = 1024 * 1024;
const READ_BUF_SIZE: usize = 4096;

const REQUEST_TIMEOUT: Duration = Duration::from_secs(10);
const KEEPALIVE_IDLE_TIMEOUT: Duration = Duration::from_secs(60);

pub async fn serve(state: Arc<AppState>, listener: TcpListener) {
    tracing::info!("HTTP control plane listening");
    loop {
        tokio::select! {
            biased;
            _ = state.shutdown.notified() => {
                tracing::info!("HTTP control plane shutting down");
                return;
            }
            accept_res = listener.accept() => {
                match accept_res {
                    Ok((stream, peer)) => {
                        let state = state.clone();
                        tokio::spawn(async move {
                            if let Err(e) = handle_connection(state, stream).await {
                                tracing::debug!(peer = %peer, error = %e, "http connection closed");
                            }
                        });
                    }
                    Err(e) => {
                        tracing::warn!(error = %e, "http accept failed");
                        tokio::time::sleep(Duration::from_millis(50)).await;
                    }
                }
            }
        }
    }
}

struct ParsedRequest {
    method: String,
    path: String,
    keep_alive: bool,
    body: Vec<u8>,
}

async fn handle_connection(state: Arc<AppState>, mut stream: TcpStream) -> io::Result<()> {
    let _ = stream.set_nodelay(true);
    loop {
        let req = match tokio::time::timeout(
            KEEPALIVE_IDLE_TIMEOUT,
            read_request(&mut stream),
        )
        .await
        {
            Ok(Ok(Some(r))) => r,
            Ok(Ok(None)) => return Ok(()),
            Ok(Err(e)) => return Err(e),
            Err(_) => return Ok(()),
        };

        let resp = handle_http_request(&state, &req.method, &req.path, &req.body);
        write_response(&mut stream, &resp, req.keep_alive).await?;
        if !req.keep_alive {
            return Ok(());
        }
    }
}

async fn read_request(stream: &mut TcpStream) -> io::Result<Option<ParsedRequest>> {
    match tokio::time::timeout(REQUEST_TIMEOUT, read_request_inner(stream)).await {
        Ok(r) => r,
        Err(_) => Err(io::Error::new(
            io::ErrorKind::TimedOut,
            "request timeout",
        )),
    }
}

async fn read_request_inner(stream: &mut TcpStream) -> io::Result<Option<ParsedRequest>> {
    let mut buf: Vec<u8> = Vec::with_capacity(READ_BUF_SIZE);
    let mut tmp = [0u8; 1024];

    let (header_body_split, header_len) = loop {
        let n = stream.read(&mut tmp).await?;
        if n == 0 {
            if buf.is_empty() {
                return Ok(None);
            }
            return Err(io::Error::new(
                io::ErrorKind::UnexpectedEof,
                "connection closed mid-header",
            ));
        }
        buf.extend_from_slice(&tmp[..n]);
        if buf.len() > MAX_HEADER_SIZE {
            return Err(io::Error::new(
                io::ErrorKind::InvalidData,
                "request headers exceed limit",
            ));
        }
        if let Some((content_end, total_end)) = find_header_end(&buf) {
            if total_end > MAX_REQUEST_LINE_SIZE + MAX_HEADER_SIZE {
                return Err(io::Error::new(
                    io::ErrorKind::InvalidData,
                    "request line + headers exceed limit",
                ));
            }
            break (content_end, total_end);
        }
    };

    let header_str = std::str::from_utf8(&buf[..header_body_split])
        .map_err(|_| io::Error::new(io::ErrorKind::InvalidData, "invalid UTF-8 in headers"))?;

    let mut lines = header_str.lines();
    let request_line = lines
        .next()
        .ok_or_else(|| io::Error::new(io::ErrorKind::InvalidData, "empty request line"))?;
    if request_line.len() > MAX_REQUEST_LINE_SIZE {
        return Err(io::Error::new(
            io::ErrorKind::InvalidData,
            "request line too long",
        ));
    }

    let mut parts = request_line.split_whitespace();
    let method = parts
        .next()
        .ok_or_else(|| io::Error::new(io::ErrorKind::InvalidData, "missing method"))?
        .to_string();
    let path = parts
        .next()
        .ok_or_else(|| io::Error::new(io::ErrorKind::InvalidData, "missing path"))?
        .to_string();
    let version = parts
        .next()
        .ok_or_else(|| io::Error::new(io::ErrorKind::InvalidData, "missing HTTP version"))?;

    let is_http_1_0 = version.eq_ignore_ascii_case("HTTP/1.0");
    let is_http_1_1 = version.eq_ignore_ascii_case("HTTP/1.1");
    if !is_http_1_0 && !is_http_1_1 {
        return Err(io::Error::new(
            io::ErrorKind::InvalidData,
            format!("unsupported HTTP version: {}", version),
        ));
    }

    let mut content_length: usize = 0;
    let mut keep_alive = is_http_1_1;
    for line in lines {
        let line = line.trim();
        if line.is_empty() {
            continue;
        }
        if let Some((k, v)) = line.split_once(':') {
            let k = k.trim();
            let v = v.trim();
            if k.eq_ignore_ascii_case("content-length") {
                content_length = v.parse().unwrap_or(0);
            } else if k.eq_ignore_ascii_case("connection") {
                if v.eq_ignore_ascii_case("close") {
                    keep_alive = false;
                } else if v.eq_ignore_ascii_case("keep-alive") {
                    keep_alive = true;
                }
            }
        }
    }

    if content_length > MAX_BODY_SIZE {
        return Err(io::Error::new(
            io::ErrorKind::InvalidData,
            format!("body size {} exceeds limit {}", content_length, MAX_BODY_SIZE),
        ));
    }

    let mut body = buf[header_len..].to_vec();
    while body.len() < content_length {
        let n = stream.read(&mut tmp).await?;
        if n == 0 {
            break;
        }
        body.extend_from_slice(&tmp[..n]);
        if body.len() > MAX_BODY_SIZE {
            return Err(io::Error::new(
                io::ErrorKind::InvalidData,
                "body exceeds limit while reading",
            ));
        }
    }
    body.truncate(content_length);

    Ok(Some(ParsedRequest {
        method,
        path,
        keep_alive,
        body,
    }))
}

async fn write_response(
    stream: &mut TcpStream,
    resp: &HttpResponse,
    keep_alive: bool,
) -> io::Result<()> {
    let body_bytes = resp.body.as_bytes();
    let conn_header = if keep_alive { "keep-alive" } else { "close" };
    // 修复（Round 20）：HTTP/1.1 头部字段必须用 CRLF（\r\n）分隔，
    // 且字段名不能有前导空白。旧实现用裸 \n 加 9 个缩进空格，
    // 导致所有控制面 HTTP 响应格式错误：
    //   - 状态行之后紧跟 9 个空格的续行 → 被解析为非法 header
    //   - 头部之间缺 CRLF → curl/wrk 直接拒绝
    // 另外删除了 `{}` 后多余的 9 个尾随空格。
    let head = format!(
        "HTTP/1.1 {} {}\r\n\
         Content-Type: {}\r\n\
         Content-Length: {}\r\n\
         Connection: {}\r\n\
         {}\r\n",
        resp.status_code,
        HttpResponse::status_text(resp.status_code),
        resp.content_type,
        body_bytes.len(),
        conn_header,
        resp.extra_headers,
    );
    stream.write_all(head.as_bytes()).await?;
    stream.write_all(body_bytes).await?;
    stream.flush().await?;
    Ok(())
}

fn find_header_end(buf: &[u8]) -> Option<(usize, usize)> {
    if let Some(pos) = buf.windows(4).position(|w| w == b"

") {
        return Some((pos, pos + 4));
    }
    if let Some(pos) = buf.windows(2).position(|w| w == b"

") {
        return Some((pos, pos + 2));
    }
    None
}
