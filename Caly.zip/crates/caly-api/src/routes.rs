//! REST API handlers, metrics exporters, and rule inspection endpoints.

use crate::state::{AppState, ReloadRequest};
use std::sync::Arc;

pub struct HttpResponse {
    pub status_code: u16,
    pub content_type: &'static str,
    pub extra_headers: &'static str,
    pub body: String,
}

impl HttpResponse {
    pub fn status_text(code: u16) -> &'static str {
        match code {
            200 => "OK",
            202 => "Accepted",
            204 => "No Content",
            400 => "Bad Request",
            404 => "Not Found",
            405 => "Method Not Allowed",
            408 => "Request Timeout",
            413 => "Payload Too Large",
            431 => "Request Header Fields Too Large",
            500 => "Internal Server Error",
            501 => "Not Implemented",
            502 => "Bad Gateway",
            503 => "Service Unavailable",
            504 => "Gateway Timeout",
            _ => "Unknown",
        }
    }
}

fn json_error(status: u16, cors: &'static str, msg: &str) -> HttpResponse {
    HttpResponse {
        status_code: status,
        content_type: "application/json",
        extra_headers: cors,
        body: format!(r#"{{"error":"{}"}}"#, json_escape(msg)),
    }
}

pub fn handle_http_request(
    state: &Arc<AppState>,
    method: &str,
    raw_path: &str,
    body: &[u8],
) -> HttpResponse {
    let clean_path = raw_path.split('?').next().unwrap_or("").trim_end_matches('/');
    let path = if clean_path.is_empty() { "/" } else { clean_path };

    if method.eq_ignore_ascii_case("OPTIONS") {
        return HttpResponse {
            status_code: 204,
            content_type: "text/plain",
            // 修复（Round 20）：CORS 头必须用 CRLF 分隔且不能带缩进。
            // 旧实现的多行字符串字面量把缩进空白写进了头部字段值。
            extra_headers: "Access-Control-Allow-Origin: *\r\n\
                            Access-Control-Allow-Methods: GET, POST, OPTIONS\r\n\
                            Access-Control-Allow-Headers: Content-Type\r\n\
                            Vary: Origin\r\n",
            body: String::new(),
        };
    }

    // 修复（Round 24）：HTTP 头必须用 CRLF 分隔。
    //
    // 旧实现是裸多行字符串字面量，字段之间只有 LF（HTTP 规范要求 CRLF），
    // 且续行前导 0 缩进被 HTTP 解析器视作 obs-fold（RFC 7230 §3.2.4
    // 明确弃用，现代客户端直接拒绝）。
    //
    // 症状：所有非 OPTIONS 的 REST 响应头部格式非法，
    // curl/wrk 需要 --http0.9 才能勉强解析。
    let cors: &'static str = "Access-Control-Allow-Origin: *\r\nVary: Origin\r\n";
    let is_get = method.eq_ignore_ascii_case("GET");
    let is_post = method.eq_ignore_ascii_case("POST");

    match path {
        "/healthz" | "/health" => HttpResponse {
            status_code: 200,
            content_type: "application/json",
            extra_headers: cors,
            body: r#"{"status":"ok","service":"caly"}"#.to_string(),
        },
        "/api/v1/version" if is_get => {
            let version = env!("CARGO_PKG_VERSION");
            let arch = std::env::consts::ARCH;
            let os = std::env::consts::OS;
            let body = format!(
                r#"{{"service":"caly","version":"{}","arch":"{}","os":"{}"}}"#,
                version, arch, os,
            );
            HttpResponse {
                status_code: 200,
                content_type: "application/json",
                extra_headers: cors,
                body,
            }
        }
        "/readyz" | "/ready" => {
            let epoch = state.epoch.load();
            HttpResponse {
                status_code: 200,
                content_type: "application/json",
                extra_headers: cors,
                body: format!(
                    r#"{{"status":"ready","epoch":{},"uptime_secs":{}}}"#,
                    epoch.id,
                    epoch.created_at.elapsed().as_secs()
                ),
            }
        }
        "/metrics" if is_get => {
            let epoch = state.epoch.load();
            let rule_stats = epoch.rules.metrics_snapshot();
            let outbound_snap = state.session_metrics.outbound_snapshot();
            let session_snap = state.session_metrics.snapshot();
            let worker_limits = state.session_metrics.worker_limits_snapshot();
            let mut cooldown_counts: Vec<(String, usize)> = Vec::new();
            for (tag, adapter) in state.outbounds.iter() {
                let n = adapter.cooldown_snapshot().len();
                if n > 0 {
                    cooldown_counts.push((tag.clone(), n));
                }
            }
            cooldown_counts.sort_by(|a, b| a.0.cmp(&b.0));
            let worker_active = state.session_metrics.worker_active_snapshot();
            let body = state.metrics.render_prometheus_with_extra(
                Some(&rule_stats),
                Some(&outbound_snap),
                Some(&session_snap),
                Some(&worker_limits),
                Some(&cooldown_counts),
                Some(&worker_active),
            );
            HttpResponse {
                status_code: 200,
                content_type: "text/plain; version=0.0.4",
                extra_headers: cors,
                body,
            }
        }
        "/api/v1/epoch" if is_get => {
            let epoch = state.epoch.load();
            HttpResponse {
                status_code: 200,
                content_type: "application/json",
                extra_headers: cors,
                body: format!(
                    r#"{{"epoch_id":{},"uptime_secs":{}}}"#,
                    epoch.id,
                    epoch.created_at.elapsed().as_secs()
                ),
            }
        }
        "/api/v1/stats" if is_get => {
            let epoch = state.epoch.load();
            let rules_stats = epoch.rules.stats();
            HttpResponse {
                status_code: 200,
                content_type: "application/json",
                extra_headers: cors,
                body: format!(
                    r#"{{"epoch":{},"domain_rules":{},"ip_rules":{},"logic_rules":{}}}"#,
                    epoch.id,
                    rules_stats.domain_rules,
                    rules_stats.ip_rules,
                    rules_stats.logic_rules,
                ),
            }
        }
        "/api/v1/rules/check" => {
            if is_get {
                handle_rules_check_get(state, cors, raw_path)
            } else if is_post {
                handle_rules_check_post(state, cors, body)
            } else {
                HttpResponse {
                    status_code: 405,
                    content_type: "text/plain",
                    extra_headers: "Allow: GET, POST, OPTIONS
",
                    body: "Method Not Allowed".to_string(),
                }
            }
        }
        "/api/v1/dns/cache/clear" => {
            if !is_post {
                return HttpResponse {
                    status_code: 405,
                    content_type: "text/plain",
                    extra_headers: "Allow: POST, OPTIONS
",
                    body: "Method Not Allowed".to_string(),
                };
            }
            let epoch = state.epoch.load();
            let cleared = epoch.dns.clear_cache();
            HttpResponse {
                status_code: 200,
                content_type: "application/json",
                extra_headers: cors,
                body: format!(r#"{{"status":"ok","cleared":{}}}"#, cleared),
            }
        }
        "/api/v1/rules/dump" if is_get => {
            let query = raw_path.split('?').nth(1).unwrap_or("");
            let mut limit: usize = usize::MAX;
            for pair in query.split('&') {
                if let Some((k, v)) = pair.split_once('=') {
                    if k == "limit" {
                        limit = v.parse().unwrap_or(usize::MAX).min(50_000);
                    }
                }
            }
            let epoch = state.epoch.load();
            let all = epoch.rules.iter_all();
            let total = all.len();
            let taken = all.len().min(limit);

            let mut body = String::with_capacity(64 + taken * 128);
            body.push_str(&format!(r#"{{"total":{},"returned":{},"rules":["#, total, taken));
            for (idx, item) in all.iter().take(taken).enumerate() {
                if idx > 0 {
                    body.push(',');
                }
                let cond_json = item
                    .condition
                    .as_ref()
                    .map(rule_condition_to_json)
                    .unwrap_or_else(|| "null".to_string());
                body.push_str(&format!(
                    r#"{{"kind":"{}","index":{},"condition":{},"outbound":"{}"}}"#,
                    item.kind.as_str(),
                    item.index,
                    cond_json,
                    json_escape(&item.outbound),
                ));
            }
            body.push_str("]}");

            HttpResponse {
                status_code: 200,
                content_type: "application/json",
                extra_headers: cors,
                body,
            }
        }
        "/api/v1/rules/stats" if is_get => {
            let query = raw_path.split('?').nth(1).unwrap_or("");
            let mut limit: usize = 20;
            for pair in query.split('&') {
                if let Some((k, v)) = pair.split_once('=') {
                    if k == "limit" {
                        limit = v.parse().unwrap_or(20).min(200);
                    }
                }
            }
            let epoch = state.epoch.load();
            let stats = epoch.rules.stats();
            let top = epoch.rules.top_hits(limit);
            let mut top_items: Vec<String> = Vec::with_capacity(top.len());
            for h in &top {
                let cond_json = h
                    .condition
                    .as_ref()
                    .map(rule_condition_to_json)
                    .unwrap_or_else(|| "null".to_string());
                top_items.push(format!(
                    r#"{{"kind":"{}","index":{},"hits":{},"condition":{},"outbound":"{}"}}"#,
                    h.kind.as_str(),
                    h.index,
                    h.hits,
                    cond_json,
                    json_escape(&h.outbound),
                ));
            }
            let body = format!(
                r#"{{"totals":{{"domain":{},"ip":{},"logic":{}}},"top":[{}]}}"#,
                stats.domain_rules,
                stats.ip_rules,
                stats.logic_rules,
                top_items.join(","),
            );
            HttpResponse {
                status_code: 200,
                content_type: "application/json",
                extra_headers: cors,
                body,
            }
        }
        "/api/v1/sessions" if is_get => {
            let snap = state.session_metrics.snapshot();
            let outbound_dispatch = state.session_metrics.outbound_snapshot();
            let mut out_json_items: Vec<String> = Vec::new();
            for (tag, count) in outbound_dispatch.iter() {
                let (b_in, b_out) = state
                    .session_metrics
                    .outbound_bytes
                    .get(tag)
                    .map(|e| {
                        (
                            e.0.load(std::sync::atomic::Ordering::Relaxed),
                            e.1.load(std::sync::atomic::Ordering::Relaxed),
                        )
                    })
                    .unwrap_or((0, 0));
                out_json_items.push(format!(
                    r#"{{"tag":"{}","count":{},"bytes_in":{},"bytes_out":{}}}"#,
                    tag, count, b_in, b_out
                ));
            }
            HttpResponse {
                status_code: 200,
                content_type: "application/json",
                extra_headers: cors,
                body: format!(
                    r#"{{"active":{},"total":{},"bytes_in":{},"bytes_out":{},"outbounds":[{}]}}"#,
                    snap.active,
                    snap.total,
                    snap.bytes_in,
                    snap.bytes_out,
                    out_json_items.join(","),
                ),
            }
        }
        "/configs" | "/api/v1/configs" => {
            if !is_post {
                return HttpResponse {
                    status_code: 405,
                    content_type: "text/plain",
                    extra_headers: "Allow: POST, OPTIONS
",
                    body: "Method Not Allowed".to_string(),
                };
            }
            let body_str = match std::str::from_utf8(body) {
                Ok(s) => s,
                Err(_) => return json_error(400, cors, "body is not valid UTF-8"),
            };
            if body_str.trim().is_empty() {
                return json_error(400, cors, "empty request body");
            }
            if serde_json::from_str::<serde_json::Value>(body_str).is_err() {
                return json_error(400, cors, "body is not valid JSON");
            }
            match state.reload_tx.try_send(ReloadRequest {
                config_json: body_str.to_string(),
            }) {
                Ok(()) => HttpResponse {
                    status_code: 202,
                    content_type: "application/json",
                    extra_headers: cors,
                    body: r#"{"status":"accepted","message":"reload in progress; poll /api/v1/epoch"}"#
                        .to_string(),
                },
                Err(_) => HttpResponse {
                    status_code: 503,
                    content_type: "application/json",
                    extra_headers: cors,
                    body: r#"{"status":"busy","message":"another reload is in progress"}"#
                        .to_string(),
                },
            }
        }
        "/api/v1/proxies" if is_get => {
            let mut entries: Vec<String> = Vec::new();
            for (tag, adapter) in state.outbounds.iter() {
                let candidates_json = match adapter.candidates() {
                    Some(c) => {
                        let quoted: Vec<String> =
                            c.iter().map(|s| format!(r#""{}""#, json_escape(s))).collect();
                        format!("[{}]", quoted.join(","))
                    }
                    None => "null".to_string(),
                };
                entries.push(format!(
                    r#"{{"tag":"{}","type":"{}","udp":{},"candidates":{}}}"#,
                    json_escape(tag),
                    adapter.adapter_type(),
                    adapter.supports_udp(),
                    candidates_json,
                ));
            }
            HttpResponse {
                status_code: 200,
                content_type: "application/json",
                extra_headers: cors,
                body: format!("[{}]", entries.join(",")),
            }
        }
        _ if path.starts_with("/api/v1/proxies/") => {
            let rest = &path["/api/v1/proxies/".len()..];
            let parts: Vec<&str> = rest.split('/').collect();
            if parts.len() == 1 && is_get {
                let tag = parts[0];
                let adapter = match state.outbounds.get(tag) {
                    Some(a) => a.clone(),
                    None => return json_error(404, cors, &format!("proxy '{}' not found", tag)),
                };
                let current = adapter.current_selection();
                let latency = adapter.latency_snapshot();
                let cands = adapter.candidates();
                let cooldown = adapter.cooldown_snapshot();
                let cands_json = match cands {
                    Some(c) => {
                        let quoted: Vec<String> =
                            c.iter().map(|s| format!(r#""{}""#, json_escape(s))).collect();
                        format!("[{}]", quoted.join(","))
                    }
                    None => "null".to_string(),
                };
                let latency_json = {
                    let items: Vec<String> = latency
                        .iter()
                        .map(|(n, ms)| format!(r#"{{"name":"{}","latency_ms":{}}}"#, json_escape(n), ms))
                        .collect();
                    format!("[{}]", items.join(","))
                };
                let cooldown_json = {
                    let items: Vec<String> = cooldown
                        .iter()
                        .map(|(n, secs)| {
                            format!(r#"{{"name":"{}","remaining_secs":{}}}"#, json_escape(n), secs)
                        })
                        .collect();
                    format!("[{}]", items.join(","))
                };
                let current_json = match current {
                    Some(c) => format!(r#""{}""#, json_escape(&c)),
                    None => "null".to_string(),
                };
                return HttpResponse {
                    status_code: 200,
                    content_type: "application/json",
                    extra_headers: cors,
                    body: format!(
                        r#"{{"tag":"{}","type":"{}","udp":{},"current":{},"candidates":{},"latency":{},"cooldown":{}}}"#,
                        json_escape(tag),
                        adapter.adapter_type(),
                        adapter.supports_udp(),
                        current_json,
                        cands_json,
                        latency_json,
                        cooldown_json,
                    ),
                };
            }
            if parts.len() == 2 && parts[1] == "reset" {
                let tag = parts[0];
                if !is_post {
                    return HttpResponse {
                        status_code: 405,
                        content_type: "text/plain",
                        extra_headers: "Allow: POST, OPTIONS
",
                        body: "Method Not Allowed".to_string(),
                    };
                }
                let adapter = match state.outbounds.get(tag) {
                    Some(a) => a.clone(),
                    None => return json_error(404, cors, &format!("proxy '{}' not found", tag)),
                };
                let n = adapter.reset_failures();
                return HttpResponse {
                    status_code: 200,
                    content_type: "application/json",
                    extra_headers: cors,
                    body: format!(r#"{{"status":"ok","tag":"{}","cleared":{}}}"#, json_escape(tag), n),
                };
            }
            if parts.len() == 2 && parts[1] == "select" {
                let tag = parts[0];
                if !is_post {
                    return HttpResponse {
                        status_code: 405,
                        content_type: "text/plain",
                        extra_headers: "Allow: POST, OPTIONS
",
                        body: "Method Not Allowed".to_string(),
                    };
                }
                let adapter = match state.outbounds.get(tag) {
                    Some(a) => a.clone(),
                    None => return json_error(404, cors, &format!("proxy '{}' not found", tag)),
                };
                let body_str = std::str::from_utf8(body).unwrap_or("");
                let name = match extract_json_string_field(body_str, "name") {
                    Some(n) => n,
                    None => return json_error(400, cors, "missing 'name' field in body"),
                };
                match adapter.try_select(&name) {
                    Ok(()) => HttpResponse {
                        status_code: 200,
                        content_type: "application/json",
                        extra_headers: cors,
                        body: format!(
                            r#"{{"status":"ok","tag":"{}","selected":"{}"}}"#,
                            json_escape(tag),
                            json_escape(&name)
                        ),
                    },
                    Err(e) => json_error(400, cors, &e),
                }
            } else {
                json_error(404, cors, "unknown proxies subpath")
            }
        }
        _ => HttpResponse {
            status_code: 404,
            content_type: "text/plain",
            extra_headers: cors,
            body: "Not Found".to_string(),
        },
    }
}

fn extract_json_string_field(json: &str, key: &str) -> Option<String> {
    let v: serde_json::Value = serde_json::from_str(json).ok()?;
    v.get(key)?.as_str().map(|s| s.to_string())
}

fn url_decode(s: &str) -> String {
    // 修复（Round 21）：以字节为单位累积，最后整体做 UTF-8 解码。
    //
    // 旧实现用 `byte as char`，这只对 0x00..=0x7F 的 ASCII 正确。
    // 若查询串是 `?domain=%E4%B8%AD%E6%96%87.com`（"中文.com"），
    // 三个字节 0xE4 0xB8 0xAD 会被分别变成 U+00E4 U+00B8 U+00AD
    // 三个 Latin-1 字符（"ä¸"）—— 中文域名永远匹配不上规则。
    //
    // 修复后：把解码出的原始字节累积到 Vec<u8>，最后用
    // `from_utf8_lossy` 做一次整体解码。非法的 UTF-8 字节被替换为
    // U+FFFD（'�'），不丢失整串。
    let mut out: Vec<u8> = Vec::with_capacity(s.len());
    let bytes = s.as_bytes();
    let mut i = 0;
    while i < bytes.len() {
        match bytes[i] {
            b'+' => {
                out.push(b' ');
                i += 1;
            }
            b'%' if i + 2 < bytes.len() => {
                let hex = std::str::from_utf8(&bytes[i + 1..i + 3]).unwrap_or("");
                if let Ok(byte) = u8::from_str_radix(hex, 16) {
                    out.push(byte);
                    i += 3;
                } else {
                    out.push(b'%');
                    i += 1;
                }
            }
            b => {
                out.push(b);
                i += 1;
            }
        }
    }
    String::from_utf8_lossy(&out).into_owned()
}

/// 把 RuleCondition 序列化为紧凑 JSON。
///
/// 只列出可读的字段，不追求与内部表示 1:1。
fn rule_condition_to_json(cond: &caly_rules::RuleCondition) -> String {
    use caly_rules::RuleCondition::*;
    match cond {
        Domain(s) => format!(r#"{{"type":"domain","value":"{}"}}"#, json_escape(s)),
        DomainSuffix(s) => format!(r#"{{"type":"domain_suffix","value":"{}"}}"#, json_escape(s)),
        DomainKeyword(s) => format!(r#"{{"type":"domain_keyword","value":"{}"}}"#, json_escape(s)),
        IpCidr(net) => format!(r#"{{"type":"ip_cidr","value":"{}"}}"#, net),
        IpIsPrivate => r#"{"type":"ip_is_private"}"#.to_string(),
        SourceIpCidr(net) => format!(r#"{{"type":"source_ip_cidr","value":"{}"}}"#, net),
        Port(p) => format!(r#"{{"type":"port","value":{}}}"#, p),
        PortRange(a, b) => format!(r#"{{"type":"port_range","lo":{},"hi":{}}}"#, a, b),
        SourcePort(p) => format!(r#"{{"type":"source_port","value":{}}}"#, p),
        ProcessName(s) => format!(r#"{{"type":"process_name","value":"{}"}}"#, json_escape(s)),
        Protocol(p) => format!(r#"{{"type":"protocol","value":"{}"}}"#, p),
        Network(n) => format!(r#"{{"type":"network","value":"{}"}}"#, n),
        Inbound(t) => format!(r#"{{"type":"inbound","value":{}}}"#, t),
        SniffSource(s) => format!(r#"{{"type":"sniff_source","value":{}}}"#, s),
        And(list) => {
            let items: Vec<String> = list.iter().map(rule_condition_to_json).collect();
            format!(r#"{{"type":"and","items":[{}]}}"#, items.join(","))
        }
        Or(list) => {
            let items: Vec<String> = list.iter().map(rule_condition_to_json).collect();
            format!(r#"{{"type":"or","items":[{}]}}"#, items.join(","))
        }
        Not(inner) => {
            format!(
                r#"{{"type":"not","inner":{}}}"#,
                rule_condition_to_json(inner)
            )
        }
    }
}

const MAX_RULES_CHECK_BATCH: usize = 1000;

fn handle_rules_check_get(
    state: &Arc<AppState>,
    cors: &'static str,
    raw_path: &str,
) -> HttpResponse {
    let query = raw_path.split('?').nth(1).unwrap_or("");
    let params = parse_query_params(query);
    if !params.contains_key("domain") && !params.contains_key("ip") {
        return json_error(400, cors, "provide ?domain= or ?ip=");
    }
    let meta = match metadata_from_params(&params) {
        Ok(m) => m,
        Err(e) => return json_error(400, cors, &e),
    };
    let epoch = state.epoch.load();
    let t0 = std::time::Instant::now();
    let expl = epoch.rules.explain(&meta);
    let elapsed_us = t0.elapsed().as_micros() as u64;
    let body = format_explanation_json(&expl, &params, elapsed_us);
    HttpResponse {
        status_code: 200,
        content_type: "application/json",
        extra_headers: cors,
        body,
    }
}

fn handle_rules_check_post(
    state: &Arc<AppState>,
    cors: &'static str,
    body: &[u8],
) -> HttpResponse {
    let body_str = match std::str::from_utf8(body) {
        Ok(s) => s,
        Err(_) => return json_error(400, cors, "body is not valid UTF-8"),
    };
    let v: serde_json::Value = match serde_json::from_str(body_str) {
        Ok(v) => v,
        Err(e) => return json_error(400, cors, &format!("invalid JSON: {e}")),
    };
    let queries = match v.get("queries").and_then(|q| q.as_array()) {
        Some(a) => a,
        None => return json_error(400, cors, "missing 'queries' array"),
    };
    if queries.is_empty() {
        return json_error(400, cors, "empty 'queries' array");
    }
    if queries.len() > MAX_RULES_CHECK_BATCH {
        return json_error(
            400,
            cors,
            &format!(
                "too many queries: {} > {}",
                queries.len(),
                MAX_RULES_CHECK_BATCH
            ),
        );
    }
    let epoch = state.epoch.load();
    let mut results: Vec<String> = Vec::with_capacity(queries.len());
    for (i, q) in queries.iter().enumerate() {
        let obj = match q.as_object() {
            Some(o) => o,
            None => {
                results.push(format!(
                    r#"{{"index":{},"error":"query is not an object"}}"#,
                    i
                ));
                continue;
            }
        };
        let mut params: std::collections::HashMap<String, String> =
            std::collections::HashMap::new();
        for (k, val) in obj {
            if let Some(s) = val.as_str() {
                params.insert(k.clone(), s.to_string());
            } else if let Some(n) = val.as_u64() {
                params.insert(k.clone(), n.to_string());
            } else if let Some(b) = val.as_bool() {
                params.insert(k.clone(), b.to_string());
            }
        }
        if !params.contains_key("domain") && !params.contains_key("ip") {
            results.push(format!(
                r#"{{"index":{},"error":"need domain or ip"}}"#,
                i
            ));
            continue;
        }
        let meta = match metadata_from_params(&params) {
            Ok(m) => m,
            Err(e) => {
                results.push(format!(
                    r#"{{"index":{},"error":"{}"}}"#,
                    i,
                    json_escape(&e)
                ));
                continue;
            }
        };
        let t0 = std::time::Instant::now();
        let expl = epoch.rules.explain(&meta);
        let elapsed_us = t0.elapsed().as_micros() as u64;
        let inner = format_explanation_json_no_braces(&expl, &params, elapsed_us);
        results.push(format!(r#"{{"query_index":{},{}}}"#, i, inner));
    }
    let body = format!(r#"{{"results":[{}]}}"#, results.join(","));
    HttpResponse {
        status_code: 200,
        content_type: "application/json",
        extra_headers: cors,
        body,
    }
}

fn parse_query_params(query: &str) -> std::collections::HashMap<String, String> {
    let mut m = std::collections::HashMap::with_capacity(8);
    for pair in query.split('&') {
        let Some((k, v)) = pair.split_once('=') else { continue };
        if !k.is_empty() {
            m.insert(k.to_string(), url_decode(v));
        }
    }
    m
}

fn metadata_from_params(
    params: &std::collections::HashMap<String, String>,
) -> Result<caly_common::metadata::SessionMetadata, String> {
    use caly_common::metadata::{Network, SessionMetadata, SniffedProto};
    let mut meta = SessionMetadata::default();
    if let Some(d) = params.get("domain") {
        if !d.is_empty() {
            meta.set_domain(d);
        }
    }
    let port: u16 = params
        .get("port")
        .and_then(|s| s.parse().ok())
        .unwrap_or(0);
    if let Some(ip_str) = params.get("ip") {
        if !ip_str.is_empty() {
            match ip_str.parse::<std::net::IpAddr>() {
                Ok(ip) => {
                    meta.dst_addr = std::net::SocketAddr::new(ip, port);
                }
                Err(_) => return Err(format!("invalid ip: '{}'", ip_str)),
            }
        }
    } else if port != 0 {
        meta.dst_addr = std::net::SocketAddr::new(
            std::net::IpAddr::V4(std::net::Ipv4Addr::UNSPECIFIED),
            port,
        );
    }
    if let Some(net) = params.get("network") {
        meta.network = match net.as_str() {
            "tcp" => Network::Tcp,
            "udp" => Network::Udp,
            "both" => Network::Both,
            other => return Err(format!("invalid network: '{}'", other)),
        };
    }
    if let Some(proto) = params.get("protocol") {
        meta.protocol = match proto.as_str() {
            "http" | "http/1.1" => SniffedProto::Http,
            "tls" => SniffedProto::Tls,
            "quic" => SniffedProto::Quic,
            "bittorrent" => SniffedProto::BitTorrent,
            "dns" => SniffedProto::Dns,
            "socks5" => SniffedProto::Socks5,
            "websocket" | "ws" => SniffedProto::WebSocket,
            "unknown" | "" => SniffedProto::Unknown,
            other => return Err(format!("invalid protocol: '{}'", other)),
        };
    }
    if let Some(src) = params.get("sniff_source") {
        use caly_common::metadata::*;
        meta.sniff_source = match src.as_str() {
            "none" | "" => SNIFF_SRC_NONE,
            "sni" => SNIFF_SRC_SNI,
            "fakeip" => SNIFF_SRC_FAKEIP,
            "dns_snoop" => SNIFF_SRC_DNS_SNOOP,
            "http_host" => SNIFF_SRC_HTTP_HOST,
            "user" => SNIFF_SRC_USER,
            "any" => SNIFF_SRC_ANY,
            other => return Err(format!("invalid sniff_source: '{}'", other)),
        };
    }
    if let Some(proc) = params.get("process") {
        if !proc.is_empty() {
            meta.set_process(proc);
        }
    }
    if let Some(iid) = params.get("inbound_id") {
        if !iid.is_empty() {
            match iid.parse::<u64>() {
                Ok(n) => meta.inbound_tag = n,
                Err(_) => return Err(format!("invalid inbound_id: '{}'", iid)),
            }
        }
    }
    Ok(meta)
}

fn format_explanation_json(
    expl: &caly_rules::RuleExplanation,
    params: &std::collections::HashMap<String, String>,
    elapsed_us: u64,
) -> String {
    let inner = format_explanation_json_no_braces(expl, params, elapsed_us);
    format!("{{{}}}", inner)
}

fn format_explanation_json_no_braces(
    expl: &caly_rules::RuleExplanation,
    params: &std::collections::HashMap<String, String>,
    elapsed_us: u64,
) -> String {
    let condition_json = expl
        .condition
        .as_ref()
        .map(rule_condition_to_json)
        .unwrap_or_else(|| "null".to_string());
    let index_json = expl
        .index
        .map(|i| i.to_string())
        .unwrap_or_else(|| "null".to_string());
    let mut input_parts: Vec<String> = Vec::new();
    for (k, v) in params {
        input_parts.push(format!(r#""{}":"{}""#, k, json_escape(v)));
    }
    input_parts.sort();
    format!(
        r#""kind":"{}","index":{},"condition":{},"outbound":"{}","elapsed_us":{},"input":{{{}}}"#,
        expl.kind.as_str(),
        index_json,
        condition_json,
        json_escape(&expl.outbound),
        elapsed_us,
        input_parts.join(","),
    )
}

fn json_escape(s: &str) -> String {
    let mut out = String::with_capacity(s.len());
    for c in s.chars() {
        match c {
            '"' => out.push_str(r#"\""#),
            '\\' => out.push_str(r#"\\"#),
            '\n' => out.push_str(r#"\n"#),
            '\r' => out.push_str(r#"\r"#),
            '\t' => out.push_str(r#"\t"#),
            c if (c as u32) < 0x20 => {
                out.push_str(&format!(r#"\u{:04x}"#, c as u32));
            }
            c => out.push(c),
        }
    }
    out
}

#[cfg(test)]
mod url_decode_tests {
    use super::url_decode;

    #[test]
    fn test_ascii_basic() {
        assert_eq!(url_decode("hello"), "hello");
        assert_eq!(url_decode("a+b"), "a b");
        assert_eq!(url_decode("a%20b"), "a b");
    }

    #[test]
    fn test_utf8_multibyte() {
        // "中" = E4 B8 AD
        assert_eq!(url_decode("%E4%B8%AD"), "中");
        // "中文.com"
        assert_eq!(url_decode("%E4%B8%AD%E6%96%87.com"), "中文.com");
        // "例え.jp"
        assert_eq!(
            url_decode("%E4%BE%8B%E3%81%88.jp"),
            "例え.jp",
        );
    }

    #[test]
    fn test_percent_literal() {
        assert_eq!(url_decode("100%25"), "100%");
        // 不完整的 % 序列保留原文
        assert_eq!(url_decode("abc%"), "abc%");
        assert_eq!(url_decode("abc%X"), "abc%X");
        assert_eq!(url_decode("abc%1"), "abc%1");
    }

    #[test]
    fn test_invalid_utf8_replaced() {
        // 0xFF 不是合法 UTF-8 起始字节 → lossy 替换为 U+FFFD
        let s = url_decode("%FF");
        assert!(s.contains('\u{FFFD}'));
    }

    #[test]
    fn fuzz_no_panic() {
        // 内联 xorshift，避免引入 rand 依赖
        struct XorShift64(u64);
        impl XorShift64 {
            fn next(&mut self) -> u64 {
                let mut x = self.0;
                x ^= x << 13;
                x ^= x >> 7;
                x ^= x << 17;
                self.0 = x;
                x
            }
        }
        let mut rng = XorShift64(0x00C4_1D00_DEC0_0001);
        for _ in 0..20_000 {
            let len = (rng.next() as usize) % 96;
            let mut bytes = vec![0u8; len];
            for b in bytes.iter_mut() {
                *b = (rng.next() & 0xFF) as u8;
            }
            let s = String::from_utf8_lossy(&bytes);
            let _ = url_decode(&s);
        }
    }
}
