//! Atomic bitmap Fake-IP allocator with DashMap reverse index.

use caly_common::error::DnsError;
use dashmap::DashMap;
use parking_lot::Mutex;
use smol_str::SmolStr;
use std::net::{IpAddr, Ipv4Addr};
use std::sync::atomic::{AtomicU64, AtomicUsize, Ordering};
use std::time::{Duration, Instant};

struct ReverseEntry {
    domain: SmolStr,
    expires_at: Instant,
}

pub struct FakeIpPool {
    bitmap: Box<[AtomicU64]>,
    reverse_map: DashMap<u32, ReverseEntry>,
    domain_to_idx: DashMap<SmolStr, u32>,
    free_list: Mutex<Vec<u32>>,
    free_list_len: AtomicUsize,
    next_hint: AtomicU64,
    capacity: u32,
    base_addr: u32,
    ttl: Duration,
}

impl Default for FakeIpPool {
    fn default() -> Self {
        Self::new(Duration::from_secs(300))
    }
}

impl FakeIpPool {
    pub fn new(ttl: Duration) -> Self {
        Self::new_with_range(Ipv4Addr::new(198, 18, 0, 0), 15, ttl)
    }

    pub fn new_with_range(network: Ipv4Addr, prefix_len: u8, ttl: Duration) -> Self {
        const MAX_CAPACITY: u32 = 1 << 22;
        let prefix_len = prefix_len.clamp(1, 30);
        let total: u64 = 1u64 << (32 - prefix_len as u64);
        let usable = total.saturating_sub(2).max(1);
        let capacity = usable.min(MAX_CAPACITY as u64) as u32;
        let words = (capacity as usize).div_ceil(64);
        let mut bitmap_vec = Vec::with_capacity(words);
        for _ in 0..words {
            bitmap_vec.push(AtomicU64::new(0));
        }
        let base_addr = u32::from(network).wrapping_add(1);

        Self {
            bitmap: bitmap_vec.into_boxed_slice(),
            reverse_map: DashMap::with_capacity(2048),
            domain_to_idx: DashMap::with_capacity(2048),
            free_list: Mutex::new(Vec::with_capacity(256)),
            free_list_len: AtomicUsize::new(0),
            next_hint: AtomicU64::new(0),
            capacity,
            base_addr,
            ttl,
        }
    }

    pub fn allocate(&self, domain: &str) -> Result<IpAddr, DnsError> {
        let domain_str = SmolStr::new(domain.to_ascii_lowercase());
        // [FIXED] 存在已有映射时直接就地续期 TTL，保持映射单调与连接平滑
        if let Some(idx) = self.domain_to_idx.get(&domain_str).map(|r| *r.value()) {
            if let Some(mut entry) = self.reverse_map.get_mut(&idx) {
                entry.expires_at = Instant::now() + self.ttl;
                return Ok(self.index_to_ip(idx));
            }
        }

        if self.free_list_len.load(Ordering::Acquire) > 0 {
            if let Some(idx) = self.pop_free_list_verified() {
                return Ok(self.install(idx, &domain_str));
            }
        }

        let hint = self.next_hint.load(Ordering::Relaxed) as u32;
        if hint < self.capacity && self.try_set_bit(hint) {
            let next = ((hint as u64) + 1) % (self.capacity as u64);
            self.next_hint.store(next, Ordering::Relaxed);
            return Ok(self.install(hint, &domain_str));
        }

        let start = self.next_hint.load(Ordering::Relaxed) % (self.capacity as u64);
        for i in 0..self.capacity {
            let idx = ((start + i as u64) % (self.capacity as u64)) as u32;
            if self.try_set_bit(idx) {
                self.next_hint.store(
                    ((idx as u64) + 1) % (self.capacity as u64),
                    Ordering::Relaxed,
                );
                return Ok(self.install(idx, &domain_str));
            }
        }

        self.garbage_collect();
        if let Some(idx) = self.pop_free_list_verified() {
            return Ok(self.install(idx, &domain_str));
        }
        Err(DnsError::FakeIpExhausted)
    }

    #[inline]
    fn pop_free_list_verified(&self) -> Option<u32> {
        loop {
            let popped = {
                let mut fl = self.free_list.lock();
                let p = fl.pop();
                if p.is_some() {
                    self.free_list_len.fetch_sub(1, Ordering::AcqRel);
                }
                p
            };
            let idx = popped?;
            if self.try_set_bit(idx) {
                return Some(idx);
            }
        }
    }

    #[inline]
    fn install(&self, idx: u32, domain: &SmolStr) -> IpAddr {
        let ip = self.index_to_ip(idx);
        let expires_at = Instant::now() + self.ttl;
        self.reverse_map.insert(
            idx,
            ReverseEntry {
                domain: domain.clone(),
                expires_at,
            },
        );
        self.domain_to_idx.insert(domain.clone(), idx);
        ip
    }

    pub fn lookup(&self, ip: IpAddr) -> Option<SmolStr> {
        let idx = self.ip_to_index(ip)?;
        let entry = self.reverse_map.get(&idx)?;
        if Instant::now() < entry.expires_at {
            Some(entry.domain.clone())
        } else {
            None
        }
    }

    pub fn release(&self, ip: IpAddr) {
        if let Some(idx) = self.ip_to_index(ip) {
            if let Some((_, entry)) = self.reverse_map.remove(&idx) {
                self.domain_to_idx.remove(&entry.domain);
            }
            self.clear_bit(idx);
            self.free_list.lock().push(idx);
            self.free_list_len.fetch_add(1, Ordering::AcqRel);
        }
    }

    pub fn garbage_collect(&self) {
        let now = Instant::now();
        let mut expired: Vec<(u32, SmolStr)> = Vec::new();
        for entry in self.reverse_map.iter() {
            if now >= entry.value().expires_at {
                expired.push((*entry.key(), entry.value().domain.clone()));
            }
        }
        if expired.is_empty() {
            return;
        }
        let mut reclaimed: Vec<u32> = Vec::with_capacity(expired.len());
        // [FIXED] 仅当 domain_to_idx 存储的依然是当前已过期的 idx 时才允许级联删除
        for (idx, domain) in expired {
            self.reverse_map.remove(&idx);
            if let Some(current_idx) = self.domain_to_idx.get(&domain) {
                if *current_idx.value() == idx {
                    drop(current_idx);
                    self.domain_to_idx.remove(&domain);
                }
            }
            self.clear_bit(idx);
            reclaimed.push(idx);
        }

        let n = reclaimed.len();
        let mut fl = self.free_list.lock();
        fl.extend(reclaimed);
        drop(fl);
        self.free_list_len.fetch_add(n, Ordering::AcqRel);
    }

    pub fn allocated(&self) -> usize {
        self.reverse_map.len()
    }

    pub fn capacity(&self) -> u32 {
        self.capacity
    }

    pub fn free_count(&self) -> usize {
        self.free_list.lock().len()
    }

    #[inline]
    fn try_set_bit(&self, idx: u32) -> bool {
        let word_idx = (idx / 64) as usize;
        let bit_idx = idx % 64;
        let mask = 1u64 << bit_idx;
        let word = &self.bitmap[word_idx];
        let prev = word.fetch_or(mask, Ordering::AcqRel);
        (prev & mask) == 0
    }

    #[inline]
    fn clear_bit(&self, idx: u32) {
        let word_idx = (idx / 64) as usize;
        let bit_idx = idx % 64;
        let mask = !(1u64 << bit_idx);
        self.bitmap[word_idx].fetch_and(mask, Ordering::AcqRel);
    }

    #[inline]
    fn index_to_ip(&self, idx: u32) -> IpAddr {
        IpAddr::V4(Ipv4Addr::from(self.base_addr.wrapping_add(idx)))
    }

    #[inline]
    fn ip_to_index(&self, ip: IpAddr) -> Option<u32> {
        match ip {
            IpAddr::V4(v4) => {
                let addr = u32::from(v4);
                if addr >= self.base_addr && addr < self.base_addr + self.capacity {
                    Some(addr - self.base_addr)
                } else {
                    None
                }
            }
            IpAddr::V6(_) => None,
        }
    }
}
