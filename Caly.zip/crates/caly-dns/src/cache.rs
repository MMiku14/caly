//! Sharded lock-partitioned LRU cache with case-insensitive hashing, leak-free queue, and optimistic background refresh.

use parking_lot::Mutex;
use smallvec::SmallVec;
use smol_str::SmolStr;
use std::collections::{HashMap, VecDeque};
use std::net::IpAddr;
use std::time::{Duration, Instant};

const SHARD_COUNT: usize = 16;
const DEFAULT_SHARD_CAPACITY: usize = 1024;
const DEFAULT_OPTIMISTIC_TTL: Duration = Duration::from_secs(60);

#[derive(Debug, Clone)]
pub struct CacheEntry {
    pub ips: SmallVec<[IpAddr; 2]>,
    pub expires_at: Instant,
    pub optimistic_until: Instant,
    pub refreshing: bool,
    pub last_accessed: Instant,
}

impl CacheEntry {
    #[inline]
    pub fn is_fresh(&self) -> bool {
        Instant::now() < self.expires_at
    }

    #[inline]
    pub fn is_usable_optimistic(&self) -> bool {
        Instant::now() < self.optimistic_until
    }
}

struct LruShard {
    entries: HashMap<SmolStr, CacheEntry>,
    ip_to_domain: HashMap<IpAddr, SmolStr>,
    lru_queue: VecDeque<SmolStr>,
    capacity: usize,
    optimistic_ttl: Duration,
}

impl LruShard {
    fn new_with_optimistic_ttl(capacity: usize, optimistic_ttl: Duration) -> Self {
        Self {
            entries: HashMap::with_capacity(capacity),
            ip_to_domain: HashMap::with_capacity(capacity),
            lru_queue: VecDeque::with_capacity(capacity),
            capacity,
            optimistic_ttl,
        }
    }

    fn get(&mut self, domain: &str) -> Option<(CacheEntry, bool)> {
        let entry = self.entries.get_mut(domain)?;
        let now = Instant::now();
        entry.last_accessed = now;
        if now < entry.expires_at {
            Some((entry.clone(), false))
        } else if now < entry.optimistic_until {
            let should_refresh = !entry.refreshing;
            if should_refresh {
                entry.refreshing = true;
            }
            Some((entry.clone(), should_refresh))
        } else {
            None
        }
    }

    fn put(&mut self, domain: &str, ips: &[IpAddr], ttl: Duration) {
        let key = SmolStr::new(domain);
        if let Some(old_entry) = self.entries.get(&key) {
            for ip in &old_entry.ips {
                self.ip_to_domain.remove(ip);
            }
        } else {
            let mut pass = 0;
            while self.entries.len() >= self.capacity && pass < 32 {
                if let Some(candidate) = self.lru_queue.pop_front() {
                    if let Some(entry) = self.entries.get(&candidate) {
                        let now = Instant::now();
                        if now.duration_since(entry.last_accessed) < Duration::from_secs(30) && pass < 16 {
                            self.lru_queue.push_back(candidate);
                            pass += 1;
                            continue;
                        }
                        if let Some(evicted) = self.entries.remove(&candidate) {
                            for ip in &evicted.ips {
                                self.ip_to_domain.remove(ip);
                            }
                            break;
                        }
                    }
                } else {
                    break;
                }
            }
            self.lru_queue.push_back(key.clone());
        }
        let mut ip_vec = SmallVec::new();
        for &ip in ips {
            ip_vec.push(ip);
            self.ip_to_domain.insert(ip, key.clone());
        }
        let now = Instant::now();
        self.entries.insert(
            key,
            CacheEntry {
                ips: ip_vec,
                expires_at: now + ttl,
                optimistic_until: now + ttl + self.optimistic_ttl,
                refreshing: false,
                last_accessed: now,
            },
        );
    }

    fn find_by_ip(&self, ip: IpAddr) -> Option<SmolStr> {
        self.ip_to_domain.get(&ip).cloned()
    }

    fn mark_refresh_done(&mut self, domain: &str) {
        if let Some(entry) = self.entries.get_mut(domain) {
            entry.refreshing = false;
        }
    }
}

pub struct ShardedCache {
    shards: [Mutex<LruShard>; SHARD_COUNT],
}

impl Default for ShardedCache {
    fn default() -> Self {
        Self::new(DEFAULT_SHARD_CAPACITY)
    }
}

impl ShardedCache {
    pub fn new(capacity_per_shard: usize) -> Self {
        Self::new_with_options(capacity_per_shard, DEFAULT_OPTIMISTIC_TTL)
    }

    pub fn new_with_options(capacity_per_shard: usize, optimistic_ttl: Duration) -> Self {
        Self {
            shards: std::array::from_fn(|_| {
                Mutex::new(LruShard::new_with_optimistic_ttl(
                    capacity_per_shard,
                    optimistic_ttl,
                ))
            }),
        }
    }

    #[inline]
    fn shard_for(&self, canonical_domain: &str) -> usize {
        let mut hash: u64 = 0xcbf29ce484222325;
        for byte in canonical_domain.bytes() {
            hash ^= byte as u64;
            hash = hash.wrapping_mul(0x100000001b3);
        }
        (hash as usize) % SHARD_COUNT
    }

    #[inline]
    fn normalize_domain(domain: &str) -> String {
        let trimmed = domain.trim().trim_end_matches('.');
        if trimmed.bytes().any(|b| b.is_ascii_uppercase()) {
            trimmed.to_ascii_lowercase()
        } else {
            trimmed.to_string()
        }
    }

    pub fn get(&self, domain: &str) -> Option<(CacheEntry, bool)> {
        let canonical = Self::normalize_domain(domain);
        let shard_idx = self.shard_for(&canonical);
        self.shards[shard_idx].lock().get(&canonical)
    }

    pub fn put(&self, domain: &str, ips: &[IpAddr], ttl: Duration) {
        let canonical = Self::normalize_domain(domain);
        let shard_idx = self.shard_for(&canonical);
        self.shards[shard_idx].lock().put(&canonical, ips, ttl);
    }

    pub fn find_by_ip(&self, ip: IpAddr) -> Option<SmolStr> {
        for shard in &self.shards {
            if let Some(domain) = shard.lock().find_by_ip(ip) {
                return Some(domain);
            }
        }
        None
    }

    pub fn mark_refresh_done(&self, domain: &str) {
        let canonical = Self::normalize_domain(domain);
        let shard_idx = self.shard_for(&canonical);
        self.shards[shard_idx].lock().mark_refresh_done(&canonical);
    }

    pub fn clear_all(&self) -> usize {
        let mut total = 0usize;
        for shard in &self.shards {
            let mut s = shard.lock();
            total += s.entries.len();
            s.entries.clear();
            s.ip_to_domain.clear();
            s.lru_queue.clear();
        }
        total
    }
}
