//! DNS Snooping cache matching resolved IPs to domains.

use dashmap::DashMap;
use smol_str::SmolStr;
use std::net::IpAddr;
use std::sync::atomic::{AtomicUsize, Ordering};
use std::time::{Duration, Instant};

struct SnoopRecord {
    domain: SmolStr,
    expires_at: Instant,
}

const MAX_ENTRIES: usize = 16_384;
const EVICT_THRESHOLD: usize = 12_288;

pub struct DnsSnooper {
    records: DashMap<(IpAddr, u16), SnoopRecord>,
    ttl: Duration,
    evictions: AtomicUsize,
}

impl Default for DnsSnooper {
    fn default() -> Self {
        Self::new(Duration::from_secs(600))
    }
}

impl DnsSnooper {
    pub fn new(ttl: Duration) -> Self {
        Self {
            records: DashMap::with_capacity(1024),
            ttl,
            evictions: AtomicUsize::new(0),
        }
    }

    pub fn record(&self, ip: IpAddr, port: u16, domain: &str) {
        let now = Instant::now();
        let len = self.records.len();
        if len >= EVICT_THRESHOLD {
            self.evict_expired();
            if self.records.len() >= MAX_ENTRIES {
                self.evict_to_capacity();
            }
        }
        self.records.insert(
            (ip, port),
            SnoopRecord {
                domain: SmolStr::new(domain),
                expires_at: now + self.ttl,
            },
        );
    }

    pub fn lookup(&self, ip: IpAddr, port: u16) -> Option<SmolStr> {
        let now = Instant::now();
        if let Some(entry) = self.records.get(&(ip, port)) {
            if now < entry.expires_at {
                return Some(entry.domain.clone());
            }
        }
        if port != 0 {
            if let Some(entry) = self.records.get(&(ip, 0)) {
                if now < entry.expires_at {
                    return Some(entry.domain.clone());
                }
            }
        }
        None
    }

    pub fn evict_expired(&self) {
        let now = Instant::now();
        self.records.retain(|_, v| now < v.expires_at);
    }

    fn evict_to_capacity(&self) {
        let target = EVICT_THRESHOLD * 3 / 4;
        let mut removed = 0usize;
        let keys_to_remove: Vec<_> = self
            .records
            .iter()
            .take(MAX_ENTRIES - target)
            .map(|e| *e.key())
            .collect();
        for k in keys_to_remove {
            if self.records.remove(&k).is_some() {
                removed += 1;
            }
        }
        self.evictions.fetch_add(removed, Ordering::Relaxed);
    }

    pub fn len(&self) -> usize {
        self.records.len()
    }

    pub fn is_empty(&self) -> bool {
        self.records.is_empty()
    }

    pub fn evictions(&self) -> usize {
        self.evictions.load(Ordering::Relaxed)
    }

    pub fn clear_all(&self) -> usize {
        let n = self.records.len();
        self.records.clear();
        n
    }
}
