//! Singleflight concurrency deduplicator with atomic leader cleanup and broadcast.

use caly_common::dns::DnsError;
use dashmap::mapref::entry::Entry;
use dashmap::DashMap;
use smol_str::SmolStr;
use std::future::Future;
use std::net::IpAddr;
use std::sync::Arc;
use std::time::Duration;
use tokio::sync::broadcast;

pub type FlightResult = Result<(Vec<IpAddr>, Duration), DnsError>;

#[derive(Clone, Default)]
pub struct Singleflight {
    in_flight: Arc<DashMap<SmolStr, broadcast::Sender<FlightResult>>>,
}

enum CallState {
    Leader,
    Follower(broadcast::Receiver<FlightResult>),
}

impl Singleflight {
    pub fn new() -> Self {
        Self {
            in_flight: Arc::new(DashMap::with_capacity(256)),
        }
    }

    pub async fn execute<F, Fut>(
        &self,
        domain: &str,
        fut: F,
    ) -> Result<(Vec<IpAddr>, Duration), DnsError>
    where
        F: FnOnce() -> Fut + Send,
        Fut: Future<Output = FlightResult> + Send,
    {
        let key = SmolStr::new(domain);
        let call_state = match self.in_flight.entry(key.clone()) {
            Entry::Occupied(e) => CallState::Follower(e.get().subscribe()),
            Entry::Vacant(e) => {
                let (tx, _rx) = broadcast::channel(32);
                e.insert(tx);
                CallState::Leader
            }
        };

        match call_state {
            CallState::Leader => {
                struct LeaderCleanupGuard<'a> {
                    sf: &'a Singleflight,
                    key: &'a SmolStr,
                }
                impl Drop for LeaderCleanupGuard<'_> {
                    fn drop(&mut self) {
                        if let Some((_, tx)) = self.sf.in_flight.remove(self.key) {
                            drop(tx);
                        }
                    }
                }
                let guard = LeaderCleanupGuard { sf: self, key: &key };
                let res = fut().await;
                if let Some(entry) = self.in_flight.get(&key) {
                    let _ = entry.value().send(res.clone());
                }
                drop(guard);
                res
            }
            CallState::Follower(mut rx) => match rx.recv().await {
                Ok(res) => res,
                Err(broadcast::error::RecvError::Lagged(_)) => fut().await,
                Err(_) => Err(DnsError::Timeout(domain.to_string())),
            },
        }
    }

    pub fn in_flight_count(&self) -> usize {
        self.in_flight.len()
    }
}
