//! DNS resolution, sharded caching, singleflight deduplication, and Fake-IP virtual pool management.

pub mod cache;
pub mod fakeip;
pub mod resolver;
pub mod singleflight;
pub mod snooping;
pub mod upstream;

pub use cache::ShardedCache;
pub use fakeip::FakeIpPool;
pub use resolver::DnsResolverImpl;
pub use singleflight::Singleflight;
pub use snooping::DnsSnooper;
pub use upstream::UpstreamServer;
