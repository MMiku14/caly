//! Upstream DNS server communication with connection-pooled UDP sockets, EDNS0, and TCP fallback.

use caly_common::dns::DnsError;
use caly_transport::tls::{TlsConnectorLayer, TlsStream};
use parking_lot::Mutex;
use std::net::{IpAddr, Ipv4Addr, Ipv6Addr, SocketAddr};
use std::sync::Arc;
use std::time::Duration;
use tokio::io::{AsyncReadExt, AsyncWriteExt};
use tokio::net::{TcpStream, UdpSocket};
use tokio::time::timeout;

const MAX_IDLE_SOCKETS: usize = 32;

#[derive(Debug)]
pub struct UdpSocketPool {
    addr: SocketAddr,
    idle: Mutex<Vec<Arc<UdpSocket>>>,
}

impl UdpSocketPool {
    pub fn new(addr: SocketAddr) -> Arc<Self> {
        Arc::new(Self {
            addr,
            idle: Mutex::new(Vec::new()),
        })
    }

    pub async fn acquire(self: &Arc<Self>) -> Result<PooledSocket, DnsError> {
        if let Some(s) = self.idle.lock().pop() {
            // Drain any pending stale packets from prior queries
            let mut drain_buf = [0u8; 1500];
            while s.try_recv(&mut drain_buf).is_ok() {}
            return Ok(PooledSocket {
                pool: self.clone(),
                socket: Some(s),
            });
        }
        let bind_addr: SocketAddr = if self.addr.is_ipv4() {
            SocketAddr::new(IpAddr::V4(Ipv4Addr::UNSPECIFIED), 0)
        } else {
            SocketAddr::new(IpAddr::V6(Ipv6Addr::UNSPECIFIED), 0)
        };
        let socket = UdpSocket::bind(bind_addr)
            .await
            .map_err(|e| DnsError::UpstreamFailed(format!("UDP bind: {e}")))?;
        socket
            .connect(self.addr)
            .await
            .map_err(|e| DnsError::UpstreamFailed(format!("UDP connect: {e}")))?;
        Ok(PooledSocket {
            pool: self.clone(),
            socket: Some(Arc::new(socket)),
        })
    }

    fn release(&self, socket: Arc<UdpSocket>) {
        let mut idle = self.idle.lock();
        if idle.len() < MAX_IDLE_SOCKETS {
            idle.push(socket);
        }
    }
}

pub struct PooledSocket {
    pool: Arc<UdpSocketPool>,
    socket: Option<Arc<UdpSocket>>,
}

impl PooledSocket {
    #[inline]
    pub fn socket(&self) -> &UdpSocket {
        self.socket.as_ref().expect("socket already released").as_ref()
    }
}

impl Drop for PooledSocket {
    fn drop(&mut self) {
        if let Some(s) = self.socket.take() {
            self.pool.release(s);
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub enum DnsStrategy {
    #[default]
    PreferIpv4,
    PreferIpv6,
    Ipv4Only,
    Ipv6Only,
}

impl std::str::FromStr for DnsStrategy {
    type Err = ();
    fn from_str(s: &str) -> Result<Self, Self::Err> {
        match s {
            "prefer_ipv4" => Ok(Self::PreferIpv4),
            "prefer_ipv6" => Ok(Self::PreferIpv6),
            "ipv4_only" => Ok(Self::Ipv4Only),
            "ipv6_only" => Ok(Self::Ipv6Only),
            _ => Err(()),
        }
    }
}

impl DnsStrategy {
    #[inline]
    pub fn from_str_opt(s: &str) -> Option<Self> {
        s.parse().ok()
    }
}

const QTYPE_A: u16 = 0x0001;
const QTYPE_AAAA: u16 = 0x001C;

/// DNS 传输类型。
///
/// 决定 `query_inner` 如何发出查询：
///   - `Udp`：明文 UDP，TC=1 时回退明文 TCP（默认，向后兼容）
///   - `Tcp`：直接走明文 TCP（未从配置暴露，为未来使用预留）
///   - `Tls`：DoT（RFC 7858），TLS over TCP + 2 字节长度前缀
#[derive(Debug, Clone)]
pub enum DnsTransportKind {
    Udp,
    Tcp,
    Tls { sni: String },
}

/// DoT 连接池的最大空闲连接数（每个上游）。
///
/// DNS 查询本身很快（< 100ms），并发度通常不高。4 个空闲连接足以
/// 应对稳态负载。压力过后多余连接被丢弃（不归还），避免资源堆积。
const DOT_MAX_IDLE_CONNS: usize = 4;

/// 空闲连接的最长存活时间。
///
/// 超过此时间的空闲连接被认为"可能已失效"，下次 acquire 时直接丢弃
/// 并新建。30 秒是保守值——公共 DoT 服务（Cloudflare / Google）
/// 通常保持连接数分钟，但保守处理避免用失效连接发出查询。
const DOT_MAX_IDLE_AGE: Duration = Duration::from_secs(30);

/// DoT 池的并发查询上限（每个上游）。
///
/// 无上限会导致：100 个并发查询 → 100 个 TCP+TLS 连接 → 打爆上游
/// 服务器 / 耗尽本机文件描述符。
///
/// 16 是经验值：
///   - 单个 DoT 服务器的 QPS 瓶颈通常是 TLS 握手（~100ms）
///   - 16 个并发 × 10 QPS/TLS ≈ 160 QPS 稳态
///   - 超过此值的请求会在 `acquire()` 里排队，不阻塞其他上游
const DOT_MAX_CONCURRENT: usize = 16;

/// 池中的一条空闲连接。
struct IdleConn {
    stream: TlsStream<TcpStream>,
    idle_since: std::time::Instant,
}

/// DoT 连接池。每个 DoT 上游一个实例，通过 `Arc` 共享。
///
/// 关键约束：
/// - **不可并发复用**：DoT 一个连接上多个查询的响应会交错，
///   必须序列化使用。RAII handle 保证同一时刻只有一个查询持有连接。
/// - **失效检测**：池中超过 `DOT_MAX_IDLE_AGE` 的空闲连接被丢弃。
///   主动探测（心跳）开销大于收益，不做。
/// - **池满即丢**：归还时若池已满，连接被 drop（等价于关闭）。
struct DotConnectionPool {
    addr: SocketAddr,
    sni: String,
    layer: Arc<TlsConnectorLayer>,
    idle: Mutex<Vec<IdleConn>>,
    /// 并发查询上限。`acquire()` 先拿许可再取/建连接；
    /// `PooledDotConn::drop` 释放许可。超额请求在 `acquire()` 内排队，
    /// 而非阻塞 tokio worker（`Semaphore::acquire_owned` 是异步的）。
    concurrency: Arc<tokio::sync::Semaphore>,
}

impl DotConnectionPool {
    fn new(addr: SocketAddr, sni: String, layer: Arc<TlsConnectorLayer>) -> Arc<Self> {
        Arc::new(Self {
            addr,
            sni,
            layer,
            idle: Mutex::new(Vec::new()),
            concurrency: Arc::new(tokio::sync::Semaphore::new(DOT_MAX_CONCURRENT)),
        })
    }

    /// 取一个 TLS 连接：优先复用空闲的，否则新建。
    ///
    /// 返回的 handle 在 drop 时归还连接（除非显式 `poison`）。
    async fn acquire(self: &Arc<Self>) -> Result<PooledDotConn, DnsError> {
        // 先获取并发许可。超额请求在此排队，而非无限制开连接。
        // `acquire_owned` 返回 `Err` 只在 Semaphore 被 close 时发生——
        // 我们从不对其 close，因此该分支实际不可达。
        let permit = self
            .concurrency
            .clone()
            .acquire_owned()
            .await
            .map_err(|_| {
                DnsError::UpstreamFailed(
                    "DoT pool semaphore closed unexpectedly".to_string(),
                )
            })?;

        // 1. 尝试复用空闲连接
        if let Some(stream) = self.take_idle() {
            return Ok(PooledDotConn {
                pool: self.clone(),
                _permit: permit,
                stream: Some(stream),
            });
        }

        // 2. 新建
        let tcp = timeout(Duration::from_millis(3000), TcpStream::connect(self.addr))
            .await
            .map_err(|_| {
                DnsError::Timeout(format!("DoT TCP connect to {} timed out", self.addr))
            })?
            .map_err(|e| DnsError::UpstreamFailed(format!("DoT TCP connect: {e}")))?;

        let stream = timeout(
            Duration::from_millis(5000),
            self.layer.handshake(&self.sni, tcp),
        )
        .await
        .map_err(|_| {
            DnsError::Timeout(format!("DoT TLS handshake to {} timed out", self.addr))
        })?
        .map_err(|e| DnsError::UpstreamFailed(format!("DoT TLS handshake: {e}")))?;

        Ok(PooledDotConn {
            pool: self.clone(),
            _permit: permit,
            stream: Some(stream),
        })
    }

    /// 从空闲列表弹出一个未过期的连接。
    ///
    /// 循环弹出：遇过期项直接丢弃（drop），直到找到未过期的或池空。
    fn take_idle(&self) -> Option<TlsStream<TcpStream>> {
        let now = std::time::Instant::now();
        let mut idle = self.idle.lock();
        while let Some(conn) = idle.pop() {
            if now.duration_since(conn.idle_since) < DOT_MAX_IDLE_AGE {
                return Some(conn.stream);
            }
            // 过期：drop 后继续尝试下一个
        }
        None
    }

    fn release(&self, stream: TlsStream<TcpStream>) {
        let mut idle = self.idle.lock();
        if idle.len() < DOT_MAX_IDLE_CONNS {
            idle.push(IdleConn {
                stream,
                idle_since: std::time::Instant::now(),
            });
        }
        // 超出上限：drop，连接随之关闭
    }
}

/// 从 DoT 池借出的连接。drop 时自动归还（除非已 `poison`）。
struct PooledDotConn {
    pool: Arc<DotConnectionPool>,
    /// 并发许可。随 handle 一起 drop，释放并发名额。
    ///
    /// 字段顺序有意义：Drop 时先 drop `stream`（自定义 Drop impl 走完），
    /// 再按声明顺序 drop `_permit`。实际上两者顺序无关紧要，但显式声明
    /// permit 在 stream 之后可读性更好。
    _permit: tokio::sync::OwnedSemaphorePermit,
    stream: Option<TlsStream<TcpStream>>,
}

impl PooledDotConn {
    #[inline]
    fn stream_mut(&mut self) -> &mut TlsStream<TcpStream> {
        self.stream
            .as_mut()
            .expect("PooledDotConn invariant: stream must be Some")
    }

    /// 标记连接为"已损坏"，drop 时不归还池。
    ///
    /// 用于查询过程中遭遇 I/O 错误时——此时连接大概率已失效，归还到
    /// 池中会让下一次查询也失败。
    #[inline]
    fn poison(&mut self) {
        self.stream.take();
    }
}

impl Drop for PooledDotConn {
    fn drop(&mut self) {
        if let Some(s) = self.stream.take() {
            self.pool.release(s);
        }
    }
}

pub struct UpstreamServer {
    pub tag: String,
    pub addr: SocketAddr,
    pub detour: Option<String>,
    pub strategy: DnsStrategy,
    pub transport: DnsTransportKind,
    udp_pool: Arc<UdpSocketPool>,
    /// 仅在 `transport == Tls { .. }` 时使用。
    ///
    /// `None` 表示 TLS 层初始化失败——此时 DoT 查询会返回明确的
    /// `UpstreamFailed` 错误，而不是静默降级到明文。
    tls_layer: Option<Arc<TlsConnectorLayer>>,
    /// DoT 连接池。与 `tls_layer` 生命周期同步：
    /// `tls_layer == Some(_)` 时 `dot_pool == Some(_)`。
    dot_pool: Option<Arc<DotConnectionPool>>,
}

/// 手写 Debug：`TlsConnectorLayer` 内部的 `tokio_rustls::TlsConnector`
/// 未实现 `Debug`，无法 derive。此处跳过 `tls_layer` 和 `udp_pool`，
/// 只打印诊断关心的字段。
impl std::fmt::Debug for UpstreamServer {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("UpstreamServer")
            .field("tag", &self.tag)
            .field("addr", &self.addr)
            .field("detour", &self.detour)
            .field("strategy", &self.strategy)
            .field("transport", &self.transport)
            .finish_non_exhaustive()
    }
}

impl Clone for UpstreamServer {
    fn clone(&self) -> Self {
        Self {
            tag: self.tag.clone(),
            addr: self.addr,
            detour: self.detour.clone(),
            strategy: self.strategy,
            transport: self.transport.clone(),
            udp_pool: self.udp_pool.clone(),
            tls_layer: self.tls_layer.clone(),
            dot_pool: self.dot_pool.clone(),
        }
    }
}

impl UpstreamServer {
    pub fn new(tag: &str, addr: SocketAddr) -> Self {
        Self::new_with_strategy(tag, addr, DnsStrategy::default(), None)
    }

    /// 指定策略和 detour 的构造。
    ///
    /// `detour`：可选的出站 tag。非 `None` 时，DNS 查询**应当**通过该
    /// 出站发送（而非直接 UDP），以支持 "DNS over proxy" 场景。
    ///
    /// **当前仅记录此信息，尚未实现路由**。真正的 detour 路由需要
    /// caly-dns → caly-outbound 的依赖倒置（caly-dns 不应直接依赖
    /// caly-outbound）。由后续轮次实现。记录它的意义：
    ///   1. 用户配了 `dns.servers[].detour` 时，日志会明确提示
    ///      "detour 已配置但尚未生效"，避免用户误以为生效
    ///   2. 未来实现时数据通路已就绪
    pub fn new_with_strategy(
        tag: &str,
        addr: SocketAddr,
        strategy: DnsStrategy,
        detour: Option<String>,
    ) -> Self {
        if let Some(ref d) = detour {
            if !d.is_empty() && d != "direct" {
                tracing::debug!(
                    tag = %tag,
                    detour = %d,
                    "DNS detour configured but routing not yet implemented; \
                     queries will go direct"
                );
            }
        }
        Self {
            tag: tag.to_string(),
            addr,
            detour,
            strategy,
            transport: DnsTransportKind::Udp,
            udp_pool: UdpSocketPool::new(addr),
            tls_layer: None,
            dot_pool: None,
        }
    }

    /// 构造 DoT（DNS over TLS）上游。
    ///
    /// `sni` 为空时，使用 `addr.ip().to_string()` 作为 SNI。
    /// 对公共 DoT 服务（如 `1.1.1.1:853`、`8.8.8.8:853`），
    /// 空 SNI 在多数场景可用，但**强烈建议显式指定**——部分服务
    /// 对 SNI 有校验。
    pub fn new_dot(
        tag: &str,
        addr: SocketAddr,
        sni: &str,
        strategy: DnsStrategy,
        detour: Option<String>,
    ) -> Self {
        let sni_effective = if sni.is_empty() {
            addr.ip().to_string()
        } else {
            sni.to_string()
        };

        let tls_layer = match TlsConnectorLayer::new() {
            Ok(layer) => Some(Arc::new(layer)),
            Err(e) => {
                tracing::error!(
                    tag = %tag,
                    error = %e,
                    "failed to initialize TLS layer for DoT;                      this upstream will return errors on every query"
                );
                None
            }
        };

        // dot_pool 与 tls_layer 同生命周期。TLS 层构造失败时池也
        // 是 None——query_tls 会返回明确错误。
        let dot_pool = tls_layer
            .as_ref()
            .map(|layer| DotConnectionPool::new(addr, sni_effective.clone(), layer.clone()));

        Self {
            tag: tag.to_string(),
            addr,
            detour,
            strategy,
            transport: DnsTransportKind::Tls { sni: sni_effective },
            udp_pool: UdpSocketPool::new(addr),
            tls_layer,
            dot_pool,
        }
    }

    pub async fn query_by_strategy(
        &self,
        domain: &str,
    ) -> Result<(Vec<IpAddr>, Duration), DnsError> {
        match self.strategy {
            DnsStrategy::Ipv4Only => self.query_inner(domain, QTYPE_A).await,
            DnsStrategy::Ipv6Only => self.query_inner(domain, QTYPE_AAAA).await,
            DnsStrategy::PreferIpv4 => match self.query_inner(domain, QTYPE_A).await {
                Ok(r) => Ok(r),
                Err(e) => {
                    // NXDOMAIN（NotFound）：域名整体不存在。查 AAAA 也会
                    // 得到同一个 NXDOMAIN。直接返回，避免无意义的第二次
                    // 查询（白等 2.5 秒超时，也浪费上游配额）。
                    if matches!(e, DnsError::NotFound(_)) {
                        return Err(e);
                    }
                    tracing::debug!(
                        tag = %self.tag, domain, error = %e,
                        "A query failed; falling back to AAAA"
                    );
                    self.query_inner(domain, QTYPE_AAAA).await
                }
            },
            DnsStrategy::PreferIpv6 => match self.query_inner(domain, QTYPE_AAAA).await {
                Ok(r) => Ok(r),
                Err(e) => {
                    if matches!(e, DnsError::NotFound(_)) {
                        return Err(e);
                    }
                    tracing::debug!(
                        tag = %self.tag, domain, error = %e,
                        "AAAA query failed; falling back to A"
                    );
                    self.query_inner(domain, QTYPE_A).await
                }
            },
        }
    }

    async fn query_inner(
        &self,
        domain: &str,
        qtype: u16,
    ) -> Result<(Vec<IpAddr>, Duration), DnsError> {
        match &self.transport {
            DnsTransportKind::Udp => self.query_udp(domain, qtype).await,
            DnsTransportKind::Tcp => {
                let (packet, txid) = build_dns_query(domain, qtype)?;
                self.query_tcp(domain, &packet, txid).await
            }
            DnsTransportKind::Tls { sni } => {
                let (packet, txid) = build_dns_query(domain, qtype)?;
                self.query_tls(domain, &packet, txid, sni).await
            }
        }
    }

    /// 明文 UDP 查询。TC=1 时回退明文 TCP。
    async fn query_udp(
        &self,
        domain: &str,
        qtype: u16,
    ) -> Result<(Vec<IpAddr>, Duration), DnsError> {
        let (packet, txid) = build_dns_query(domain, qtype)?;
        let pooled = self.udp_pool.acquire().await?;
        let socket = pooled.socket();
        socket
            .send(&packet)
            .await
            .map_err(|e| DnsError::UpstreamFailed(format!("UDP send: {e}")))?;

        let mut buf = [0u8; 1232];
        let deadline = tokio::time::Instant::now() + Duration::from_millis(2500);

        loop {
            let remaining = deadline.saturating_duration_since(tokio::time::Instant::now());
            if remaining.is_zero() {
                return Err(DnsError::Timeout(domain.to_string()));
            }

            let n = match timeout(remaining, socket.recv(&mut buf)).await {
                Ok(Ok(n)) => n,
                Ok(Err(e)) => return Err(DnsError::UpstreamFailed(format!("UDP recv: {e}"))),
                Err(_) => return Err(DnsError::Timeout(domain.to_string())),
            };

            if n < 12 {
                continue;
            }

            let resp_txid = ((buf[0] as u16) << 8) | (buf[1] as u16);
            if resp_txid != txid {
                // Ignore stale packet from prior query and keep listening
                continue;
            }

            if (buf[2] & 0x02) != 0 {
                // TC=1: drop UDP and fallback to TCP
                drop(pooled);
                return self.query_tcp(domain, &packet, txid).await;
            }

            return parse_dns_response(&buf[..n]);
        }
    }

    /// DoT（DNS over TLS）查询。流程与 TCP 相同，但流被 TLS 包裹。
    ///
    /// 步骤：TCP 连接 → TLS 握手 → 发送长度前缀查询 → 读长度前缀响应
    /// → 校验 TXID → 解析 → 发送 TLS close_notify。
    async fn query_tls(
        &self,
        domain: &str,
        query_packet: &[u8],
        expected_txid: u16,
        _sni: &str,
    ) -> Result<(Vec<IpAddr>, Duration), DnsError> {
        // 池在 new_dot 里初始化。若 transport == Tls 但池是 None，
        // 意味着 TLS 层构造失败——返回明确错误，不静默降级。
        let pool = self.dot_pool.as_ref().ok_or_else(|| {
            DnsError::UpstreamFailed(
                "DoT requested but connection pool unavailable \
                 (TLS layer init failed at startup)"
                    .to_string(),
            )
        })?;

        // RAII 借出。成功路径下 drop 时归还池；出错路径 poison() 后不归还。
        let mut conn = pool.acquire().await?;

        // ─── 发送查询 ─────────────────────────────
        let len = query_packet.len() as u16;
        let mut framed = Vec::with_capacity(2 + query_packet.len());
        framed.extend_from_slice(&len.to_be_bytes());
        framed.extend_from_slice(query_packet);

        if let Err(e) = conn.stream_mut().write_all(&framed).await {
            conn.poison();
            return Err(DnsError::UpstreamFailed(format!("DoT write: {e}")));
        }
        if let Err(e) = conn.stream_mut().flush().await {
            conn.poison();
            return Err(DnsError::UpstreamFailed(format!("DoT flush: {e}")));
        }

        // ─── 读响应头（2 字节长度前缀）─────────────
        let mut len_buf = [0u8; 2];
        match timeout(
            Duration::from_millis(2500),
            conn.stream_mut().read_exact(&mut len_buf),
        )
        .await
        {
            Ok(Ok(_)) => {}
            Ok(Err(e)) => {
                conn.poison();
                return Err(DnsError::UpstreamFailed(format!("DoT read len: {e}")));
            }
            Err(_) => {
                // 超时视为连接可能已失效——不归还
                conn.poison();
                return Err(DnsError::Timeout(domain.to_string()));
            }
        }

        let resp_len = u16::from_be_bytes(len_buf) as usize;
        if !(12..=65535).contains(&resp_len) {
            conn.poison();
            return Err(DnsError::ParseError(format!(
                "Invalid DoT response length: {resp_len}"
            )));
        }

        // ─── 读响应体 ─────────────────────────────
        let mut resp_buf = vec![0u8; resp_len];
        match timeout(
            Duration::from_millis(2500),
            conn.stream_mut().read_exact(&mut resp_buf),
        )
        .await
        {
            Ok(Ok(_)) => {}
            Ok(Err(e)) => {
                conn.poison();
                return Err(DnsError::UpstreamFailed(format!("DoT read body: {e}")));
            }
            Err(_) => {
                conn.poison();
                return Err(DnsError::Timeout(domain.to_string()));
            }
        }

        // ─── 校验 TXID ────────────────────────────
        let resp_txid = ((resp_buf[0] as u16) << 8) | (resp_buf[1] as u16);
        if resp_txid != expected_txid {
            // 收到错误 TXID 说明协议状态错乱，连接不可信
            conn.poison();
            return Err(DnsError::ParseError(
                "DoT DNS Transaction ID mismatch".to_string(),
            ));
        }

        // 到这里 conn 会随 drop 自动归还池中
        parse_dns_response(&resp_buf)
    }

    pub async fn query_tcp(
        &self,
        domain: &str,
        query_packet: &[u8],
        expected_txid: u16,
    ) -> Result<(Vec<IpAddr>, Duration), DnsError> {
        let mut stream = timeout(Duration::from_millis(3000), TcpStream::connect(self.addr))
            .await
            .map_err(|_| DnsError::Timeout(domain.to_string()))?
            .map_err(|e| DnsError::UpstreamFailed(format!("TCP DNS connect failure: {e}")))?;
        let len = query_packet.len() as u16;
        let mut framed = Vec::with_capacity(2 + query_packet.len());
        framed.extend_from_slice(&len.to_be_bytes());
        framed.extend_from_slice(query_packet);
        // [FIXED] 为全流程 TCP 传输增加 3 秒超时，避免黑洞连接导致工作线程卡死
        let resp_buf = timeout(Duration::from_millis(3000), async {
            stream.write_all(&framed).await?;
            let mut len_buf = [0u8; 2];
            stream.read_exact(&mut len_buf).await?;
            let resp_len = u16::from_be_bytes(len_buf) as usize;
            if !(12..=65535).contains(&resp_len) {
                return Err(std::io::Error::new(std::io::ErrorKind::InvalidData, "invalid len"));
            }
            let mut resp_buf = vec![0u8; resp_len];
            stream.read_exact(&mut resp_buf).await?;
            Ok(resp_buf)
        })
        .await
        .map_err(|_| DnsError::Timeout(domain.to_string()))?
        .map_err(|e| DnsError::UpstreamFailed(format!("TCP DNS I/O failure: {e}")))?;
        let resp_txid = ((resp_buf[0] as u16) << 8) | (resp_buf[1] as u16);
        if resp_txid != expected_txid {
            return Err(DnsError::ParseError(
                "TCP DNS Transaction ID mismatch".to_string(),
            ));
        }
        parse_dns_response(&resp_buf)
    }
}

pub fn build_dns_query(domain: &str, qtype: u16) -> Result<(Vec<u8>, u16), DnsError> {
    let trimmed = domain.trim().trim_end_matches('.');
    if trimmed.is_empty() {
        return Err(DnsError::NotFound("Empty domain name".to_string()));
    }
    if trimmed.len() > 253 {
        return Err(DnsError::ParseError(
            "Domain exceeds 253 characters RFC limit".to_string(),
        ));
    }
    let txid: u16 = rand::random::<u16>();
    let mut packet = Vec::with_capacity(75);
    packet.extend_from_slice(&txid.to_be_bytes());
    packet.extend_from_slice(&[0x01, 0x00]); // RD=1
    packet.extend_from_slice(&[0x00, 0x01]); // QDCOUNT=1
    packet.extend_from_slice(&[0x00, 0x00]); // ANCOUNT
    packet.extend_from_slice(&[0x00, 0x00]); // NSCOUNT
    packet.extend_from_slice(&[0x00, 0x01]); // ARCOUNT=1 (EDNS0)

    for label in trimmed.split('.') {
        let l_bytes = label.as_bytes();
        if l_bytes.is_empty() || l_bytes.len() > 63 {
            return Err(DnsError::ParseError(format!(
                "Invalid DNS label length: {}",
                l_bytes.len()
            )));
        }
        packet.push(l_bytes.len() as u8);
        packet.extend_from_slice(l_bytes);
    }
    packet.push(0x00);
    packet.extend_from_slice(&qtype.to_be_bytes());
    packet.extend_from_slice(&[0x00, 0x01]); // IN

    // EDNS0 OPT (RFC 6891)
    packet.push(0x00);
    packet.extend_from_slice(&[0x00, 0x29]); // TYPE OPT
    packet.extend_from_slice(&[0x04, 0xD0]); // UDP payload 1232
    packet.extend_from_slice(&[0x00, 0x00, 0x00, 0x00]);
    packet.extend_from_slice(&[0x00, 0x00]);

    Ok((packet, txid))
}

pub fn parse_dns_response(buf: &[u8]) -> Result<(Vec<IpAddr>, Duration), DnsError> {
    if buf.len() < 12 {
        return Err(DnsError::ParseError(
            "Packet smaller than header".to_string(),
        ));
    }
    let rcode = buf[3] & 0x0F;
    match rcode {
        0 => {}
        1 => return Err(DnsError::UpstreamFailed("FORMERR".to_string())),
        2 => return Err(DnsError::UpstreamFailed("SERVFAIL".to_string())),
        3 => return Err(DnsError::NotFound("NXDOMAIN".to_string())),
        4 => return Err(DnsError::UpstreamFailed("NOTIMP".to_string())),
        5 => return Err(DnsError::UpstreamFailed("REFUSED".to_string())),
        other => return Err(DnsError::UpstreamFailed(format!("RCODE {other}"))),
    }

    let qdcount = ((buf[4] as u16) << 8) | (buf[5] as u16);
    let ancount = ((buf[6] as u16) << 8) | (buf[7] as u16);
    if qdcount > 1 {
        return Err(DnsError::ParseError(
            "Multi-question response rejected".to_string(),
        ));
    }

    let mut pos = 12;
    for _ in 0..qdcount {
        pos = skip_dns_name(buf, pos, 0)?;
        if pos + 4 > buf.len() {
            return Err(DnsError::ParseError("Truncated question".to_string()));
        }
        pos += 4;
    }

    let mut results = Vec::new();
    let mut min_ttl_secs = 86400u32;
    for _ in 0..ancount {
        // 合法地少了记录：RFC 1035 §4.1.3 允许服务器返回比 ancount
        // 声明更少的记录（例如响应被尾部截断但 TC=0）。
        // 这种情况直接 break 是**正确**的。
        if pos >= buf.len() {
            break;
        }
        pos = skip_dns_name(buf, pos, 0)?;
        // RR 固定头是 10 字节。位置 + 10 超出缓冲区意味着包被**中途
        // 切断**——这不是"少了记录"，是"记录本身不完整"。静默容忍
        // 会让被篡改的响应污染缓存（攻击者只需伪造一条完整记录 + 半个
        // 头部）。必须报错。
        if pos + 10 > buf.len() {
            return Err(DnsError::ParseError(format!(
                "truncated RR header at offset {pos}: need 10 bytes, have {}",
                buf.len().saturating_sub(pos)
            )));
        }
        let atype = ((buf[pos] as u16) << 8) | (buf[pos + 1] as u16);
        let ttl = u32::from_be_bytes([buf[pos + 4], buf[pos + 5], buf[pos + 6], buf[pos + 7]]);
        let rdlen = ((buf[pos + 8] as usize) << 8) | (buf[pos + 9] as usize);
        pos += 10;
        // 同理：RDATA 被截断 → 报错，不静默吞掉。
        if pos + rdlen > buf.len() {
            return Err(DnsError::ParseError(format!(
                "truncated RR data at offset {pos}: need {rdlen} bytes, have {}",
                buf.len().saturating_sub(pos)
            )));
        }
        if atype == 1 && rdlen == 4 {
            results.push(IpAddr::V4(Ipv4Addr::new(
                buf[pos], buf[pos + 1], buf[pos + 2], buf[pos + 3],
            )));
            min_ttl_secs = min_ttl_secs.min(ttl);
        } else if atype == 28 && rdlen == 16 {
            let mut octets = [0u8; 16];
            octets.copy_from_slice(&buf[pos..pos + 16]);
            results.push(IpAddr::V6(Ipv6Addr::from(octets)));
            min_ttl_secs = min_ttl_secs.min(ttl);
        }
        pos += rdlen;
    }

    if results.is_empty() {
        // 空结果可能源于：
        //   - 上游返回 CNAME-only 响应（应转到递归服务器解析）
        //   - 查询族与记录族不匹配（A 查但只有 AAAA）
        //   - 响应被中间设备过滤
        // 携带 rcode / ancount 便于诊断——用户看到 "ancount=1" 就知道
        // 上游返回了 1 条非 A/AAAA 记录（很可能是 CNAME）。
        Err(DnsError::NotFound(format!(
            "No A/AAAA records (rcode={rcode}, ancount={ancount}); \
             possibly CNAME-only or empty response"
        )))
    } else {
        let final_ttl = Duration::from_secs(min_ttl_secs.clamp(5, 86400) as u64);
        Ok((results, final_ttl))
    }
}

fn skip_dns_name(buf: &[u8], mut pos: usize, depth: usize) -> Result<usize, DnsError> {
    if depth > 10 {
        return Err(DnsError::ParseError(
            "DNS compression pointer loop".to_string(),
        ));
    }
    while pos < buf.len() {
        let len = buf[pos] as usize;
        if len == 0 {
            return Ok(pos + 1);
        }
        if (len & 0xC0) != 0 {
            if (len & 0xC0) == 0xC0 {
                if pos + 1 >= buf.len() {
                    return Err(DnsError::ParseError("Truncated pointer".to_string()));
                }
                return Ok(pos + 2);
            }
            return Err(DnsError::ParseError("Invalid DNS compression flag".to_string()));
        }
        pos += 1 + len;
    }
    Err(DnsError::ParseError("Unexpected end of DNS name".to_string()))
}


#[cfg(test)]
mod round19_tests {
    // Marker: caly-round19-tests
    use super::*;
    use std::net::{IpAddr, Ipv4Addr};

    /// 构造一个最小的合法 DNS 响应：
    ///   header (12B) + question (example.com A IN) + 1 answer (A 1.2.3.4)
    fn build_valid_response() -> Vec<u8> {
        let mut buf = Vec::new();
        // ID
        buf.extend_from_slice(&[0x12, 0x34]);
        // Flags: QR=1, RD=1, RA=1, RCODE=0
        buf.extend_from_slice(&[0x81, 0x80]);
        // QDCOUNT=1, ANCOUNT=1, NSCOUNT=0, ARCOUNT=0
        buf.extend_from_slice(&[0x00, 0x01]);
        buf.extend_from_slice(&[0x00, 0x01]);
        buf.extend_from_slice(&[0x00, 0x00]);
        buf.extend_from_slice(&[0x00, 0x00]);
        // Question: example.com A IN
        buf.push(7); buf.extend_from_slice(b"example");
        buf.push(3); buf.extend_from_slice(b"com");
        buf.push(0);
        buf.extend_from_slice(&[0x00, 0x01]); // QTYPE A
        buf.extend_from_slice(&[0x00, 0x01]); // QCLASS IN
        // Answer: 压缩指针 + A 记录
        buf.extend_from_slice(&[0xC0, 0x0C]); // 指向偏移 12（question 起始）
        buf.extend_from_slice(&[0x00, 0x01]); // TYPE A
        buf.extend_from_slice(&[0x00, 0x01]); // CLASS IN
        buf.extend_from_slice(&[0x00, 0x00, 0x01, 0x2C]); // TTL 300
        buf.extend_from_slice(&[0x00, 0x04]); // RDLENGTH 4
        buf.extend_from_slice(&[1, 2, 3, 4]); // 1.2.3.4
        buf
    }

    #[test]
    fn test_valid_response_parses() {
        let resp = build_valid_response();
        let (ips, ttl) = parse_dns_response(&resp).expect("valid response");
        assert_eq!(ips, vec![IpAddr::V4(Ipv4Addr::new(1, 2, 3, 4))]);
        assert_eq!(ttl.as_secs(), 300);
    }

    #[test]
    fn test_truncated_rr_header_rejected() {
        // 篡改 RDLENGTH 位置之后但未写完整头
        let mut resp = build_valid_response();
        // 把最后 4 字节（A 记录 body）截掉，RDLENGTH 声称有 4 字节
        resp.truncate(resp.len() - 4);
        let err = parse_dns_response(&resp).unwrap_err();
        let msg = format!("{err}");
        assert!(
            msg.contains("truncated RR data"),
            "应报 truncated RR data，实际: {msg}"
        );
    }

    #[test]
    fn test_truncated_rr_body_rejected() {
        // 在 RR 头中途截断（保留前 8 字节，去掉后 2 字节）
        let resp = build_valid_response();
        let cut = resp.len() - 4 - 2; // 切到 RDLENGTH 之内
        let partial = &resp[..cut];
        let err = parse_dns_response(partial).unwrap_err();
        let msg = format!("{err}");
        assert!(
            msg.contains("truncated RR") || msg.contains("Unexpected end"),
            "应报截断相关错误，实际: {msg}"
        );
    }

    #[test]
    fn test_ancount_over_declared_is_ok() {
        // ancount=5 但只提供 1 条记录：RFC 1035 §4.1.3 允许
        let mut resp = build_valid_response();
        // 修改 ANCOUNT 字段（offset 6..8）
        resp[6] = 0x00;
        resp[7] = 0x05;
        // 应当成功，返回实际解析到的 1 条
        let (ips, _ttl) = parse_dns_response(&resp).expect("fewer records than declared is legal");
        assert_eq!(ips.len(), 1);
    }

    #[test]
    fn test_empty_answers_returns_not_found() {
        let mut resp = build_valid_response();
        // ANCOUNT=0
        resp[6] = 0x00;
        resp[7] = 0x00;
        // 去掉 answer 部分
        resp.truncate(12 + 17); // header + question 长度（example.com = 13 字节 + 4 = 17）
        let err = parse_dns_response(&resp).unwrap_err();
        let msg = format!("{err}");
        assert!(
            msg.contains("No A/AAAA records"),
            "应报 no records，实际: {msg}"
        );
    }
}
