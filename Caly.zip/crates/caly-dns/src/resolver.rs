//! Unified DnsResolver implementation with sharded LRU caching, routing rules, and singleflight deduplication.

use crate::cache::ShardedCache;
use crate::fakeip::FakeIpPool;
use crate::singleflight::Singleflight;
use crate::snooping::DnsSnooper;
use crate::upstream::UpstreamServer;
use async_trait::async_trait;
use caly_common::dns::{DnsError, DnsResolver, ResolveResult};
use smol_str::SmolStr;
use std::collections::HashMap;
use std::net::{IpAddr, Ipv4Addr};
use std::sync::Arc;
use std::time::Duration;

#[derive(Debug, Clone)]
pub struct DnsRouteRule {
    pub domain_suffix: Vec<SmolStr>,
    pub domain_keyword: Vec<SmolStr>,
    pub server_tag: SmolStr,
}

impl DnsRouteRule {
    fn matches(&self, domain: &str) -> bool {
        let d = domain.trim_end_matches('.');
        for suffix in &self.domain_suffix {
            let s = suffix.trim_start_matches('.').trim_end_matches('.');
            if s.is_empty() {
                continue;
            }
            if d.eq_ignore_ascii_case(s) {
                return true;
            }
            if d.len() > s.len() {
                let start = d.len() - s.len();
                if d.is_char_boundary(start)
                    && d.as_bytes()[start - 1] == b'.'
                    && d[start..].eq_ignore_ascii_case(s)
                {
                    return true;
                }
            }
        }
        for kw in &self.domain_keyword {
            if kw.is_empty() {
                continue;
            }
            let kw_bytes = kw.as_bytes();
            if d.as_bytes()
                .windows(kw_bytes.len())
                .any(|w| w.eq_ignore_ascii_case(kw_bytes))
            {
                return true;
            }
        }
        false
    }
}

#[derive(Debug, Default)]
pub struct DnsRouter {
    rules: Vec<DnsRouteRule>,
    final_tag: Option<SmolStr>,
}

impl DnsRouter {
    pub fn new(rules: Vec<DnsRouteRule>, final_tag: Option<SmolStr>) -> Self {
        Self { rules, final_tag }
    }

    pub fn route(&self, domain: &str) -> Option<&str> {
        for rule in &self.rules {
            if rule.matches(domain) {
                return Some(rule.server_tag.as_str());
            }
        }
        None
    }

    pub fn final_tag(&self) -> Option<&str> {
        self.final_tag.as_deref()
    }
}

#[derive(Debug, Clone)]
pub struct DnsResolverConfig {
    pub cache_capacity: usize,
    pub optimistic: bool,
    pub optimistic_ttl_secs: u64,
    pub fakeip_ttl_secs: u64,
    pub fakeip_inet4_range: Option<(Ipv4Addr, u8)>,
    pub dns_rules: Vec<DnsRouteRule>,
    pub final_server_tag: Option<SmolStr>,
}

impl Default for DnsResolverConfig {
    fn default() -> Self {
        Self {
            cache_capacity: 4096,
            optimistic: true,
            optimistic_ttl_secs: 60,
            fakeip_ttl_secs: 300,
            fakeip_inet4_range: None,
            dns_rules: Vec::new(),
            final_server_tag: None,
        }
    }
}

pub struct DnsResolverImpl {
    cache: Arc<ShardedCache>,
    fakeip: FakeIpPool,
    snooper: DnsSnooper,
    // 修复（Round 27）：Vec<UpstreamServer> → Arc<[UpstreamServer]>。
    //
    // 旧实现每次乐观缓存刷新都要 `.into_iter().cloned().collect()`
    // 出一个完整的 Vec<UpstreamServer>：每个元素的 tag: String
    // （以及可能存在的 detour: Option<String>）都重新分配。
    //
    // 高 QPS 下（缓存过期刷新可达每秒上千次）这会持续给分配器
    // 施压，而且是完全不必要的 —— upstreams 在启动时确定后就不再
    // 变化，只是需要在多个 async 任务间共享只读视图。
    //
    // Arc<[T]> 的 clone 只是原子引用计数 +1。长度固定不变。
    upstreams: Arc<[UpstreamServer]>,
    upstream_index: HashMap<SmolStr, usize>,
    router: DnsRouter,
    singleflight: Singleflight,
    fakeip_enabled: bool,
}

impl DnsResolverImpl {
    pub fn new(upstreams: Vec<UpstreamServer>, fakeip_enabled: bool) -> Self {
        Self::new_with_config(upstreams, fakeip_enabled, DnsResolverConfig::default())
    }

    pub fn new_with_config(
        upstreams: Vec<UpstreamServer>,
        fakeip_enabled: bool,
        config: DnsResolverConfig,
    ) -> Self {
        let per_shard = (config.cache_capacity / 16).max(1);
        let optimistic_ttl = if config.optimistic {
            Duration::from_secs(config.optimistic_ttl_secs)
        } else {
            Duration::ZERO
        };
        let fakeip_ttl = Duration::from_secs(config.fakeip_ttl_secs);
        let fakeip = match config.fakeip_inet4_range {
            Some((net, prefix)) => FakeIpPool::new_with_range(net, prefix, fakeip_ttl),
            None => FakeIpPool::new(fakeip_ttl),
        };
        let upstream_index: HashMap<SmolStr, usize> = upstreams
            .iter()
            .enumerate()
            .map(|(i, u)| (SmolStr::new(u.tag.as_str()), i))
            .collect();
        let router = DnsRouter::new(config.dns_rules, config.final_server_tag);

        Self {
            cache: Arc::new(ShardedCache::new_with_options(per_shard, optimistic_ttl)),
            fakeip,
            snooper: DnsSnooper::default(),
            // Round 27：Vec<T> → Arc<[T]>（无损、O(1) clone 语义）。
            // upstream_index 必须在此之前构建 —— 它需要遍历 Vec。
            upstreams: upstreams.into(),
            upstream_index,
            router,
            singleflight: Singleflight::new(),
            fakeip_enabled,
        }
    }

    /// 返回选中 upstream 在 `self.upstreams` 中的索引列表。
    ///
    /// Round 27 改为返回索引而非 `Vec<&UpstreamServer>`：
    ///
    /// 刷新路径需要在 `tokio::spawn` 的 `'static` 闭包里使用这些
    /// upstream。原实现靠 `.into_iter().cloned().collect()` 把每个
    /// `UpstreamServer` 完整克隆一遍 —— 其中 tag: String 会重新
    /// 分配。改为索引后，`Arc<[UpstreamServer]>` 只需一次原子计数
    /// 就能搬进闭包，配合 `&upstreams[idx]` 零额外分配。
    ///
    /// 语义与旧 `select_upstreams` 完全一致：优先 DNS 路由命中的
    /// server；无匹配时回退到 final_tag；两者都无则返回全部。
    fn select_upstream_indices(&self, domain: &str) -> Vec<usize> {
        if let Some(tag) = self.router.route(domain) {
            if let Some(&idx) = self.upstream_index.get(tag) {
                return vec![idx];
            }
        }
        if let Some(tag) = self.router.final_tag() {
            if let Some(&idx) = self.upstream_index.get(tag) {
                return vec![idx];
            }
        }
        (0..self.upstreams.len()).collect()
    }
}

#[async_trait]
impl DnsResolver for DnsResolverImpl {
    async fn resolve(&self, raw_domain: &str) -> Result<ResolveResult, DnsError> {
        let domain = raw_domain.trim().trim_end_matches('.');
        if domain.is_empty() {
            return Err(DnsError::NotFound("Empty domain".to_string()));
        }

        // Fast-path: Literal IP parsing
        if let Ok(ip) = domain.parse::<IpAddr>() {
            return Ok(ResolveResult::RealIp(vec![ip]));
        }

        // Fast-path: localhost
        if domain.eq_ignore_ascii_case("localhost") {
            return Ok(ResolveResult::RealIp(vec![
                IpAddr::V4(Ipv4Addr::LOCALHOST),
                IpAddr::V6(std::net::Ipv6Addr::LOCALHOST),
            ]));
        }

        // 1. Sharded Cache Lookup (Fresh or Optimistic)
        if let Some((entry, should_refresh)) = self.cache.get(domain) {
            if entry.is_fresh() {
                return Ok(ResolveResult::RealIp(entry.ips.to_vec()));
            }
            if should_refresh && !self.upstreams.is_empty() && entry.is_usable_optimistic() {
                // Round 27：只搬索引 + Arc 引用，避免 clone 整个
                // Vec<UpstreamServer>（见 select_upstream_indices 注释）。
                let selected_idx = self.select_upstream_indices(domain);
                let upstreams = Arc::clone(&self.upstreams);
                let domain_owned = domain.to_string();
                let sf = self.singleflight.clone();
                let cache = self.cache.clone();
                tokio::spawn(async move {
                    let mut refreshed = false;
                    for &idx in &selected_idx {
                        let upstream = &upstreams[idx];
                        let dom = domain_owned.clone();
                        if let Ok((ips, ttl)) = sf.execute(&dom, || async {
                            upstream.query_by_strategy(&dom).await
                        }).await {
                            cache.put(&domain_owned, &ips, ttl);
                            refreshed = true;
                            break;
                        }
                    }
                    if !refreshed {
                        cache.mark_refresh_done(&domain_owned);
                    }
                });
            }
            if entry.is_usable_optimistic() {
                return Ok(ResolveResult::RealIp(entry.ips.to_vec()));
            }
        }

        // 2. FakeIP
        if self.fakeip_enabled {
            let fake_ip = self.fakeip.allocate(domain)?;
            self.snooper.record(fake_ip, 0, domain);
            return Ok(ResolveResult::FakeIp(fake_ip));
        }

        // 3. Upstream Query + Singleflight
        if self.upstreams.is_empty() {
            return Err(DnsError::NoUpstream);
        }
        let selected_idx = self.select_upstream_indices(domain);
        if selected_idx.is_empty() {
            return Err(DnsError::NoUpstream);
        }

        let mut last_err = DnsError::NoUpstream;
        for idx in selected_idx {
            let upstream = &self.upstreams[idx];
            let domain_owned = domain.to_string();
            let sf = self.singleflight.clone();
            match sf.execute(&domain_owned, || async {
                upstream.query_by_strategy(&domain_owned).await
            }).await {
                Ok((ips, ttl)) => {
                    self.cache.put(domain, &ips, ttl);
                    return Ok(ResolveResult::RealIp(ips));
                }
                Err(e) => {
                    last_err = e;
                }
            }
        }
        Err(last_err)
    }

    fn lookup_fakeip(&self, ip: IpAddr) -> Option<SmolStr> {
        self.fakeip.lookup(ip)
    }

    fn snoop(&self, ip: IpAddr, port: u16) -> Option<SmolStr> {
        self.snooper.lookup(ip, port).or_else(|| self.cache.find_by_ip(ip))
    }

    fn gc(&self) {
        self.fakeip.garbage_collect();
        self.snooper.evict_expired();
    }

    fn clear_cache(&self) -> usize {
        let mut total = 0usize;
        total += self.cache.clear_all();
        total += self.snooper.clear_all();
        tracing::info!(cleared = total, "dns cache cleared via API");
        total
    }
}
