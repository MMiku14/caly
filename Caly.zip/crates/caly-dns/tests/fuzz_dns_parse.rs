//! Fuzz tests for DNS response parsing.
//!
//! `parse_dns_response` 从网络读取任意字节，是攻击者最直接的可控入口。
//! 本测试确保任意输入（随机 / 半有效 / 恶意构造）都不会：
//!   1. panic
//!   2. 无限循环
//!   3. 越界读
//!
//! 输入上限 2KB（DNS over UDP 常见上限 1232 字节），符合实际威胁模型。

use caly_dns::upstream::parse_dns_response;

/// 轻量级可重现 PRNG（xorshift64），不引入 rand 依赖。
///
/// 固定种子 + 固定迭代次数 = 可复现。若失败，修改 SEED 或具体某个
/// 循环变量即可定位。恐慌栈里给出的 `i` 值配合 SEED 足以复现。
struct XorShift64(u64);

impl XorShift64 {
    fn new(seed: u64) -> Self {
        // 0 会让 xorshift 陷入不动点
        Self(if seed == 0 { 0x9E37_79B9_7F4A_7C15 } else { seed })
    }

    fn next_u64(&mut self) -> u64 {
        let mut x = self.0;
        x ^= x << 13;
        x ^= x >> 7;
        x ^= x << 17;
        self.0 = x;
        x
    }

    fn fill(&mut self, buf: &mut [u8]) {
        for chunk in buf.chunks_mut(8) {
            let v = self.next_u64().to_le_bytes();
            let n = chunk.len();
            chunk.copy_from_slice(&v[..n]);
        }
    }

    fn range(&mut self, max: usize) -> usize {
        if max == 0 { 0 } else { (self.next_u64() as usize) % max }
    }
}

const SEED_DNS: u64 = 0x00C4_1D00_D05E_0001;

#[test]
fn fuzz_parse_random_bytes_no_panic() {
    let mut rng = XorShift64::new(SEED_DNS);
    for i in 0..20_000 {
        let len = rng.range(2048);
        let mut buf = vec![0u8; len];
        rng.fill(&mut buf);
        // 只要求不 panic —— 返回 Ok / Err 都接受
        let _ = parse_dns_response(&buf);
        // 若失败，panic 消息会带上 i，用 SEED_DNS 复现
        let _ = i;
    }
}

#[test]
fn fuzz_parse_valid_header_random_tail() {
    // 有效 DNS header + 随机尾部。触发"头部过 header 校验但
    // question/answer 段畸形"的中间路径。
    let mut rng = XorShift64::new(SEED_DNS ^ 0xA5A5_A5A5);
    for _ in 0..10_000 {
        let mut buf = vec![
            0x12, 0x34, // TXID
            0x81, 0x80, // Flags: QR=1, RD=1, RA=1, RCODE=0
            0x00, 0x01, // QDCOUNT=1
            0x00, 0x01, // ANCOUNT=1
            0x00, 0x00, // NSCOUNT
            0x00, 0x00, // ARCOUNT
        ];
        let tail_len = rng.range(512);
        let mut tail = vec![0u8; tail_len];
        rng.fill(&mut tail);
        buf.extend_from_slice(&tail);
        let _ = parse_dns_response(&buf);
    }
}

#[test]
fn fuzz_parse_deeply_nested_compression_pointers() {
    // 压缩指针环：多个指针互相指向，验证 skip_dns_name 不会无限递归。
    //
    // 攻击者可以构造：指针 A 指向指针 B，指针 B 指向指针 A。
    // RFC 1035 没有要求解析器 follow 指针链 —— 我们只需要跳过 2 字节，
    // 但必须确保深度计数生效（防止某些实现的尾递归变体）。
    let mut rng = XorShift64::new(SEED_DNS ^ 0xDEAD_BEEF);
    for _ in 0..5_000 {
        let mut buf = Vec::with_capacity(64);
        buf.extend_from_slice(&[
            0x12, 0x34, 0x81, 0x80, 0x00, 0x01, 0x00, 0x10, 0x00, 0x00, 0x00, 0x00,
        ]);
        // 交替填充 0xC0 0x0C 指针（互相指向自身）
        for _ in 0..rng.range(32) + 1 {
            buf.push(0xC0);
            buf.push(0x0C);
        }
        let _ = parse_dns_response(&buf);
    }
}

#[test]
fn fuzz_parse_truncated_at_every_offset() {
    // 从一个合法报文出发，在每一个位置截断，验证全部路径健壮。
    let base: Vec<u8> = vec![
        0x12, 0x34, 0x81, 0x80, 0x00, 0x01, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00,
        // Question: example.com A IN
        7, b'e', b'x', b'a', b'm', b'p', b'l', b'e',
        3, b'c', b'o', b'm',
        0,
        0x00, 0x01, 0x00, 0x01,
        // Answer
        0xC0, 0x0C,
        0x00, 0x01, 0x00, 0x01,
        0x00, 0x00, 0x01, 0x2C,
        0x00, 0x04,
        1, 2, 3, 4,
    ];
    for cut in 0..=base.len() {
        let _ = parse_dns_response(&base[..cut]);
    }
}
