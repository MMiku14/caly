//! Concrete static-dispatch stream implementation.

use crate::sansio_stream::SansIoStream;
use caly_common::protocol::ProtocolStateMachine;
use caly_common::transport::{StreamType, TransportStream};
use std::io;
use std::net::SocketAddr;
use std::pin::Pin;
use std::task::{Context, Poll};
use tokio::io::{AsyncRead, AsyncWrite, DuplexStream, ReadBuf};
use tokio::net::TcpStream;
use tokio_rustls::client::TlsStream;

pub enum ConcreteStream {
    Tcp(TcpStream),
    Tls(Box<TlsStream<TcpStream>>),
    Memory(DuplexStream),
    Ss2022(Box<dyn DynSansIoStream>),
}

pub trait DynSansIoStream: AsyncRead + AsyncWrite + Unpin + Send + Sync {
    fn peer_addr(&self) -> Option<SocketAddr>;
}

impl<SM, S> DynSansIoStream for SansIoStream<SM, S>
where
    SM: ProtocolStateMachine + Send + Sync + Unpin + 'static,
    SM::Error: Send + Sync,
    S: AsyncRead + AsyncWrite + Unpin + Send + Sync + 'static,
{
    fn peer_addr(&self) -> Option<SocketAddr> {
        None
    }
}

impl TransportStream for ConcreteStream {
    fn stream_type(&self) -> StreamType {
        match self {
            ConcreteStream::Tcp(_) => StreamType::Tcp,
            ConcreteStream::Tls(_) => StreamType::Tls,
            ConcreteStream::Memory(_) => StreamType::Tcp,
            ConcreteStream::Ss2022(_) => StreamType::Tcp,
        }
    }

    fn peer_addr(&self) -> Option<SocketAddr> {
        match self {
            ConcreteStream::Tcp(s) => s.peer_addr().ok(),
            ConcreteStream::Tls(s) => s.get_ref().0.peer_addr().ok(),
            ConcreteStream::Memory(_) => None,
            ConcreteStream::Ss2022(s) => s.peer_addr(),
        }
    }
}

impl AsyncRead for ConcreteStream {
    fn poll_read(
        self: Pin<&mut Self>,
        cx: &mut Context<'_>,
        buf: &mut ReadBuf<'_>,
    ) -> Poll<io::Result<()>> {
        match self.get_mut() {
            ConcreteStream::Tcp(s) => Pin::new(s).poll_read(cx, buf),
            ConcreteStream::Tls(s) => Pin::new(&mut **s).poll_read(cx, buf),
            ConcreteStream::Memory(s) => Pin::new(s).poll_read(cx, buf),
            ConcreteStream::Ss2022(s) => Pin::new(&mut **s).poll_read(cx, buf),
        }
    }
}

impl AsyncWrite for ConcreteStream {
    fn poll_write(
        self: Pin<&mut Self>,
        cx: &mut Context<'_>,
        buf: &[u8],
    ) -> Poll<io::Result<usize>> {
        match self.get_mut() {
            ConcreteStream::Tcp(s) => Pin::new(s).poll_write(cx, buf),
            ConcreteStream::Tls(s) => Pin::new(&mut **s).poll_write(cx, buf),
            ConcreteStream::Memory(s) => Pin::new(s).poll_write(cx, buf),
            ConcreteStream::Ss2022(s) => Pin::new(&mut **s).poll_write(cx, buf),
        }
    }

    fn poll_flush(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<io::Result<()>> {
        match self.get_mut() {
            ConcreteStream::Tcp(s) => Pin::new(s).poll_flush(cx),
            ConcreteStream::Tls(s) => Pin::new(&mut **s).poll_flush(cx),
            ConcreteStream::Memory(s) => Pin::new(s).poll_flush(cx),
            ConcreteStream::Ss2022(s) => Pin::new(&mut **s).poll_flush(cx),
        }
    }

    fn poll_shutdown(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<io::Result<()>> {
        match self.get_mut() {
            ConcreteStream::Tcp(s) => Pin::new(s).poll_shutdown(cx),
            ConcreteStream::Tls(s) => {
                let tls = &mut **s;
                match Pin::new(tls).poll_shutdown(cx) {
                    Poll::Ready(Ok(())) => {
                        let tcp = &mut s.get_mut().0;
                        Pin::new(tcp).poll_shutdown(cx)
                    }
                    other => other,
                }
            }
            ConcreteStream::Memory(s) => Pin::new(s).poll_shutdown(cx),
            ConcreteStream::Ss2022(s) => Pin::new(&mut **s).poll_shutdown(cx),
        }
    }
}
