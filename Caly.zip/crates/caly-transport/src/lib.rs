//! Composable transport layer supporting high-performance static dispatch.

pub mod builder;
pub mod sansio_stream;
pub mod stream;
pub mod tls;

pub use builder::StreamBuilder;
pub use sansio_stream::{wrap_sans_io, SansIoStream};
pub use stream::{ConcreteStream, DynSansIoStream};
pub use tls::TlsConnectorLayer;
