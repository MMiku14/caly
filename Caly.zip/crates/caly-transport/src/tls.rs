//! TLS transport layer based on rustls with ALPN and certificate validation.

use caly_common::error::TransportError;
use rustls::client::danger::{HandshakeSignatureValid, ServerCertVerified, ServerCertVerifier};
use rustls::pki_types::{CertificateDer, ServerName, UnixTime};
use rustls::{ClientConfig, DigitallySignedStruct, SignatureScheme};
use std::net::IpAddr;
use std::sync::Arc;
use tokio::net::TcpStream;
// 重新导出 TlsStream：
// 它是 TlsConnectorLayer::handshake 的返回类型，属于 caly-transport 的
// **公共契约**。使用方（例如 caly-dns 的 DoT 连接池）需要在自己的
// 结构体里保存这个类型。
//
// 若 caly-dns 直接依赖 tokio-rustls，一旦未来切换 TLS 后端
//（aws-lc-rs / boring），caly-dns 也得跟着改。通过 re-export，
// 依赖封闭在 caly-transport 内。
pub use tokio_rustls::client::TlsStream;
use tokio_rustls::TlsConnector;

pub struct TlsConnectorLayer {
    connector: TlsConnector,
    skip_verify: bool,
}

impl TlsConnectorLayer {
    pub fn new() -> Result<Self, TransportError> {
        Self::new_with_options(false)
    }

    pub fn new_with_options(skip_verify: bool) -> Result<Self, TransportError> {
        let provider = Arc::new(rustls::crypto::ring::default_provider());
        let mut config = if skip_verify {
            tracing::warn!(
                "TlsConnectorLayer: skip_verify=true; certificate validation disabled. DO NOT use in production."
            );
            ClientConfig::builder_with_provider(provider.clone())
                .with_safe_default_protocol_versions()
                .map_err(|e| TransportError::TlsHandshake(e.to_string()))?
                .dangerous()
                .with_custom_certificate_verifier(Arc::new(NoVerifyVerifier::new(provider)))
                .with_no_client_auth()
        } else {
            let mut root_store = rustls::RootCertStore::empty();
            root_store.extend(webpki_roots::TLS_SERVER_ROOTS.iter().cloned());
            ClientConfig::builder_with_provider(provider.clone())
                .with_safe_default_protocol_versions()
                .map_err(|e| TransportError::TlsHandshake(e.to_string()))?
                .with_root_certificates(root_store)
                .with_no_client_auth()
        };

        config.alpn_protocols = vec![b"h2".to_vec(), b"http/1.1".to_vec()];
        Ok(Self {
            connector: TlsConnector::from(Arc::new(config)),
            skip_verify,
        })
    }

    #[inline]
    pub fn is_skip_verify(&self) -> bool {
        self.skip_verify
    }

    pub async fn handshake(
        &self,
        domain_or_ip: &str,
        stream: TcpStream,
    ) -> Result<TlsStream<TcpStream>, TransportError> {
        let server_name = if let Ok(ip) = domain_or_ip.parse::<IpAddr>() {
            ServerName::from(ip)
        } else {
            ServerName::try_from(domain_or_ip.to_string())
                .map_err(|e| TransportError::TlsHandshake(format!("Invalid SNI: {e}")))?
        };
        self.connector
            .connect(server_name, stream)
            .await
            .map_err(|e| TransportError::TlsHandshake(e.to_string()))
    }
}

#[derive(Debug)]
struct NoVerifyVerifier {
    provider: Arc<rustls::crypto::CryptoProvider>,
}

impl NoVerifyVerifier {
    fn new(provider: Arc<rustls::crypto::CryptoProvider>) -> Self {
        Self { provider }
    }
}

impl ServerCertVerifier for NoVerifyVerifier {
    fn verify_server_cert(
        &self,
        _end_entity: &CertificateDer<'_>,
        _intermediates: &[CertificateDer<'_>],
        _server_name: &ServerName<'_>,
        _ocsp_response: &[u8],
        _now: UnixTime,
    ) -> Result<ServerCertVerified, rustls::Error> {
        Ok(ServerCertVerified::assertion())
    }

    fn verify_tls12_signature(
        &self,
        _message: &[u8],
        _cert: &CertificateDer<'_>,
        _dss: &DigitallySignedStruct,
    ) -> Result<HandshakeSignatureValid, rustls::Error> {
        Ok(HandshakeSignatureValid::assertion())
    }

    fn verify_tls13_signature(
        &self,
        _message: &[u8],
        _cert: &CertificateDer<'_>,
        _dss: &DigitallySignedStruct,
    ) -> Result<HandshakeSignatureValid, rustls::Error> {
        Ok(HandshakeSignatureValid::assertion())
    }

    fn supported_verify_schemes(&self) -> Vec<SignatureScheme> {
        self.provider
            .signature_verification_algorithms
            .supported_schemes()
    }
}
