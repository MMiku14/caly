//! Sans-IO Stream Adapter wrapping ProtocolStateMachine as AsyncRead + AsyncWrite with backpressure.

use caly_common::protocol::ProtocolStateMachine;
use std::io;
use std::pin::Pin;
use std::task::{Context, Poll};
use tokio::io::{AsyncRead, AsyncWrite, ReadBuf};

const MAX_PENDING_WRITE: usize = 65536;

pub struct SansIoStream<SM, S> {
    inner: S,
    sm: SM,
    pending_write: Vec<u8>,
    pending_write_pos: usize,
    net_read_buf: Box<[u8]>,
}

impl<SM, S> SansIoStream<SM, S>
where
    SM: ProtocolStateMachine,
    S: AsyncRead + AsyncWrite + Unpin,
{
    pub fn new(inner: S, sm: SM) -> Self {
        Self {
            inner,
            sm,
            pending_write: Vec::with_capacity(4096),
            pending_write_pos: 0,
            net_read_buf: vec![0u8; 16384].into_boxed_slice(),
        }
    }

    fn drain_sm_to_pending(&mut self) {
        let mut tmp = [0u8; 32768];
        while let Some(n) = self.sm.poll_network_output(&mut tmp) {
            self.pending_write.extend_from_slice(&tmp[..n]);
            if n < tmp.len() {
                break;
            }
        }
    }
}

impl<SM, S> AsyncRead for SansIoStream<SM, S>
where
    SM: ProtocolStateMachine + Unpin,
    S: AsyncRead + AsyncWrite + Unpin,
{
    fn poll_read(
        self: Pin<&mut Self>,
        cx: &mut Context<'_>,
        buf: &mut ReadBuf<'_>,
    ) -> Poll<io::Result<()>> {
        let this = self.get_mut();
        loop {
            let unfilled = buf.initialize_unfilled();
            if unfilled.is_empty() {
                return Poll::Ready(Ok(()));
            }
            if let Some(n) = this.sm.poll_app_output(unfilled) {
                buf.advance(n);
                return Poll::Ready(Ok(()));
            }

            let filled_len = {
                let mut read_buf = ReadBuf::new(&mut this.net_read_buf[..]);
                match Pin::new(&mut this.inner).poll_read(cx, &mut read_buf) {
                    Poll::Ready(Ok(())) => read_buf.filled().len(),
                    Poll::Ready(Err(e)) => return Poll::Ready(Err(e)),
                    Poll::Pending => return Poll::Pending,
                }
            };

            if filled_len == 0 {
                return Poll::Ready(Ok(()));
            }

            if let Err(e) = this.sm.on_network_input(&this.net_read_buf[..filled_len]) {
                return Poll::Ready(Err(io::Error::new(
                    io::ErrorKind::InvalidData,
                    format!("state machine error: {e}"),
                )));
            }
        }
    }
}

impl<SM, S> AsyncWrite for SansIoStream<SM, S>
where
    SM: ProtocolStateMachine + Unpin,
    S: AsyncRead + AsyncWrite + Unpin,
{
    fn poll_write(
        self: Pin<&mut Self>,
        cx: &mut Context<'_>,
        data: &[u8],
    ) -> Poll<io::Result<usize>> {
        let this = self.get_mut();

        // 1. Flush existing pending buffer
        while this.pending_write_pos < this.pending_write.len() {
            let remaining = &this.pending_write[this.pending_write_pos..];
            match Pin::new(&mut this.inner).poll_write(cx, remaining) {
                Poll::Ready(Ok(0)) => {
                    return Poll::Ready(Err(io::Error::new(
                        io::ErrorKind::WriteZero,
                        "underlying stream accepted 0 bytes",
                    )));
                }
                Poll::Ready(Ok(n)) => this.pending_write_pos += n,
                Poll::Ready(Err(e)) => return Poll::Ready(Err(e)),
                Poll::Pending => return Poll::Pending,
            }
        }
        this.pending_write.clear();
        this.pending_write_pos = 0;

        // Backpressure check
        if this.pending_write.len() >= MAX_PENDING_WRITE {
            return Poll::Pending;
        }

        // 2. Feed app input
        if let Err(e) = this.sm.on_app_input(data) {
            return Poll::Ready(Err(io::Error::new(
                io::ErrorKind::InvalidInput,
                format!("on_app_input: {e}"),
            )));
        }

        // 3. Drain state machine network output
        this.drain_sm_to_pending();

        // 4. Opportunistically write
        while this.pending_write_pos < this.pending_write.len() {
            let remaining = &this.pending_write[this.pending_write_pos..];
            match Pin::new(&mut this.inner).poll_write(cx, remaining) {
                Poll::Ready(Ok(0)) => {
                    return Poll::Ready(Err(io::Error::new(
                        io::ErrorKind::WriteZero,
                        "underlying stream accepted 0 bytes",
                    )));
                }
                Poll::Ready(Ok(n)) => this.pending_write_pos += n,
                Poll::Ready(Err(e)) => return Poll::Ready(Err(e)),
                Poll::Pending => break,
            }
        }

        Poll::Ready(Ok(data.len()))
    }

    fn poll_flush(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<io::Result<()>> {
        let this = self.get_mut();
        this.drain_sm_to_pending();
        while this.pending_write_pos < this.pending_write.len() {
            let remaining = &this.pending_write[this.pending_write_pos..];
            match Pin::new(&mut this.inner).poll_write(cx, remaining) {
                Poll::Ready(Ok(0)) => {
                    return Poll::Ready(Err(io::Error::new(
                        io::ErrorKind::WriteZero,
                        "underlying stream accepted 0 bytes",
                    )));
                }
                Poll::Ready(Ok(n)) => this.pending_write_pos += n,
                Poll::Ready(Err(e)) => return Poll::Ready(Err(e)),
                Poll::Pending => return Poll::Pending,
            }
        }
        this.pending_write.clear();
        this.pending_write_pos = 0;
        Pin::new(&mut this.inner).poll_flush(cx)
    }

    fn poll_shutdown(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<io::Result<()>> {
        match self.as_mut().poll_flush(cx) {
            Poll::Pending => return Poll::Pending,
            Poll::Ready(Err(e)) => return Poll::Ready(Err(e)),
            Poll::Ready(Ok(())) => {}
        }
        let this = self.get_mut();
        Pin::new(&mut this.inner).poll_shutdown(cx)
    }
}

pub fn wrap_sans_io<SM, S>(inner: S, sm: SM) -> SansIoStream<SM, S>
where
    SM: ProtocolStateMachine,
    S: AsyncRead + AsyncWrite + Unpin,
{
    SansIoStream::new(inner, sm)
}
