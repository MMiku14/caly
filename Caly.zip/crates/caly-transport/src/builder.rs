//! Stream builder for connecting and upgrading transport streams with TCP_NODELAY and SO_KEEPALIVE.

use crate::stream::ConcreteStream;
use crate::tls::TlsConnectorLayer;
use caly_common::error::TransportError;
use std::net::SocketAddr;
use tokio::net::TcpStream;

#[derive(Debug, Clone, Default)]
pub struct TransportConfig {
    pub tls_enabled: bool,
    pub sni: Option<String>,
}

pub struct StreamBuilder {
    config: TransportConfig,
    tls_layer: Option<TlsConnectorLayer>,
}

impl StreamBuilder {
    pub fn new(config: TransportConfig) -> Result<Self, TransportError> {
        let tls_layer = if config.tls_enabled {
            Some(TlsConnectorLayer::new()?)
        } else {
            None
        };
        Ok(Self { config, tls_layer })
    }

    pub async fn dial(&self, target_addr: SocketAddr) -> Result<ConcreteStream, TransportError> {
        let tcp = TcpStream::connect(target_addr).await.map_err(TransportError::Io)?;
        let _ = tcp.set_nodelay(true);
        if self.config.tls_enabled {
            if let Some(ref tls) = self.tls_layer {
                let sni = self.config.sni.as_deref().unwrap_or("localhost");
                let tls_stream = tls.handshake(sni, tcp).await?;
                return Ok(ConcreteStream::Tls(Box::new(tls_stream)));
            }
        }
        Ok(ConcreteStream::Tcp(tcp))
    }
}
