//! Session management, metadata enrichment, and protocol sniffing.

pub mod context;
pub mod guard;
pub mod pipeline;
pub mod sniff;

pub use context::{SessionContext, SessionStats};
pub use guard::{ConnectionGuard, SessionMetricsSnapshot, SessionMetricsTracker};
pub use pipeline::EnrichmentPipeline;
pub use sniff::{SniffResult, Sniffer};
