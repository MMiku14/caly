//! Session context representation, stats, and metadata enrichment.

use caly_common::dns::DnsResolver;
use caly_common::metadata::{Network, SessionMetadata};
use smol_str::SmolStr;
use std::net::{IpAddr, SocketAddr};
use std::time::Instant;

#[derive(Debug, Clone, Copy, Default, PartialEq, Eq)]
pub struct SessionStats {
    pub bytes_in: u64,
    pub bytes_out: u64,
    pub packets_in: u64,
    pub packets_out: u64,
}

impl SessionStats {
    #[inline]
    pub fn add_rx(&mut self, bytes: u64) {
        self.bytes_in += bytes;
        self.packets_in += 1;
    }

    #[inline]
    pub fn add_tx(&mut self, bytes: u64) {
        self.bytes_out += bytes;
        self.packets_out += 1;
    }
}

pub struct SessionContext {
    pub id: u64,
    pub metadata: SessionMetadata,
    pub outbound_tag: Option<SmolStr>,
    pub created_at: Instant,
    pub stats: SessionStats,
}

impl SessionContext {
    pub fn new(id: u64, src_addr: SocketAddr, dst_addr: SocketAddr, network: Network) -> Self {
        Self {
            id,
            metadata: SessionMetadata::new(src_addr, dst_addr, network),
            outbound_tag: None,
            created_at: Instant::now(),
            stats: SessionStats::default(),
        }
    }

    #[inline]
    pub fn is_fake_ip(ip: IpAddr) -> bool {
        match ip {
            IpAddr::V4(v4) => {
                let octets = v4.octets();
                octets[0] == 198 && (octets[1] == 18 || octets[1] == 19)
            }
            // 修复（Round 20）：FakeIP 池仅使用 IPv4（198.18.0.0/15）。
            // 旧实现检测的 2001:db8:fa1e::/48 是 IETF 文档保留段，
            // 与 FakeIP 无关；且 FakeIpPool 根本不产生 IPv6 地址。
            // 这里直接返回 false，语义清晰。
            IpAddr::V6(_) => false,
        }
    }

    pub fn enrich_metadata(
        &mut self,
        dns: &dyn DnsResolver,
        initial_payload: Option<&[u8]>,
    ) {
        use caly_common::metadata::SniffedProto;
        use caly_common::metadata::{
            SNIFF_SRC_DNS_SNOOP, SNIFF_SRC_FAKEIP, SNIFF_SRC_HTTP_HOST, SNIFF_SRC_SNI,
        };

        if self.metadata.has_domain()
            && self.metadata.sniff_source == caly_common::metadata::SNIFF_SRC_NONE
        {
            self.metadata.sniff_source = caly_common::metadata::SNIFF_SRC_USER;
        }

        let dst_ip = self.metadata.dst_addr.ip();
        if !self.metadata.has_domain() {
            // Check FakeIP resolution via direct resolver lookup or benchmark range
            if let Some(domain) = dns.lookup_fakeip(dst_ip) {
                self.metadata.set_domain_with_source(&domain, SNIFF_SRC_FAKEIP);
            } else if let Some(domain) = dns.snoop(dst_ip, self.metadata.dst_addr.port()) {
                self.metadata.set_domain_with_source(&domain, SNIFF_SRC_DNS_SNOOP);
            }
        }

        // Protocol sniffing: always sniff payload to classify protocol for L4 splice,
        // even if domain was already known!
        if let Some(payload) = initial_payload {
            let sniffer = crate::sniff::Sniffer;
            if let Some(result) = sniffer.sniff(payload) {
                if !self.metadata.has_domain() {
                    if let Some(host) = result.domain {
                        let source = match result.proto {
                            SniffedProto::Tls => SNIFF_SRC_SNI,
                            SniffedProto::Http => SNIFF_SRC_HTTP_HOST,
                            _ => caly_common::metadata::SNIFF_SRC_NONE,
                        };
                        self.metadata.set_domain_with_source(&host, source);
                    }
                }
                if result.proto != SniffedProto::Unknown {
                    self.metadata.protocol = result.proto;
                }
                if let Some(alpn) = result.alpn {
                    if self.metadata.alpn.is_none() {
                        self.metadata.set_alpn(&alpn);
                    }
                }
            }
        }
    }
}
