//! Zero-copy Deep Packet Inspection (DPI) parser for TLS SNI/ALPN/GREASE, HTTP Host, HTTP/2 Preface, and QUIC.

use caly_common::metadata::SniffedProto;
use smol_str::SmolStr;

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct SniffResult {
    pub proto: SniffedProto,
    pub domain: Option<SmolStr>,
    pub alpn: Option<SmolStr>,
}

pub struct Sniffer;

impl Sniffer {
    pub fn sniff(&self, payload: &[u8]) -> Option<SniffResult> {
        if payload.is_empty() {
            return None;
        }
        // 1. HTTP/2 Client Connection Preface (RFC 7540)
        if payload.starts_with(b"PRI * HTTP/2.0

SM

") {
            return Some(SniffResult {
                proto: SniffedProto::Http,
                domain: None,
                alpn: Some(SmolStr::new("h2")),
            });
        }
        // 2. TLS ClientHello with SNI and ALPN extraction
        if let Some((domain, alpn)) = Self::sniff_tls(payload) {
            return Some(SniffResult {
                proto: SniffedProto::Tls,
                domain,
                alpn,
            });
        }
        // 3. HTTP Host extraction
        if let Some(domain) = Self::sniff_http_host(payload) {
            return Some(SniffResult {
                proto: SniffedProto::Http,
                domain: Some(domain),
                alpn: Some(SmolStr::new("http/1.1")),
            });
        }
        // 4. QUIC Initial packet (RFC 9000)
        if Self::is_quic_initial(payload) {
            return Some(SniffResult {
                proto: SniffedProto::Quic,
                domain: None,
                alpn: None,
            });
        }
        // 5. BitTorrent protocol
        if payload.len() >= 20 && payload[0] == 19 && &payload[1..20] == b"BitTorrent protocol" {
            return Some(SniffResult {
                proto: SniffedProto::BitTorrent,
                domain: None,
                alpn: None,
            });
        }
        None
    }

    pub fn sniff_tls(buf: &[u8]) -> Option<(Option<SmolStr>, Option<SmolStr>)> {
        if buf.len() < 43 || buf[0] != 0x16 || buf[5] != 0x01 {
            return None;
        }
        let mut offset = 43;
        let session_id_len = *buf.get(offset)? as usize;
        offset += 1 + session_id_len;
        let cipher_suites_len =
            (*buf.get(offset)? as usize) << 8 | (*buf.get(offset + 1)? as usize);
        offset += 2 + cipher_suites_len;
        let comp_methods_len = *buf.get(offset)? as usize;
        offset += 1 + comp_methods_len;
        if offset + 2 > buf.len() {
            return None;
        }
        let extensions_len =
            (*buf.get(offset)? as usize) << 8 | (*buf.get(offset + 1)? as usize);
        offset += 2;
        let extensions_end = (offset + extensions_len).min(buf.len());
        let mut sni_result = None;
        let mut alpn_result = None;
        while offset + 4 <= extensions_end {
            let ext_type = (*buf.get(offset)? as u16) << 8 | (*buf.get(offset + 1)? as u16);
            let ext_len = (*buf.get(offset + 2)? as usize) << 8 | (*buf.get(offset + 3)? as usize);
            offset += 4;
            if offset + ext_len > extensions_end {
                break;
            }
            // Skip RFC 8701 GREASE extension values (0x?a?a)
            if (ext_type & 0x0F0F) == 0x0A0A {
                offset += ext_len;
                continue;
            }
            // Server Name Indication (SNI) - 0x0000
            if ext_type == 0x0000 {
                let mut sni_offset = offset;
                if sni_offset + 2 <= offset + ext_len {
                    sni_offset += 2;
                    while sni_offset + 3 <= offset + ext_len {
                        let name_type = *buf.get(sni_offset)?;
                        let name_len = (*buf.get(sni_offset + 1)? as usize) << 8
                            | (*buf.get(sni_offset + 2)? as usize);
                        sni_offset += 3;
                        if name_type == 0x00 && sni_offset + name_len <= offset + ext_len {
                            let name_bytes = &buf[sni_offset..sni_offset + name_len];
                            if let Ok(name_str) = std::str::from_utf8(name_bytes) {
                                sni_result = Some(SmolStr::new(name_str.to_ascii_lowercase()));
                            }
                        }
                        sni_offset += name_len;
                    }
                }
            }
            // Application-Layer Protocol Negotiation (ALPN) - 0x0010
            if ext_type == 0x0010 && offset + 2 <= offset + ext_len {
                let mut alpn_offset = offset + 2;
                if alpn_offset < offset + ext_len {
                    let proto_len = *buf.get(alpn_offset)? as usize;
                    alpn_offset += 1;
                    if alpn_offset + proto_len <= offset + ext_len {
                        if let Ok(alpn_str) =
                            std::str::from_utf8(&buf[alpn_offset..alpn_offset + proto_len])
                        {
                            alpn_result = Some(SmolStr::new(alpn_str.to_ascii_lowercase()));
                        }
                    }
                }
            }
            offset += ext_len;
        }
        if sni_result.is_some() || alpn_result.is_some() {
            Some((sni_result, alpn_result))
        } else {
            None
        }
    }

    pub fn sniff_http_host(buf: &[u8]) -> Option<SmolStr> {
        // [FIXED] 仅切分出 HTTP Header 区域解析，避免 Body 包含二进制数据导致 UTF-8 解码失败
        let header_bytes = if let Some(pos) = buf.windows(4).position(|w| w == b"\r\n\r\n") {
            &buf[..pos]
        } else if let Some(pos) = buf.windows(2).position(|w| w == b"\n\n") {
            &buf[..pos]
        } else {
            buf
        };
        let text = std::str::from_utf8(header_bytes).ok()?;
        let mut lines = text.lines();
        let first_line = lines.next()?;
        let valid_method = first_line.starts_with("GET ")
            || first_line.starts_with("POST ")
            || first_line.starts_with("CONNECT ")
            || first_line.starts_with("PUT ")
            || first_line.starts_with("DELETE ")
            || first_line.starts_with("HEAD ")
            || first_line.starts_with("OPTIONS ")
            || first_line.starts_with("PATCH ");
        if !valid_method {
            return None;
        }
        for line in lines {
            if line.trim().is_empty() {
                break;
            }
            if line.len() > 5 && line[..5].eq_ignore_ascii_case("host:") {
                let val = line[5..].trim();
                let host = if val.starts_with('[') {
                    if let Some(bracket) = val.find(']') {
                        &val[1..bracket]
                    } else {
                        val
                    }
                } else if let Some(idx) = val.find(':') {
                    &val[..idx]
                } else {
                    val
                };
                if !host.is_empty() {
                    return Some(SmolStr::new(host.to_ascii_lowercase()));
                }
            }
        }
        None
    }

    #[inline]
    pub fn is_quic_initial(buf: &[u8]) -> bool {
        if buf.len() < 12 {
            return false;
        }
        let first_byte = buf[0];
        let is_long_header = (first_byte & 0x80) != 0;
        let fixed_bit = (first_byte & 0x40) != 0;
        let packet_type = (first_byte & 0x30) >> 4;
        if !is_long_header || !fixed_bit || packet_type != 0x00 {
            return false;
        }
        let version = u32::from_be_bytes([buf[1], buf[2], buf[3], buf[4]]);
        version != 0
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_sniff_h2_preface() {
        let payload = b"PRI * HTTP/2.0

SM

";
        let result = Sniffer.sniff(payload).unwrap();
        assert_eq!(result.proto, SniffedProto::Http);
        assert_eq!(result.alpn.as_deref(), Some("h2"));
    }

    #[test]
    fn test_sniff_bittorrent() {
        let mut payload = vec![19u8];
        payload.extend_from_slice(b"BitTorrent protocol");
        payload.extend_from_slice(&[0u8; 8]);
        let result = Sniffer.sniff(&payload).unwrap();
        assert_eq!(result.proto, SniffedProto::BitTorrent);
    }

    #[test]
    fn test_sniff_http_host_simple() {
        let payload = b"GET / HTTP/1.1
Host: example.com

";
        let domain = Sniffer::sniff_http_host(payload).unwrap();
        assert_eq!(domain.as_str(), "example.com");
    }

    #[test]
    fn test_sniff_http_host_case_insensitive() {
        let payload = b"GET / HTTP/1.1
host: EXAMPLE.com

";
        let domain = Sniffer::sniff_http_host(payload).unwrap();
        assert_eq!(domain.as_str(), "example.com");
    }
}
