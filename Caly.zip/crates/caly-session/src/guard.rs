//! RAII connection guard ensuring deterministic resource teardown.

use dashmap::DashMap;
use std::sync::atomic::{AtomicU64, AtomicUsize, Ordering};
use std::sync::Arc;
use std::time::Instant;

/// 支持的最大 worker 数量。
///
/// 与 bootstrap 里 `available_parallelism().clamp(1, 64)` 的上限一致。
/// 固定上界让 worker_limits / worker_active 可以用定长数组取代
/// DashMap。
const MAX_WORKERS: usize = 64;

/// 独占一个 cache line 的原子计数器。
///
/// Thread-per-Core 架构下每个 worker 有独立的计数器。如果不做 padding，
/// 相邻两个 worker 的 AtomicU64 会共享同一个 64 字节 cache line：
///
/// ```text
/// cache line (64B)
/// ┌─────────┬─────────┬─────────┬─────┬─────────┐
/// │ worker0 │ worker1 │ worker2 │ ... │ worker7 │
/// └─────────┴─────────┴─────────┴─────┴─────────┘
///      ▲                    ▲
///   worker0 写           worker1 写
///   → 从 worker1 的 L1 里驱逐整个 line
///   → MESI 协议下反复 invalidation
/// ```
///
/// `#[repr(align(64))]` 让每个计数器独享一个 cache line。
/// 成本：64 worker × 64 字节 = 4KB。可忽略。
#[derive(Debug)]
#[repr(align(64))]
struct PaddedCounter(AtomicU64);

#[derive(Debug)]
pub struct SessionMetricsTracker {
    pub active_connections: AtomicU64,
    pub total_connections: AtomicU64,
    pub bytes_in_total: AtomicU64,
    pub bytes_out_total: AtomicU64,
    pub outbound_hits: DashMap<String, AtomicU64>,
    pub outbound_bytes: DashMap<String, (AtomicU64, AtomicU64)>,
    // 修复（Round 28）：worker_limits / worker_active 从 DashMap 改为
    // 固定大小数组，worker_id 直接索引。
    //
    // 旧实现每次会话开始/结束都要在全局 DashMap 里做 hash + 分片锁，
    // 与 Thread-per-Core 的 share-nothing 原则矛盾。修复后：
    //   - 无 hash
    //   - 无分片锁
    //   - worker_active 用 PaddedCounter 隔离 cache line
    //
    // outbound_hits / outbound_bytes 保留 DashMap：
    //   - 写频率 = 每会话一次（非每包）
    //   - tag 数量动态，无法预分配索引
    //   - 10K QPS 下 DashMap 分片锁完全够用
    worker_limits: [AtomicUsize; MAX_WORKERS],
    worker_active: [PaddedCounter; MAX_WORKERS],
}

impl Default for SessionMetricsTracker {
    fn default() -> Self {
        Self::new()
    }
}

impl SessionMetricsTracker {
    pub fn new() -> Self {
        Self {
            active_connections: AtomicU64::new(0),
            total_connections: AtomicU64::new(0),
            bytes_in_total: AtomicU64::new(0),
            bytes_out_total: AtomicU64::new(0),
            outbound_hits: DashMap::new(),
            outbound_bytes: DashMap::new(),
            worker_limits: std::array::from_fn(|_| AtomicUsize::new(0)),
            worker_active: std::array::from_fn(|_| PaddedCounter(AtomicU64::new(0))),
        }
    }

    #[inline]
    pub fn inc(&self) {
        self.active_connections.fetch_add(1, Ordering::Relaxed);
        self.total_connections.fetch_add(1, Ordering::Relaxed);
    }

    #[inline]
    pub fn dec(&self) {
        self.active_connections.fetch_sub(1, Ordering::Relaxed);
    }

    #[inline]
    pub fn record_bytes(&self, bytes_in: u64, bytes_out: u64) {
        self.bytes_in_total.fetch_add(bytes_in, Ordering::Relaxed);
        self.bytes_out_total.fetch_add(bytes_out, Ordering::Relaxed);
    }

    #[inline]
    pub fn record_outbound_bytes(&self, tag: &str, bytes_in: u64, bytes_out: u64) {
        if let Some(entry) = self.outbound_bytes.get(tag) {
            entry.0.fetch_add(bytes_in, Ordering::Relaxed);
            entry.1.fetch_add(bytes_out, Ordering::Relaxed);
            return;
        }
        self.outbound_bytes
            .entry(tag.to_string())
            .or_insert_with(|| (AtomicU64::new(0), AtomicU64::new(0)));
        if let Some(entry) = self.outbound_bytes.get(tag) {
            entry.0.fetch_add(bytes_in, Ordering::Relaxed);
            entry.1.fetch_add(bytes_out, Ordering::Relaxed);
        }
    }

    pub fn set_worker_limit(&self, worker_id: usize, limit: usize) {
        if worker_id < MAX_WORKERS {
            self.worker_limits[worker_id].store(limit, Ordering::Relaxed);
        }
    }

    #[inline]
    pub fn worker_inc(&self, worker_id: usize) {
        if worker_id < MAX_WORKERS {
            self.worker_active[worker_id].0.fetch_add(1, Ordering::Relaxed);
        }
    }

    #[inline]
    pub fn worker_dec(&self, worker_id: usize) {
        if worker_id < MAX_WORKERS {
            self.worker_active[worker_id].0.fetch_sub(1, Ordering::Relaxed);
        }
    }

    pub fn worker_active_snapshot(&self) -> Vec<(usize, u64)> {
        let mut v: Vec<(usize, u64)> = Vec::with_capacity(MAX_WORKERS);
        for (id, c) in self.worker_active.iter().enumerate() {
            let n = c.0.load(Ordering::Relaxed);
            // 只返回活跃的 worker，避免 /metrics 里出现 64 条全 0 的噪声。
            if n > 0 {
                v.push((id, n));
            }
        }
        v
    }

    pub fn worker_limits_snapshot(&self) -> Vec<(usize, usize)> {
        let mut v: Vec<(usize, usize)> = Vec::with_capacity(MAX_WORKERS);
        for (id, c) in self.worker_limits.iter().enumerate() {
            let n = c.load(Ordering::Relaxed);
            // 未 set 的 worker 保持 0；只返回已设置的。
            if n > 0 {
                v.push((id, n));
            }
        }
        v
    }

    pub fn snapshot(&self) -> SessionMetricsSnapshot {
        SessionMetricsSnapshot {
            active: self.active_connections.load(Ordering::Relaxed),
            total: self.total_connections.load(Ordering::Relaxed),
            bytes_in: self.bytes_in_total.load(Ordering::Relaxed),
            bytes_out: self.bytes_out_total.load(Ordering::Relaxed),
        }
    }

    #[inline]
    pub fn record_outbound(&self, tag: &str) {
        if let Some(c) = self.outbound_hits.get(tag) {
            c.fetch_add(1, Ordering::Relaxed);
            return;
        }
        self.outbound_hits
            .entry(tag.to_string())
            .or_insert_with(|| AtomicU64::new(0))
            .fetch_add(1, Ordering::Relaxed);
    }

    pub fn outbound_snapshot(&self) -> Vec<(String, u64)> {
        let mut out: Vec<(String, u64)> = self
            .outbound_hits
            .iter()
            .map(|e| (e.key().clone(), e.value().load(Ordering::Relaxed)))
            .collect();
        out.sort_by(|a, b| a.0.cmp(&b.0));
        out
    }
}

#[derive(Debug, Clone, Copy)]
pub struct SessionMetricsSnapshot {
    pub active: u64,
    pub total: u64,
    pub bytes_in: u64,
    pub bytes_out: u64,
}

pub struct ConnectionGuard {
    pub session_id: u64,
    metrics: Option<Arc<SessionMetricsTracker>>,
    created_at: Instant,
}

impl ConnectionGuard {
    pub fn new(session_id: u64, metrics: Option<Arc<SessionMetricsTracker>>) -> Self {
        if let Some(ref m) = metrics {
            m.inc();
        }
        Self {
            session_id,
            metrics,
            created_at: Instant::now(),
        }
    }

    #[inline]
    pub fn elapsed(&self) -> std::time::Duration {
        self.created_at.elapsed()
    }
}

impl Drop for ConnectionGuard {
    fn drop(&mut self) {
        if let Some(ref m) = self.metrics {
            m.dec();
        }
    }
}
