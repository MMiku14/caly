//! Metadata enrichment orchestration pipeline.

use crate::context::SessionContext;
use caly_common::dns::DnsResolver;

pub struct EnrichmentPipeline;

impl EnrichmentPipeline {
    #[inline]
    pub fn execute(ctx: &mut SessionContext, dns: &dyn DnsResolver, initial_payload: Option<&[u8]>) {
        ctx.enrich_metadata(dns, initial_payload);
    }
}
