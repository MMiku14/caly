//! Fuzz tests for DPI sniffer.
//!
//! `Sniffer::sniff` 处理客户端首个应用层字节。旧实现在多个位置
//! 使用 `offset += len` 累积，一旦某处漏了边界检查就会 panic。

use caly_session::sniff::Sniffer;

struct XorShift64(u64);

impl XorShift64 {
    fn new(seed: u64) -> Self {
        Self(if seed == 0 { 0x9E37_79B9_7F4A_7C15 } else { seed })
    }
    fn next_u64(&mut self) -> u64 {
        let mut x = self.0;
        x ^= x << 13;
        x ^= x >> 7;
        x ^= x << 17;
        self.0 = x;
        x
    }
    fn fill(&mut self, buf: &mut [u8]) {
        for chunk in buf.chunks_mut(8) {
            let v = self.next_u64().to_le_bytes();
            let n = chunk.len();
            chunk.copy_from_slice(&v[..n]);
        }
    }
    fn range(&mut self, max: usize) -> usize {
        if max == 0 { 0 } else { (self.next_u64() as usize) % max }
    }
}

const SEED_SNIFF: u64 = 0x00C4_1D00_5E55_0001;

#[test]
fn fuzz_sniff_random_bytes() {
    let mut rng = XorShift64::new(SEED_SNIFF);
    for _ in 0..20_000 {
        let len = rng.range(2048);
        let mut buf = vec![0u8; len];
        rng.fill(&mut buf);
        let _ = Sniffer.sniff(&buf);
    }
}

#[test]
fn fuzz_sniff_tls_prefix_random_tail() {
    // 合法的 TLS ClientHello 起始（0x16 0x03 0x01 ...）+ 随机尾部。
    // 触发 TLS 扩展解析路径，验证所有 offset 计算的健壮性。
    let mut rng = XorShift64::new(SEED_SNIFF ^ 0x7573);
    for _ in 0..10_000 {
        let mut buf = vec![
            0x16, 0x03, 0x01, 0x00, 0x00, 0x01, // TLS record header
            0x01, 0x00, 0x00, 0xFD, 0x03, 0x03, // handshake header + version
        ];
        // 32 字节 random
        let mut rand32 = [0u8; 32];
        rng.fill(&mut rand32);
        buf.extend_from_slice(&rand32);

        // session_id_len（0..32）
        let sid_len = rng.range(33);
        buf.push(sid_len as u8);
        let mut sid = vec![0u8; sid_len];
        rng.fill(&mut sid);
        buf.extend_from_slice(&sid);

        // cipher_suites_len（偶数）
        let cs_len = rng.range(64) * 2;
        buf.push((cs_len >> 8) as u8);
        buf.push((cs_len & 0xFF) as u8);
        let mut cs = vec![0u8; cs_len];
        rng.fill(&mut cs);
        buf.extend_from_slice(&cs);

        // comp_methods_len
        buf.push(1);
        buf.push(0x00);

        // extensions_len
        let ext_len = rng.range(512);
        buf.push((ext_len >> 8) as u8);
        buf.push((ext_len & 0xFF) as u8);
        let mut exts = vec![0u8; ext_len];
        rng.fill(&mut exts);
        buf.extend_from_slice(&exts);

        let _ = Sniffer.sniff(&buf);
    }
}

#[test]
fn fuzz_sniff_http_variants() {
    let methods = [
        b"GET ".as_slice(),
        b"POST ".as_slice(),
        b"CONNECT ".as_slice(),
        b"PUT ".as_slice(),
        b"HEAD ".as_slice(),
    ];
    let mut rng = XorShift64::new(SEED_SNIFF ^ 0x4854_5450);
    for _ in 0..10_000 {
        let method = methods[rng.range(methods.len())];
        let mut buf = method.to_vec();
        let path_len = rng.range(64);
        let mut path = vec![0u8; path_len];
        rng.fill(&mut path);
        buf.extend_from_slice(&path);
        buf.extend_from_slice(b" HTTP/1.1\r\n");
        buf.extend_from_slice(b"Host: ");
        let host_len = rng.range(64);
        let mut host = vec![0u8; host_len];
        rng.fill(&mut host);
        buf.extend_from_slice(&host);
        buf.extend_from_slice(b"\r\n\r\n");
        let _ = Sniffer.sniff(&buf);
    }
}
