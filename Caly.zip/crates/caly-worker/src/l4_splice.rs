//! Linux zero-copy L4 splice gating logic.

use caly_common::metadata::SessionMetadata;

pub struct L4SpliceDecider;

impl L4SpliceDecider {
    pub fn can_splice(_meta: &SessionMetadata, outbound_tag: &str) -> bool {
        #[cfg(target_os = "linux")]
        {
            outbound_tag == "direct"
        }
        #[cfg(not(target_os = "linux"))]
        {
            let _ = outbound_tag;
            false
        }
    }
}
