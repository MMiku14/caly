//! ByteSlab: static aligned memory slabs with mlock and prefault warmup fallback.

use parking_lot::Mutex;
use std::cell::UnsafeCell;
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::Arc;

#[repr(align(64))]
pub struct AlignedBuffer {
    pub data: UnsafeCell<[u8; 65536]>,
}

unsafe impl Send for AlignedBuffer {}
unsafe impl Sync for AlignedBuffer {}

impl Default for AlignedBuffer {
    fn default() -> Self {
        Self {
            data: UnsafeCell::new([0u8; 65536]),
        }
    }
}

pub struct SlabPool {
    buffers: Box<[AlignedBuffer]>,
    free_list: Mutex<Vec<usize>>,
    buffer_size: usize,
    mlock_succeeded: AtomicBool,
}

impl SlabPool {
    pub fn new(count: usize, buffer_size: usize) -> Self {
        let mut bufs = Vec::with_capacity(count);
        for _ in 0..count {
            bufs.push(AlignedBuffer::default());
        }
        let free_list = (0..count).collect();
        Self {
            buffers: bufs.into_boxed_slice(),
            free_list: Mutex::new(free_list),
            buffer_size: buffer_size.min(65536),
            mlock_succeeded: AtomicBool::new(false),
        }
    }

    pub fn init(&mut self) {
        let ptr = self.buffers.as_mut_ptr() as *mut libc::c_void;
        let size = self.buffers.len() * std::mem::size_of::<AlignedBuffer>();
        #[cfg(target_os = "linux")]
        {
            let res = unsafe { libc::mlock(ptr, size) };
            if res == 0 {
                self.mlock_succeeded.store(true, Ordering::Relaxed);
                tracing::info!(size_bytes = size, "mlock successfully locked Slab memory pages");
            } else {
                let err = std::io::Error::last_os_error();
                tracing::warn!(
                    error = %err,
                    "mlock failed (missing CAP_IPC_LOCK in container?); gracefully falling back to prefault warmup"
                );
            }
        }
        for buf in self.buffers.iter_mut() {
            unsafe {
                std::ptr::write_bytes(buf.data.get() as *mut u8, 0, 65536);
            }
        }
    }

    pub fn acquire(self: &Arc<Self>) -> Option<SlabHandle> {
        let idx = self.free_list.lock().pop()?;
        Some(SlabHandle {
            pool: self.clone(),
            index: idx,
        })
    }

    fn return_index(&self, idx: usize) {
        self.free_list.lock().push(idx);
    }
}

pub struct SlabHandle {
    pool: Arc<SlabPool>,
    pub index: usize,
}

impl SlabHandle {
    #[inline]
    pub fn as_slice_mut(&mut self) -> &mut [u8] {
        let buf_ptr = self.pool.buffers[self.index].data.get() as *mut u8;
        unsafe { std::slice::from_raw_parts_mut(buf_ptr, self.pool.buffer_size) }
    }
}

impl Drop for SlabHandle {
    fn drop(&mut self) {
        self.pool.return_index(self.index);
    }
}
