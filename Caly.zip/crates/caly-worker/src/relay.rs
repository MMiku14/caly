//! Bidirectional zero-copy proxy relaying with graceful TCP FIN half-close propagation.

use caly_transport::ConcreteStream;
use std::cell::RefCell;
use std::io;
use std::time::Duration;
use tokio::io::{AsyncRead, AsyncReadExt, AsyncWrite, AsyncWriteExt};
use tokio::net::TcpStream;
use tokio::sync::watch;

/// 单次 relay 的缓冲区大小。
const RELAY_BUF_SIZE: usize = 32 * 1024;

/// 线程本地空闲缓冲区池的最大深度。
///
/// 每个 worker 是单线程（thread-per-core），relay 在同一线程内运行。
/// 池深度对应"同线程内并发 relay 数量"——超过此数量时会重新分配。
/// 8 对 32KB 缓冲 = 512KB 峰值缓存/线程，对 4-16 核部署可接受。
const RELAY_BUF_POOL_DEPTH: usize = 8;

thread_local! {
    /// 每 worker 线程独立的空闲 relay 缓冲区池。
    ///
    /// 背景：旧实现 `vec![0u8; 32 * 1024]` 在每个连接的两个方向上
    /// 各分配一次，即每连接 2× 32KB = 64KB 堆分配 + 零初始化。
    /// 在 10K QPS 场景下这意味着 640 MB/s 的分配器压力。
    ///
    /// 池化后稳态零分配：连接建立时从池取，结束时 Drop 归还。
    /// tokio 的 `spawn_local` 保证同一连接的所有 relay 代码在同一
    /// worker 线程执行，因此线程本地池天然安全。
    static RELAY_BUF_POOL: RefCell<Vec<Vec<u8>>> = const { RefCell::new(Vec::new()) };
}

/// RAII relay 缓冲区。Drop 时归还线程本地池。
struct RelayBuf {
    buf: Option<Vec<u8>>,
}

impl RelayBuf {
    #[inline]
    fn acquire() -> Self {
        let buf = RELAY_BUF_POOL.with(|pool| pool.borrow_mut().pop());
        match buf {
            Some(b) if b.len() == RELAY_BUF_SIZE => Self { buf: Some(b) },
            _ => Self {
                buf: Some(vec![0u8; RELAY_BUF_SIZE]),
            },
        }
    }

    #[inline]
    fn as_mut_slice(&mut self) -> &mut [u8] {
        self.buf.as_mut().expect("RelayBuf invariant: buf is Some")
    }
}

impl Drop for RelayBuf {
    fn drop(&mut self) {
        if let Some(buf) = self.buf.take() {
            RELAY_BUF_POOL.with(|pool| {
                let mut p = pool.borrow_mut();
                if p.len() < RELAY_BUF_POOL_DEPTH {
                    p.push(buf);
                }
                // 超出池深度：缓冲区自然 Drop，避免无界增长
            });
        }
    }
}

/// 单方向空闲多久后强制关闭。
///
/// 5 分钟是保守上限。正常代理会话中，客户端每几秒至少发一次数据
/// （HTTP keep-alive 保活、TLS 心跳等）。5 分钟无数据 = 死连接。
const RELAY_IDLE_TIMEOUT: Duration = Duration::from_secs(300);

/// 一方完成（EOF）后，另一方的宽限时间。
///
/// 场景：客户端发完 FIN，但上游还没回包。TCP 半关闭允许我们继续
/// 读取上游数据。但如果上游挂死，我们不希望无限等待 —— 旧实现就是
/// 卡在这里，上游无响应时连接永挂。
///
/// 30 秒覆盖绝大多数"客户端提前关闭但上游还在响应"的场景
/// （HTTP/1.1 请求-响应模型：客户端发完请求立刻 half-close，
/// 服务端通常在几百毫秒内返回完整响应）。
const RELAY_HALF_CLOSE_GRACE: Duration = Duration::from_secs(30);

/// 单向数据泵。从 `reader` 读，写到 `writer`，直到：
///   1. 读到 EOF → shutdown 写端，通过 `my_done_tx` 通知对方方向
///   2. 对方向已完成 → 进入 `RELAY_HALF_CLOSE_GRACE` 宽限期，
///      宽限期内无数据则返回 Timeout
///   3. 超过 `RELAY_IDLE_TIMEOUT` 无数据 → 返回 Timeout
///   4. 读写 I/O 错误 → 立即返回该错误
///
/// 关键点：`peer_done_rx` 与 `my_done_tx` 是**两个独立的 watch
/// channel**。c2s 方向的 sender 对应 s2c 方向的 receiver，反之亦然。
/// 不能用同一个 channel —— 否则一方完成会让另一方误以为自己完成。
async fn pump_direction<R, W>(
    mut reader: R,
    mut writer: W,
    my_done_tx: watch::Sender<bool>,
    mut peer_done_rx: watch::Receiver<bool>,
    label: &'static str,
) -> io::Result<u64>
where
    R: AsyncRead + Unpin,
    W: AsyncWrite + Unpin,
{
    let mut relay_buf = RelayBuf::acquire();
    let mut total = 0u64;
    let mut grace_deadline: Option<tokio::time::Instant> = None;

    // peer_done 等待 future。watch::Receiver::changed 是 cancel-safe：
    // 即便被 select 取消，下次进入时会重新检查当前值。
    let peer_done_fut = async {
        loop {
            if *peer_done_rx.borrow() {
                return;
            }
            if peer_done_rx.changed().await.is_err() {
                // sender 全 drop（理论上不会，另一方向会持有）
                return;
            }
        }
    };
    tokio::pin!(peer_done_fut);

    loop {
        let read_timeout = match grace_deadline {
            Some(d) => d.saturating_duration_since(tokio::time::Instant::now()),
            None => RELAY_IDLE_TIMEOUT,
        };

        if read_timeout.is_zero() {
            let _ = my_done_tx.send(true);
            tracing::debug!(direction = label, "relay: half-close grace expired");
            return Err(io::Error::new(
                io::ErrorKind::TimedOut,
                "relay half-close grace expired",
            ));
        }

        // 每次循环重新拿 buf（&mut 借用无法跨迭代持有）
        let buf = relay_buf.as_mut_slice();

        tokio::select! {
            biased;

            // 优先处理读：如果有数据在等，不能因为 peer_done 就绪
            // 而取消 read 导致数据丢失（tokio AsyncReadExt::read 在
            // 被取消时已读出的字节会丢失）。
            read_res = tokio::time::timeout(read_timeout, reader.read(buf)) => {
                match read_res {
                    Ok(Ok(0)) => {
                        // 本地 EOF：半关闭写端，通知对方方向
                        let _ = writer.shutdown().await;
                        let _ = my_done_tx.send(true);
                        return Ok(total);
                    }
                    Ok(Ok(n)) => {
                        writer.write_all(&buf[..n]).await?;
                        total += n as u64;
                    }
                    Ok(Err(e)) => {
                        let _ = my_done_tx.send(true);
                        return Err(e);
                    }
                    Err(_) => {
                        let _ = my_done_tx.send(true);
                        tracing::debug!(
                            direction = label,
                            in_grace = grace_deadline.is_some(),
                            "relay: idle timeout"
                        );
                        return Err(io::Error::new(
                            io::ErrorKind::TimedOut,
                            "relay idle timeout",
                        ));
                    }
                }
            }

            // 对方向完成 → 启动宽限期
            _ = &mut peer_done_fut, if grace_deadline.is_none() => {
                grace_deadline = Some(tokio::time::Instant::now() + RELAY_HALF_CLOSE_GRACE);
                tracing::debug!(
                    direction = label,
                    grace_secs = RELAY_HALF_CLOSE_GRACE.as_secs(),
                    "relay: peer direction done, entering half-close grace"
                );
            }
        }
    }
}

pub async fn relay_bidirectional(
    inbound: TcpStream,
    outbound: ConcreteStream,
) -> io::Result<(u64, u64)> {
    relay_bidirectional_with_early_data(inbound, outbound, None).await
}

pub async fn relay_bidirectional_with_early_data(
    mut inbound: TcpStream,
    mut outbound: ConcreteStream,
    early_data: Option<&[u8]>,
) -> io::Result<(u64, u64)> {
    if let Some(early) = early_data {
        if !early.is_empty() {
            outbound.write_all(early).await?;
        }
    }

    let (in_r, in_w) = inbound.split();
    let (out_r, out_w) = tokio::io::split(outbound);

    // 两个独立的 watch channel：
    //   c2s_done 传达 "客户端→服务端 方向已完成"
    //   s2c_done 传达 "服务端→客户端 方向已完成"
    //
    // c2s 持有 c2s_done_tx（发信号）+ s2c_done_rx（等对方）
    // s2c 持有 s2c_done_tx（发信号）+ c2s_done_rx（等对方）
    let (c2s_done_tx, c2s_done_rx) = watch::channel(false);
    let (s2c_done_tx, s2c_done_rx) = watch::channel(false);

    let c2s = pump_direction(in_r, out_w, c2s_done_tx, s2c_done_rx, "c2s");
    let s2c = pump_direction(out_r, in_w, s2c_done_tx, c2s_done_rx, "s2c");

    // join! 而非 try_join!：
    //   - 单方向出错不应立即取消另一方向 —— 对方可能正在把剩余的
    //     缓冲数据写到客户端，突然取消会让客户端收到半截响应。
    //   - pump_direction 内部已带 idle / grace 超时，两边会各自在
    //     有限时间内完成，join 不会无限等。
    let (c2s_res, s2c_res) = tokio::join!(c2s, s2c);

    match (c2s_res, s2c_res) {
        (Ok(a), Ok(b)) => Ok((a, b)),
        // 优先返回 c2s 的错误（客户端方向），通常是更有意义的诊断信息
        (Err(e), _) => Err(e),
        (_, Err(e)) => Err(e),
    }
}
