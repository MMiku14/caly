//! Thread-per-core Worker Loop driving Sans-IO state machines, SO_REUSEPORT, and async I/O.

use crate::relay::relay_bidirectional_with_early_data;
use arc_swap::ArcSwap;
use caly_common::dns::DnsResolver;
use caly_common::error::ProxyError;
use caly_common::metadata::Network;
use caly_inbound::http::{HttpInbound, HttpRequestType};
use caly_inbound::socks5::{AuthConfig, Socks5Command, Socks5StateMachine, TargetAddr};
use caly_outbound::ProxyAdapter;
use caly_rules::RuleEngine;
use caly_session::context::SessionContext;
use caly_session::guard::{ConnectionGuard, SessionMetricsTracker};
use caly_transport::ConcreteStream;
use socket2::{Domain, Socket, Type};
use std::collections::HashMap;
use std::net::SocketAddr;
use std::sync::atomic::{AtomicU64, AtomicUsize, Ordering};
use std::sync::Arc;
use std::time::Duration;
use tokio::io::{AsyncReadExt, AsyncWriteExt};
use tokio::net::{TcpListener, TcpStream};
use tokio::sync::Notify;

#[derive(Debug, Clone)]
pub struct InboundSpec {
    pub tag: String,
    pub listen_addr: SocketAddr,
    pub auth: AuthConfig,
    /// 是否允许 UDP ASSOCIATE。
    ///
    /// 当前 worker **不实现** UDP ASSOCIATE（SOCKS5 命令 0x03），
    /// 此字段仅用于：
    ///   1. 生成更精确的 debug 日志，区分 "配置未开" vs "未实现"
    ///   2. 作为未来 UDP 中继实现的开关
    ///
    /// 无论此字段为何，SOCKS5 UDP ASSOCIATE 都会收到 REP=0x07（Command
    /// not supported）——客户端行为一致，但日志会说明原因。
    pub udp: bool,
    /// 是否启用首包 DPI 嗅探。
    ///
    /// `true` 时 worker 会把客户端发送的第一批应用数据传给
    /// `SessionContext::enrich_metadata`，尝试从 TLS SNI / HTTP Host
    /// 恢复域名并填充 protocol / alpn 字段。
    /// `false` 时完全跳过嗅探（对已知域名的 SOCKS5 域名 CONNECT 可
    /// 节省一次解析）。
    pub sniff: bool,
}

pub struct WorkerConfig {
    pub worker_id: usize,
    pub worker_count: usize,
    pub inbounds: Vec<Arc<InboundSpec>>,
    pub rules: Arc<ArcSwap<RuleEngine>>,
    pub dns: Arc<dyn DnsResolver>,
    pub outbounds: Arc<HashMap<String, Arc<dyn ProxyAdapter>>>,
    pub metrics: Arc<SessionMetricsTracker>,
    pub shutdown: Arc<Notify>,
}

const HARD_MAX_CONNECTIONS_PER_WORKER: usize = 8192;

fn compute_worker_connection_limit(worker_count: usize) -> usize {
    const RESERVE_RATIO_NUM: u64 = 3;
    const RESERVE_RATIO_DEN: u64 = 4;

    // 修复（Round 21）：MIN_LIMIT 之前定义后从未使用 —— 旧代码把
    // 下界写成字面量 `clamp(16, 128)`，MIN_LIMIT 是死代码（-D warnings
    // 直接拒绝编译）。这里把下界提上来，语义统一。
    //
    // 取 16 的理由：
    //   - 单 worker 至少保留 16 个并发连接，避免极端配置
    //     （RLIMIT_NOFILE 极低 / worker_count 极大）下把值压到 0~1。
    //   - 16 是实测能跑通一次 SOCKS5 握手 + 若干并发连接的合理地板。
    const MIN_LIMIT: usize = 16;

    let soft = read_rlimit_nofile().unwrap_or(1024);
    // 代理业务双端各需 1 个 Socket FD，实际可用并发数须折半
    let usable_conns = (soft * RESERVE_RATIO_NUM / RESERVE_RATIO_DEN) / 2;
    let per_worker = (usable_conns / worker_count.max(1) as u64) as usize;
    per_worker.clamp(MIN_LIMIT, HARD_MAX_CONNECTIONS_PER_WORKER)
}

#[cfg(unix)]
fn read_rlimit_nofile() -> Option<u64> {
    unsafe {
        let mut rlim: libc::rlimit = std::mem::zeroed();
        if libc::getrlimit(libc::RLIMIT_NOFILE, &mut rlim) == 0 {
            Some(rlim.rlim_cur)
        } else {
            None
        }
    }
}

#[cfg(not(unix))]
fn read_rlimit_nofile() -> Option<u64> {
    None
}

pub struct WorkerLoop {
    pub worker_id: usize,
    inbounds: Vec<Arc<InboundSpec>>,
    rules: Arc<ArcSwap<RuleEngine>>,
    dns: Arc<dyn DnsResolver>,
    outbounds: Arc<HashMap<String, Arc<dyn ProxyAdapter>>>,
    metrics: Arc<SessionMetricsTracker>,
    session_counter: AtomicU64,
    connections: Arc<tokio::sync::Semaphore>,
    connection_limit: usize,
    active_sessions: Arc<AtomicUsize>,
    shutdown: Arc<Notify>,
}

struct ActiveSessionGuard {
    counter: Arc<AtomicUsize>,
    metrics: Arc<SessionMetricsTracker>,
    worker_id: usize,
}

impl ActiveSessionGuard {
    fn new(
        counter: Arc<AtomicUsize>,
        metrics: Arc<SessionMetricsTracker>,
        worker_id: usize,
    ) -> Self {
        counter.fetch_add(1, Ordering::AcqRel);
        metrics.worker_inc(worker_id);
        Self {
            counter,
            metrics,
            worker_id,
        }
    }
}

impl Drop for ActiveSessionGuard {
    fn drop(&mut self) {
        self.counter.fetch_sub(1, Ordering::AcqRel);
        self.metrics.worker_dec(self.worker_id);
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum ResolveFailure {
    Failed,
    Timeout,
}

impl WorkerLoop {
    pub fn new(cfg: WorkerConfig) -> Self {
        let connection_limit = compute_worker_connection_limit(cfg.worker_count);
        tracing::info!(
            worker_id = cfg.worker_id,
            connection_limit,
            worker_count = cfg.worker_count,
            inbounds = cfg.inbounds.len(),
            "worker connection limit computed"
        );
        cfg.metrics.set_worker_limit(cfg.worker_id, connection_limit);
        Self {
            worker_id: cfg.worker_id,
            inbounds: cfg.inbounds,
            rules: cfg.rules,
            dns: cfg.dns,
            outbounds: cfg.outbounds,
            metrics: cfg.metrics,
            session_counter: AtomicU64::new(1),
            connections: Arc::new(tokio::sync::Semaphore::new(connection_limit)),
            connection_limit,
            active_sessions: Arc::new(AtomicUsize::new(0)),
            shutdown: cfg.shutdown,
        }
    }

    pub fn connection_limit(&self) -> usize {
        self.connection_limit
    }

    pub fn set_affinity(&self) {
        #[cfg(target_os = "linux")]
        unsafe {
            let cpus = num_cpus();
            if cpus > 0 {
                let mut cpuset: libc::cpu_set_t = std::mem::zeroed();
                libc::CPU_ZERO(&mut cpuset);
                libc::CPU_SET(self.worker_id % cpus, &mut cpuset);
                let tid = libc::pthread_self();
                let _ = libc::pthread_setaffinity_np(
                    tid,
                    std::mem::size_of::<libc::cpu_set_t>(),
                    &cpuset,
                );
            }
        }
    }

    fn create_reuseport_listener(addr: SocketAddr) -> Result<TcpListener, std::io::Error> {
        let domain = if addr.is_ipv6() { Domain::IPV6 } else { Domain::IPV4 };
        let socket = Socket::new(domain, Type::STREAM, None)?;
        socket.set_reuse_address(true)?;
        #[cfg(all(unix, not(target_os = "solaris"), not(target_os = "illumos")))]
        let _ = socket.set_reuse_port(true);
        socket.set_nonblocking(true)?;
        socket.bind(&addr.into())?;
        socket.listen(1024)?;
        let std_listener: std::net::TcpListener = socket.into();
        TcpListener::from_std(std_listener)
    }

    async fn accept_loop(self: Arc<Self>, spec: Arc<InboundSpec>, listener: TcpListener) {
        loop {
            match listener.accept().await {
                Ok((inbound_stream, peer_addr)) => {
                    let worker = self.clone();
                    let spec = spec.clone();
                    tokio::task::spawn_local(async move {
                        worker.handle_connection(inbound_stream, peer_addr, &spec).await;
                    });
                }
                Err(err) => {
                    tracing::error!(
                        worker_id = self.worker_id,
                        tag = %spec.tag,
                        error = %err,
                        "Accept failure"
                    );
                    tokio::time::sleep(Duration::from_millis(50)).await;
                }
            }
        }
    }

    pub async fn run(self: Arc<Self>) -> Result<(), std::io::Error> {
        self.set_affinity();

        let mut listeners: Vec<(Arc<InboundSpec>, TcpListener)> =
            Vec::with_capacity(self.inbounds.len());
        for spec in &self.inbounds {
            let listener = Self::create_reuseport_listener(spec.listen_addr)?;
            tracing::info!(
                worker_id = self.worker_id,
                tag = %spec.tag,
                addr = %spec.listen_addr,
                "listener bound with SO_REUSEPORT"
            );
            listeners.push((spec.clone(), listener));
        }

        let mut accept_tasks: tokio::task::JoinSet<()> = tokio::task::JoinSet::new();
        for (spec, listener) in listeners {
            let worker = self.clone();
            accept_tasks.spawn_local(async move {
                worker.accept_loop(spec, listener).await;
            });
        }

        self.shutdown.notified().await;

        // CRITICAL BUG FIX: Abort accept loops immediately on shutdown signal
        // so no new connections are accepted during session drain!
        accept_tasks.abort_all();

        let active = self.active_sessions.load(Ordering::Acquire);
        tracing::info!(
            worker_id = self.worker_id,
            active_sessions = active,
            "worker shutting down, draining active sessions"
        );

        let deadline = tokio::time::Instant::now() + Duration::from_secs(8);
        loop {
            let remaining = self.active_sessions.load(Ordering::Acquire);
            if remaining == 0 {
                break;
            }
            if tokio::time::Instant::now() >= deadline {
                tracing::warn!(
                    worker_id = self.worker_id,
                    remaining,
                    "worker drain timeout, forcing exit"
                );
                break;
            }
            tokio::time::sleep(Duration::from_millis(50)).await;
        }

        while accept_tasks.join_next().await.is_some() {}
        tracing::info!(worker_id = self.worker_id, "worker shutdown complete");
        Ok(())
    }

    async fn handle_connection(
        &self,
        inbound_stream: TcpStream,
        peer_addr: SocketAddr,
        spec: &InboundSpec,
    ) {
        let _permit = match self.connections.clone().try_acquire_owned() {
            Ok(p) => p,
            Err(_) => {
                tracing::warn!(
                    worker_id = self.worker_id,
                    tag = %spec.tag,
                    peer = %peer_addr,
                    limit = self.connection_limit,
                    active = self.active_sessions.load(Ordering::Relaxed),
                    "connection limit reached, rejecting"
                );
                return;
            }
        };

        let session_id = self.session_counter.fetch_add(1, Ordering::Relaxed);
        let _guard = ConnectionGuard::new(session_id, Some(self.metrics.clone()));
        let _active = ActiveSessionGuard::new(
            self.active_sessions.clone(),
            self.metrics.clone(),
            self.worker_id,
        );

        let mut peek_buf = [0u8; 1];
        match tokio::time::timeout(
            Duration::from_secs(10),
            inbound_stream.peek(&mut peek_buf),
        )
        .await
        {
            Ok(Ok(1..)) => {}
            Ok(_) => return,
            Err(_) => {
                tracing::debug!(session_id, peer = %peer_addr, "first byte timeout");
                return;
            }
        }

        match peek_buf[0] {
            0x05 => {
                // 传整块 spec 而非 &spec.auth：handle_socks5 现在需要
                // spec.udp（生成精确的 UDP ASSOCIATE 拒绝日志）和
                // spec.sniff（决定是否嗅探首包）。
                self.handle_socks5(session_id, inbound_stream, peer_addr, spec).await;
            }
            b'G' | b'C' | b'P' | b'H' | b'O' | b'D' | b'T' | b'p' | b'g' | b'c' | b'h' | b'd'
            | b'o' | b't' => {
                self.handle_http(session_id, inbound_stream, peer_addr, spec).await;
            }
            other => {
                tracing::debug!(
                    session_id,
                    peer = %peer_addr,
                    first_byte = other,
                    "unknown protocol first byte, closing"
                );
            }
        }
    }

    fn probe_domain_route(&self, domain: &str, port: u16) -> String {
        let dummy = SocketAddr::new(std::net::IpAddr::V4(std::net::Ipv4Addr::UNSPECIFIED), port);
        let mut meta = caly_common::metadata::SessionMetadata {
            dst_addr: dummy,
            network: Network::Tcp,
            ..Default::default()
        };
        meta.set_domain(domain);
        let rules = self.rules.load();
        rules.explain_internal(&meta).outbound
    }

    async fn resolve_ip(
        &self,
        session_id: u64,
        domain: &str,
    ) -> Result<std::net::IpAddr, ResolveFailure> {
        let resolve_result =
            tokio::time::timeout(Duration::from_secs(5), self.dns.resolve(domain)).await;
        match resolve_result {
            Ok(Ok(caly_common::dns::ResolveResult::RealIp(ips))) if !ips.is_empty() => Ok(ips[0]),
            Ok(Ok(caly_common::dns::ResolveResult::FakeIp(fake_ip))) => Ok(fake_ip),
            Ok(_) => {
                tracing::warn!(session_id, domain, "DNS resolution failed");
                Err(ResolveFailure::Failed)
            }
            Err(_) => {
                tracing::warn!(session_id, domain, "DNS resolution timed out");
                Err(ResolveFailure::Timeout)
            }
        }
    }

    fn prepare_outbound(
        &self,
        session_id: u64,
        peer_addr: SocketAddr,
        dst_addr: SocketAddr,
        domain: Option<&str>,
        initial_payload: Option<&[u8]>,
    ) -> Result<(SessionContext, String, Arc<dyn ProxyAdapter>), String> {
        let mut ctx = SessionContext::new(session_id, peer_addr, dst_addr, Network::Tcp);
        if let Some(d) = domain {
            ctx.metadata.set_domain(d);
        }
        // 首包嗅探：即使 domain 已确定，仍会填充 protocol / alpn 字段，
        // 供 L4 splice 判定和协议匹配规则使用。
        //
        // 旧实现在此硬编码 `None`，使得 `sniff: true` 配置完全失效——
        // SOCKS5/HTTP 客户端在协议握手后立即发送的应用数据从未被嗅探。
        ctx.enrich_metadata(self.dns.as_ref(), initial_payload);
        let outbound_tag: String = {
            let rules = self.rules.load();
            rules.match_outbound(&ctx.metadata).to_string()
        };
        self.metrics.record_outbound(&outbound_tag);
        let adapter = self
            .outbounds
            .get(&outbound_tag)
            .cloned()
            .ok_or_else(|| outbound_tag.clone())?;
        Ok((ctx, outbound_tag, adapter))
    }

    async fn do_relay(
        &self,
        ctx: &mut SessionContext,
        outbound_tag: &str,
        inbound: TcpStream,
        outbound: ConcreteStream,
        early_data: Option<&[u8]>,
    ) -> (u64, u64) {
        match relay_bidirectional_with_early_data(inbound, outbound, early_data).await {
            Ok((rx, tx)) => {
                ctx.stats.add_rx(rx);
                ctx.stats.add_tx(tx);
                self.metrics.record_bytes(rx, tx);
                self.metrics.record_outbound_bytes(outbound_tag, rx, tx);
                tracing::debug!(
                    session_id = ctx.id,
                    rx_bytes = rx,
                    tx_bytes = tx,
                    "session relay completed"
                );
                (rx, tx)
            }
            Err(e) => {
                tracing::debug!(
                    session_id = ctx.id,
                    error = %e,
                    "relay ended with error"
                );
                (0, 0)
            }
        }
    }

    async fn handle_socks5(
        &self,
        session_id: u64,
        mut inbound_stream: TcpStream,
        peer_addr: SocketAddr,
        spec: &InboundSpec,
    ) {
        let mut socks5 = Socks5StateMachine::new(spec.auth.clone(), 30_000);
        let handshake = async {
            let mut buf = [0u8; 512];
            loop {
                match inbound_stream.read(&mut buf).await {
                    Ok(0) => return None,
                    Ok(n) => {
                        if let Err(e) = socks5.on_network_input(&buf[..n]) {
                            tracing::debug!(session_id, error = ?e, "SOCKS5 input error");
                            socks5.on_error(0x01);
                            write_socks5_output(&mut inbound_stream, &mut socks5).await;
                            return None;
                        }
                        let mut out = [0u8; 512];
                        while let Some(out_n) = socks5.poll_network_output(&mut out) {
                            if let Err(e) = inbound_stream.write_all(&out[..out_n]).await {
                                tracing::debug!(session_id, error = %e, "SOCKS5 write error");
                                return None;
                            }
                        }
                        if let Some(target) = socks5.target.clone() {
                            return Some(target);
                        }
                    }
                    Err(e) => {
                        tracing::debug!(session_id, error = %e, "SOCKS5 read failure");
                        return None;
                    }
                }
            }
        };

        let target = match tokio::time::timeout(Duration::from_secs(30), handshake).await {
            Ok(Some(t)) => t,
            Ok(None) => return,
            Err(_) => {
                tracing::debug!(session_id, "SOCKS5 handshake timeout");
                return;
            }
        };

        if socks5.command == Some(Socks5Command::UdpAssociate) {
            // 无论 spec.udp 为何，当前都返回 REP=0x07（Command not supported）。
            // 但日志区分两种情况，便于运维定位：
            //   - spec.udp=false：用户没开 UDP，符合预期
            //   - spec.udp=true：用户开了但实现尚未完成，是已知限制
            if spec.udp {
                tracing::info!(
                    session_id,
                    tag = %spec.tag,
                    "UDP ASSOCIATE requested but not implemented; \
                     rejecting with REP=0x07 (Command not supported)"
                );
            } else {
                tracing::debug!(
                    session_id,
                    tag = %spec.tag,
                    "UDP ASSOCIATE disabled by config (udp=false); rejecting"
                );
            }
            reject_socks5(&mut inbound_stream, &mut socks5, 0x07).await;
            return;
        }

        let (dst_addr, domain_opt) = match target {
            TargetAddr::Ip(addr) => (addr, None),
            TargetAddr::Domain(ref domain, port) => {
                if let Ok(ip) = domain.parse::<std::net::IpAddr>() {
                    (SocketAddr::new(ip, port), None)
                } else {
                    let route = self.probe_domain_route(domain.as_str(), port);
                    if route != "direct" {
                        (
                            SocketAddr::new(std::net::IpAddr::V4(std::net::Ipv4Addr::UNSPECIFIED), port),
                            Some(domain.clone()),
                        )
                    } else {
                        match self.resolve_ip(session_id, domain.as_str()).await {
                            Ok(ip) => (SocketAddr::new(ip, port), Some(domain.clone())),
                            Err(_) => {
                                reject_socks5(&mut inbound_stream, &mut socks5, 0x04).await;
                                return;
                            }
                        }
                    }
                }
            }
        };

        // ─── 提取 SOCKS5 早期数据（在 prepare_outbound 之前）────
        let mut early_data_vec: Vec<u8> = Vec::new();
        {
            const EARLY_DATA_MAX: usize = 64 * 1024;
            let mut chunk = [0u8; 1024];
            loop {
                match socks5.poll_app_output(&mut chunk) {
                    Some(0) | None => break,
                    Some(n) => {
                        if early_data_vec.len() + n > EARLY_DATA_MAX {
                            let remain = EARLY_DATA_MAX - early_data_vec.len();
                            early_data_vec.extend_from_slice(&chunk[..remain]);
                            break;
                        }
                        early_data_vec.extend_from_slice(&chunk[..n]);
                    }
                }
            }
        }
        let initial_payload = if spec.sniff && !early_data_vec.is_empty() {
            Some(early_data_vec.as_slice())
        } else {
            None
        };

        let (mut ctx, outbound_tag, adapter) = match self.prepare_outbound(
            session_id,
            peer_addr,
            dst_addr,
            domain_opt.as_deref(),
            initial_payload,
        ) {
            Ok(v) => v,
            Err(tag) => {
                tracing::error!(session_id, outbound_tag = %tag, "outbound not found");
                reject_socks5(&mut inbound_stream, &mut socks5, 0x01).await;
                return;
            }
        };

        let outbound_stream = match adapter.dial(&ctx.metadata).await {
            Ok(s) => s,
            Err(e) => {
                tracing::warn!(session_id, error = %e, target = %dst_addr, "outbound dial failed");
                let rep = map_proxy_error_to_socks5(&e);
                reject_socks5(&mut inbound_stream, &mut socks5, rep).await;
                return;
            }
        };

        let bind = SocketAddr::new(std::net::IpAddr::V4(std::net::Ipv4Addr::UNSPECIFIED), 0);
        if socks5.on_connected(bind).is_ok() {
            let mut out = [0u8; 512];
            while let Some(out_n) = socks5.poll_network_output(&mut out) {
                if inbound_stream.write_all(&out[..out_n]).await.is_err() {
                    return;
                }
            }
            let _ = inbound_stream.flush().await;
        }

        // 关键修复（Round 20）：复用上面已提取的 early_data_vec。
        //
        // 旧实现在此处**再次**调用 poll_app_output，但 input_buf 早已
        // 被 prepare_outbound 之前的第一次抽取清空 —— 本次抽取永远
        // 返回 0 字节，客户端的早期数据在 do_relay 时被丢弃。
        //
        // 症状：SOCKS5 pipelined 请求（greeting + CONNECT + 首个应用
        // 数据在同一 TCP 段内发送）在握手完成后，首块应用数据永远不会
        // 被转发到出站，导致上层协议（如 HTTP）认为"连接已建立但请求
        // 未收到"而挂起。
        //
        // 修复方式：直接复用上面那次抽取的结果，不再二次消费 input_buf。
        let early_slice = if early_data_vec.is_empty() {
            None
        } else {
            Some(early_data_vec.as_slice())
        };

        let _ = self
            .do_relay(
                &mut ctx,
                &outbound_tag,
                inbound_stream,
                outbound_stream,
                early_slice,
            )
            .await;
    }

    async fn handle_http(
        &self,
        session_id: u64,
        mut inbound_stream: TcpStream,
        peer_addr: SocketAddr,
        spec: &InboundSpec,
    ) {
        const MAX_HTTP_HEADER: usize = 16 * 1024;
        const HTTP_HEADER_TIMEOUT: Duration = Duration::from_secs(10);

        let parsed = tokio::time::timeout(
            HTTP_HEADER_TIMEOUT,
            async {
                let mut buf: Vec<u8> = Vec::with_capacity(4096);
                let mut tmp = [0u8; 2048];
                loop {
                    if buf.len() >= MAX_HTTP_HEADER {
                        let _ = inbound_stream
                            .write_all(b"HTTP/1.1 431 Request Header Fields Too Large

")
                            .await;
                        return None;
                    }
                    let n = match inbound_stream.read(&mut tmp).await {
                        Ok(0) => return None,
                        Ok(n) => n,
                        Err(_) => return None,
                    };
                    buf.extend_from_slice(&tmp[..n]);
                    match HttpInbound::parse_request(&buf) {
                        Ok(Some(r)) => return Some((r, buf)),
                        Ok(None) => continue,
                        Err(_) => {
                            let _ = inbound_stream
                                .write_all(HttpInbound::build_400_response())
                                .await;
                            return None;
                        }
                    }
                }
            },
        )
        .await;

        let (req, buf) = match parsed {
            Ok(Some(pair)) => pair,
            Ok(None) => return,
            Err(_) => {
                tracing::debug!(session_id, "HTTP header read timed out");
                let _ = inbound_stream
                    .write_all(b"HTTP/1.1 408 Request Timeout
Connection: close

")
                    .await;
                return;
            }
        };

        match req {
            HttpRequestType::Connect {
                host,
                port,
                header_end,
            } => {
                let (dst_addr, domain_opt) =
                    if let Ok(ip) = host.parse::<std::net::IpAddr>() {
                        (SocketAddr::new(ip, port), None)
                    } else {
                        let route = self.probe_domain_route(host.as_str(), port);
                        if route != "direct" {
                            (
                                SocketAddr::new(std::net::IpAddr::V4(std::net::Ipv4Addr::UNSPECIFIED), port),
                                Some(host.clone()),
                            )
                        } else {
                            match self.resolve_ip(session_id, host.as_str()).await {
                                Ok(ip) => (SocketAddr::new(ip, port), Some(host.clone())),
                                Err(_) => {
                                    let _ = inbound_stream
                                        .write_all(b"HTTP/1.1 504 Gateway Timeout

")
                                        .await;
                                    return;
                                }
                            }
                        }
                    };

                // ─── 提取 CONNECT 头之后的早期数据（在 prepare_outbound 之前）
                let early_data = if buf.len() > header_end {
                    Some(&buf[header_end..])
                } else {
                    None
                };
                let initial_payload = if spec.sniff { early_data } else { None };

                let (mut ctx, outbound_tag, adapter) = match self.prepare_outbound(
                    session_id,
                    peer_addr,
                    dst_addr,
                    domain_opt.as_deref(),
                    initial_payload,
                ) {
                    Ok(v) => v,
                    Err(_) => {
                        let _ = inbound_stream
                            .write_all(b"HTTP/1.1 502 Bad Gateway

")
                            .await;
                        return;
                    }
                };

                let outbound_stream = match adapter.dial(&ctx.metadata).await {
                    Ok(s) => s,
                    Err(e) => {
                        tracing::warn!(session_id, error = %e, "HTTP CONNECT outbound dial failed");
                        let _ = inbound_stream
                            .write_all(b"HTTP/1.1 502 Bad Gateway

")
                            .await;
                        return;
                    }
                };

                let _ = inbound_stream
                    .write_all(HttpInbound::build_connect_response())
                    .await;
                let _ = inbound_stream.flush().await;
                let early_data = if buf.len() > header_end {
                    Some(&buf[header_end..])
                } else {
                    None
                };

                let _ = self
                    .do_relay(
                        &mut ctx,
                        &outbound_tag,
                        inbound_stream,
                        outbound_stream,
                        early_data,
                    )
                    .await;
            }
            HttpRequestType::Forward { .. } => {
                let _ = inbound_stream
                    .write_all(HttpInbound::build_501_response())
                    .await;
            }
        }
    }
}

async fn write_socks5_output(stream: &mut TcpStream, sm: &mut Socks5StateMachine) {
    let mut out = [0u8; 512];
    while let Some(n) = sm.poll_network_output(&mut out) {
        if stream.write_all(&out[..n]).await.is_err() {
            return;
        }
    }
    let _ = stream.flush().await;
}

async fn reject_socks5(
    stream: &mut TcpStream,
    sm: &mut Socks5StateMachine,
    rep: u8,
) {
    sm.on_error(rep);
    write_socks5_output(stream, sm).await;
}

fn map_proxy_error_to_socks5(e: &ProxyError) -> u8 {
    match e {
        ProxyError::Blocked => 0x02,
        ProxyError::NetworkUnreachable => 0x03,
        ProxyError::ConnectionRefused => 0x05,
        _ => 0x01,
    }
}

fn num_cpus() -> usize {
    std::thread::available_parallelism()
        .map(|n| n.get())
        .unwrap_or(1)
        .clamp(1, 64)
}
