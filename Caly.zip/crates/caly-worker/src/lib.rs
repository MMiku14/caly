//! High-performance worker loop, thread-per-core scheduler, and ByteSlab memory fabric.

pub mod l4_splice;
pub mod loop_scheduler;
pub mod relay;
pub mod slab;

pub use l4_splice::L4SpliceDecider;
pub use loop_scheduler::{InboundSpec, WorkerConfig, WorkerLoop};
pub use relay::relay_bidirectional;
