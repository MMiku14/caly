use caly_common::transport::TransportStream;
use caly_transport::stream::{ConcreteStream, MemoryStreamLayer};
use tokio::io::{AsyncReadExt, AsyncWriteExt};

#[tokio::test]
async fn test_memory_stream_echo() {
    let (c, mut s) = tokio::io::duplex(512);
    let mut mem = MemoryStreamLayer::new(c);

    mem.write_all(b"HELLO").await.unwrap();
    mem.flush().await.unwrap();

    let mut buf = [0u8; 5];
    s.read_exact(&mut buf).await.unwrap();
    assert_eq!(&buf, b"HELLO");
}
