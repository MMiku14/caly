use caly_transport::builder::{StreamBuilder, TransportConfig};

#[test]
fn test_builder_construction() {
    let cfg = TransportConfig {
        tls_enabled: false,
        ..Default::default()
    };
    assert!(StreamBuilder::new(cfg).is_ok());
}
