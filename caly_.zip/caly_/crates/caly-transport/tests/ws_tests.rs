use caly_transport::ws::{apply_mask, compute_ws_accept};

#[test]
fn test_rfc6455_official_accept_vector() {
    let key = "dGhlIHNhbXBsZSBub25jZQ==";
    assert_eq!(compute_ws_accept(key), "s3pPLMBiTxaQ9kYGzzhZRbK+xOo=");
}

#[test]
fn test_ws_mask_xor_roundtrip() {
    let mut data = *b"SECRET_PAYLOAD_1234";
    let original = data;
    let mask = [0xAA, 0xBB, 0xCC, 0xDD];

    apply_mask(&mut data, mask);
    assert_ne!(data, original);
    apply_mask(&mut data, mask);
    assert_eq!(data, original);
}
