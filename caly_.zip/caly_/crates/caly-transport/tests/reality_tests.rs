use caly_transport::reality::{RealityClientConfig, RealityHandshakeLayer};

#[test]
fn test_reality_session_id_layout() {
    let short_id = [1, 2, 3, 4, 5, 6, 7, 8];
    let cfg = RealityClientConfig::new("www.apple.com", [0xEE; 32], short_id);
    let layer = RealityHandshakeLayer::new(cfg);
    let (session_id, pubkey) = layer.build_session_id();

    assert_eq!(&session_id[0..8], &short_id);
    assert_eq!(&session_id[8..32], &pubkey.as_bytes()[0..24]);
}
