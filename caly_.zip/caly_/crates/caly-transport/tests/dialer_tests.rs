use caly_transport::dialer::HappyEyeballsDialer;
use std::net::{IpAddr, SocketAddr};

#[test]
fn test_happy_eyeballs_interleaving_ipv6_first() {
    let port = 443;
    let v4: IpAddr = "1.1.1.1".parse().unwrap();
    let v6: IpAddr = "2606:4700:4700::1111".parse().unwrap();

    let interleaved = HappyEyeballsDialer::interleave_addresses(&[v4, v6], port);
    assert_eq!(interleaved.len(), 2);
    assert_eq!(interleaved[0], SocketAddr::new(v6, port));
    assert_eq!(interleaved[1], SocketAddr::new(v4, port));
}
