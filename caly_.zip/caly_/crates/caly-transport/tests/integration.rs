use caly_transport::stream::ConcreteStream;
use caly_common::transport::TransportStream;

#[test]
fn test_concrete_stream_transport_type() {
    let (c, _s) = tokio::io::duplex(64);
    let stream = ConcreteStream::from_memory(c);
    assert_eq!(stream.transport_type(), "memory");
    assert!(stream.is_alive());
}
