use criterion::{criterion_group, criterion_main, Criterion};
use caly_transport::ws::apply_mask;
use std::hint::black_box;

fn bench_ws_mask(c: &mut Criterion) {
    let mut payload = vec![0x42u8; 4096];
    let mask = [0x12, 0x34, 0x56, 0x78];

    c.bench_function("ws/apply_mask_4k", |b| {
        b.iter(|| {
            apply_mask(black_box(&mut payload), black_box(mask));
        })
    });
}

criterion_group!(benches, bench_ws_mask);
criterion_main!(benches);
