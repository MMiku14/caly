//! Memory duplex stream for tests.

use caly_common::transport::TransportStream;
use std::io;
use std::net::SocketAddr;
use std::pin::Pin;
use std::task::{Context, Poll};
use tokio::io::{AsyncRead, AsyncWrite, DuplexStream, ReadBuf};

pub struct MemoryStreamLayer {
    inner: DuplexStream,
    peer: SocketAddr,
    local: SocketAddr,
}

impl MemoryStreamLayer {
    #[must_use]
    pub fn new(stream: DuplexStream) -> Self {
        Self {
            inner: stream,
            peer: "127.0.0.1:8080".parse().unwrap(),
            local: "127.0.0.1:1080".parse().unwrap(),
        }
    }
}

impl TransportStream for MemoryStreamLayer {
    fn transport_type(&self) -> &'static str { "memory" }
    fn is_alive(&self) -> bool { true }
    fn peer_addr(&self) -> io::Result<SocketAddr> { Ok(self.peer) }
    fn local_addr(&self) -> io::Result<SocketAddr> { Ok(self.local) }
}

impl AsyncRead for MemoryStreamLayer {
    fn poll_read(
        mut self: Pin<&mut Self>,
        cx: &mut Context<'_>,
        buf: &mut ReadBuf<'_>,
    ) -> Poll<io::Result<()>> {
        Pin::new(&mut self.inner).poll_read(cx, buf)
    }
}

impl AsyncWrite for MemoryStreamLayer {
    fn poll_write(
        mut self: Pin<&mut Self>,
        cx: &mut Context<'_>,
        buf: &[u8],
    ) -> Poll<io::Result<usize>> {
        Pin::new(&mut self.inner).poll_write(cx, buf)
    }
    fn poll_flush(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<io::Result<()>> {
        Pin::new(&mut self.inner).poll_flush(cx)
    }
    fn poll_shutdown(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<io::Result<()>> {
        Pin::new(&mut self.inner).poll_shutdown(cx)
    }
}
