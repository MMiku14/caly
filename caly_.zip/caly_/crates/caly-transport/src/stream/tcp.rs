//! Native TCP stream layer.

use caly_common::transport::TransportStream;
use std::io;
use std::net::SocketAddr;
use std::pin::Pin;
use std::task::{Context, Poll};
use tokio::io::{AsyncRead, AsyncWrite, ReadBuf};
use tokio::net::TcpStream;

pub struct TcpStreamLayer {
    inner: TcpStream,
}

impl TcpStreamLayer {
    #[must_use]
    pub fn new(stream: TcpStream) -> Self {
        let _ = stream.set_nodelay(true);
        Self { inner: stream }
    }

    #[must_use]
    pub fn into_inner(self) -> TcpStream { self.inner }
    #[must_use]
    pub fn get_ref(&self) -> &TcpStream { &self.inner }
    pub fn get_mut(&mut self) -> &mut TcpStream { &mut self.inner }
}

impl TransportStream for TcpStreamLayer {
    fn transport_type(&self) -> &'static str { "tcp" }
    fn is_alive(&self) -> bool {
        self.inner.take_error().map_or(false, |e| e.is_none())
    }
    fn peer_addr(&self) -> io::Result<SocketAddr> { self.inner.peer_addr() }
    fn local_addr(&self) -> io::Result<SocketAddr> { self.inner.local_addr() }
}

impl AsyncRead for TcpStreamLayer {
    fn poll_read(
        mut self: Pin<&mut Self>,
        cx: &mut Context<'_>,
        buf: &mut ReadBuf<'_>,
    ) -> Poll<io::Result<()>> {
        Pin::new(&mut self.inner).poll_read(cx, buf)
    }
}

impl AsyncWrite for TcpStreamLayer {
    fn poll_write(
        mut self: Pin<&mut Self>,
        cx: &mut Context<'_>,
        buf: &[u8],
    ) -> Poll<io::Result<usize>> {
        Pin::new(&mut self.inner).poll_write(cx, buf)
    }
    fn poll_flush(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<io::Result<()>> {
        Pin::new(&mut self.inner).poll_flush(cx)
    }
    fn poll_shutdown(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<io::Result<()>> {
        Pin::new(&mut self.inner).poll_shutdown(cx)
    }
}
