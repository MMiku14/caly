//! Concrete static-dispatch stream.

use crate::stream::memory::MemoryStreamLayer;
use crate::stream::tcp::TcpStreamLayer;
use caly_common::transport::TransportStream;
use std::io;
use std::net::SocketAddr;
use std::pin::Pin;
use std::task::{Context, Poll};
use tokio::io::{AsyncRead, AsyncWrite, DuplexStream, ReadBuf};
use tokio::net::TcpStream;
use tokio_rustls::client::TlsStream;

pub enum ConcreteStream {
    Tcp(TcpStreamLayer),
    Tls(Box<TlsStream<Box<dyn TransportStream>>>),
    Ws(Box<crate::ws::WebSocketStreamLayer<Box<dyn TransportStream>>>),
    Memory(MemoryStreamLayer),
    Boxed(Box<dyn TransportStream>),
}

impl ConcreteStream {
    #[must_use]
    pub fn from_tcp(stream: TcpStream) -> Self {
        Self::Tcp(TcpStreamLayer::new(stream))
    }

    #[must_use]
    pub fn from_memory(stream: DuplexStream) -> Self {
        Self::Memory(MemoryStreamLayer::new(stream))
    }

    #[must_use]
    pub fn from_boxed(stream: Box<dyn TransportStream>) -> Self {
        Self::Boxed(stream)
    }
}

impl TransportStream for ConcreteStream {
    fn transport_type(&self) -> &'static str {
        match self {
            Self::Tcp(s) => s.transport_type(),
            Self::Tls(_) => "tls",
            Self::Ws(_) => "ws",
            Self::Memory(s) => s.transport_type(),
            Self::Boxed(s) => s.transport_type(),
        }
    }

    fn is_alive(&self) -> bool {
        match self {
            Self::Tcp(s) => s.is_alive(),
            Self::Tls(s) => s.get_ref().1.is_alive(),
            Self::Ws(s) => s.is_alive(),
            Self::Memory(s) => s.is_alive(),
            Self::Boxed(s) => s.is_alive(),
        }
    }

    fn peer_addr(&self) -> io::Result<SocketAddr> {
        match self {
            Self::Tcp(s) => s.peer_addr(),
            Self::Tls(s) => s.get_ref().1.peer_addr(),
            Self::Ws(s) => s.peer_addr(),
            Self::Memory(s) => s.peer_addr(),
            Self::Boxed(s) => s.peer_addr(),
        }
    }

    fn local_addr(&self) -> io::Result<SocketAddr> {
        match self {
            Self::Tcp(s) => s.local_addr(),
            Self::Tls(s) => s.get_ref().1.local_addr(),
            Self::Ws(s) => s.local_addr(),
            Self::Memory(s) => s.local_addr(),
            Self::Boxed(s) => s.local_addr(),
        }
    }
}

impl AsyncRead for ConcreteStream {
    fn poll_read(
        self: Pin<&mut Self>,
        cx: &mut Context<'_>,
        buf: &mut ReadBuf<'_>,
    ) -> Poll<io::Result<()>> {
        match self.get_mut() {
            Self::Tcp(s) => Pin::new(s).poll_read(cx, buf),
            Self::Tls(s) => Pin::new(&mut **s).poll_read(cx, buf),
            Self::Ws(s) => Pin::new(&mut **s).poll_read(cx, buf),
            Self::Memory(s) => Pin::new(s).poll_read(cx, buf),
            Self::Boxed(s) => Pin::new(&mut **s).poll_read(cx, buf),
        }
    }
}

impl AsyncWrite for ConcreteStream {
    fn poll_write(
        self: Pin<&mut Self>,
        cx: &mut Context<'_>,
        buf: &[u8],
    ) -> Poll<io::Result<usize>> {
        match self.get_mut() {
            Self::Tcp(s) => Pin::new(s).poll_write(cx, buf),
            Self::Tls(s) => Pin::new(&mut **s).poll_write(cx, buf),
            Self::Ws(s) => Pin::new(&mut **s).poll_write(cx, buf),
            Self::Memory(s) => Pin::new(s).poll_write(cx, buf),
            Self::Boxed(s) => Pin::new(&mut **s).poll_write(cx, buf),
        }
    }
    fn poll_flush(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<io::Result<()>> {
        match self.get_mut() {
            Self::Tcp(s) => Pin::new(s).poll_flush(cx),
            Self::Tls(s) => Pin::new(&mut **s).poll_flush(cx),
            Self::Ws(s) => Pin::new(&mut **s).poll_flush(cx),
            Self::Memory(s) => Pin::new(s).poll_flush(cx),
            Self::Boxed(s) => Pin::new(&mut **s).poll_flush(cx),
        }
    }
    fn poll_shutdown(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<io::Result<()>> {
        match self.get_mut() {
            Self::Tcp(s) => Pin::new(s).poll_shutdown(cx),
            Self::Tls(s) => Pin::new(&mut **s).poll_shutdown(cx),
            Self::Ws(s) => Pin::new(&mut **s).poll_shutdown(cx),
            Self::Memory(s) => Pin::new(s).poll_shutdown(cx),
            Self::Boxed(s) => Pin::new(&mut **s).poll_shutdown(cx),
        }
    }
}
