//! WebSocketStreamLayer wrapping TransportStream.

use caly_common::transport::TransportStream;
use std::io;
use std::net::SocketAddr;
use std::pin::Pin;
use std::task::{Context, Poll};
use tokio::io::{AsyncRead, AsyncWrite, ReadBuf};

pub struct WebSocketStreamLayer<S> {
    inner: S,
    mask_key: [u8; 4],
    is_client: bool,
}

impl<S: TransportStream> WebSocketStreamLayer<S> {
    #[must_use]
    pub fn new_client(inner: S) -> Self {
        Self {
            inner,
            mask_key: rand::random(),
            is_client: true,
        }
    }

    pub fn into_inner(self) -> S { self.inner }
}

impl<S: TransportStream> TransportStream for WebSocketStreamLayer<S> {
    fn transport_type(&self) -> &'static str { "ws" }
    fn is_alive(&self) -> bool { self.inner.is_alive() }
    fn peer_addr(&self) -> io::Result<SocketAddr> { self.inner.peer_addr() }
    fn local_addr(&self) -> io::Result<SocketAddr> { self.inner.local_addr() }
}

impl<S: TransportStream> AsyncRead for WebSocketStreamLayer<S> {
    fn poll_read(mut self: Pin<&mut Self>, cx: &mut Context<'_>, buf: &mut ReadBuf<'_>) -> Poll<io::Result<()>> {
        Pin::new(&mut self.inner).poll_read(cx, buf)
    }
}

impl<S: TransportStream> AsyncWrite for WebSocketStreamLayer<S> {
    fn poll_write(mut self: Pin<&mut Self>, cx: &mut Context<'_>, buf: &[u8]) -> Poll<io::Result<usize>> {
        Pin::new(&mut self.inner).poll_write(cx, buf)
    }
    fn poll_flush(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<io::Result<()>> {
        Pin::new(&mut self.inner).poll_flush(cx)
    }
    fn poll_shutdown(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<io::Result<()>> {
        Pin::new(&mut self.inner).poll_shutdown(cx)
    }
}
