//! RFC 6455 client handshake.

use base64::Engine;
use sha1::{Digest, Sha1};
use std::io;
use tokio::io::{AsyncRead, AsyncReadExt, AsyncWrite, AsyncWriteExt};

pub const WS_GUID: &str = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11";

#[must_use]
pub fn compute_ws_accept(sec_key: &str) -> String {
    let mut hasher = Sha1::new();
    hasher.update(sec_key.as_bytes());
    hasher.update(WS_GUID.as_bytes());
    base64::engine::general_purpose::STANDARD.encode(hasher.finalize())
}

pub async fn client_handshake<S>(
    stream: &mut S,
    host: &str,
    path: &str,
) -> io::Result<()>
where
    S: AsyncRead + AsyncWrite + Unpin,
{
    let nonce: [u8; 16] = rand::random();
    let sec_key = base64::engine::general_purpose::STANDARD.encode(nonce);

    let req = format!(
        "GET {} HTTP/1.1\r\n         Host: {}\r\n         Upgrade: websocket\r\n         Connection: Upgrade\r\n         Sec-WebSocket-Key: {}\r\n         Sec-WebSocket-Version: 13\r\n\r\n",
        path, host, sec_key
    );

    stream.write_all(req.as_bytes()).await?;
    stream.flush().await?;

    let mut resp_buf = [0u8; 1024];
    let mut read_bytes = 0;

    while read_bytes < resp_buf.len() {
        let n = stream.read(&mut resp_buf[read_bytes..]).await?;
        if n == 0 {
            return Err(io::Error::new(io::ErrorKind::UnexpectedEof, "WebSocket handshake closed prematurely"));
        }
        read_bytes += n;
        if resp_buf[..read_bytes].windows(4).any(|w| w == b"\r\n\r\n") {
            break;
        }
    }

    let resp_str = String::from_utf8_lossy(&resp_buf[..read_bytes]);
    if !resp_str.starts_with("HTTP/1.1 101") {
        return Err(io::Error::new(io::ErrorKind::ConnectionRefused, format!("Bad status: {resp_str}")));
    }

    let expected_accept = compute_ws_accept(&sec_key);
    if !resp_str.contains(&expected_accept) {
        return Err(io::Error::new(io::ErrorKind::InvalidData, "Sec-WebSocket-Accept mismatch"));
    }

    Ok(())
}
