//! Transport pipeline configuration.

use crate::reality::RealityClientConfig;
use std::time::Duration;

#[derive(Debug, Clone)]
pub struct TransportConfig {
    pub tls_enabled: bool,
    pub sni: Option<String>,
    pub alpn: Vec<String>,
    pub insecure: bool,
    pub reality_enabled: bool,
    pub reality_config: Option<RealityClientConfig>,
    pub ws_enabled: bool,
    pub ws_path: Option<String>,
    pub ws_host: Option<String>,
    pub connection_attempt_delay: Duration,
    pub fwmark: Option<u32>,
}

impl Default for TransportConfig {
    fn default() -> Self {
        Self {
            tls_enabled: false,
            sni: None,
            alpn: vec!["h2".to_string(), "http/1.1".to_string()],
            insecure: false,
            reality_enabled: false,
            reality_config: None,
            ws_enabled: false,
            ws_path: None,
            ws_host: None,
            connection_attempt_delay: Duration::from_millis(250),
            fwmark: None,
        }
    }
}
