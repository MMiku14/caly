//! End-to-end transport stream builder.

use crate::builder::config::TransportConfig;
use crate::dialer::HappyEyeballsDialer;
use crate::reality::RealityHandshakeLayer;
use crate::stream::{ConcreteStream, TcpStreamLayer};
use crate::tls::TlsConnectorLayer;
use crate::ws::{client_handshake, WebSocketStreamLayer};
use caly_common::transport::TransportStream;
use std::net::{IpAddr, SocketAddr};

pub struct StreamBuilder {
    config: TransportConfig,
    tls_layer: Option<TlsConnectorLayer>,
    reality_layer: Option<RealityHandshakeLayer>,
    dialer: HappyEyeballsDialer,
}

impl StreamBuilder {
    pub fn new(config: TransportConfig) -> Result<Self, std::io::Error> {
        let tls_layer = if config.tls_enabled {
            let alpn_refs: Vec<&str> = config.alpn.iter().map(String::as_str).collect();
            Some(TlsConnectorLayer::with_options(&alpn_refs, config.insecure)?)
        } else {
            None
        };

        let reality_layer = if config.reality_enabled {
            config.reality_config.as_ref().map(|cfg| RealityHandshakeLayer::new(cfg.clone()))
        } else {
            None
        };

        let dialer = HappyEyeballsDialer::new(config.connection_attempt_delay, config.fwmark);

        Ok(Self {
            config,
            tls_layer,
            reality_layer,
            dialer,
        })
    }

    pub async fn dial(&self, target_addr: SocketAddr) -> Result<ConcreteStream, std::io::Error> {
        self.dial_candidates(&[target_addr.ip()], target_addr.port()).await
    }

    pub async fn dial_candidates(
        &self,
        candidates: &[IpAddr],
        port: u16,
    ) -> Result<ConcreteStream, std::io::Error> {
        let raw_tcp = self.dialer.dial(candidates, port).await?;
        let tcp_layer = TcpStreamLayer::new(raw_tcp);

        if !self.config.tls_enabled && !self.config.ws_enabled && !self.config.reality_enabled {
            return Ok(ConcreteStream::Tcp(tcp_layer));
        }

        let stream: Box<dyn TransportStream> = if let Some(ref reality) = self.reality_layer {
            Box::new(reality.wrap_client(tcp_layer).await?)
        } else {
            Box::new(tcp_layer)
        };

        let stream: Box<dyn TransportStream> = if let Some(ref tls) = self.tls_layer {
            let sni = self.config.sni.as_deref().unwrap_or("localhost");
            Box::new(tls.handshake(sni, stream).await?)
        } else {
            stream
        };

        let stream: Box<dyn TransportStream> = if self.config.ws_enabled {
            let host = self.config.ws_host.as_deref().unwrap_or("localhost");
            let path = self.config.ws_path.as_deref().unwrap_or("/");
            let mut boxed = stream;
            client_handshake(&mut boxed, host, path).await?;
            Box::new(WebSocketStreamLayer::new_client(boxed))
        } else {
            stream
        };

        Ok(ConcreteStream::Boxed(stream))
    }
}
