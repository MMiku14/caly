//! TLS connector with WebPKI roots and ALPN negotiation.

use crate::tls::verifier::NoopCertVerifier;
use rustls::pki_types::ServerName;
use rustls::ClientConfig;
use std::net::IpAddr;
use std::sync::Arc;
use tokio::io::{AsyncRead, AsyncWrite};
use tokio_rustls::client::TlsStream;
use tokio_rustls::TlsConnector;

#[derive(Clone)]
pub struct TlsConnectorLayer {
    connector: TlsConnector,
}

impl TlsConnectorLayer {
    pub fn new() -> Result<Self, std::io::Error> {
        Self::with_options(&["h2", "http/1.1"], false)
    }

    pub fn with_options(alpn: &[&str], insecure: bool) -> Result<Self, std::io::Error> {
        let mut root_store = rustls::RootCertStore::empty();
        root_store.extend(webpki_roots::TLS_SERVER_ROOTS.iter().cloned());

        let provider = rustls::crypto::ring::default_provider();
        let builder = ClientConfig::builder_with_provider(Arc::new(provider))
            .with_safe_default_protocol_versions()
            .map_err(|e| std::io::Error::new(std::io::ErrorKind::Other, e.to_string()))?;

        let mut config = if insecure {
            builder
                .dangerous()
                .with_custom_certificate_verifier(Arc::new(NoopCertVerifier))
                .with_no_client_auth()
        } else {
            builder.with_root_certificates(root_store).with_no_client_auth()
        };

        config.alpn_protocols = alpn.iter().map(|p| p.as_bytes().to_vec()).collect();

        Ok(Self {
            connector: TlsConnector::from(Arc::new(config)),
        })
    }

    pub async fn handshake<S>(
        &self,
        domain_or_ip: &str,
        stream: S,
    ) -> Result<TlsStream<S>, std::io::Error>
    where
        S: AsyncRead + AsyncWrite + Unpin + Send + Sync,
    {
        let server_name = if let Ok(ip) = domain_or_ip.parse::<IpAddr>() {
            ServerName::from(ip)
        } else {
            ServerName::try_from(domain_or_ip.to_string())
                .map_err(|e| std::io::Error::new(std::io::ErrorKind::InvalidInput, e.to_string()))?
        };

        self.connector
            .connect(server_name, stream)
            .await
            .map_err(|e| std::io::Error::new(std::io::ErrorKind::ConnectionAborted, e))
    }
}
