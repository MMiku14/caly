//! Caly Transport — Composable anti-censorship transport fabric (Happy Eyeballs, REALITY, WS, TLS).
//!
//! # Architecture
//!
//! ```text
//!  ┌──────────────────────────────────────────────────────────┐
//!  │  builder    StreamBuilder: TCP -> TLS/REALITY -> WS      │
//!  ├──────────────────────────────────────────────────────────┤
//!  │  reality    REALITY 32-byte Session ID camouflage        │
//!  ├──────────────────────────────────────────────────────────┤
//!  │  ws         RFC 6455 Binary Frame mask streaming         │
//!  ├──────────────────────────────────────────────────────────┤
//!  │  tls        Rustls 0.23 TLS 1.3 + ALPN wrapper           │
//!  ├──────────────────────────────────────────────────────────┤
//!  │  stream     ConcreteStream static-dispatch & memory test │
//!  ├──────────────────────────────────────────────────────────┤
//!  │  dialer     RFC 8305 Happy Eyeballs + SO_MARK fwmark     │
//!  └──────────────────────────────────────────────────────────┘
//! ```

pub mod builder;
pub mod dialer;
pub mod reality;
pub mod stream;
pub mod tls;
pub mod ws;

pub use builder::{StreamBuilder, TransportConfig};
pub use dialer::HappyEyeballsDialer;
pub use reality::{RealityClientConfig, RealityHandshakeLayer};
pub use stream::{ConcreteStream, MemoryStreamLayer, TcpStreamLayer};
pub use tls::TlsConnectorLayer;
pub use ws::WebSocketStreamLayer;
