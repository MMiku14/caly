//! RFC 8305 Happy Eyeballs Dual-Stack Concurrent Dialer.

use crate::dialer::socket::connect_single;
use smallvec::SmallVec;
use std::net::{IpAddr, SocketAddr};
use std::time::Duration;
use tokio::net::TcpStream;

pub struct HappyEyeballsDialer {
    pub connection_attempt_delay: Duration,
    pub fwmark: Option<u32>,
}

impl Default for HappyEyeballsDialer {
    fn default() -> Self {
        Self::new(Duration::from_millis(250), None)
    }
}

impl HappyEyeballsDialer {
    #[must_use]
    pub fn new(connection_attempt_delay: Duration, fwmark: Option<u32>) -> Self {
        Self {
            connection_attempt_delay,
            fwmark,
        }
    }

    #[must_use]
    pub fn interleave_addresses(candidates: &[IpAddr], port: u16) -> SmallVec<[SocketAddr; 4]> {
        let mut interleaved = SmallVec::<[SocketAddr; 4]>::new();
        let mut v6_iter = candidates.iter().filter(|ip| ip.is_ipv6());
        let mut v4_iter = candidates.iter().filter(|ip| ip.is_ipv4());

        loop {
            let mut added = false;
            if let Some(v6) = v6_iter.next() {
                interleaved.push(SocketAddr::new(*v6, port));
                added = true;
            }
            if let Some(v4) = v4_iter.next() {
                interleaved.push(SocketAddr::new(*v4, port));
                added = true;
            }
            if !added {
                break;
            }
        }
        interleaved
    }

    pub async fn dial(
        &self,
        candidates: &[IpAddr],
        port: u16,
    ) -> Result<TcpStream, std::io::Error> {
        if candidates.is_empty() {
            return Err(std::io::Error::new(
                std::io::ErrorKind::AddrNotAvailable,
                "Candidate address list is empty",
            ));
        }

        let interleaved = Self::interleave_addresses(candidates, port);
        if interleaved.is_empty() {
            return Err(std::io::Error::new(
                std::io::ErrorKind::AddrNotAvailable,
                "No valid socket addresses",
            ));
        }

        let (success_tx, mut success_rx) = tokio::sync::mpsc::channel(1);
        let mut task_set = tokio::task::JoinSet::new();
        let total = interleaved.len();

        for (idx, addr) in interleaved.into_iter().enumerate() {
            let mark = self.fwmark;
            let tx = success_tx.clone();

            task_set.spawn(async move {
                if let Ok(stream) = connect_single(addr, mark).await {
                    let _ = tx.send(stream).await;
                }
            });

            if idx < total - 1 {
                tokio::select! {
                    Some(winner) = success_rx.recv() => {
                        task_set.abort_all();
                        return Ok(winner);
                    }
                    _ = tokio::time::sleep(self.connection_attempt_delay) => {}
                }
            }
        }

        drop(success_tx);

        if let Some(winner) = success_rx.recv().await {
            task_set.abort_all();
            Ok(winner)
        } else {
            Err(std::io::Error::new(
                std::io::ErrorKind::ConnectionRefused,
                "All dual-stack candidates failed to connect",
            ))
        }
    }
}
