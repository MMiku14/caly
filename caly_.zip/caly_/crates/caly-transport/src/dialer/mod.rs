//! Outbound dialers.

pub mod happy_eyeballs;
pub mod socket;

pub use happy_eyeballs::HappyEyeballsDialer;
pub use socket::connect_single;
