//! Low-level socket creation and SO_MARK injection.

use socket2::{Domain, Protocol, Socket, Type};
use std::net::SocketAddr;
use tokio::net::TcpStream;

pub async fn connect_single(addr: SocketAddr, fwmark: Option<u32>) -> std::io::Result<TcpStream> {
    let domain = if addr.is_ipv6() { Domain::IPV6 } else { Domain::IPV4 };
    let socket = Socket::new(domain, Type::STREAM, Some(Protocol::TCP))?;
    socket.set_nonblocking(true)?;

    #[cfg(target_os = "linux")]
    if let Some(mark) = fwmark {
        unsafe {
            use std::os::unix::io::AsRawFd;
            let mark_int = mark as libc::c_int;
            let ret = libc::setsockopt(
                socket.as_raw_fd(),
                libc::SOL_SOCKET,
                libc::SO_MARK,
                &mark_int as *const _ as *const libc::c_void,
                std::mem::size_of_val(&mark_int) as libc::socklen_t,
            );
            if ret != 0 {
                return Err(std::io::Error::last_os_error());
            }
        }
    }

    let std_socket: std::net::TcpStream = match socket.connect(&addr.into()) {
        Ok(()) => socket.into(),
        Err(err) if err.raw_os_error() == Some(libc::EINPROGRESS) => socket.into(),
        Err(err) => return Err(err),
    };

    let stream = TcpStream::from_std(std_socket)?;
    stream.writable().await?;

    if let Some(e) = stream.take_error()? {
        return Err(e);
    }
    Ok(stream)
}
