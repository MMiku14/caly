//! REALITY TLS 1.3 outer camouflage.

pub mod config;
pub mod handshake;

pub use config::RealityClientConfig;
pub use handshake::RealityHandshakeLayer;
