//! REALITY camouflage configuration.

use smol_str::SmolStr;

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct RealityClientConfig {
    pub server_name: SmolStr,
    pub public_key: [u8; 32],
    pub short_id: [u8; 8],
}

impl RealityClientConfig {
    pub fn new(server_name: &str, public_key: [u8; 32], short_id: [u8; 8]) -> Self {
        Self {
            server_name: SmolStr::new(server_name),
            public_key,
            short_id,
        }
    }
}
