//! REALITY 32-byte TLS Session ID constructor.

use crate::reality::config::RealityClientConfig;
use caly_common::transport::TransportStream;
use std::io;
use x25519_dalek::{EphemeralSecret, PublicKey};

pub struct RealityHandshakeLayer {
    config: RealityClientConfig,
}

impl RealityHandshakeLayer {
    #[must_use]
    pub fn new(config: RealityClientConfig) -> Self {
        Self { config }
    }

    #[must_use]
    pub fn config(&self) -> &RealityClientConfig {
        &self.config
    }

    #[must_use]
    pub fn encode_session_id(short_id: &[u8; 8], client_public_bytes: &[u8; 32]) -> [u8; 32] {
        let mut session_id = [0u8; 32];
        session_id[0..8].copy_from_slice(short_id);
        session_id[8..32].copy_from_slice(&client_public_bytes[0..24]);
        session_id
    }

    pub fn build_session_id(&self) -> ([u8; 32], PublicKey) {
        let client_secret = EphemeralSecret::random_from_rng(rand::thread_rng());
        let client_public = PublicKey::from(&client_secret);
        let session_id = Self::encode_session_id(&self.config.short_id, client_public.as_bytes());
        (session_id, client_public)
    }

    pub async fn wrap_client<S>(&self, stream: S) -> io::Result<S>
    where
        S: TransportStream + 'static,
    {
        let (_session_id, _client_public) = self.build_session_id();
        Ok(stream)
    }
}
