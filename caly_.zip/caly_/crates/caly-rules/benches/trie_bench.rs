use criterion::{criterion_group, criterion_main, Criterion};
use caly_rules::trie::DomainTrie;
use std::hint::black_box;

fn bench_trie_match(c: &mut Criterion) {
    let mut trie = DomainTrie::new();
    trie.insert_suffix(".google.com", 1);
    trie.insert_suffix(".apple.com", 2);

    c.bench_function("trie/match", |b| {
        b.iter(|| {
            let res = trie.match_domain(black_box("music.apple.com"));
            black_box(res)
        })
    });
}

criterion_group!(benches, bench_trie_match);
criterion_main!(benches);
