use criterion::{criterion_group, criterion_main, Criterion};
use caly_rules::lpm::TreeBitmapLpm;
use std::hint::black_box;
use std::net::IpAddr;

fn bench_lpm_lookup(c: &mut Criterion) {
    let mut lpm = TreeBitmapLpm::new();
    lpm.insert("10.0.0.0/8".parse().unwrap(), 1);
    lpm.insert("10.1.0.0/16".parse().unwrap(), 2);
    lpm.insert("10.1.1.0/24".parse().unwrap(), 3);
    lpm.compile();

    let ip: IpAddr = "10.1.1.50".parse().unwrap();
    c.bench_function("lpm/lookup", |b| {
        b.iter(|| {
            let res = lpm.lookup(black_box(ip));
            black_box(res)
        })
    });
}

criterion_group!(benches, bench_lpm_lookup);
criterion_main!(benches);
