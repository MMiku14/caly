//! Read-only Mmap rule archive loader with SHA-256 self-checksumming.

use crate::archive::header::{ArchiveHeader, ARCHIVE_HEADER_SIZE, CURRENT_FORMAT_VERSION, MAGIC_CALYRULE};
use sha2::{Digest, Sha256};
use std::fs::File;
use std::path::Path;
use std::sync::Arc;
use thiserror::Error;

#[derive(Error, Debug)]
pub enum RuleLoadError {
    #[error("I/O error: {0}")]
    Io(#[from] std::io::Error),
    #[error("Rule archive file too small (< {ARCHIVE_HEADER_SIZE} bytes)")]
    FileTooSmall,
    #[error("Magic mismatch: invalid CALYRULE header")]
    InvalidMagic,
    #[error("Format version mismatch: expected {CURRENT_FORMAT_VERSION}, found {0}")]
    VersionMismatch(u32),
    #[error("Integrity check failed: SHA-256 checksum mismatch")]
    ChecksumMismatch,
    #[error("Invalid format: {0}")]
    InvalidFormat(&'static str),
}

pub struct MmapRuleArchive {
    mmap: Arc<memmap2::Mmap>,
    archive_header: *const ArchiveHeader,
    payload_len: usize,
    rules_count: u32,
}

unsafe impl Send for MmapRuleArchive {}
unsafe impl Sync for MmapRuleArchive {}

impl MmapRuleArchive {
    pub fn open<P: AsRef<Path>>(path: P) -> Result<Self, RuleLoadError> {
        let file = File::open(path)?;
        let meta = file.metadata()?;
        if meta.len() < ARCHIVE_HEADER_SIZE as u64 {
            return Err(RuleLoadError::FileTooSmall);
        }

        #[cfg(target_os = "linux")]
        {
            use std::os::unix::io::AsRawFd;
            let _ = nix::fcntl::flock(file.as_raw_fd(), nix::fcntl::FlockArg::LockShared);
        }

        let mmap = unsafe { memmap2::MmapOptions::new().map(&file)? };

        #[cfg(target_os = "linux")]
        let _ = mmap.advise(memmap2::Advice::WillNeed);

        if mmap.len() < ARCHIVE_HEADER_SIZE {
            return Err(RuleLoadError::FileTooSmall);
        }

        let header = mmap.as_ptr() as *const ArchiveHeader;
        let (magic, version, payload_len, rules_count, expected_checksum) = unsafe {
            (
                (*header).magic,
                (*header).format_version,
                (*header).payload_len as usize,
                (*header).rules_count,
                (*header).payload_checksum,
            )
        };

        if magic != MAGIC_CALYRULE {
            return Err(RuleLoadError::InvalidMagic);
        }
        if version != CURRENT_FORMAT_VERSION {
            return Err(RuleLoadError::VersionMismatch(version));
        }
        if ARCHIVE_HEADER_SIZE + payload_len > mmap.len() {
            return Err(RuleLoadError::InvalidFormat("Payload exceeds archive length"));
        }

        let payload_slice = &mmap[ARCHIVE_HEADER_SIZE..ARCHIVE_HEADER_SIZE + payload_len];
        let mut hasher = Sha256::new();
        hasher.update(payload_slice);
        let actual_hash = hasher.finalize();

        if expected_checksum != actual_hash.as_slice() {
            return Err(RuleLoadError::ChecksumMismatch);
        }

        Ok(Self {
            mmap: Arc::new(mmap),
            archive_header: header,
            payload_len,
            rules_count,
        })
    }

    pub fn create_archive<P: AsRef<Path>>(
        path: P,
        payload: &[u8],
        rules_count: u32,
    ) -> std::io::Result<()> {
        use std::io::Write;

        let mut hasher = Sha256::new();
        hasher.update(payload);
        let checksum: [u8; 32] = hasher.finalize().into();

        let header = ArchiveHeader {
            magic: MAGIC_CALYRULE,
            format_version: CURRENT_FORMAT_VERSION,
            layout_hash: 0xCA11_CA11_0001,
            payload_checksum: checksum,
            payload_len: payload.len() as u64,
            rules_count,
            _reserved: [0; 32],
        };

        let mut file = File::create(path)?;
        let header_bytes = unsafe {
            std::slice::from_raw_parts(
                &header as *const _ as *const u8,
                std::mem::size_of::<ArchiveHeader>(),
            )
        };

        file.write_all(header_bytes)?;
        file.write_all(payload)?;
        file.flush()?;
        Ok(())
    }

    #[must_use]
    pub fn payload(&self) -> &[u8] {
        &self.mmap[ARCHIVE_HEADER_SIZE..ARCHIVE_HEADER_SIZE + self.payload_len]
    }

    #[must_use]
    pub fn rules_count(&self) -> u32 { self.rules_count }
    #[must_use]
    pub fn len(&self) -> usize { self.payload_len }
    #[must_use]
    pub fn is_empty(&self) -> bool { self.payload_len == 0 }
}
