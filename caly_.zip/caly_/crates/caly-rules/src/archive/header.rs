//! 64-byte aligned archive header descriptor.

pub const MAGIC_CALYRULE: [u8; 8] = *b"CALYRULE";
pub const CURRENT_FORMAT_VERSION: u32 = 1;
pub const ARCHIVE_HEADER_SIZE: usize = 96;

#[repr(C, align(64))]
#[derive(Debug, Clone, Copy)]
pub struct ArchiveHeader {
    pub magic: [u8; 8],
    pub format_version: u32,
    pub layout_hash: u64,
    pub payload_checksum: [u8; 32],
    pub payload_len: u64,
    pub rules_count: u32,
    pub _reserved: [u8; 32],
}
