//! Precompiled binary rule archive persistence and mmap loading.

pub mod header;
pub mod mmap;

pub use header::{ArchiveHeader, ARCHIVE_HEADER_SIZE, CURRENT_FORMAT_VERSION, MAGIC_CALYRULE};
pub use mmap::{MmapRuleArchive, RuleLoadError};
