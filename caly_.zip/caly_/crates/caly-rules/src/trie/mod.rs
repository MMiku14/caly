//! Domain pattern matching trees.

pub mod keyword;
pub mod node;
pub mod regex;
pub mod suffix;

pub use keyword::DomainKeywordMatcher;
pub use node::DomainTrieNode;
pub use regex::DomainRegexMatcher;
pub use suffix::DomainTrie;
