//! Multi-keyword substring matcher.

use smol_str::SmolStr;

#[derive(Default, Debug, Clone)]
pub struct DomainKeywordMatcher {
    keywords: Vec<(SmolStr, u32)>,
}

impl DomainKeywordMatcher {
    #[must_use]
    pub fn new() -> Self {
        Self::default()
    }

    pub fn insert(&mut self, keyword: &str, rule_id: u32) {
        self.keywords.push((SmolStr::new(keyword.to_ascii_lowercase()), rule_id));
    }

    #[must_use]
    pub fn matches(&self, domain: &str) -> Option<u32> {
        let lower = domain.to_ascii_lowercase();
        for (kw, rule_id) in &self.keywords {
            if lower.contains(kw.as_str()) {
                return Some(*rule_id);
            }
        }
        None
    }
}
