//! Domain Trie node definition.

use smol_str::SmolStr;
use std::collections::HashMap;

#[derive(Default, Debug, Clone)]
pub struct DomainTrieNode {
    pub children: HashMap<SmolStr, DomainTrieNode>,
    pub rule_id: Option<u32>,
    pub is_wildcard: bool,
}
