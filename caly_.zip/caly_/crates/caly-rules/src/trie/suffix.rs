//! Label-based reverse suffix trie (RFC 1035 label boundaries).

use crate::trie::node::DomainTrieNode;
use smol_str::SmolStr;
use std::collections::HashMap;

#[derive(Default, Debug, Clone)]
pub struct DomainTrie {
    root: DomainTrieNode,
    exact_matches: HashMap<SmolStr, u32>,
}

impl DomainTrie {
    #[must_use]
    pub fn new() -> Self {
        Self::default()
    }

    pub fn insert_exact(&mut self, domain: &str, rule_id: u32) {
        let clean = domain.trim().trim_matches('.').to_ascii_lowercase();
        self.exact_matches.insert(SmolStr::new(clean), rule_id);
    }

    pub fn insert_suffix(&mut self, domain: &str, rule_id: u32) {
        let clean = domain.trim().trim_matches('.').to_ascii_lowercase();
        if clean.is_empty() { return; }
        let labels: Vec<&str> = clean.split('.').collect();
        let mut curr = &mut self.root;
        for label in labels.into_iter().rev() {
            curr = curr.children.entry(SmolStr::new(label)).or_default();
        }
        curr.rule_id = Some(rule_id);
    }

    #[must_use]
    pub fn match_domain(&self, domain: &str) -> Option<u32> {
        let clean = domain.trim().trim_matches('.').to_ascii_lowercase();
        if clean.is_empty() { return None; }

        if let Some(&rule_id) = self.exact_matches.get(clean.as_str()) {
            return Some(rule_id);
        }

        let labels: Vec<&str> = clean.split('.').collect();
        let mut curr = &self.root;
        let mut best = None;

        for label in labels.into_iter().rev() {
            if let Some(rule) = curr.rule_id {
                best = Some(rule);
            }
            match curr.children.get(label) {
                Some(next) => curr = next,
                None => return best,
            }
        }
        if let Some(rule) = curr.rule_id {
            best = Some(rule);
        }
        best
    }

    #[must_use]
    pub fn match_exact(&self, domain: &str) -> Option<u32> {
        let clean = domain.trim().trim_matches('.').to_ascii_lowercase();
        self.exact_matches.get(clean.as_str()).copied()
    }
}
