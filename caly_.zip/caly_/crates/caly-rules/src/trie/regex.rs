//! Linear-time DFA regex matcher (no catastrophic backtracking).

#[derive(Debug, Clone, Default)]
pub struct DomainRegexMatcher {
    regexes: Vec<(regex_lite::Regex, u32)>,
}

impl DomainRegexMatcher {
    #[must_use]
    pub fn new() -> Self {
        Self::default()
    }

    pub fn insert(&mut self, pattern: &str, rule_id: u32) -> Result<(), regex_lite::Error> {
        let re = regex_lite::RegexBuilder::new(pattern)
            .case_insensitive(true)
            .build()?;
        self.regexes.push((re, rule_id));
        Ok(())
    }

    #[must_use]
    pub fn matches(&self, domain: &str) -> Option<u32> {
        for (re, rule_id) in &self.regexes {
            if re.is_match(domain) {
                return Some(*rule_id);
            }
        }
        None
    }
}
