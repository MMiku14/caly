//! Caly Rules — Staged routing pipeline, 510-bit Tree-Bitmap LPM, and label-based Domain Trie.
//!
//! # Architecture
//!
//! ```text
//!  ┌──────────────────────────────────────────────────────────┐
//!  │  engine    Three-stage routing pipeline (FastPath -> DNS │
//!  │            -> 510-bit Tree-Bitmap LPM)                   │
//!  ├──────────────────────────────────────────────────────────┤
//!  │  logic     Composable RuleCondition and RFC private IP   │
//!  ├──────────────────────────────────────────────────────────┤
//!  │  trie      Label-based Suffix Trie & exact hash matching │
//!  ├──────────────────────────────────────────────────────────┤
//!  │  lpm       64-byte aligned 510-bit Tree-Bitmap LPM table │
//!  ├──────────────────────────────────────────────────────────┤
//!  │  archive   MmapRuleArchive with SHA-256 integrity check  │
//!  └──────────────────────────────────────────────────────────┘
//! ```

pub mod archive;
pub mod engine;
pub mod logic;
pub mod lpm;
pub mod trie;

pub use archive::{ArchiveHeader, MmapRuleArchive, RuleLoadError};
pub use engine::RuleEngine;
pub use logic::{is_private_ip, RuleCondition, RuleItem};
pub use lpm::{InternalNode, TreeBitmapLpm, TreeBitmapTable};
pub use trie::{DomainKeywordMatcher, DomainRegexMatcher, DomainTrie, DomainTrieNode};
