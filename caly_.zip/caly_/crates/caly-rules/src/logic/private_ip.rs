//! Complete RFC private, link-local, loopback, CGNAT, and benchmarking IP classification.

use std::net::IpAddr;

#[inline]
#[must_use]
pub fn is_private_ip(ip: IpAddr) -> bool {
    match ip {
        IpAddr::V4(v4) => {
            let octets = v4.octets();
            octets[0] == 10
                || (octets[0] == 172 && (octets[1] >= 16 && octets[1] <= 31))
                || (octets[0] == 192 && octets[1] == 168)
                || octets[0] == 127
                || (octets[0] == 169 && octets[1] == 254)
                || (octets[0] == 100 && (octets[1] >= 64 && octets[1] <= 127))
                || (octets[0] == 198 && (octets[1] == 18 || octets[1] == 19))
                || octets[0] == 0
                || (octets[0] >= 224 && octets[0] <= 239)
                || (octets[0] == 255 && octets[1] == 255 && octets[2] == 255 && octets[3] == 255)
        }
        IpAddr::V6(v6) => {
            v6.is_loopback()
                || (v6.segments()[0] & 0xfe00) == 0xfc00
                || (v6.segments()[0] & 0xffc0) == 0xfe80
                || (v6.segments()[0] & 0xff00) == 0xff00
                || v6.is_unspecified()
        }
    }
}
