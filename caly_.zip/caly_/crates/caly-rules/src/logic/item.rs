//! Declarative RuleItem structure.

use crate::logic::condition::RuleCondition;
use caly_common::metadata::SessionMetadata;
use smol_str::SmolStr;

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct RuleItem {
    pub condition: RuleCondition,
    pub outbound: SmolStr,
    pub invert: bool,
}

impl RuleItem {
    #[must_use]
    pub fn new(condition: RuleCondition, outbound: &str) -> Self {
        Self {
            condition,
            outbound: SmolStr::new(outbound),
            invert: false,
        }
    }

    #[must_use]
    pub fn with_invert(mut self, invert: bool) -> Self {
        self.invert = invert;
        self
    }

    #[must_use]
    pub fn matches(&self, meta: &SessionMetadata) -> bool {
        let res = self.condition.matches(meta);
        if self.invert { !res } else { res }
    }
}
