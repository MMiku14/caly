//! Composable rule conditions.

use crate::logic::private_ip::is_private_ip;
use caly_common::metadata::{Network, SessionMetadata, SniffedProtocol};
use smol_str::SmolStr;

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum RuleCondition {
    Domain(SmolStr),
    DomainSuffix(SmolStr),
    DomainKeyword(SmolStr),
    DomainRegex(String),
    IpCidr(ipnet::IpNet),
    SourceIpCidr(ipnet::IpNet),
    IpIsPrivate,
    Port(u16),
    PortRange(u16, u16),
    SourcePort(u16),
    SourcePortRange(u16, u16),
    ProcessName(SmolStr),
    ProcessPath(SmolStr),
    User(u32),
    Protocol(SniffedProtocol),
    Network(Network),
    Inbound(SmolStr),
    RuleSet(SmolStr),
    And(Vec<RuleCondition>),
    Or(Vec<RuleCondition>),
    Not(Box<RuleCondition>),
    Invert(Box<RuleCondition>),
}

impl RuleCondition {
    pub fn matches(&self, meta: &SessionMetadata) -> bool {
        match self {
            Self::Domain(d) => meta.has_domain() && meta.domain.eq_ignore_ascii_case(d.as_str()),
            Self::DomainSuffix(suffix) => {
                if !meta.has_domain() { return false; }
                let s = suffix.as_str().trim_matches('.');
                let d = meta.domain.as_str();
                if d.eq_ignore_ascii_case(s) {
                    true
                } else if d.len() > s.len() {
                    let prefix_end = d.len() - s.len();
                    d.ends_with(s) && d.as_bytes()[prefix_end - 1] == b'.'
                } else {
                    false
                }
            }
            Self::DomainKeyword(kw) => {
                if !meta.has_domain() { return false; }
                meta.domain.to_ascii_lowercase().contains(&kw.to_ascii_lowercase())
            }
            Self::DomainRegex(pat) => {
                if !meta.has_domain() { return false; }
                regex_lite::RegexBuilder::new(pat)
                    .case_insensitive(true)
                    .build()
                    .map(|re| re.is_match(meta.domain.as_str()))
                    .unwrap_or(false)
            }
            Self::IpCidr(net) => {
                if net.contains(&meta.dst_addr.ip()) { return true; }
                meta.resolved_ips.iter().any(|ip| net.contains(ip))
            }
            Self::SourceIpCidr(net) => net.contains(&meta.src_addr.ip()),
            Self::IpIsPrivate => {
                if is_private_ip(meta.dst_addr.ip()) { return true; }
                meta.resolved_ips.iter().any(|&ip| is_private_ip(ip))
            }
            Self::Port(p) => meta.dst_addr.port() == *p,
            Self::PortRange(start, end) => {
                let p = meta.dst_addr.port();
                p >= *start && p <= *end
            }
            Self::SourcePort(p) => meta.src_addr.port() == *p,
            Self::SourcePortRange(start, end) => {
                let p = meta.src_addr.port();
                p >= *start && p <= *end
            }
            Self::ProcessName(name) => meta.process_name.as_ref() == Some(name),
            Self::ProcessPath(path) => meta.process_path.as_ref() == Some(path),
            Self::User(uid) => meta.user_id == Some(*uid),
            Self::Protocol(proto) => meta.protocol == *proto,
            Self::Network(net) => net.matches(meta.network),
            Self::Inbound(tag) => meta.inbound_tag == *tag,
            Self::RuleSet(_) => false,
            Self::And(sub) => sub.iter().all(|c| c.matches(meta)),
            Self::Or(sub) => sub.iter().any(|c| c.matches(meta)),
            Self::Not(sub) | Self::Invert(sub) => !sub.matches(meta),
        }
    }

    #[must_use]
    pub fn requires_ip(&self) -> bool {
        match self {
            Self::IpCidr(_) | Self::IpIsPrivate => true,
            Self::And(sub) | Self::Or(sub) => sub.iter().any(Self::requires_ip),
            Self::Not(sub) | Self::Invert(sub) => sub.requires_ip(),
            _ => false,
        }
    }

    #[must_use]
    pub fn uses_process(&self) -> bool {
        match self {
            Self::ProcessName(_) | Self::ProcessPath(_) | Self::User(_) => true,
            Self::And(sub) | Self::Or(sub) => sub.iter().any(Self::uses_process),
            Self::Not(sub) | Self::Invert(sub) => sub.uses_process(),
            _ => false,
        }
    }
}
