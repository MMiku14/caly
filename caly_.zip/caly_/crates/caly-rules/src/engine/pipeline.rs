//! Three-stage Staged Routing Pipeline orchestrator.

use crate::lpm::TreeBitmapLpm;
use crate::logic::{RuleCondition, RuleItem};
use crate::trie::{DomainKeywordMatcher, DomainRegexMatcher, DomainTrie};
use caly_common::dns::DnsResolver;
use caly_common::metadata::SessionMetadata;
use smol_str::SmolStr;
use std::sync::Arc;

#[derive(Debug, Clone)]
pub struct RuleEngine {
    domain_trie: DomainTrie,
    domain_trie_outbounds: Vec<SmolStr>,
    keyword_matcher: DomainKeywordMatcher,
    keyword_outbounds: Vec<SmolStr>,
    regex_matcher: DomainRegexMatcher,
    regex_outbounds: Vec<SmolStr>,
    ip_tree: TreeBitmapLpm,
    ip_tree_outbounds: Vec<SmolStr>,
    rules: Vec<RuleItem>,
    final_outbound: SmolStr,
    has_process_rules: bool,
    has_ip_rules: bool,
}

impl RuleEngine {
    pub fn new(rules: Vec<RuleItem>, final_outbound: &str) -> Self {
        let mut domain_trie = DomainTrie::new();
        let mut domain_trie_outbounds = Vec::new();
        let mut keyword_matcher = DomainKeywordMatcher::new();
        let mut keyword_outbounds = Vec::new();
        let mut regex_matcher = DomainRegexMatcher::new();
        let mut regex_outbounds = Vec::new();
        let mut ip_tree = TreeBitmapLpm::new();
        let mut ip_tree_outbounds = Vec::new();

        let mut has_process_rules = false;
        let mut has_ip_rules = false;

        for rule in &rules {
            if rule.condition.uses_process() { has_process_rules = true; }
            if rule.condition.requires_ip() { has_ip_rules = true; }

            match &rule.condition {
                RuleCondition::Domain(d) => {
                    let id = domain_trie_outbounds.len() as u32;
                    domain_trie.insert_exact(d.as_str(), id);
                    domain_trie_outbounds.push(rule.outbound.clone());
                }
                RuleCondition::DomainSuffix(s) => {
                    let id = domain_trie_outbounds.len() as u32;
                    domain_trie.insert_suffix(s.as_str(), id);
                    domain_trie_outbounds.push(rule.outbound.clone());
                }
                RuleCondition::DomainKeyword(kw) => {
                    let id = keyword_outbounds.len() as u32;
                    keyword_matcher.insert(kw.as_str(), id);
                    keyword_outbounds.push(rule.outbound.clone());
                }
                RuleCondition::DomainRegex(pat) => {
                    let id = regex_outbounds.len() as u32;
                    if let Ok(()) = regex_matcher.insert(pat, id) {
                        regex_outbounds.push(rule.outbound.clone());
                    }
                }
                RuleCondition::IpCidr(net) => {
                    let id = ip_tree_outbounds.len() as u32;
                    ip_tree.insert(*net, id);
                    ip_tree_outbounds.push(rule.outbound.clone());
                }
                _ => {}
            }
        }

        ip_tree.compile();

        Self {
            domain_trie,
            domain_trie_outbounds,
            keyword_matcher,
            keyword_outbounds,
            regex_matcher,
            regex_outbounds,
            ip_tree,
            ip_tree_outbounds,
            rules,
            final_outbound: SmolStr::new(final_outbound),
            has_process_rules,
            has_ip_rules,
        }
    }

    #[inline(always)]
    #[must_use]
    pub fn uses_process_rules(&self) -> bool { self.has_process_rules }

    #[inline(always)]
    #[must_use]
    pub fn has_ip_rules(&self) -> bool { self.has_ip_rules }

    #[must_use]
    pub fn final_outbound(&self) -> &str { self.final_outbound.as_str() }

    #[must_use]
    pub fn match_outbound(&self, meta: &SessionMetadata) -> &str {
        for rule in &self.rules {
            if rule.matches(meta) {
                return rule.outbound.as_str();
            }
        }

        if meta.has_domain() {
            if let Some(id) = self.domain_trie.match_domain(meta.domain.as_str()) {
                if let Some(out) = self.domain_trie_outbounds.get(id as usize) {
                    return out.as_str();
                }
            }
            if let Some(id) = self.keyword_matcher.matches(meta.domain.as_str()) {
                if let Some(out) = self.keyword_outbounds.get(id as usize) {
                    return out.as_str();
                }
            }
            if let Some(id) = self.regex_matcher.matches(meta.domain.as_str()) {
                if let Some(out) = self.regex_outbounds.get(id as usize) {
                    return out.as_str();
                }
            }
        }

        if let Some(id) = self.ip_tree.lookup(meta.dst_addr.ip()) {
            if let Some(out) = self.ip_tree_outbounds.get(id as usize) {
                return out.as_str();
            }
        }

        for &ip in &meta.resolved_ips {
            if let Some(id) = self.ip_tree.lookup(ip) {
                if let Some(out) = self.ip_tree_outbounds.get(id as usize) {
                    return out.as_str();
                }
            }
        }

        self.final_outbound.as_str()
    }

    pub async fn evaluate(
        &self,
        meta: &mut SessionMetadata,
        dns: Option<&Arc<dyn DnsResolver>>,
    ) -> SmolStr {
        // Stage 1: Zero-I/O Fast Path
        for rule in &self.rules {
            if !rule.condition.requires_ip() && rule.matches(meta) {
                return rule.outbound.clone();
            }
        }

        if meta.has_domain() {
            if let Some(id) = self.domain_trie.match_domain(meta.domain.as_str()) {
                if let Some(out) = self.domain_trie_outbounds.get(id as usize) {
                    return out.clone();
                }
            }
            if let Some(id) = self.keyword_matcher.matches(meta.domain.as_str()) {
                if let Some(out) = self.keyword_outbounds.get(id as usize) {
                    return out.clone();
                }
            }
            if let Some(id) = self.regex_matcher.matches(meta.domain.as_str()) {
                if let Some(out) = self.regex_outbounds.get(id as usize) {
                    return out.clone();
                }
            }
        }

        // Stage 2: Conditional DNS Resolution
        if self.has_ip_rules && meta.has_domain() && meta.resolved_ips.is_empty() {
            if let Some(resolver) = dns {
                if let Ok(candidates) = resolver.resolve_for_dial(meta.domain.as_str()).await {
                    meta.resolved_ips = candidates;
                }
            }
        }

        // Stage 3: L3 LPM 510-bit Tree-Bitmap lookup
        for rule in &self.rules {
            if rule.condition.requires_ip() && rule.matches(meta) {
                return rule.outbound.clone();
            }
        }

        if let Some(id) = self.ip_tree.lookup(meta.dst_addr.ip()) {
            if let Some(out) = self.ip_tree_outbounds.get(id as usize) {
                return out.clone();
            }
        }

        for &ip in &meta.resolved_ips {
            if let Some(id) = self.ip_tree.lookup(ip) {
                if let Some(out) = self.ip_tree_outbounds.get(id as usize) {
                    return out.clone();
                }
            }
        }

        self.final_outbound.clone()
    }
}
