//! Staged routing engine pipeline.

pub mod pipeline;
pub use pipeline::RuleEngine;
