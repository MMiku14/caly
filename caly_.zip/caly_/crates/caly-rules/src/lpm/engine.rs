//! Tree-Bitmap LPM router supporting IPv4 & IPv6.

use ipnet::IpNet;
use std::net::{IpAddr, Ipv4Addr, Ipv6Addr};
use crate::lpm::builder::{compile_dynamic_tree, DynamicNode};
use crate::lpm::table::TreeBitmapTable;

#[derive(Debug, Clone, Default)]
pub struct TreeBitmapLpm {
    v4_dynamic: DynamicNode,
    v6_dynamic: DynamicNode,
    v4_table: TreeBitmapTable,
    v6_table: TreeBitmapTable,
    raw_rules: Vec<(IpNet, u32)>,
    is_compiled: bool,
}

impl TreeBitmapLpm {
    #[must_use]
    pub fn new() -> Self {
        Self::default()
    }

    pub fn insert(&mut self, net: IpNet, rule_id: u32) {
        self.raw_rules.push((net, rule_id));
        self.is_compiled = false;

        match net {
            IpNet::V4(v4) => {
                let octets = v4.network().octets();
                Self::insert_into_dynamic(&mut self.v4_dynamic, &octets, v4.prefix_len(), rule_id);
            }
            IpNet::V6(v6) => {
                let octets = v6.network().octets();
                Self::insert_into_dynamic(&mut self.v6_dynamic, &octets, v6.prefix_len(), rule_id);
            }
        }
    }

    fn insert_into_dynamic(root: &mut DynamicNode, net_bytes: &[u8], prefix_len: u8, rule_id: u32) {
        if prefix_len == 0 {
            root.prefixes.insert((0, 0), rule_id);
            return;
        }

        let mut curr = root;
        let mut stride_idx = 0usize;
        let mut rem_len = prefix_len;

        while rem_len > 0 {
            let octet = net_bytes[stride_idx];
            if rem_len <= 8 {
                let val = octet >> (8 - rem_len);
                curr.prefixes.insert((rem_len, val), rule_id);
                break;
            } else {
                curr = curr.children.entry(octet).or_default();
                stride_idx += 1;
                rem_len -= 8;
            }
        }
    }

    pub fn compile(&mut self) {
        self.v4_table = compile_dynamic_tree(&self.v4_dynamic);
        self.v6_table = compile_dynamic_tree(&self.v6_dynamic);
        self.is_compiled = true;
    }

    #[must_use]
    pub fn lookup_v4(&self, ip: Ipv4Addr) -> Option<u32> {
        if !self.is_compiled {
            return self.lookup_fallback(IpAddr::V4(ip));
        }
        self.v4_table.lookup_bytes(&ip.octets())
    }

    #[must_use]
    pub fn lookup_v6(&self, ip: Ipv6Addr) -> Option<u32> {
        if !self.is_compiled {
            return self.lookup_fallback(IpAddr::V6(ip));
        }
        self.v6_table.lookup_bytes(&ip.octets())
    }

    #[must_use]
    pub fn lookup(&self, ip: IpAddr) -> Option<u32> {
        match ip {
            IpAddr::V4(v4) => self.lookup_v4(v4),
            IpAddr::V6(v6) => self.lookup_v6(v6),
        }
    }

    fn lookup_fallback(&self, ip: IpAddr) -> Option<u32> {
        let mut best: Option<(u8, u32)> = None;
        for &(net, rule_id) in &self.raw_rules {
            if net.contains(&ip) {
                let plen = net.prefix_len();
                if best.map_or(true, |(blen, _)| plen > blen) {
                    best = Some((plen, rule_id));
                }
            }
        }
        best.map(|(_, r)| r)
    }

    #[must_use]
    pub fn len(&self) -> usize { self.raw_rules.len() }
    #[must_use]
    pub fn is_empty(&self) -> bool { self.raw_rules.is_empty() }
}
