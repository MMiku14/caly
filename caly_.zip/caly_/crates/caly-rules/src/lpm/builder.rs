//! Dynamic BFS node compiler into contiguous 64-byte aligned hardware tables.

use std::collections::{HashMap, VecDeque};
use crate::lpm::node::{prefix_to_bit_index, InternalNode};
use crate::lpm::table::TreeBitmapTable;

#[derive(Default, Debug, Clone)]
pub struct DynamicNode {
    pub prefixes: HashMap<(u8, u8), u32>,
    pub children: HashMap<u8, DynamicNode>,
}

pub fn compile_dynamic_tree(dynamic_root: &DynamicNode) -> TreeBitmapTable {
    let mut nodes = Vec::new();
    let mut prefix_rules = Vec::new();
    let mut queue = VecDeque::new();

    let default_rule = dynamic_root.prefixes.get(&(0, 0)).copied();
    nodes.push(InternalNode::default());
    queue.push_back((0usize, dynamic_root));

    while let Some((node_idx, dyn_node)) = queue.pop_front() {
        let mut prefix_items: Vec<((u8, u8), u32)> = dyn_node
            .prefixes
            .iter()
            .filter(|(&(len, _), _)| len >= 1 && len <= 8)
            .map(|(&k, &v)| (k, v))
            .collect();

        prefix_items.sort_by_key(|&((len, val), _)| prefix_to_bit_index(len, val));

        let prefix_ptr = prefix_rules.len() as u32;
        let prefix_count = prefix_items.len() as u16;

        let mut prefix_bitmap = [0u64; 8];
        for &((len, val), rule_id) in &prefix_items {
            let bit_idx = prefix_to_bit_index(len, val);
            let word = bit_idx / 64;
            let bit = bit_idx % 64;
            prefix_bitmap[word] |= 1u64 << bit;
            prefix_rules.push(rule_id);
        }

        let mut child_octets: Vec<u8> = dyn_node.children.keys().copied().collect();
        child_octets.sort_unstable();

        let child_count = child_octets.len() as u16;
        let child_ptr = nodes.len() as u32;

        let mut child_bitmap = [0u64; 4];
        for &octet in &child_octets {
            let word = (octet / 64) as usize;
            let bit = octet % 64;
            child_bitmap[word] |= 1u64 << bit;
        }

        for _ in 0..child_count {
            nodes.push(InternalNode::default());
        }

        nodes[node_idx].prefix_bitmap = prefix_bitmap;
        nodes[node_idx].child_bitmap = child_bitmap;
        nodes[node_idx].prefix_ptr = prefix_ptr;
        nodes[node_idx].prefix_count = prefix_count;
        nodes[node_idx].child_ptr = child_ptr;
        nodes[node_idx].child_count = child_count;

        for (rank, &octet) in child_octets.iter().enumerate() {
            let child_node_idx = (child_ptr as usize) + rank;
            let child_dyn = &dyn_node.children[&octet];
            queue.push_back((child_node_idx, child_dyn));
        }
    }

    TreeBitmapTable {
        nodes,
        prefix_rules,
        default_rule,
    }
}
