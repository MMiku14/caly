//! Static 8-bit Stride Tree-Bitmap table.

use crate::lpm::node::{count_ones_up_to, count_ones_up_to_child, prefix_to_bit_index, InternalNode};

#[derive(Debug, Clone)]
pub struct TreeBitmapTable {
    pub(crate) nodes: Vec<InternalNode>,
    pub(crate) prefix_rules: Vec<u32>,
    pub(crate) default_rule: Option<u32>,
}

impl Default for TreeBitmapTable {
    fn default() -> Self {
        Self {
            nodes: vec![InternalNode::default()],
            prefix_rules: Vec::new(),
            default_rule: None,
        }
    }
}

impl TreeBitmapTable {
    #[must_use]
    pub fn new() -> Self {
        Self::default()
    }

    #[must_use]
    pub fn lookup_bytes(&self, octets: &[u8]) -> Option<u32> {
        if self.nodes.is_empty() {
            return self.default_rule;
        }

        let mut curr_node_idx = 0usize;
        let mut best_rule = self.default_rule;

        for &octet in octets {
            if curr_node_idx >= self.nodes.len() {
                break;
            }
            let node = &self.nodes[curr_node_idx];

            for len in (1..=8).rev() {
                let val = octet >> (8 - len);
                let bit_idx = prefix_to_bit_index(len, val);
                let word = bit_idx / 64;
                let bit = bit_idx % 64;

                if (node.prefix_bitmap[word] & (1u64 << bit)) != 0 {
                    let rank = count_ones_up_to(&node.prefix_bitmap, bit_idx);
                    let idx = (node.prefix_ptr as usize) + rank;
                    if idx < self.prefix_rules.len() {
                        best_rule = Some(self.prefix_rules[idx]);
                    }
                    break;
                }
            }

            let child_word = (octet / 64) as usize;
            let child_bit = octet % 64;

            if (node.child_bitmap[child_word] & (1u64 << child_bit)) == 0 {
                return best_rule;
            }

            let child_rank = count_ones_up_to_child(&node.child_bitmap, octet as usize);
            curr_node_idx = (node.child_ptr as usize) + child_rank;
        }

        best_rule
    }
}
