//! 8-bit Stride Tree-Bitmap internal node (aligned to 64 bytes).

#[repr(C, align(64))]
#[derive(Clone, Copy, Debug)]
pub struct InternalNode {
    pub prefix_bitmap: [u64; 8],  // 512 bits (uses 510 bits)
    pub child_bitmap: [u64; 4],   // 256 bits
    pub child_ptr: u32,
    pub prefix_ptr: u32,
    pub child_count: u16,
    pub prefix_count: u16,
    pub _reserved: [u8; 16],
}

const _: () = assert!(std::mem::align_of::<InternalNode>() >= 64);

impl Default for InternalNode {
    fn default() -> Self {
        Self {
            prefix_bitmap: [0; 8],
            child_bitmap: [0; 4],
            child_ptr: 0,
            prefix_ptr: 0,
            child_count: 0,
            prefix_count: 0,
            _reserved: [0; 16],
        }
    }
}

#[inline(always)]
pub fn prefix_to_bit_index(len: u8, val: u8) -> usize {
    debug_assert!(len >= 1 && len <= 8);
    let offset = (1usize << len) - 2;
    offset + (val as usize)
}

#[inline(always)]
pub fn count_ones_up_to(bitmap: &[u64; 8], target_bit: usize) -> usize {
    let word_idx = target_bit / 64;
    let bit_rem = target_bit % 64;
    let mut count = 0usize;

    for i in 0..word_idx {
        count += bitmap[i].count_ones() as usize;
    }
    if bit_rem > 0 {
        let mask = (1u64 << bit_rem) - 1;
        count += (bitmap[word_idx] & mask).count_ones() as usize;
    }
    count
}

#[inline(always)]
pub fn count_ones_up_to_child(bitmap: &[u64; 4], target_bit: usize) -> usize {
    let word_idx = target_bit / 64;
    let bit_rem = target_bit % 64;
    let mut count = 0usize;

    for i in 0..word_idx {
        count += bitmap[i].count_ones() as usize;
    }
    if bit_rem > 0 {
        let mask = (1u64 << bit_rem) - 1;
        count += (bitmap[word_idx] & mask).count_ones() as usize;
    }
    count
}
