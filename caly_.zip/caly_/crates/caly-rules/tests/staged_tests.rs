use async_trait::async_trait;
use caly_common::dns::{DnsError, DnsResolver, ResolveResult};
use caly_common::metadata::{Network, SessionMetadata};
use caly_rules::engine::RuleEngine;
use caly_rules::logic::{RuleCondition, RuleItem};
use smallvec::{smallvec, SmallVec};
use smol_str::SmolStr;
use std::net::IpAddr;
use std::sync::atomic::{AtomicUsize, Ordering};
use std::sync::Arc;

struct MockResolver {
    calls: AtomicUsize,
}

#[async_trait]
impl DnsResolver for MockResolver {
    async fn resolve_for_client(&self, _domain: &str) -> Result<ResolveResult, DnsError> {
        Ok(ResolveResult::RealIp(smallvec!["1.1.1.1".parse().unwrap()]))
    }
    async fn resolve_for_dial(&self, _domain: &str) -> Result<SmallVec<[IpAddr; 4]>, DnsError> {
        self.calls.fetch_add(1, Ordering::SeqCst);
        Ok(smallvec!["1.1.1.1".parse().unwrap()])
    }
    fn lookup_fakeip(&self, _ip: IpAddr) -> Option<SmolStr> { None }
    fn snoop(&self, _ip: IpAddr) -> Option<SmolStr> { None }
}

#[tokio::test]
async fn test_stage1_short_circuits_without_dns() {
    let rules = vec![
        RuleItem::new(RuleCondition::DomainSuffix(SmolStr::new(".google.com")), "proxy"),
        RuleItem::new(RuleCondition::IpIsPrivate, "direct"),
    ];
    let engine = RuleEngine::new(rules, "fallback");
    let mock = Arc::new(MockResolver { calls: AtomicUsize::new(0) });
    let resolver: Arc<dyn DnsResolver> = mock.clone();

    let mut meta = SessionMetadata::new(
        "127.0.0.1:1000".parse().unwrap(),
        "10.0.0.1:443".parse().unwrap(),
        Network::Tcp,
        SmolStr::new("tproxy-in"),
    );
    meta.set_domain("mail.google.com");

    let out = engine.evaluate(&mut meta, Some(&resolver)).await;
    assert_eq!(out.as_str(), "proxy");
    assert_eq!(mock.calls.load(Ordering::SeqCst), 0);
}
