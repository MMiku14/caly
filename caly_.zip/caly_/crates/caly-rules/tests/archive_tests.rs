use caly_rules::archive::MmapRuleArchive;

#[test]
fn test_mmap_archive_roundtrip() {
    let tmp = std::env::temp_dir().join("caly_rules_test.bin");
    let payload = b"CALY_RULES_PRECOMPILED_DATA";
    MmapRuleArchive::create_archive(&tmp, payload, 10).unwrap();

    let loaded = MmapRuleArchive::open(&tmp).unwrap();
    assert_eq!(loaded.payload(), payload);
    assert_eq!(loaded.rules_count(), 10);
    let _ = std::fs::remove_file(&tmp);
}
