use caly_rules::logic::is_private_ip;

#[test]
fn test_rfc_private_classifications() {
    assert!(is_private_ip("10.0.0.1".parse().unwrap()));
    assert!(is_private_ip("172.16.0.1".parse().unwrap()));
    assert!(is_private_ip("192.168.1.1".parse().unwrap()));
    assert!(is_private_ip("198.18.0.1".parse().unwrap())); // FakeIP RFC 2544
    assert!(is_private_ip("100.64.0.1".parse().unwrap())); // CGNAT RFC 6598
    assert!(is_private_ip("fc00::1".parse().unwrap()));     // IPv6 ULA
    assert!(!is_private_ip("8.8.8.8".parse().unwrap()));
    assert!(!is_private_ip("1.1.1.1".parse().unwrap()));
}
