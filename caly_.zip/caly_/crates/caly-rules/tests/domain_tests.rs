use caly_rules::trie::{DomainKeywordMatcher, DomainRegexMatcher, DomainTrie};

#[test]
fn test_domain_suffix_label_isolation() {
    let mut trie = DomainTrie::new();
    trie.insert_suffix(".google.com", 1);
    trie.insert_suffix(".cn", 2);

    assert_eq!(trie.match_domain("google.com"), Some(1));
    assert_eq!(trie.match_domain("www.google.com"), Some(1));
    assert_eq!(trie.match_domain("api.sub.google.com"), Some(1));
    assert_eq!(trie.match_domain("google.cn"), Some(2));

    // RFC 1035 label boundaries: MUST NOT match substrings
    assert_eq!(trie.match_domain("fakegoogle.com"), None);
    assert_eq!(trie.match_domain("evil-google.com"), None);
}

#[test]
fn test_domain_exact_precedence() {
    let mut trie = DomainTrie::new();
    trie.insert_exact("github.com", 10);
    trie.insert_suffix(".github.com", 20);

    assert_eq!(trie.match_domain("github.com"), Some(10));
    assert_eq!(trie.match_domain("api.github.com"), Some(20));
}
