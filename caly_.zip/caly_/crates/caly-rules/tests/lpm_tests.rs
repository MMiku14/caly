use caly_rules::lpm::TreeBitmapLpm;
use std::net::IpAddr;

#[test]
fn test_tree_bitmap_non_aligned_masks() {
    let mut lpm = TreeBitmapLpm::new();
    lpm.insert("10.128.0.0/9".parse().unwrap(), 101);
    lpm.insert("128.0.0.0/1".parse().unwrap(), 102);
    lpm.compile();

    let ip9: IpAddr = "10.200.1.1".parse().unwrap();
    assert_eq!(lpm.lookup(ip9), Some(101));

    let ip1: IpAddr = "192.168.1.1".parse().unwrap();
    assert_eq!(lpm.lookup(ip1), Some(102));

    let ip_miss: IpAddr = "8.8.8.8".parse().unwrap();
    assert_eq!(lpm.lookup(ip_miss), None);
}

#[test]
fn test_tree_bitmap_ipv6_lpm() {
    let mut lpm = TreeBitmapLpm::new();
    lpm.insert("2001:db8::/32".parse().unwrap(), 201);
    lpm.insert("2001:db8:abcd::/48".parse().unwrap(), 202);
    lpm.compile();

    let ip48: IpAddr = "2001:db8:abcd::1".parse().unwrap();
    assert_eq!(lpm.lookup(ip48), Some(202));

    let ip32: IpAddr = "2001:db8:1234::1".parse().unwrap();
    assert_eq!(lpm.lookup(ip32), Some(201));
}
