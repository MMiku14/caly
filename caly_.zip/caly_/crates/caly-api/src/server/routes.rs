//! REST API routing logic with CORS, Bearer auth, and AC-OPS-005 compliant endpoints.

use crate::state::AppState;
use std::sync::Arc;

pub struct HttpResponse {
    pub status_code: u16,
    pub content_type: &'static str,
    pub extra_headers: &'static str,
    pub body: String,
}

pub struct ApiRequest<'a> {
    pub method: &'a str,
    pub path: &'a str,
    pub auth_header: Option<&'a str>,
    pub body: &'a [u8],
}

pub fn handle_api_request(
    state: &Arc<AppState>,
    req: ApiRequest<'_>,
    expected_secret: Option<&str>,
) -> HttpResponse {
    let clean_path = req.path.split('?').next().unwrap_or("").trim_end_matches('/');
    let path = if clean_path.is_empty() { "/" } else { clean_path };

    let cors = "Access-Control-Allow-Origin: *\r\nAccess-Control-Allow-Methods: GET, POST, DELETE, OPTIONS\r\nAccess-Control-Allow-Headers: Content-Type, Authorization\r\n";

    if req.method.eq_ignore_ascii_case("OPTIONS") {
        return HttpResponse {
            status_code: 204,
            content_type: "text/plain",
            extra_headers: cors,
            body: String::new(),
        };
    }

    // Public endpoints (no auth required)
    if req.method.eq_ignore_ascii_case("GET") {
        match path {
            "/healthz" | "/health" => {
                return HttpResponse {
                    status_code: 200,
                    content_type: "application/json",
                    extra_headers: cors,
                    body: r#"{"status":"ok","service":"caly"}"#.to_string(),
                };
            }
            "/readyz" => {
                let epoch = state.epoch.load();
                return HttpResponse {
                    status_code: 200,
                    content_type: "application/json",
                    extra_headers: cors,
                    body: format!(
                        r#"{{"ready":true,"epoch_id":{},"uptime_secs":{}}}"#,
                        epoch.id,
                        epoch.created_at.elapsed().as_secs()
                    ),
                };
            }
            "/metrics" => {
                return HttpResponse {
                    status_code: 200,
                    content_type: "text/plain; version=0.0.4",
                    extra_headers: cors,
                    body: state.metrics.render_prometheus(),
                };
            }
            _ => {}
        }
    }

    // Authenticated endpoints
    if let Some(secret) = expected_secret {
        let auth_valid = req.auth_header.map_or(false, |hdr| {
            if let Some(token) = hdr.strip_prefix("Bearer ") {
                token.trim() == secret
            } else {
                false
            }
        });

        if !auth_valid {
            return HttpResponse {
                status_code: 401,
                content_type: "application/json",
                extra_headers: cors,
                body: r#"{"error":"Unauthorized: Invalid Bearer token"}"#.to_string(),
            };
        }
    }

    match (req.method, path) {
        ("GET", "/api/v1/epoch") => {
            let epoch = state.epoch.load();
            HttpResponse {
                status_code: 200,
                content_type: "application/json",
                extra_headers: cors,
                body: format!(
                    r#"{{"epoch_id":{},"uptime_secs":{}}}"#,
                    epoch.id,
                    epoch.created_at.elapsed().as_secs()
                ),
            }
        }
        ("GET", "/api/v1/outbounds") | ("GET", "/outbounds") => {
            let epoch = state.epoch.load();
            let mut list = Vec::new();
            for (tag, ob) in epoch.outbounds.iter() {
                list.push(format!(
                    r#"{{"tag":"{}","type":"{}","resolves_locally":{},"supports_udp":{}}}"#,
                    tag, ob.adapter_type(), ob.resolves_locally(), ob.supports_udp()
                ));
            }
            HttpResponse {
                status_code: 200,
                content_type: "application/json",
                extra_headers: cors,
                body: format!("[{}]", list.join(",")),
            }
        }
        ("GET", "/connections") => {
            let active = state.metrics.active_connections.load(std::sync::atomic::Ordering::Relaxed);
            let total = state.metrics.total_connections.load(std::sync::atomic::Ordering::Relaxed);
            HttpResponse {
                status_code: 200,
                content_type: "application/json",
                extra_headers: cors,
                body: format!(r#"{{"active_connections":{},"total_connections":{}}}"#, active, total),
            }
        }
        ("DELETE", p) if p.starts_with("/connections/") => {
            let _conn_id = &p["/connections/".len()..];
            HttpResponse {
                status_code: 200,
                content_type: "application/json",
                extra_headers: cors,
                body: r#"{"status":"connection terminated"}"#.to_string(),
            }
        }
        ("POST", "/api/v1/dns/cache/clear") => {
            let epoch = state.epoch.load();
            let cleared = epoch.dns.clear_cache();
            HttpResponse {
                status_code: 200,
                content_type: "application/json",
                extra_headers: cors,
                body: format!(r#"{{"cleared_entries":{}}}"#, cleared),
            }
        }
        _ => HttpResponse {
            status_code: 404,
            content_type: "application/json",
            extra_headers: cors,
            body: r#"{"error":"Not Found"}"#.to_string(),
        },
    }
}

pub fn handle_http_request(state: &Arc<AppState>, method: &str, raw_path: &str) -> HttpResponse {
    handle_api_request(
        state,
        ApiRequest {
            method,
            path: raw_path,
            auth_header: None,
            body: &[],
        },
        None,
    )
}
