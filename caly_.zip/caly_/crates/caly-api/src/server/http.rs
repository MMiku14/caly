//! Embedded lightweight HTTP server.

use crate::server::routes::{handle_api_request, ApiRequest};
use crate::state::AppState;
use std::net::SocketAddr;
use std::sync::Arc;
use tokio::io::{AsyncReadExt, AsyncWriteExt};
use tokio::net::TcpListener;

pub async fn run_api_server(
    listen_addr: SocketAddr,
    state: Arc<AppState>,
    secret: Option<String>,
) -> std::io::Result<()> {
    let listener = TcpListener::bind(listen_addr).await?;
    tracing::info!(listen = %listen_addr, "Caly Control API server listening");

    let secret_arc = secret.map(Arc::new);

    loop {
        let (mut stream, _) = listener.accept().await?;
        let state = Arc::clone(&state);
        let secret = secret_arc.clone();

        tokio::spawn(async move {
            let mut buf = [0u8; 4096];
            if let Ok(n) = stream.read(&mut buf).await {
                if n > 0 {
                    let req_str = String::from_utf8_lossy(&buf[..n]);
                    let mut lines = req_str.lines();
                    if let Some(first_line) = lines.next() {
                        let parts: Vec<&str> = first_line.split_whitespace().collect();
                        if parts.len() >= 2 {
                            let mut auth_header = None;
                            for line in lines {
                                if line.starts_with("Authorization:") {
                                    auth_header = Some(line["Authorization:".len()..].trim());
                                    break;
                                }
                            }

                            let api_req = ApiRequest {
                                method: parts[0],
                                path: parts[1],
                                auth_header,
                                body: &[],
                            };

                            let resp = handle_api_request(&state, api_req, secret.as_deref().map(String::as_str));
                            let body_bytes = resp.body.as_bytes();
                            let formatted = format!(
                                "HTTP/1.1 {} OK\r\nContent-Type: {}\r\nContent-Length: {}\r\n{}Connection: close\r\n\r\n{}",
                                resp.status_code, resp.content_type, body_bytes.len(), resp.extra_headers, resp.body
                            );
                            let _ = stream.write_all(formatted.as_bytes()).await;
                            let _ = stream.flush().await;
                        }
                    }
                }
            }
        });
    }
}
