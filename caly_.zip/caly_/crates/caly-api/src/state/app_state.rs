//! Global AppState with lock-free atomic hot-reload.

use crate::metrics::PrometheusMetrics;
use crate::state::epoch::Epoch;
use arc_swap::ArcSwap;
use caly_common::adapter::ProxyAdapter;
use caly_common::dns::DnsResolver;
use caly_rules::RuleEngine;
use std::collections::HashMap;
use std::sync::Arc;
use std::time::Instant;

pub struct AppState {
    pub epoch: ArcSwap<Epoch>,
    pub metrics: Arc<PrometheusMetrics>,
}

impl AppState {
    #[must_use]
    pub fn new(initial_epoch: Epoch, metrics: Arc<PrometheusMetrics>) -> Self {
        Self {
            epoch: ArcSwap::new(Arc::new(initial_epoch)),
            metrics,
        }
    }

    pub fn reload(
        &self,
        new_rules: Arc<RuleEngine>,
        new_dns: Arc<dyn DnsResolver>,
        new_outbounds: Arc<HashMap<String, Arc<dyn ProxyAdapter>>>,
    ) -> u64 {
        let prev_id = self.epoch.load().id;
        let new_id = prev_id + 1;

        let new_epoch = Epoch {
            id: new_id,
            rules: new_rules,
            dns: new_dns,
            outbounds: new_outbounds,
            created_at: Instant::now(),
        };

        let _old = self.epoch.swap(Arc::new(new_epoch));
        new_id
    }
}
