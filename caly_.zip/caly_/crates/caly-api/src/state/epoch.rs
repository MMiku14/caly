//! Control plane epoch state.

use caly_common::adapter::ProxyAdapter;
use caly_common::dns::DnsResolver;
use caly_rules::RuleEngine;
use std::collections::HashMap;
use std::sync::Arc;
use std::time::Instant;

pub struct Epoch {
    pub id: u64,
    pub rules: Arc<RuleEngine>,
    pub dns: Arc<dyn DnsResolver>,
    pub outbounds: Arc<HashMap<String, Arc<dyn ProxyAdapter>>>,
    pub created_at: Instant,
}

impl Epoch {
    #[must_use]
    pub fn new(
        id: u64,
        rules: Arc<RuleEngine>,
        dns: Arc<dyn DnsResolver>,
        outbounds: Arc<HashMap<String, Arc<dyn ProxyAdapter>>>,
    ) -> Self {
        Self {
            id,
            rules,
            dns,
            outbounds,
            created_at: Instant::now(),
        }
    }
}
