//! Caly API — Lightweight control plane, atomic configuration hot-reloading, and Prometheus exporter.
//!
//! # Architecture
//!
//! ```text
//!  ┌──────────────────────────────────────────────────────────┐
//!  │  server     Embedded HTTP API server & route dispatcher  │
//!  ├──────────────────────────────────────────────────────────┤
//!  │  state      ArcSwap<Epoch> lock-free state & reload      │
//!  ├──────────────────────────────────────────────────────────┤
//!  │  metrics    Prometheus text exporter formatting          │
//!  └──────────────────────────────────────────────────────────┘
//! ```

pub mod metrics;
pub mod server;
pub mod state;

pub use metrics::PrometheusMetrics;
pub use server::{handle_http_request, run_api_server, HttpResponse};
pub use state::{AppState, Epoch};
