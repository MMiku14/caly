//! Zero-overhead text format Prometheus exporter.

use std::sync::atomic::{AtomicU64, Ordering};
use std::time::Instant;

pub struct PrometheusMetrics {
    pub active_connections: AtomicU64,
    pub total_connections: AtomicU64,
    pub bytes_in_total: AtomicU64,
    pub bytes_out_total: AtomicU64,
    pub dns_queries_total: AtomicU64,
    pub dns_cache_hits: AtomicU64,
    start_time: Instant,
}

impl Default for PrometheusMetrics {
    fn default() -> Self { Self::new() }
}

impl PrometheusMetrics {
    #[must_use]
    pub fn new() -> Self {
        Self {
            active_connections: AtomicU64::new(0),
            total_connections: AtomicU64::new(0),
            bytes_in_total: AtomicU64::new(0),
            bytes_out_total: AtomicU64::new(0),
            dns_queries_total: AtomicU64::new(0),
            dns_cache_hits: AtomicU64::new(0),
            start_time: Instant::now(),
        }
    }

    #[must_use]
    pub fn render_prometheus(&self) -> String {
        let uptime = self.start_time.elapsed().as_secs();
        let active = self.active_connections.load(Ordering::Relaxed);
        let total = self.total_connections.load(Ordering::Relaxed);
        let bytes_in = self.bytes_in_total.load(Ordering::Relaxed);
        let bytes_out = self.bytes_out_total.load(Ordering::Relaxed);
        let dns_queries = self.dns_queries_total.load(Ordering::Relaxed);
        let dns_hits = self.dns_cache_hits.load(Ordering::Relaxed);

        format!(
            "# HELP caly_uptime_seconds Process uptime in seconds\n             # TYPE caly_uptime_seconds gauge\n             caly_uptime_seconds {uptime}\n             # HELP caly_active_connections Current active in-flight proxy connections\n             # TYPE caly_active_connections gauge\n             caly_active_connections {active}\n             # HELP caly_total_connections Cumulative handled proxy connections\n             # TYPE caly_total_connections counter\n             caly_total_connections {total}\n             # HELP caly_bytes_in_total Cumulative ingress bytes\n             # TYPE caly_bytes_in_total counter\n             caly_bytes_in_total {bytes_in}\n             # HELP caly_bytes_out_total Cumulative egress bytes\n             # TYPE caly_bytes_out_total counter\n             caly_bytes_out_total {bytes_out}\n             # HELP caly_dns_queries_total Cumulative DNS queries resolved\n             # TYPE caly_dns_queries_total counter\n             caly_dns_queries_total {dns_queries}\n             # HELP caly_dns_cache_hits_total Cumulative DNS cache hit count\n             # TYPE caly_dns_cache_hits_total counter\n             caly_dns_cache_hits_total {dns_hits}\n"
        )
    }
}
