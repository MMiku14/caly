use caly_api::metrics::PrometheusMetrics;

#[test]
fn test_render_prometheus() {
    let m = PrometheusMetrics::new();
    m.active_connections.store(42, std::sync::atomic::Ordering::Relaxed);
    let output = m.render_prometheus();
    assert!(output.contains("caly_active_connections 42"));
    assert!(output.contains("caly_uptime_seconds"));
}
