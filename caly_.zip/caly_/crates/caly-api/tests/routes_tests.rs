use caly_api::metrics::PrometheusMetrics;
use caly_api::server::handle_http_request;
use caly_api::state::{AppState, Epoch};
use caly_dns::Config as DnsConfig;
use caly_dns::DnsResolver;
use caly_rules::RuleEngine;
use std::collections::HashMap;
use std::sync::Arc;

#[test]
fn test_api_health_endpoint() {
    let dns_cfg = DnsConfig::from_json(r#"{"servers":[{"tag":"local","address":"127.0.0.1:53"}],"final_tag":"local"}"#).unwrap();
    let dns = Arc::new(DnsResolver::from_config(&dns_cfg).unwrap());
    let rules = Arc::new(RuleEngine::new(vec![], "direct"));
    let outbounds = Arc::new(HashMap::new());
    let epoch = Epoch::new(1, rules, dns, outbounds);
    let state = Arc::new(AppState::new(epoch, Arc::new(PrometheusMetrics::new())));

    let res = handle_http_request(&state, "GET", "/health");
    assert_eq!(res.status_code, 200);
    assert!(res.body.contains("status"));
}
