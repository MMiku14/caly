use criterion::{criterion_group, criterion_main, Criterion};
use caly_session::sniff::sniff_protocol;
use std::hint::black_box;

fn bench_sniff_http(c: &mut Criterion) {
    let req = b"GET /api/v1 HTTP/1.1\r\nHost: example.org\r\nUser-Agent: test\r\n\r\n";
    c.bench_function("sniff/http", |b| {
        b.iter(|| {
            let res = sniff_protocol(black_box(req));
            black_box(res.protocol)
        })
    });
}

criterion_group!(benches, bench_sniff_http);
criterion_main!(benches);
