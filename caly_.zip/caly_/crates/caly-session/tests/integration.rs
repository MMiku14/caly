use caly_common::metadata::{Network, SessionMetadata};
use caly_session::pipeline::MetadataEnrichmentPipeline;
use caly_session::process::{InboundMode, ProcessResolver};
use smol_str::SmolStr;
use std::sync::Arc;

#[test]
fn test_pipeline_without_dns_sniffs_payload() {
    let resolver = Arc::new(ProcessResolver::default());
    let pipeline = MetadataEnrichmentPipeline::new(None, resolver);

    let mut meta = SessionMetadata::new(
        "127.0.0.1:12345".parse().unwrap(),
        "10.0.0.1:80".parse().unwrap(),
        Network::Tcp,
        SmolStr::new("http-in"),
    );

    let payload = b"GET /index.html HTTP/1.1\r\nHost: my-site.org\r\n\r\n";
    pipeline.enrich(&mut meta, InboundMode::Auto, "127.0.0.1:8080".parse().unwrap(), payload);

    assert_eq!(meta.domain.as_str(), "my-site.org");
}
