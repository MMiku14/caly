use caly_session::guard::{ConnectionGuard, SessionMetricsTracker};
use std::sync::Arc;

#[test]
fn test_connection_guard_raii_metrics() {
    let tracker = Arc::new(SessionMetricsTracker::new());
    assert_eq!(tracker.active_connections.get(), 0);
    assert_eq!(tracker.total_connections.get(), 0);

    {
        let _guard = ConnectionGuard::new(100, Arc::clone(&tracker));
        assert_eq!(tracker.active_connections.get(), 1);
        assert_eq!(tracker.total_connections.get(), 1);
    }

    assert_eq!(tracker.active_connections.get(), 0);
    assert_eq!(tracker.total_connections.get(), 1);
}
