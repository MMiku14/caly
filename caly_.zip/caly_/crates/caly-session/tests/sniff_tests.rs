use caly_common::metadata::SniffedProtocol;
use caly_session::sniff::sniff_protocol;

#[test]
fn test_sniff_http1_host() {
    let req = b"GET / HTTP/1.1\r\nHost: api.github.com\r\nUser-Agent: curl\r\n\r\n";
    let res = sniff_protocol(req);
    assert_eq!(res.protocol, SniffedProtocol::Http);
    assert_eq!(res.domain.as_deref(), Some("api.github.com"));
}

#[test]
fn test_sniff_bittorrent() {
    let req = b"\x13BitTorrent protocol\x00\x00\x00\x00\x00\x00\x00\x00";
    let res = sniff_protocol(req);
    assert_eq!(res.protocol, SniffedProtocol::BitTorrent);
}
