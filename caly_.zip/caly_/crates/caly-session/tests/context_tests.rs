use caly_common::metadata::{Network, SessionMetadata};
use caly_session::context::{SessionContext, SessionStats};
use smol_str::SmolStr;

#[test]
fn test_session_stats_atomic_traffic() {
    let stats = SessionStats::new();
    stats.add_rx(1024);
    stats.add_tx(2048);
    assert_eq!(stats.bytes_rx(), 1024);
    assert_eq!(stats.bytes_tx(), 2048);
    assert_eq!(stats.packets_rx(), 1);
    assert_eq!(stats.packets_tx(), 1);
}

#[test]
fn test_session_context_creation() {
    let meta = SessionMetadata::new(
        "127.0.0.1:1000".parse().unwrap(),
        "1.1.1.1:80".parse().unwrap(),
        Network::Tcp,
        SmolStr::new("socks-in"),
    );
    let ctx = SessionContext::new(1, meta, SmolStr::new("socks-in"));
    assert_eq!(ctx.id, 1);
}
