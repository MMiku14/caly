//! Lock-free session traffic and packet statistics.

use std::sync::atomic::{AtomicU64, Ordering};

#[derive(Debug, Default)]
pub struct SessionStats {
    bytes_rx: AtomicU64,
    bytes_tx: AtomicU64,
    packets_rx: AtomicU64,
    packets_tx: AtomicU64,
}

impl SessionStats {
    #[must_use]
    pub fn new() -> Self {
        Self::default()
    }

    #[inline]
    pub fn add_rx(&self, bytes: u64) {
        self.bytes_rx.fetch_add(bytes, Ordering::Relaxed);
        self.packets_rx.fetch_add(1, Ordering::Relaxed);
    }

    #[inline]
    pub fn add_tx(&self, bytes: u64) {
        self.bytes_tx.fetch_add(bytes, Ordering::Relaxed);
        self.packets_tx.fetch_add(1, Ordering::Relaxed);
    }

    #[inline]
    pub fn add_traffic(&self, rx: u64, tx: u64) {
        self.bytes_rx.fetch_add(rx, Ordering::Relaxed);
        self.bytes_tx.fetch_add(tx, Ordering::Relaxed);
    }

    #[must_use]
    pub fn bytes_rx(&self) -> u64 {
        self.bytes_rx.load(Ordering::Relaxed)
    }

    #[must_use]
    pub fn bytes_tx(&self) -> u64 {
        self.bytes_tx.load(Ordering::Relaxed)
    }

    #[must_use]
    pub fn packets_rx(&self) -> u64 {
        self.packets_rx.load(Ordering::Relaxed)
    }

    #[must_use]
    pub fn packets_tx(&self) -> u64 {
        self.packets_tx.load(Ordering::Relaxed)
    }
}
