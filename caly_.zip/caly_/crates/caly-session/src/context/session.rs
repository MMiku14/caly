//! SessionContext data representation.

use crate::context::stats::SessionStats;
use caly_common::metadata::SessionMetadata;
use smol_str::SmolStr;
use std::time::Instant;

pub struct SessionContext {
    pub id: u64,
    pub metadata: SessionMetadata,
    pub inbound_tag: SmolStr,
    pub outbound_tag: Option<SmolStr>,
    pub stats: SessionStats,
    pub created_at: Instant,
}

impl SessionContext {
    #[must_use]
    pub fn new(id: u64, metadata: SessionMetadata, inbound_tag: SmolStr) -> Self {
        Self {
            id,
            metadata,
            inbound_tag,
            outbound_tag: None,
            stats: SessionStats::new(),
            created_at: Instant::now(),
        }
    }
}
