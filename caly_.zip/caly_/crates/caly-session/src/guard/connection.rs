//! RAII connection guard with automatic Prometheus histogram injection on drop.

use crate::guard::tracker::SessionMetricsTracker;
use std::sync::atomic::Ordering;
use std::sync::Arc;
use std::time::Instant;

pub struct ConnectionGuard {
    pub session_id: u64,
    metrics: Arc<SessionMetricsTracker>,
    created_at: Instant,
}

impl ConnectionGuard {
    #[must_use]
    pub fn new(session_id: u64, metrics: Arc<SessionMetricsTracker>) -> Self {
        metrics.active_connections.inc();
        metrics.total_connections.inc();
        Self {
            session_id,
            metrics,
            created_at: Instant::now(),
        }
    }
}

impl Drop for ConnectionGuard {
    fn drop(&mut self) {
        self.metrics.active_connections.value.fetch_sub(1, Ordering::Relaxed);
        let elapsed_secs = self.created_at.elapsed().as_secs_f64();
        self.metrics.session_duration.observe(elapsed_secs);
    }
}
