//! Global session metrics tracker.

use caly_common::metrics::{AlignedCounter, Histogram, SESSION_DURATION_SECONDS};

pub struct SessionMetricsTracker {
    pub active_connections: AlignedCounter,
    pub total_connections: AlignedCounter,
    pub session_duration: Histogram,
}

impl Default for SessionMetricsTracker {
    fn default() -> Self {
        Self::new()
    }
}

impl SessionMetricsTracker {
    #[must_use]
    pub fn new() -> Self {
        Self {
            active_connections: AlignedCounter::new(0),
            total_connections: AlignedCounter::new(0),
            session_duration: Histogram::new(SESSION_DURATION_SECONDS),
        }
    }
}
