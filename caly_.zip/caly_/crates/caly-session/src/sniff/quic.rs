//! QUIC Initial packet sniffer.

use smol_str::SmolStr;

pub fn sniff_quic_initial(buf: &[u8]) -> Option<SmolStr> {
    if buf.len() < 5 { return None; }
    let first = buf[0];
    if (first & 0x80) == 0 || (first & 0x40) == 0 {
        return None; // Not Long Header or Fixed bit 0
    }
    let packet_type = (first & 0x30) >> 4;
    if packet_type != 0x00 { // 0x00 = Initial
        return None;
    }
    // QUIC Initial confirmed
    None
}
