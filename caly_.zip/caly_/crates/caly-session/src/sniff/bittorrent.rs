//! BitTorrent handshake sniffer.

const BITTORRENT_HEADER: &[u8] = b"\x13BitTorrent protocol";

pub fn is_bittorrent(buf: &[u8]) -> bool {
    buf.starts_with(BITTORRENT_HEADER)
}
