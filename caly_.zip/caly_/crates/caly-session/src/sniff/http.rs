//! Zero-copy HTTP/1.x and HTTP/2 sniffer.

use smol_str::SmolStr;

const HTTP2_PREFACE: &[u8] = b"PRI * HTTP/2.0\r\n\r\nSM\r\n\r\n";

pub fn is_http2_preamble(buf: &[u8]) -> bool {
    buf.starts_with(HTTP2_PREFACE)
}

pub fn sniff_http1_host(buf: &[u8]) -> Option<SmolStr> {
    let header_end = buf.windows(4).position(|w| w == b"\r\n\r\n")?;
    let header_bytes = &buf[..header_end];
    let header_str = std::str::from_utf8(header_bytes).ok()?;

    for line in header_str.lines().skip(1) {
        if let Some(colon) = line.find(':') {
            let name = line[..colon].trim();
            if name.eq_ignore_ascii_case("Host") {
                let value = line[colon + 1..].trim();
                let host = if let Some(c) = value.rfind(':') {
                    if !value.contains(']') { &value[..c] } else { value }
                } else {
                    value
                };
                return Some(SmolStr::new(host.to_ascii_lowercase()));
            }
        }
    }
    None
}
