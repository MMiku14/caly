//! Unified protocol sniffer.

use crate::sniff::bittorrent::is_bittorrent;
use crate::sniff::http::{is_http2_preamble, sniff_http1_host};
use crate::sniff::quic::sniff_quic_initial;
use crate::sniff::tls::sniff_tls_client_hello;
use caly_common::metadata::SniffedProtocol;
use smol_str::SmolStr;

pub struct SniffResult {
    pub protocol: SniffedProtocol,
    pub domain: Option<SmolStr>,
    pub alpn: Option<SmolStr>,
}

pub fn sniff_protocol(buf: &[u8]) -> SniffResult {
    if is_bittorrent(buf) {
        return SniffResult {
            protocol: SniffedProtocol::BitTorrent,
            domain: None,
            alpn: None,
        };
    }

    if let Some((sni, alpn)) = sniff_tls_client_hello(buf) {
        return SniffResult {
            protocol: SniffedProtocol::Tls,
            domain: Some(sni),
            alpn,
        };
    }

    if is_http2_preamble(buf) {
        return SniffResult {
            protocol: SniffedProtocol::Http,
            domain: None,
            alpn: Some(SmolStr::new("h2")),
        };
    }

    if let Some(host) = sniff_http1_host(buf) {
        return SniffResult {
            protocol: SniffedProtocol::Http,
            domain: Some(host),
            alpn: Some(SmolStr::new("http/1.1")),
        };
    }

    if let Some(sni) = sniff_quic_initial(buf) {
        return SniffResult {
            protocol: SniffedProtocol::Quic,
            domain: Some(sni),
            alpn: None,
        };
    }

    SniffResult {
        protocol: SniffedProtocol::Unknown,
        domain: None,
        alpn: None,
    }
}
