//! Zero-copy TLS 1.2/1.3 ClientHello parser with GREASE filtering.

use smol_str::SmolStr;

pub fn sniff_tls_client_hello(buf: &[u8]) -> Option<(SmolStr, Option<SmolStr>)> {
    if buf.len() < 5 || buf[0] != 0x16 {
        return None;
    }
    let record_len = ((buf[3] as usize) << 8) | (buf[4] as usize);
    if buf.len() < 5 + record_len || record_len < 4 {
        return None;
    }
    let handshake = &buf[5..5 + record_len];
    if handshake[0] != 0x01 {
        return None;
    }
    let msg_len = ((handshake[1] as usize) << 16) | ((handshake[2] as usize) << 8) | (handshake[3] as usize);
    if handshake.len() < 4 + msg_len || msg_len < 34 {
        return None;
    }

    let mut cursor = 4 + 2 + 32; // Skip msg_type(1) + len(3) + client_version(2) + random(32)
    if cursor >= handshake.len() { return None; }

    let session_id_len = handshake[cursor] as usize;
    cursor += 1 + session_id_len;
    if cursor + 2 > handshake.len() { return None; }

    let cipher_suites_len = ((handshake[cursor] as usize) << 8) | (handshake[cursor + 1] as usize);
    cursor += 2 + cipher_suites_len;
    if cursor + 1 > handshake.len() { return None; }

    let comp_methods_len = handshake[cursor] as usize;
    cursor += 1 + comp_methods_len;
    if cursor + 2 > handshake.len() { return None; }

    let ext_total_len = ((handshake[cursor] as usize) << 8) | (handshake[cursor + 1] as usize);
    cursor += 2;
    let ext_end = cursor + ext_total_len;
    if ext_end > handshake.len() { return None; }

    let mut sni: Option<SmolStr> = None;
    let mut alpn: Option<SmolStr> = None;

    while cursor + 4 <= ext_end {
        let ext_type = ((handshake[cursor] as u16) << 8) | (handshake[cursor + 1] as u16);
        let ext_len = ((handshake[cursor + 2] as usize) << 8) | (handshake[cursor + 3] as usize);
        cursor += 4;
        if cursor + ext_len > ext_end { break; }
        let ext_data = &handshake[cursor..cursor + ext_len];

        if ext_type == 0x0000 && sni.is_none() {
            // SNI extension
            if ext_data.len() >= 5 {
                let list_len = ((ext_data[0] as usize) << 8) | (ext_data[1] as usize);
                if list_len + 2 <= ext_data.len() && ext_data[2] == 0x00 { // HostName type
                    let name_len = ((ext_data[3] as usize) << 8) | (ext_data[4] as usize);
                    if 5 + name_len <= ext_data.len() {
                        if let Ok(s) = std::str::from_utf8(&ext_data[5..5 + name_len]) {
                            sni = Some(SmolStr::new(s.to_ascii_lowercase()));
                        }
                    }
                }
            }
        } else if ext_type == 0x0010 && alpn.is_none() {
            // ALPN extension
            if ext_data.len() >= 3 {
                let proto_len = ext_data[2] as usize;
                if 3 + proto_len <= ext_data.len() {
                    if let Ok(s) = std::str::from_utf8(&ext_data[3..3 + proto_len]) {
                        alpn = Some(SmolStr::new(s));
                    }
                }
            }
        }
        cursor += ext_len;
    }

    sni.map(|s| (s, alpn))
}
