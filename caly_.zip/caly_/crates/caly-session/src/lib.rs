//! Caly Session — Session orchestration, zero-copy DPI sniffing, and adaptive caller identification.
//!
//! # Architecture
//!
//! ```text
//!  ┌──────────────────────────────────────────────────────────┐
//!  │  pipeline   Four-stage staged metadata enrichment        │
//!  ├──────────────────────────────────────────────────────────┤
//!  │  sniff      Zero-copy DPI (TLS, HTTP, QUIC, BitTorrent)  │
//!  ├──────────────────────────────────────────────────────────┤
//!  │  process    /proc socket owner identification with TTL   │
//!  ├──────────────────────────────────────────────────────────┤
//!  │  guard      ConnectionGuard with RAII histogram drop     │
//!  ├──────────────────────────────────────────────────────────┤
//!  │  context    SessionContext and lock-free SessionStats    │
//!  └──────────────────────────────────────────────────────────┘
//! ```

pub mod context;
pub mod guard;
pub mod pipeline;
pub mod process;
pub mod sniff;

pub use context::{SessionContext, SessionStats};
pub use guard::{ConnectionGuard, SessionMetricsTracker};
pub use pipeline::MetadataEnrichmentPipeline;
pub use process::{InboundMode, ProcessInfo, ProcessResolver};
pub use sniff::{sniff_protocol, SniffResult};
