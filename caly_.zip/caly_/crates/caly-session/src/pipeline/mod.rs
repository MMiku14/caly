//! Staged metadata enrichment pipeline.

pub mod enrichment;
pub use enrichment::MetadataEnrichmentPipeline;
