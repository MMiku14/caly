//! Staged metadata enrichment pipeline.

use crate::process::resolver::{InboundMode, ProcessResolver};
use crate::sniff::engine::sniff_protocol;
use caly_common::dns::DnsResolver;
use caly_common::metadata::SessionMetadata;
use std::net::SocketAddr;
use std::sync::Arc;

pub struct MetadataEnrichmentPipeline {
    dns: Option<Arc<dyn DnsResolver>>,
    process_resolver: Arc<ProcessResolver>,
}

impl MetadataEnrichmentPipeline {
    #[must_use]
    pub fn new(dns: Option<Arc<dyn DnsResolver>>, process_resolver: Arc<ProcessResolver>) -> Self {
        Self {
            dns,
            process_resolver,
        }
    }

    pub fn enrich(
        &self,
        meta: &mut SessionMetadata,
        mode: InboundMode,
        listener_addr: SocketAddr,
        first_payload: &[u8],
    ) {
        // Stage 1: FakeIP reverse restoration
        if !meta.has_domain() {
            if let Some(ref dns) = self.dns {
                if let Some(domain) = dns.lookup_fakeip(meta.dst_addr.ip()) {
                    meta.set_domain_with_source(domain.as_str(), 1);
                }
            }
        }

        // Stage 2: DNS Snooping reverse restoration
        if !meta.has_domain() {
            if let Some(ref dns) = self.dns {
                if let Some(domain) = dns.snoop(meta.dst_addr.ip()) {
                    meta.set_domain_with_source(domain.as_str(), 2);
                }
            }
        }

        // Stage 3: Zero-copy DPI sniffing
        if !first_payload.is_empty() {
            let sniff_res = sniff_protocol(first_payload);
            meta.protocol = sniff_res.protocol;
            if !meta.has_domain() {
                if let Some(domain) = sniff_res.domain {
                    meta.set_domain_with_source(domain.as_str(), 3);
                }
            }
        }

        // Stage 4: Process and caller identification
        if let Some(proc_info) = self.process_resolver.resolve(
            mode,
            meta.src_addr,
            meta.dst_addr,
            listener_addr,
        ) {
            meta.pid = Some(proc_info.pid);
            meta.set_process_name(proc_info.process_name.as_str());
            meta.set_process_path(proc_info.process_path.as_str());
            meta.user_id = Some(proc_info.user_id);
        }
    }
}
