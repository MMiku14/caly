//! Process metadata readers from /proc/[pid].

use smol_str::SmolStr;
use std::fs;
use std::path::PathBuf;

#[derive(Debug, Clone)]
pub struct ProcessInfo {
    pub pid: u32,
    pub process_name: SmolStr,
    pub process_path: SmolStr,
    pub user_id: u32,
}

pub fn read_process_info(pid: u32) -> Option<ProcessInfo> {
    let pid_dir = PathBuf::from(format!("/proc/{pid}"));
    let comm_path = pid_dir.join("comm");
    let process_name = fs::read_to_string(comm_path)
        .ok()
        .map(|s| SmolStr::new(s.trim()))?;

    let exe_path = pid_dir.join("exe");
    let mut exe_target = fs::read_link(exe_path)
        .ok()
        .and_then(|p| p.into_os_string().into_string().ok())
        .map(SmolStr::new)?;

    if exe_target.ends_with(" (deleted)") {
        exe_target = SmolStr::new(&exe_target[..exe_target.len() - 10]);
    }

    let status_path = pid_dir.join("status");
    let mut user_id = 0u32;
    if let Ok(content) = fs::read_to_string(status_path) {
        for line in content.lines() {
            if line.starts_with("Uid:") {
                let parts: Vec<&str> = line.split_whitespace().collect();
                if parts.len() > 1 {
                    user_id = parts[1].parse().unwrap_or(0);
                }
                break;
            }
        }
    }

    Some(ProcessInfo {
        pid,
        process_name,
        process_path: exe_target,
        user_id,
    })
}
