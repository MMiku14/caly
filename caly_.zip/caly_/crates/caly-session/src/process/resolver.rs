//! Adaptive process resolver with bounded TTL cache.

use crate::process::fd_scanner::find_pid_by_socket_inode;
use crate::process::lookup::lookup_socket_inode;
use crate::process::metadata::{read_process_info, ProcessInfo};
use dashmap::DashMap;
use std::net::SocketAddr;
use std::time::{Duration, Instant};

#[derive(Hash, PartialEq, Eq)]
struct SocketPairKey {
    src: SocketAddr,
    dst: SocketAddr,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum InboundMode {
    Auto,
    Tproxy,
}

pub struct ProcessResolver {
    cache: DashMap<SocketPairKey, (ProcessInfo, Instant)>,
    ttl: Duration,
}

impl Default for ProcessResolver {
    fn default() -> Self {
        Self::new(Duration::from_secs(3))
    }
}

impl ProcessResolver {
    #[must_use]
    pub fn new(ttl: Duration) -> Self {
        Self {
            cache: DashMap::with_capacity(1024),
            ttl,
        }
    }

    pub fn resolve(
        &self,
        mode: InboundMode,
        client: SocketAddr,
        target: SocketAddr,
        listener: SocketAddr,
    ) -> Option<ProcessInfo> {
        let (query_src, query_dst) = match mode {
            InboundMode::Tproxy => (client, target),
            InboundMode::Auto => (client, listener),
        };
        let key = SocketPairKey { src: query_src, dst: query_dst };
        let now = Instant::now();

        if let Some(entry) = self.cache.get(&key) {
            if now.duration_since(entry.1) < self.ttl {
                return Some(entry.0.clone());
            }
        }

        #[cfg(target_os = "linux")]
        {
            if let Some(inode) = lookup_socket_inode(query_src, query_dst) {
                if let Some(pid) = find_pid_by_socket_inode(inode) {
                    if let Some(info) = read_process_info(pid) {
                        self.cache.insert(key, (info.clone(), now));
                        return Some(info);
                    }
                }
            }
        }

        None
    }
}
