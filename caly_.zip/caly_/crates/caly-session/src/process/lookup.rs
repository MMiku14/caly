//! Linux /proc/net/tcp & tcp6 socket inode parser.

use std::fs::File;
use std::io::{BufRead, BufReader};
use std::net::{IpAddr, Ipv4Addr, Ipv6Addr, SocketAddr};

pub fn lookup_socket_inode(src: SocketAddr, dst: SocketAddr) -> Option<u64> {
    let path = if src.is_ipv6() { "/proc/net/tcp6" } else { "/proc/net/tcp" };
    let file = File::open(path).ok()?;
    let reader = BufReader::new(file);

    let src_hex = format_addr_hex(src);
    let dst_hex = format_addr_hex(dst);

    for line in reader.lines().skip(1).flatten() {
        let fields: Vec<&str> = line.split_whitespace().collect();
        if fields.len() > 9 {
            if fields[1] == src_hex && fields[2] == dst_hex {
                return fields[9].parse::<u64>().ok();
            }
        }
    }
    None
}

fn format_addr_hex(addr: SocketAddr) -> String {
    match addr.ip() {
        IpAddr::V4(v4) => {
            let ip_u32 = u32::from(v4).to_be();
            format!("{:08X}:{:04X}", ip_u32, addr.port())
        }
        IpAddr::V6(v6) => {
            let s = v6.segments();
            format!(
                "{:04X}{:04X}{:04X}{:04X}{:04X}{:04X}{:04X}{:04X}:{:04X}",
                s[0], s[1], s[2], s[3], s[4], s[5], s[6], s[7], addr.port()
            )
        }
    }
}
