//! Process identification and caller resolution.

pub mod fd_scanner;
pub mod lookup;
pub mod metadata;
pub mod resolver;

pub use metadata::ProcessInfo;
pub use resolver::{InboundMode, ProcessResolver};
