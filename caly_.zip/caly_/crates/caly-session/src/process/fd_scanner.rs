//! Scans /proc/[pid]/fd to associate socket inodes with PID.

use std::fs;

pub fn find_pid_by_socket_inode(target_inode: u64) -> Option<u32> {
    let proc_dir = fs::read_dir("/proc").ok()?;
    let target_link = format!("socket:[{target_inode}]");

    for entry in proc_dir.flatten() {
        if let Ok(file_name) = entry.file_name().into_string() {
            if let Ok(pid) = file_name.parse::<u32>() {
                let fd_dir = entry.path().join("fd");
                if let Ok(fds) = fs::read_dir(fd_dir) {
                    for fd_entry in fds.flatten() {
                        if let Ok(link) = fs::read_link(fd_entry.path()) {
                            if link.to_str() == Some(&target_link) {
                                return Some(pid);
                            }
                        }
                    }
                }
            }
        }
    }
    None
}
