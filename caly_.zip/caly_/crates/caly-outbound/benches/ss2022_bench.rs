use criterion::{criterion_group, criterion_main, Criterion};
use caly_outbound::shadowsocks::encode_ss2022_handshake;
use std::hint::black_box;

fn bench_ss2022_handshake(c: &mut Criterion) {
    let psk = [0x33; 32];
    let target = "1.1.1.1:443".parse().unwrap();
    let payload = b"GET / HTTP/1.1\r\n\r\n";

    c.bench_function("ss2022/handshake_encode", |b| {
        b.iter(|| {
            let res = encode_ss2022_handshake(black_box(&psk), black_box(Some("apple.com")), black_box(target), black_box(payload), 0);
            black_box(res.unwrap())
        })
    });
}

criterion_group!(benches, bench_ss2022_handshake);
criterion_main!(benches);
