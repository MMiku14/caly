//! SIP022 AEAD handshake encoding.

use aes_gcm::aead::Aead;
use aes_gcm::{Aes256Gcm, KeyInit};
use blake3::Hasher;
use rand::RngCore;
use std::net::{IpAddr, SocketAddr};
use thiserror::Error;

#[derive(Error, Debug)]
pub enum Ss2022Error {
    #[error("Crypto initialization failed")]
    CryptoInit,
    #[error("AEAD encryption failed")]
    EncryptionFailed,
}

pub fn encode_ss2022_handshake(
    psk: &[u8; 32],
    target_domain: Option<&str>,
    target_addr: SocketAddr,
    initial_payload: &[u8],
    padding_len: usize,
) -> Result<Vec<u8>, Ss2022Error> {
    let mut salt = [0u8; 32];
    rand::thread_rng().fill_bytes(&mut salt);

    let mut key_material = Vec::with_capacity(64);
    key_material.extend_from_slice(psk);
    key_material.extend_from_slice(&salt);
    let mut hasher = Hasher::new_keyed(psk);
    hasher.update(&key_material);
    let subkey = hasher.finalize();

    let cipher = Aes256Gcm::new_from_slice(subkey.as_bytes()).map_err(|_| Ss2022Error::CryptoInit)?;

    let mut var_header = Vec::with_capacity(128 + padding_len + initial_payload.len());
    if let Some(domain) = target_domain {
        var_header.push(0x03);
        let d_bytes = domain.as_bytes();
        var_header.push(d_bytes.len() as u8);
        var_header.extend_from_slice(d_bytes);
        var_header.extend_from_slice(&target_addr.port().to_be_bytes());
    } else {
        match target_addr.ip() {
            IpAddr::V4(v4) => {
                var_header.push(0x01);
                var_header.extend_from_slice(&v4.octets());
                var_header.extend_from_slice(&target_addr.port().to_be_bytes());
            }
            IpAddr::V6(v6) => {
                var_header.push(0x04);
                var_header.extend_from_slice(&v6.octets());
                var_header.extend_from_slice(&target_addr.port().to_be_bytes());
            }
        }
    }

    var_header.extend_from_slice(&(padding_len as u16).to_be_bytes());
    if padding_len > 0 {
        let pad_start = var_header.len();
        var_header.resize(pad_start + padding_len, 0);
        rand::thread_rng().fill_bytes(&mut var_header[pad_start..]);
    }
    var_header.extend_from_slice(initial_payload);

    let now = std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).unwrap().as_secs();
    let mut fixed_header = [0u8; 11];
    fixed_header[0] = 0x00;
    fixed_header[1..9].copy_from_slice(&now.to_be_bytes());
    fixed_header[9..11].copy_from_slice(&(var_header.len() as u16).to_be_bytes());

    let nonce_0 = [0u8; 12];
    let enc_fixed = cipher.encrypt((&nonce_0).into(), fixed_header.as_ref())
        .map_err(|_| Ss2022Error::EncryptionFailed)?;

    let mut nonce_1 = [0u8; 12];
    nonce_1[0] = 1;
    let enc_var = cipher.encrypt((&nonce_1).into(), var_header.as_ref())
        .map_err(|_| Ss2022Error::EncryptionFailed)?;

    let mut packet = Vec::with_capacity(32 + enc_fixed.len() + enc_var.len());
    packet.extend_from_slice(&salt);
    packet.extend_from_slice(&enc_fixed);
    packet.extend_from_slice(&enc_var);
    Ok(packet)
}
