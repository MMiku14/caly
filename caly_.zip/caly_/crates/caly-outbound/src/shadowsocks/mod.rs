//! Shadowsocks 2022 implementation.

pub mod adapter;
pub mod sip022;

pub use adapter::ShadowsocksAdapter;
pub use sip022::{encode_ss2022_handshake, Ss2022Error};
