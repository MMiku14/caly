//! Shadowsocks 2022 outbound adapter.

use crate::shadowsocks::sip022::encode_ss2022_handshake;
use async_trait::async_trait;
use caly_common::adapter::ProxyAdapter;
use caly_common::error::ProxyError;
use caly_common::metadata::SessionMetadata;
use caly_common::transport::TransportStream;
use caly_transport::dialer::HappyEyeballsDialer;
use caly_transport::stream::TcpStreamLayer;
use smol_str::SmolStr;
use std::net::SocketAddr;
use std::time::Duration;
use tokio::io::AsyncWriteExt;

pub struct ShadowsocksAdapter {
    tag: SmolStr,
    server_addr: SocketAddr,
    psk: [u8; 32],
}

impl ShadowsocksAdapter {
    #[must_use]
    pub fn new(tag: &str, server_addr: SocketAddr, psk: [u8; 32]) -> Self {
        Self {
            tag: SmolStr::new(tag),
            server_addr,
            psk,
        }
    }
}

#[async_trait]
impl ProxyAdapter for ShadowsocksAdapter {
    fn tag(&self) -> &str { self.tag.as_str() }
    fn adapter_type(&self) -> &'static str { "ss2022" }
    fn resolves_locally(&self) -> bool { false }
    fn supports_udp(&self) -> bool { true }

    async fn dial(
        &self,
        metadata: &SessionMetadata,
    ) -> Result<Box<dyn TransportStream>, ProxyError> {
        let dialer = HappyEyeballsDialer::new(Duration::from_millis(250), metadata.fwmark);
        let mut stream = dialer
            .dial(&[self.server_addr.ip()], self.server_addr.port())
            .await
            .map_err(|e| ProxyError::ConnectionFailed(e.to_string()))?;

        let domain_opt = if metadata.has_domain() { Some(metadata.domain.as_str()) } else { None };
        let handshake_bytes = encode_ss2022_handshake(&self.psk, domain_opt, metadata.dst_addr, &[], 0)
            .map_err(|e| ProxyError::HandshakeFailed(e.to_string()))?;

        stream.write_all(&handshake_bytes).await
            .map_err(|e| ProxyError::HandshakeFailed(e.to_string()))?;
        stream.flush().await
            .map_err(|e| ProxyError::HandshakeFailed(e.to_string()))?;

        Ok(Box::new(TcpStreamLayer::new(stream)))
    }
}
