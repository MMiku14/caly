//! SOCKS5 client outbound adapter.

use async_trait::async_trait;
use caly_common::adapter::ProxyAdapter;
use caly_common::error::ProxyError;
use caly_common::metadata::SessionMetadata;
use caly_common::transport::TransportStream;
use caly_transport::dialer::HappyEyeballsDialer;
use caly_transport::stream::TcpStreamLayer;
use smol_str::SmolStr;
use std::net::{IpAddr, SocketAddr};
use std::time::Duration;
use tokio::io::{AsyncReadExt, AsyncWriteExt};

pub struct Socks5ClientAdapter {
    tag: SmolStr,
    server_addr: SocketAddr,
    username: Option<SmolStr>,
    password: Option<SmolStr>,
}

impl Socks5ClientAdapter {
    #[must_use]
    pub fn new(tag: &str, server_addr: SocketAddr, username: Option<&str>, password: Option<&str>) -> Self {
        Self {
            tag: SmolStr::new(tag),
            server_addr,
            username: username.map(SmolStr::new),
            password: password.map(SmolStr::new),
        }
    }
}

#[async_trait]
impl ProxyAdapter for Socks5ClientAdapter {
    fn tag(&self) -> &str { self.tag.as_str() }
    fn adapter_type(&self) -> &'static str { "socks5" }
    fn resolves_locally(&self) -> bool { false }
    fn supports_udp(&self) -> bool { false }

    async fn dial(
        &self,
        metadata: &SessionMetadata,
    ) -> Result<Box<dyn TransportStream>, ProxyError> {
        let dialer = HappyEyeballsDialer::new(Duration::from_millis(250), metadata.fwmark);
        let mut stream = dialer
            .dial(&[self.server_addr.ip()], self.server_addr.port())
            .await
            .map_err(|e| ProxyError::ConnectionFailed(e.to_string()))?;

        let has_auth = self.username.is_some() && self.password.is_some();
        if has_auth {
            stream.write_all(&[0x05, 0x02, 0x00, 0x02]).await
                .map_err(|e| ProxyError::HandshakeFailed(e.to_string()))?;
        } else {
            stream.write_all(&[0x05, 0x01, 0x00]).await
                .map_err(|e| ProxyError::HandshakeFailed(e.to_string()))?;
        }
        stream.flush().await.map_err(|e| ProxyError::HandshakeFailed(e.to_string()))?;

        let mut greeting_resp = [0u8; 2];
        stream.read_exact(&mut greeting_resp).await
            .map_err(|e| ProxyError::HandshakeFailed(e.to_string()))?;

        if greeting_resp[0] != 0x05 {
            return Err(ProxyError::HandshakeFailed("Upstream not SOCKS5".to_string()));
        }

        if greeting_resp[1] == 0x02 {
            let u = self.username.as_ref().unwrap();
            let p = self.password.as_ref().unwrap();
            let mut auth_req = Vec::with_capacity(3 + u.len() + p.len());
            auth_req.push(0x01);
            auth_req.push(u.len() as u8);
            auth_req.extend_from_slice(u.as_bytes());
            auth_req.push(p.len() as u8);
            auth_req.extend_from_slice(p.as_bytes());

            stream.write_all(&auth_req).await
                .map_err(|e| ProxyError::HandshakeFailed(e.to_string()))?;
            stream.flush().await.map_err(|e| ProxyError::HandshakeFailed(e.to_string()))?;

            let mut auth_resp = [0u8; 2];
            stream.read_exact(&mut auth_resp).await
                .map_err(|e| ProxyError::HandshakeFailed(e.to_string()))?;

            if auth_resp[1] != 0x00 {
                return Err(ProxyError::HandshakeFailed("SOCKS5 auth failed".to_string()));
            }
        } else if greeting_resp[1] != 0x00 {
            return Err(ProxyError::HandshakeFailed("Auth method rejected".to_string()));
        }

        let mut req = vec![0x05, 0x01, 0x00];
        if metadata.has_domain() {
            req.push(0x03);
            let d_bytes = metadata.domain.as_bytes();
            req.push(d_bytes.len() as u8);
            req.extend_from_slice(d_bytes);
            req.extend_from_slice(&metadata.dst_addr.port().to_be_bytes());
        } else {
            match metadata.dst_addr.ip() {
                IpAddr::V4(v4) => {
                    req.push(0x01);
                    req.extend_from_slice(&v4.octets());
                    req.extend_from_slice(&metadata.dst_addr.port().to_be_bytes());
                }
                IpAddr::V6(v6) => {
                    req.push(0x04);
                    req.extend_from_slice(&v6.octets());
                    req.extend_from_slice(&metadata.dst_addr.port().to_be_bytes());
                }
            }
        }

        stream.write_all(&req).await
            .map_err(|e| ProxyError::HandshakeFailed(e.to_string()))?;
        stream.flush().await.map_err(|e| ProxyError::HandshakeFailed(e.to_string()))?;

        let mut resp_header = [0u8; 4];
        stream.read_exact(&mut resp_header).await
            .map_err(|e| ProxyError::HandshakeFailed(e.to_string()))?;

        if resp_header[1] != 0x00 {
            return Err(ProxyError::ConnectionFailed(format!("Upstream error code: 0x{:02X}", resp_header[1])));
        }

        let bnd_addr_len = match resp_header[3] {
            0x01 => 4,
            0x04 => 16,
            0x03 => {
                let mut len_buf = [0u8; 1];
                stream.read_exact(&mut len_buf).await
                    .map_err(|e| ProxyError::HandshakeFailed(e.to_string()))?;
                len_buf[0] as usize
            }
            _ => return Err(ProxyError::HandshakeFailed("Invalid ATYP".to_string())),
        };

        let mut bnd_buf = vec![0u8; bnd_addr_len + 2];
        stream.read_exact(&mut bnd_buf).await
            .map_err(|e| ProxyError::HandshakeFailed(e.to_string()))?;

        Ok(Box::new(TcpStreamLayer::new(stream)))
    }
}
