//! SOCKS5 outbound client.

pub mod client;
pub use client::Socks5ClientAdapter;
