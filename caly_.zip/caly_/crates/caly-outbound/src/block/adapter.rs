//! Blackhole / Block outbound adapter.

use async_trait::async_trait;
use caly_common::adapter::{ProxyAdapter, UdpSessionEndpoint};
use caly_common::error::ProxyError;
use caly_common::metadata::SessionMetadata;
use caly_common::transport::TransportStream;
use smol_str::SmolStr;

pub struct BlockAdapter {
    tag: SmolStr,
}

impl Default for BlockAdapter {
    fn default() -> Self { Self::new("block") }
}

impl BlockAdapter {
    #[must_use]
    pub fn new(tag: &str) -> Self {
        Self { tag: SmolStr::new(tag) }
    }
}

#[async_trait]
impl ProxyAdapter for BlockAdapter {
    fn tag(&self) -> &str { self.tag.as_str() }
    fn adapter_type(&self) -> &'static str { "block" }
    fn resolves_locally(&self) -> bool { false }
    fn supports_udp(&self) -> bool { false }

    async fn dial(
        &self,
        _metadata: &SessionMetadata,
    ) -> Result<Box<dyn TransportStream>, ProxyError> {
        Err(ProxyError::Blocked)
    }

    async fn connect_udp(
        &self,
        _metadata: &SessionMetadata,
    ) -> Result<Box<dyn UdpSessionEndpoint>, ProxyError> {
        Err(ProxyError::Blocked)
    }
}
