//! Blackhole block adapter.

pub mod adapter;
pub use adapter::BlockAdapter;
