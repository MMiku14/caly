//! Caly Outbound — Proxy adapters (Direct, Block, SS2022, VLESS, SOCKS5 Client, Groups).
//!
//! # Architecture
//!
//! ```text
//!  ┌──────────────────────────────────────────────────────────┐
//!  │  registry    InMemoryOutboundRegistry for EpochState     │
//!  ├──────────────────────────────────────────────────────────┤
//!  │  group       Selector, URLTest, and Fallback adapters     │
//!  ├──────────────────────────────────────────────────────────┤
//!  │  vless       VLESS v0 protocol + XTLS Vision flow control │
//!  ├──────────────────────────────────────────────────────────┤
//!  │  shadowsocks Shadowsocks 2022 (SIP022) AEAD handshake    │
//!  ├──────────────────────────────────────────────────────────┤
//!  │  socks5      Remote SOCKS5 client proxy adapter          │
//!  ├──────────────────────────────────────────────────────────┤
//!  │  direct      Direct connection with Happy Eyeballs & mark│
//!  ├──────────────────────────────────────────────────────────┤
//!  │  block       Blackhole drop and immediate reject         │
//!  └──────────────────────────────────────────────────────────┘
//! ```

pub mod block;
pub mod direct;
pub mod group;
pub mod registry;
pub mod shadowsocks;
pub mod socks5;
pub mod vless;

pub use block::BlockAdapter;
pub use direct::DirectAdapter;
pub use group::{FallbackAdapter, OutboundRegistry, SelectorAdapter, UrlTestAdapter};
pub use registry::InMemoryOutboundRegistry;
pub use shadowsocks::{encode_ss2022_handshake, ShadowsocksAdapter, Ss2022Error};
pub use socks5::Socks5ClientAdapter;
pub use vless::{VlessAdapter, VlessHeader, VisionFlowController};
