//! In-memory outbound adapter registry.

use crate::group::OutboundRegistry;
use caly_common::adapter::ProxyAdapter;
use smol_str::SmolStr;
use std::collections::HashMap;
use std::sync::Arc;

#[derive(Default)]
pub struct InMemoryOutboundRegistry {
    adapters: HashMap<SmolStr, Arc<dyn ProxyAdapter>>,
}

impl InMemoryOutboundRegistry {
    #[must_use]
    pub fn new() -> Self { Self::default() }

    pub fn insert(&mut self, tag: &str, adapter: Arc<dyn ProxyAdapter>) {
        self.adapters.insert(SmolStr::new(tag), adapter);
    }

    #[must_use]
    pub fn len(&self) -> usize { self.adapters.len() }
    #[must_use]
    pub fn is_empty(&self) -> bool { self.adapters.is_empty() }
}

impl OutboundRegistry for InMemoryOutboundRegistry {
    fn get(&self, tag: &str) -> Option<Arc<dyn ProxyAdapter>> {
        self.adapters.get(tag).cloned()
    }
}
