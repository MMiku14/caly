//! Outbound adapter registry.

pub mod container;
pub use container::InMemoryOutboundRegistry;
