//! XTLS Vision (xtls-rprx-vision) flow control state machine.

pub const FLOW_VISION: &str = "xtls-rprx-vision";

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum VisionState {
    Handshake,
    Padding,
    DirectHandoff,
}

pub struct VisionFlowController {
    state: VisionState,
    remaining_padding_records: u8,
}

impl Default for VisionFlowController {
    fn default() -> Self {
        Self::new()
    }
}

impl VisionFlowController {
    #[must_use]
    pub fn new() -> Self {
        Self {
            state: VisionState::Handshake,
            remaining_padding_records: 8, // Standard XTLS Vision padding window
        }
    }

    #[must_use]
    pub fn is_handoff_ready(&self) -> bool {
        self.state == VisionState::DirectHandoff
    }

    pub fn on_inbound_data(&mut self, payload: &[u8]) {
        if self.state == VisionState::DirectHandoff {
            return;
        }

        // Detect TLS Application Data (0x17)
        if payload.len() >= 5 && payload[0] == 0x17 {
            if self.remaining_padding_records > 0 {
                self.remaining_padding_records -= 1;
            } else {
                self.state = VisionState::DirectHandoff;
            }
        }
    }
}
