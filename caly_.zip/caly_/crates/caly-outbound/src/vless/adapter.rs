//! VLESS outbound proxy adapter.

use crate::vless::protocol::VlessHeader;
use crate::vless::vision::{VisionFlowController, FLOW_VISION};
use async_trait::async_trait;
use caly_common::adapter::ProxyAdapter;
use caly_common::error::ProxyError;
use caly_common::metadata::SessionMetadata;
use caly_common::transport::TransportStream;
use caly_transport::builder::{StreamBuilder, TransportConfig};
use caly_transport::reality::RealityClientConfig;
use smol_str::SmolStr;
use std::net::SocketAddr;
use std::time::Duration;
use tokio::io::AsyncWriteExt;

pub struct VlessAdapter {
    tag: SmolStr,
    server_addr: SocketAddr,
    uuid: [u8; 16],
    flow: Option<SmolStr>,
    transport_config: TransportConfig,
}

impl VlessAdapter {
    pub fn new(
        tag: &str,
        server_addr: SocketAddr,
        uuid: [u8; 16],
        flow: Option<&str>,
        server_name: Option<&str>,
        reality_config: Option<RealityClientConfig>,
    ) -> Self {
        let is_reality = reality_config.is_some();
        let transport_config = TransportConfig {
            tls_enabled: true,
            sni: server_name.map(str::to_string),
            alpn: vec!["h2".to_string(), "http/1.1".to_string()],
            insecure: false,
            reality_enabled: is_reality,
            reality_config,
            ws_enabled: false,
            ws_path: None,
            ws_host: None,
            connection_attempt_delay: Duration::from_millis(250),
            fwmark: None,
        };

        Self {
            tag: SmolStr::new(tag),
            server_addr,
            uuid,
            flow: flow.map(SmolStr::new),
            transport_config,
        }
    }
}

#[async_trait]
impl ProxyAdapter for VlessAdapter {
    fn tag(&self) -> &str { self.tag.as_str() }
    fn adapter_type(&self) -> &'static str { "vless" }
    fn resolves_locally(&self) -> bool { false }
    fn supports_udp(&self) -> bool { true }

    async fn dial(
        &self,
        metadata: &SessionMetadata,
    ) -> Result<Box<dyn TransportStream>, ProxyError> {
        let mut cfg = self.transport_config.clone();
        cfg.fwmark = metadata.fwmark;

        let builder = StreamBuilder::new(cfg)
            .map_err(|e| ProxyError::ConnectionFailed(e.to_string()))?;

        let mut stream = builder
            .dial(self.server_addr)
            .await
            .map_err(|e| ProxyError::ConnectionFailed(e.to_string()))?;

        let domain_opt = if metadata.has_domain() { Some(metadata.domain.as_str()) } else { None };
        let header = VlessHeader::new_tcp(
            self.uuid,
            self.flow.as_deref(),
            domain_opt,
            metadata.dst_addr,
        );

        let mut header_bytes = Vec::with_capacity(128);
        header.encode(&mut header_bytes)?;

        stream.write_all(&header_bytes).await
            .map_err(|e| ProxyError::HandshakeFailed(e.to_string()))?;
        stream.flush().await
            .map_err(|e| ProxyError::HandshakeFailed(e.to_string()))?;

        Ok(Box::new(stream))
    }
}
