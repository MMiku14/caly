//! VLESS protocol outbound implementation with XTLS Vision flow.

pub mod adapter;
pub mod protocol;
pub mod vision;

pub use adapter::VlessAdapter;
pub use protocol::{VlessHeader, TargetAddress};
pub use vision::{VisionFlowController, FLOW_VISION};
