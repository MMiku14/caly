//! VLESS protocol header encoding (RFC-compliant VLESS v0).

use caly_common::addr_type::VlessAddressType;
use caly_common::error::ProxyError;
use smol_str::SmolStr;
use std::net::{IpAddr, SocketAddr};

pub const VLESS_VERSION: u8 = 0x00;
pub const VLESS_CMD_TCP: u8 = 0x01;
pub const VLESS_CMD_UDP: u8 = 0x02;

pub struct VlessHeader {
    pub uuid: [u8; 16],
    pub flow: Option<SmolStr>,
    pub command: u8,
    pub port: u16,
    pub address: TargetAddress,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum TargetAddress {
    Ipv4(std::net::Ipv4Addr),
    Ipv6(std::net::Ipv6Addr),
    Domain(SmolStr),
}

impl VlessHeader {
    pub fn new_tcp(uuid: [u8; 16], flow: Option<&str>, target_domain: Option<&str>, target_addr: SocketAddr) -> Self {
        let address = if let Some(domain) = target_domain {
            TargetAddress::Domain(SmolStr::new(domain))
        } else {
            match target_addr.ip() {
                IpAddr::V4(v4) => TargetAddress::Ipv4(v4),
                IpAddr::V6(v6) => TargetAddress::Ipv6(v6),
            }
        };

        Self {
            uuid,
            flow: flow.map(SmolStr::new),
            command: VLESS_CMD_TCP,
            port: target_addr.port(),
            address,
        }
    }

    pub fn encode(&self, out: &mut Vec<u8>) -> Result<(), ProxyError> {
        out.push(VLESS_VERSION);
        out.extend_from_slice(&self.uuid);

        // Addons length + Addons proto
        if let Some(ref flow) = self.flow {
            let flow_bytes = flow.as_bytes();
            // protobuf: tag 1 = Flow string (wire type 2: length delimited)
            // 0x0a = (1 << 3) | 2
            let mut proto_buf = Vec::with_capacity(2 + flow_bytes.len());
            proto_buf.push(0x0a);
            proto_buf.push(flow_bytes.len() as u8);
            proto_buf.extend_from_slice(flow_bytes);

            out.push(proto_buf.len() as u8);
            out.extend_from_slice(&proto_buf);
        } else {
            out.push(0x00); // 0 addons
        }

        out.push(self.command);
        out.extend_from_slice(&self.port.to_be_bytes());

        match &self.address {
            TargetAddress::Ipv4(v4) => {
                out.push(VlessAddressType::Ipv4 as u8);
                out.extend_from_slice(&v4.octets());
            }
            TargetAddress::Domain(d) => {
                out.push(VlessAddressType::Domain as u8);
                let bytes = d.as_bytes();
                if bytes.len() > 255 {
                    return Err(ProxyError::HandshakeFailed("Domain name exceeds 255 bytes".to_string()));
                }
                out.push(bytes.len() as u8);
                out.extend_from_slice(bytes);
            }
            TargetAddress::Ipv6(v6) => {
                out.push(VlessAddressType::Ipv6 as u8);
                out.extend_from_slice(&v6.octets());
            }
        }

        Ok(())
    }
}
