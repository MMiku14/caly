//! Priority ordered failover group (Fallback).

use crate::group::registry::OutboundRegistry;
use async_trait::async_trait;
use caly_common::adapter::{ProxyAdapter, UdpSessionEndpoint};
use caly_common::error::ProxyError;
use caly_common::metadata::SessionMetadata;
use caly_common::transport::TransportStream;
use parking_lot::RwLock;
use smol_str::SmolStr;
use std::collections::HashMap;
use std::sync::Arc;

pub struct FallbackAdapter {
    tag: SmolStr,
    outbounds: Vec<SmolStr>,
    failures: RwLock<HashMap<SmolStr, u32>>,
    registry: Arc<dyn OutboundRegistry>,
}

impl FallbackAdapter {
    pub fn new(tag: &str, outbounds: Vec<&str>, registry: Arc<dyn OutboundRegistry>) -> Self {
        Self {
            tag: SmolStr::new(tag),
            outbounds: outbounds.into_iter().map(SmolStr::new).collect(),
            failures: RwLock::new(HashMap::new()),
            registry,
        }
    }
}

#[async_trait]
impl ProxyAdapter for FallbackAdapter {
    fn tag(&self) -> &str { self.tag.as_str() }
    fn adapter_type(&self) -> &'static str { "fallback" }

    fn resolves_locally(&self) -> bool {
        for tag in &self.outbounds {
            if let Some(adapter) = self.registry.get(tag.as_str()) {
                return adapter.resolves_locally();
            }
        }
        false
    }

    fn supports_udp(&self) -> bool {
        for tag in &self.outbounds {
            if let Some(adapter) = self.registry.get(tag.as_str()) {
                return adapter.supports_udp();
            }
        }
        false
    }

    async fn dial(&self, metadata: &SessionMetadata) -> Result<Box<dyn TransportStream>, ProxyError> {
        let mut last_err = ProxyError::NotFound("No healthy backup outbounds".to_string());
        for tag in &self.outbounds {
            if let Some(adapter) = self.registry.get(tag.as_str()) {
                match adapter.dial(metadata).await {
                    Ok(stream) => return Ok(stream),
                    Err(e) => {
                        *self.failures.write().entry(tag.clone()).or_insert(0) += 1;
                        last_err = e;
                    }
                }
            }
        }
        Err(last_err)
    }

    async fn connect_udp(&self, metadata: &SessionMetadata) -> Result<Box<dyn UdpSessionEndpoint>, ProxyError> {
        let mut last_err = ProxyError::NotFound("No healthy backup outbounds".to_string());
        for tag in &self.outbounds {
            if let Some(adapter) = self.registry.get(tag.as_str()) {
                match adapter.connect_udp(metadata).await {
                    Ok(endpoint) => return Ok(endpoint),
                    Err(e) => { last_err = e; }
                }
            }
        }
        Err(last_err)
    }

    fn candidates(&self) -> Option<Vec<String>> {
        Some(self.outbounds.iter().map(|s| s.to_string()).collect())
    }

    fn reset_failures(&self) -> usize {
        let mut map = self.failures.write();
        let c = map.len();
        map.clear();
        c
    }
}
