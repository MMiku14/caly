//! Latency auto-selection outbound group (URLTest).

use crate::group::registry::OutboundRegistry;
use async_trait::async_trait;
use caly_common::adapter::{ProxyAdapter, UdpSessionEndpoint};
use caly_common::error::ProxyError;
use caly_common::metadata::SessionMetadata;
use caly_common::transport::TransportStream;
use parking_lot::RwLock;
use smol_str::SmolStr;
use std::collections::HashMap;
use std::sync::Arc;

pub struct UrlTestAdapter {
    tag: SmolStr,
    outbounds: Vec<SmolStr>,
    latencies: RwLock<HashMap<SmolStr, u32>>,
    registry: Arc<dyn OutboundRegistry>,
}

impl UrlTestAdapter {
    pub fn new(tag: &str, outbounds: Vec<&str>, registry: Arc<dyn OutboundRegistry>) -> Self {
        let mut latencies = HashMap::new();
        for &ob in &outbounds {
            latencies.insert(SmolStr::new(ob), u32::MAX);
        }
        Self {
            tag: SmolStr::new(tag),
            outbounds: outbounds.into_iter().map(SmolStr::new).collect(),
            latencies: RwLock::new(latencies),
            registry,
        }
    }

    pub fn record_latency(&self, candidate: &str, rtt_ms: u32) {
        let mut map = self.latencies.write();
        map.insert(SmolStr::new(candidate), rtt_ms);
    }

    fn get_best_adapter(&self) -> Result<Arc<dyn ProxyAdapter>, ProxyError> {
        if self.outbounds.is_empty() {
            return Err(ProxyError::NotFound("Empty URLTest group".to_string()));
        }

        let map = self.latencies.read();
        let mut best_tag = &self.outbounds[0];
        let mut best_rtt = u32::MAX;

        for tag in &self.outbounds {
            let rtt = map.get(tag).copied().unwrap_or(u32::MAX);
            if rtt < best_rtt {
                best_rtt = rtt;
                best_tag = tag;
            }
        }

        self.registry.get(best_tag.as_str()).ok_or_else(|| {
            ProxyError::NotFound(format!("URLTest best outbound '{best_tag}' not found"))
        })
    }
}

#[async_trait]
impl ProxyAdapter for UrlTestAdapter {
    fn tag(&self) -> &str { self.tag.as_str() }
    fn adapter_type(&self) -> &'static str { "urltest" }

    fn resolves_locally(&self) -> bool {
        self.get_best_adapter().map_or(false, |a| a.resolves_locally())
    }

    fn supports_udp(&self) -> bool {
        self.get_best_adapter().map_or(false, |a| a.supports_udp())
    }

    async fn dial(&self, metadata: &SessionMetadata) -> Result<Box<dyn TransportStream>, ProxyError> {
        self.get_best_adapter()?.dial(metadata).await
    }

    async fn connect_udp(&self, metadata: &SessionMetadata) -> Result<Box<dyn UdpSessionEndpoint>, ProxyError> {
        self.get_best_adapter()?.connect_udp(metadata).await
    }

    fn candidates(&self) -> Option<Vec<String>> {
        Some(self.outbounds.iter().map(|s| s.to_string()).collect())
    }

    fn latency_snapshot(&self) -> Vec<(String, u32)> {
        let map = self.latencies.read();
        map.iter().map(|(k, v)| (k.to_string(), *v)).collect()
    }
}
