//! Outbound adapter registry trait.

use caly_common::adapter::ProxyAdapter;
use std::sync::Arc;

pub trait OutboundRegistry: Send + Sync {
    fn get(&self, tag: &str) -> Option<Arc<dyn ProxyAdapter>>;
}
