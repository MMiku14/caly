//! Outbound adapter group strategies.

pub mod fallback;
pub mod registry;
pub mod selector;
pub mod urltest;

pub use fallback::FallbackAdapter;
pub use registry::OutboundRegistry;
pub use selector::SelectorAdapter;
pub use urltest::UrlTestAdapter;
