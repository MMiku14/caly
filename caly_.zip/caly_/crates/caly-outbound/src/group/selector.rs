//! Manual selector outbound adapter.

use crate::group::registry::OutboundRegistry;
use async_trait::async_trait;
use caly_common::adapter::{ProxyAdapter, UdpSessionEndpoint};
use caly_common::error::ProxyError;
use caly_common::metadata::SessionMetadata;
use caly_common::transport::TransportStream;
use smol_str::SmolStr;
use std::sync::atomic::{AtomicUsize, Ordering};
use std::sync::Arc;

pub struct SelectorAdapter {
    tag: SmolStr,
    outbounds: Vec<SmolStr>,
    selected_index: AtomicUsize,
    registry: Arc<dyn OutboundRegistry>,
}

impl SelectorAdapter {
    pub fn new(tag: &str, outbounds: Vec<&str>, registry: Arc<dyn OutboundRegistry>) -> Self {
        Self {
            tag: SmolStr::new(tag),
            outbounds: outbounds.into_iter().map(SmolStr::new).collect(),
            selected_index: AtomicUsize::new(0),
            registry,
        }
    }

    fn get_current_adapter(&self) -> Result<Arc<dyn ProxyAdapter>, ProxyError> {
        if self.outbounds.is_empty() {
            return Err(ProxyError::NotFound("Empty selector outbound group".to_string()));
        }
        let idx = self.selected_index.load(Ordering::Relaxed) % self.outbounds.len();
        let tag = &self.outbounds[idx];
        self.registry.get(tag.as_str()).ok_or_else(|| {
            ProxyError::NotFound(format!("Selector outbound '{tag}' not found"))
        })
    }
}

#[async_trait]
impl ProxyAdapter for SelectorAdapter {
    fn tag(&self) -> &str { self.tag.as_str() }
    fn adapter_type(&self) -> &'static str { "selector" }

    fn resolves_locally(&self) -> bool {
        self.get_current_adapter().map_or(false, |a| a.resolves_locally())
    }

    fn supports_udp(&self) -> bool {
        self.get_current_adapter().map_or(false, |a| a.supports_udp())
    }

    async fn dial(&self, metadata: &SessionMetadata) -> Result<Box<dyn TransportStream>, ProxyError> {
        self.get_current_adapter()?.dial(metadata).await
    }

    async fn connect_udp(&self, metadata: &SessionMetadata) -> Result<Box<dyn UdpSessionEndpoint>, ProxyError> {
        self.get_current_adapter()?.connect_udp(metadata).await
    }

    fn try_select(&self, candidate: &str) -> Result<(), String> {
        if let Some(pos) = self.outbounds.iter().position(|x| x.as_str() == candidate) {
            self.selected_index.store(pos, Ordering::SeqCst);
            Ok(())
        } else {
            Err(format!("Candidate '{candidate}' not found in selector '{}'", self.tag))
        }
    }

    fn candidates(&self) -> Option<Vec<String>> {
        Some(self.outbounds.iter().map(|s| s.to_string()).collect())
    }

    fn current_selection(&self) -> Option<String> {
        if self.outbounds.is_empty() { return None; }
        let idx = self.selected_index.load(Ordering::Relaxed) % self.outbounds.len();
        self.outbounds.get(idx).map(|s| s.to_string())
    }
}
