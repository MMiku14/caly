//! Direct outbound adapter with Happy Eyeballs dialer and SO_MARK injection.

use crate::direct::udp::DirectUdpEndpoint;
use async_trait::async_trait;
use caly_common::adapter::{ProxyAdapter, UdpSessionEndpoint};
use caly_common::error::ProxyError;
use caly_common::metadata::SessionMetadata;
use caly_common::transport::TransportStream;
use caly_transport::dialer::HappyEyeballsDialer;
use caly_transport::stream::TcpStreamLayer;
use smol_str::SmolStr;
use std::net::{IpAddr, SocketAddr};
use std::time::Duration;
use tokio::net::UdpSocket;

pub struct DirectAdapter {
    tag: SmolStr,
}

impl Default for DirectAdapter {
    fn default() -> Self { Self::new("direct") }
}

impl DirectAdapter {
    #[must_use]
    pub fn new(tag: &str) -> Self {
        Self { tag: SmolStr::new(tag) }
    }
}

#[async_trait]
impl ProxyAdapter for DirectAdapter {
    fn tag(&self) -> &str { self.tag.as_str() }
    fn adapter_type(&self) -> &'static str { "direct" }
    fn resolves_locally(&self) -> bool { true }
    fn supports_udp(&self) -> bool { true }

    async fn dial(
        &self,
        metadata: &SessionMetadata,
    ) -> Result<Box<dyn TransportStream>, ProxyError> {
        let dialer = HappyEyeballsDialer::new(Duration::from_millis(250), metadata.fwmark);

        let fallback_ip = [metadata.dst_addr.ip()];
        let candidates: &[IpAddr] = if !metadata.resolved_ips.is_empty() {
            metadata.resolved_ips.as_slice()
        } else {
            &fallback_ip
        };

        let stream = dialer
            .dial(candidates, metadata.dst_addr.port())
            .await
            .map_err(|e| ProxyError::ConnectionFailed(e.to_string()))?;

        Ok(Box::new(TcpStreamLayer::new(stream)))
    }

    async fn connect_udp(
        &self,
        metadata: &SessionMetadata,
    ) -> Result<Box<dyn UdpSessionEndpoint>, ProxyError> {
        let bind_addr: SocketAddr = if metadata.dst_addr.is_ipv6() {
            "[::]:0".parse().unwrap()
        } else {
            "0.0.0.0:0".parse().unwrap()
        };

        let socket = UdpSocket::bind(bind_addr)
            .await
            .map_err(|e| ProxyError::ConnectionFailed(e.to_string()))?;

        #[cfg(target_os = "linux")]
        if let Some(mark) = metadata.fwmark {
            use std::os::unix::io::AsRawFd;
            unsafe {
                let mark_int = mark as libc::c_int;
                let _ = libc::setsockopt(
                    socket.as_raw_fd(),
                    libc::SOL_SOCKET,
                    libc::SO_MARK,
                    &mark_int as *const _ as *const libc::c_void,
                    std::mem::size_of_val(&mark_int) as libc::socklen_t,
                );
            }
        }

        Ok(Box::new(DirectUdpEndpoint { socket }))
    }
}
