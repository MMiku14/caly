//! Direct UDP endpoint implementation.

use async_trait::async_trait;
use caly_common::adapter::UdpSessionEndpoint;
use std::net::SocketAddr;
use tokio::net::UdpSocket;

pub struct DirectUdpEndpoint {
    pub(crate) socket: UdpSocket,
}

#[async_trait]
impl UdpSessionEndpoint for DirectUdpEndpoint {
    async fn send_to(&self, payload: &[u8], dst: SocketAddr) -> std::io::Result<()> {
        self.socket.send_to(payload, dst).await.map(|_| ())
    }

    async fn recv_from(&self, buf: &mut [u8]) -> std::io::Result<(usize, SocketAddr)> {
        self.socket.recv_from(buf).await
    }
}
