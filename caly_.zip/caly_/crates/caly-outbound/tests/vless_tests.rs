use caly_common::adapter::ProxyAdapter;
use caly_common::addr_type::VlessAddressType;
use caly_outbound::vless::{VlessAdapter, VlessHeader};

#[test]
fn test_vless_header_atyp_alignment() {
    let uuid = [0x11; 16];
    let target = "1.1.1.1:443".parse().unwrap();
    let header = VlessHeader::new_tcp(uuid, Some("xtls-rprx-vision"), Some("example.com"), target);

    let mut buf = Vec::new();
    header.encode(&mut buf).unwrap();

    // Verify VLESS Address Type is 0x02 for Domain (not 0x03 as in SOCKS5)
    assert_eq!(VlessAddressType::Domain as u8, 0x02);
    assert_eq!(buf[0], 0x00); // Version 0
    assert_eq!(&buf[1..17], &uuid);
}

#[test]
fn test_vless_adapter_contract() {
    let adapter = VlessAdapter::new(
        "vless-out",
        "1.1.1.1:443".parse().unwrap(),
        [0u8; 16],
        Some("xtls-rprx-vision"),
        Some("example.com"),
        None,
    );
    assert_eq!(adapter.tag(), "vless-out");
    assert_eq!(adapter.adapter_type(), "vless");
    assert!(!adapter.resolves_locally());
    assert!(adapter.supports_udp());
}
