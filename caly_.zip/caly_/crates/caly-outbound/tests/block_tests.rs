use caly_common::adapter::ProxyAdapter;
use caly_common::error::ProxyError;
use caly_common::metadata::{Network, SessionMetadata};
use caly_outbound::block::BlockAdapter;
use smol_str::SmolStr;

#[tokio::test]
async fn test_block_rejection() {
    let block = BlockAdapter::new("block");
    let meta = SessionMetadata::new(
        "127.0.0.1:1000".parse().unwrap(),
        "1.1.1.1:80".parse().unwrap(),
        Network::Tcp,
        SmolStr::new("tproxy-in"),
    );
    match block.dial(&meta).await {
        Err(ProxyError::Blocked) => {}
        _ => panic!("Expected ProxyError::Blocked"),
    }
}
