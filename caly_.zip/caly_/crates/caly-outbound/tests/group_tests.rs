use caly_common::adapter::ProxyAdapter;
use caly_outbound::direct::DirectAdapter;
use caly_outbound::block::BlockAdapter;
use caly_outbound::group::{FallbackAdapter, SelectorAdapter, UrlTestAdapter};
use caly_outbound::registry::InMemoryOutboundRegistry;
use std::sync::Arc;

#[test]
fn test_selector_group() {
    let mut reg = InMemoryOutboundRegistry::new();
    reg.insert("direct", Arc::new(DirectAdapter::new("direct")));
    reg.insert("block", Arc::new(BlockAdapter::new("block")));
    let reg_arc = Arc::new(reg);

    let selector = SelectorAdapter::new("proxy", vec!["direct", "block"], reg_arc);
    assert_eq!(selector.current_selection(), Some("direct".to_string()));
    assert!(selector.try_select("block").is_ok());
    assert_eq!(selector.current_selection(), Some("block".to_string()));
}

#[test]
fn test_urltest_group() {
    let mut reg = InMemoryOutboundRegistry::new();
    reg.insert("hk", Arc::new(DirectAdapter::new("hk")));
    reg.insert("jp", Arc::new(DirectAdapter::new("jp")));
    let reg_arc = Arc::new(reg);

    let urltest = UrlTestAdapter::new("fastest", vec!["hk", "jp"], reg_arc);
    urltest.record_latency("hk", 50);
    urltest.record_latency("jp", 20);

    assert_eq!(urltest.latency_snapshot().len(), 2);
}
