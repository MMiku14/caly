use caly_outbound::shadowsocks::encode_ss2022_handshake;

#[test]
fn test_ss2022_handshake_encoding() {
    let psk = [0x55; 32];
    let target = "1.1.1.1:443".parse().unwrap();
    let packet = encode_ss2022_handshake(&psk, Some("example.com"), target, b"PING", 8).unwrap();

    assert!(packet.len() > 32 + 27);
}
