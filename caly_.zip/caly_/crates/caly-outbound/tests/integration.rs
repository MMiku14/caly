use caly_outbound::socks5::Socks5ClientAdapter;
use caly_common::adapter::ProxyAdapter;

#[test]
fn test_socks5_client_adapter_properties() {
    let client = Socks5ClientAdapter::new("upstream-socks", "127.0.0.1:1080".parse().unwrap(), None, None);
    assert_eq!(client.tag(), "upstream-socks");
    assert_eq!(client.adapter_type(), "socks5");
    assert!(!client.resolves_locally());
}
