use caly_common::adapter::ProxyAdapter;
use caly_outbound::direct::DirectAdapter;

#[test]
fn test_direct_contract() {
    let direct = DirectAdapter::new("direct");
    assert_eq!(direct.tag(), "direct");
    assert_eq!(direct.adapter_type(), "direct");
    assert!(direct.resolves_locally());
    assert!(direct.supports_udp());
}
