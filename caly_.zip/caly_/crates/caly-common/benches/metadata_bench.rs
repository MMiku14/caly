use criterion::{criterion_group, criterion_main, Criterion};
use caly_common::metadata::SessionMetadata;
use std::hint::black_box;

fn bench_metadata_domain(c: &mut Criterion) {
    let mut meta = SessionMetadata::default();
    c.bench_function("metadata/set_domain", |b| {
        b.iter(|| {
            meta.set_domain(black_box("api.github.com"));
            black_box(meta.has_domain())
        })
    });
}

criterion_group!(benches, bench_metadata_domain);
criterion_main!(benches);
