use caly_common::addr_type::{Socks5AddressType, VlessAddressType};

#[test]
fn test_atyp_differentiation() {
    assert_ne!(Socks5AddressType::Domain as u8, VlessAddressType::Domain as u8);
}
