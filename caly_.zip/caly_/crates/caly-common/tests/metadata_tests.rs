use caly_common::metadata::{Network, SessionFlags, SessionMetadata, SniffedProtocol};
use smol_str::SmolStr;
use std::net::SocketAddr;

#[test]
fn test_metadata_memory_layout_and_size() {
    assert!(std::mem::size_of::<SessionMetadata>() <= 288);
    assert_eq!(std::mem::align_of::<SessionMetadata>(), 64);
}

#[test]
fn test_metadata_domain_normalization() {
    let mut meta = SessionMetadata::default();
    meta.set_domain("  WWW.Google.COM.  ");
    assert_eq!(meta.domain.as_str(), "www.google.com");
    assert!(meta.has_domain());

    meta.set_domain("");
    assert!(!meta.has_domain());
}

#[test]
fn test_metadata_flags() {
    let mut flags = SessionFlags::EMPTY;
    assert!(!flags.contains(SessionFlags::TPROXY));
    flags.insert(SessionFlags::TPROXY);
    assert!(flags.contains(SessionFlags::TPROXY));
    flags.insert(SessionFlags::TLS_SNIFFED);
    assert!(flags.contains(SessionFlags::TPROXY));
    assert!(flags.contains(SessionFlags::TLS_SNIFFED));
    flags.remove(SessionFlags::TPROXY);
    assert!(!flags.contains(SessionFlags::TPROXY));
    assert!(flags.contains(SessionFlags::TLS_SNIFFED));
}
