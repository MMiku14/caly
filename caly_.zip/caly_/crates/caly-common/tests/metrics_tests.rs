use caly_common::metrics::{AlignedCounter, Histogram, TagTable, DNS_SECONDS};

#[test]
fn test_aligned_counter_cache_line() {
    assert_eq!(std::mem::align_of::<AlignedCounter>(), 64);
    assert_eq!(std::mem::size_of::<AlignedCounter>(), 64);
    let c = AlignedCounter::new(10);
    c.inc();
    c.add(5);
    assert_eq!(c.get(), 16);
}

#[test]
fn test_histogram_buckets() {
    let hist = Histogram::new(DNS_SECONDS);
    hist.observe(0.001); // 1ms
    hist.observe(0.020); // 20ms
    hist.observe(2.0);   // 2s

    let snap = hist.snapshot();
    assert_eq!(snap.count, 3);
    assert!(snap.sum > 2.0);
}

#[test]
fn test_tag_table_bidirectional() {
    let table = TagTable::new();
    let id1 = table.get_or_register("direct");
    let id2 = table.get_or_register("proxy");
    let id1_again = table.get_or_register("direct");

    assert_eq!(id1, id1_again);
    assert_ne!(id1, id2);
    assert_eq!(table.get_tag(id1).as_deref(), Some("direct"));
    assert_eq!(table.get_tag(id2).as_deref(), Some("proxy"));
}
