//! Unified error contracts for Caly core abstractions.

use smol_str::SmolStr;
use thiserror::Error;

/// 顶层系统通用异常枚举
#[derive(Error, Debug)]
pub enum CalyError {
    #[error("I/O error: {0}")]
    Io(#[from] std::io::Error),
    #[error("Protocol negotiation failed: {0}")]
    Protocol(String),
    #[error("Configuration error: {0}")]
    Config(String),
    #[error("Resource limit reached: {0}")]
    LimitExceeded(String),
    #[error("Internal kernel error: {0}")]
    Internal(String),
}

/// 出站代理适配器异常枚举
#[derive(Error, Debug)]
pub enum ProxyError {
    #[error("Outbound connection failed: {0}")]
    ConnectionFailed(String),
    #[error("Outbound traffic blocked by policy")]
    Blocked,
    #[error("Outbound adapter not found: {0}")]
    NotFound(String),
    #[error("Outbound handshake failed: {0}")]
    HandshakeFailed(String),
    #[error("Operation unsupported: {0}")]
    Unsupported(String),
    #[error("Network unreachable")]
    NetworkUnreachable,
    #[error("Connection refused by peer")]
    ConnectionRefused,
}

/// SOCKS5 握手协议异常枚举
#[derive(Error, Debug, Clone, Copy, PartialEq, Eq)]
pub enum Socks5Error {
    #[error("Buffer overflow in Sans-IO state machine")]
    BufferOverflow,
    #[error("Unsupported SOCKS version (must be 0x05)")]
    UnsupportedVersion,
    #[error("Unsupported authentication version")]
    UnsupportedAuthVersion,
    #[error("No acceptable authentication method")]
    NoAcceptableAuth,
    #[error("Authentication failed")]
    AuthFailed,
    #[error("Unsupported SOCKS command")]
    UnsupportedCommand,
    #[error("Unsupported address type (ATYP)")]
    UnsupportedAddressType,
    #[error("Invalid state transition")]
    InvalidState,
    #[error("Connection not yet established")]
    NotEstablished,
    #[error("Handshake timed out")]
    Timeout,
    #[error("Malformed address payload")]
    MalformedAddress,
}

/// 传输层外壳异常枚举
#[derive(Error, Debug)]
pub enum TransportError {
    #[error("Transport I/O error: {0}")]
    Io(#[from] std::io::Error),
    #[error("TLS handshake error: {0}")]
    TlsHandshake(String),
    #[error("WebSocket handshake error: {0}")]
    WsHandshake(String),
    #[error("REALITY handshake error: {0}")]
    RealityHandshake(String),
    #[error("Connection closed by peer")]
    Closed,
    #[error("Operation timed out")]
    Timeout,
}
