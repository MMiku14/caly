//! Outbound proxy adapter contract.

use async_trait::async_trait;
use crate::adapter::endpoint::UdpSessionEndpoint;
use crate::error::ProxyError;
use crate::metadata::SessionMetadata;
use crate::transport::TransportStream;

#[async_trait]
pub trait ProxyAdapter: Send + Sync {
    fn tag(&self) -> &str;
    fn adapter_type(&self) -> &str;

    fn resolves_locally(&self) -> bool { false }
    fn supports_udp(&self) -> bool { false }

    async fn dial(
        &self,
        metadata: &SessionMetadata,
    ) -> Result<Box<dyn TransportStream>, ProxyError>;

    async fn connect_udp(
        &self,
        metadata: &SessionMetadata,
    ) -> Result<Box<dyn UdpSessionEndpoint>, ProxyError> {
        Err(ProxyError::Unsupported(format!(
            "Outbound '{}' does not support UDP",
            self.tag()
        )))
    }

    fn try_select(&self, _candidate: &str) -> Result<(), String> {
        Err(format!("Outbound '{}' does not support manual selection", self.tag()))
    }

    fn candidates(&self) -> Option<Vec<String>> { None }
    fn current_selection(&self) -> Option<String> { None }
    fn latency_snapshot(&self) -> Vec<(String, u32)> { Vec::new() }
    fn cooldown_snapshot(&self) -> Vec<(String, u64)> { Vec::new() }
    fn reset_failures(&self) -> usize { 0 }
}
