//! Inbound listener descriptor contract.

use std::net::SocketAddr;

pub trait InboundListener: Send + Sync {
    fn tag(&self) -> &str;
    fn listener_type(&self) -> &str;
    fn listen_addr(&self) -> Option<SocketAddr>;
}
