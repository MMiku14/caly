//! UDP session endpoint contract.

use async_trait::async_trait;
use std::net::SocketAddr;

#[async_trait]
pub trait UdpSessionEndpoint: Send + Sync {
    async fn send_to(&self, payload: &[u8], dst: SocketAddr) -> std::io::Result<()>;
    async fn recv_from(&self, buf: &mut [u8]) -> std::io::Result<(usize, SocketAddr)>;
}
