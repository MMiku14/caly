//! Proxy adapter contracts.

pub mod endpoint;
pub mod inbound;
pub mod proxy;

pub use endpoint::UdpSessionEndpoint;
pub use inbound::InboundListener;
pub use proxy::ProxyAdapter;
