//! Protocol address type assertions and safety guardrails.
//!
//! # The Problem
//!
//! SOCKS5 (RFC 1928) and VLESS use differing numerical representations for Address Types (ATYP):
//! - SOCKS5: IPv4 = 0x01, Domain = 0x03, IPv6 = 0x04.
//! - VLESS:  IPv4 = 0x01, Domain = 0x02, IPv6 = 0x03.
//!
//! Conflating these values leads to silent cross-protocol memory corruption and routing failures.
//! This module provides strict type-level distinctions and compile-time assertions.

#[repr(u8)]
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Socks5AddressType {
    Ipv4 = 0x01,
    Domain = 0x03,
    Ipv6 = 0x04,
}

#[repr(u8)]
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum VlessAddressType {
    Ipv4 = 0x01,
    Domain = 0x02,
    Ipv6 = 0x03,
}

// Compile-time assertions verifying standard RFC alignment.
const _: () = assert!(Socks5AddressType::Ipv4 as u8 == 0x01);
const _: () = assert!(Socks5AddressType::Domain as u8 == 0x03);
const _: () = assert!(Socks5AddressType::Ipv6 as u8 == 0x04);

const _: () = assert!(VlessAddressType::Ipv4 as u8 == 0x01);
const _: () = assert!(VlessAddressType::Domain as u8 == 0x02);
const _: () = assert!(VlessAddressType::Ipv6 as u8 == 0x03);
