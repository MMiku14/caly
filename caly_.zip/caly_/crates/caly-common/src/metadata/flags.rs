//! Compact session bitflags.

#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub struct SessionFlags(pub u16);

impl SessionFlags {
    pub const EMPTY: Self = Self(0);
    pub const TPROXY: Self = Self(1 << 0);
    pub const UDP_ASSOCIATE: Self = Self(1 << 1);
    pub const TLS_SNIFFED: Self = Self(1 << 2);
    pub const HTTP_SNIFFED: Self = Self(1 << 3);
    pub const QUIC_SNIFFED: Self = Self(1 << 4);
    pub const FAKE_IP: Self = Self(1 << 5);
    pub const SNOOPED: Self = Self(1 << 6);

    #[inline]
    #[must_use]
    pub const fn contains(self, other: Self) -> bool {
        (self.0 & other.0) == other.0
    }

    #[inline]
    pub fn insert(&mut self, other: Self) {
        self.0 |= other.0;
    }

    #[inline]
    pub fn remove(&mut self, other: Self) {
        self.0 &= !other.0;
    }
}
