//! Protocol enumeration types.

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Default)]
#[repr(u8)]
pub enum Network {
    #[default]
    Tcp = 0x01,
    Udp = 0x02,
}

impl Network {
    #[inline]
    #[must_use]
    pub const fn matches(self, other: Self) -> bool {
        (self as u8) == (other as u8)
    }

    #[must_use]
    pub const fn as_str(self) -> &'static str {
        match self {
            Self::Tcp => "tcp",
            Self::Udp => "udp",
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Default)]
#[repr(u8)]
pub enum SniffedProtocol {
    #[default]
    Unknown = 0x00,
    Http = 0x01,
    Tls = 0x02,
    Quic = 0x03,
    BitTorrent = 0x04,
    Dns = 0x05,
}

impl SniffedProtocol {
    #[must_use]
    pub const fn as_str(self) -> &'static str {
        match self {
            Self::Unknown => "unknown",
            Self::Http => "http",
            Self::Tls => "tls",
            Self::Quic => "quic",
            Self::BitTorrent => "bittorrent",
            Self::Dns => "dns",
        }
    }
}
