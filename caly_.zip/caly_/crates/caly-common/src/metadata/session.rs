//! Compact session metadata aligned to CPU cache lines (RFC 8305 Dual-Stack Ready).
//!
//! # Architecture
//!
//! SessionMetadata is aligned to 64 bytes (`#[repr(C, align(64))]`) to eliminate cache line bouncing
//! across worker threads. Its physical size is strictly verified to remain <= 288 bytes.
//! It embeds inline storage (`SmallVec<[IpAddr; 4]>`) for Happy Eyeballs candidate sets,
//! preventing heap allocation on connection hot paths.

use crate::metadata::flags::SessionFlags;
use crate::metadata::protocol::{Network, SniffedProtocol};
use smallvec::SmallVec;
use smol_str::SmolStr;
use std::net::{IpAddr, SocketAddr};

#[repr(C, align(64))]
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct SessionMetadata {
    pub src_addr: SocketAddr,                            // 28 B
    pub dst_addr: SocketAddr,                            // 28 B
    pub domain: SmolStr,                                 // 24 B (<=23B inline on stack)
    pub inbound_tag: SmolStr,                            // 24 B
    pub process_path: Option<SmolStr>,                   // 24 B
    pub process_name: Option<SmolStr>,                   // 24 B
    pub resolved_ips: SmallVec<[IpAddr; 4]>,             // 48 B (Inline 4 dual-stack candidates)
    pub fwmark: Option<u32>,                             // 8 B  (Routing shield / anti-self-loop)
    pub user_id: Option<u32>,                            // 8 B  (Real UID)
    pub pid: Option<u32>,                                // 8 B  (Process PID)
    pub network: Network,                                // 1 B
    pub protocol: SniffedProtocol,                       // 1 B
    pub flags: SessionFlags,                             // 2 B
    pub sniff_source: u8,                                // 1 B
    pub _reserved: [u8; 57],                             // Padding strictly aligned to 288 bytes
}

const _: () = assert!(
    std::mem::size_of::<SessionMetadata>() <= 288,
    "SessionMetadata size exceeds 288-byte ceiling"
);
const _: () = assert!(
    std::mem::align_of::<SessionMetadata>() >= 64,
    "SessionMetadata must satisfy 64-byte cache line alignment"
);

impl Default for SessionMetadata {
    fn default() -> Self {
        Self {
            src_addr: SocketAddr::from(([127, 0, 0, 1], 0)),
            dst_addr: SocketAddr::from(([127, 0, 0, 1], 0)),
            domain: SmolStr::default(),
            inbound_tag: SmolStr::default(),
            process_path: None,
            process_name: None,
            resolved_ips: SmallVec::new(),
            fwmark: None,
            user_id: None,
            pid: None,
            network: Network::Tcp,
            protocol: SniffedProtocol::Unknown,
            flags: SessionFlags::EMPTY,
            sniff_source: 0,
            _reserved: [0u8; 57],
        }
    }
}

impl SessionMetadata {
    #[must_use]
    pub fn new(src_addr: SocketAddr, dst_addr: SocketAddr, network: Network, inbound_tag: SmolStr) -> Self {
        Self {
            src_addr,
            dst_addr,
            network,
            inbound_tag,
            ..Default::default()
        }
    }

    #[inline]
    pub fn set_domain(&mut self, raw_domain: &str) {
        let trimmed = raw_domain.trim();
        let stripped = trimmed.trim_end_matches('.');
        if stripped.is_empty() {
            self.domain = SmolStr::default();
            return;
        }
        if stripped.bytes().any(|b| b.is_ascii_uppercase()) {
            self.domain = SmolStr::new(stripped.to_ascii_lowercase());
        } else {
            self.domain = SmolStr::new(stripped);
        }
    }

    #[inline]
    pub fn set_domain_with_source(&mut self, raw_domain: &str, source: u8) {
        self.set_domain(raw_domain);
        self.sniff_source = source;
    }

    #[inline]
    #[must_use]
    pub fn has_domain(&self) -> bool {
        !self.domain.is_empty()
    }

    #[inline]
    pub fn set_process_name(&mut self, name: &str) {
        self.process_name = Some(SmolStr::new(name));
    }

    #[inline]
    pub fn set_process_path(&mut self, path: &str) {
        self.process_path = Some(SmolStr::new(path));
    }
}
