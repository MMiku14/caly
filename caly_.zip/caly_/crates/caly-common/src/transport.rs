//! Pure L4/L5 reliable byte stream transport abstraction.

use std::net::SocketAddr;
use tokio::io::{AsyncRead, AsyncWrite};

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum StreamType {
    Tcp,
    Tls,
    Ws,
    TlsWs,
    H2,
    Quic,
}

pub trait TransportStream: AsyncRead + AsyncWrite + Unpin + Send + Sync {
    fn transport_type(&self) -> &'static str;
    fn is_alive(&self) -> bool { true }
    fn peer_addr(&self) -> std::io::Result<SocketAddr>;
    fn local_addr(&self) -> std::io::Result<SocketAddr>;
}

impl TransportStream for Box<dyn TransportStream> {
    fn transport_type(&self) -> &'static str {
        (**self).transport_type()
    }
    fn is_alive(&self) -> bool {
        (**self).is_alive()
    }
    fn peer_addr(&self) -> std::io::Result<SocketAddr> {
        (**self).peer_addr()
    }
    fn local_addr(&self) -> std::io::Result<SocketAddr> {
        (**self).local_addr()
    }
}
