//! Cache-line aligned atomic counters.

use std::sync::atomic::{AtomicU64, Ordering};

#[repr(C, align(64))]
#[derive(Debug, Default)]
pub struct AlignedCounter {
    pub value: AtomicU64,
    _pad: [u64; 7],
}

impl AlignedCounter {
    #[must_use]
    pub fn new(val: u64) -> Self {
        Self {
            value: AtomicU64::new(val),
            _pad: [0; 7],
        }
    }

    #[inline]
    pub fn inc(&self) {
        self.value.fetch_add(1, Ordering::Relaxed);
    }

    #[inline]
    pub fn add(&self, n: u64) {
        self.value.fetch_add(n, Ordering::Relaxed);
    }

    #[inline]
    #[must_use]
    pub fn get(&self) -> u64 {
        self.value.load(Ordering::Relaxed)
    }
}
