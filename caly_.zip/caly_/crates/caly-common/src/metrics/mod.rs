//! Unified metric primitives and histograms.

pub mod atomic;
pub mod histogram;
pub mod tag_table;

pub use atomic::AlignedCounter;
pub use histogram::{Histogram, HistogramSnapshot, DNS_SECONDS, SESSION_DURATION_SECONDS};
pub use tag_table::TagTable;
