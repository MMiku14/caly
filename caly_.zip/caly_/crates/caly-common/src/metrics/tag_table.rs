//! Lock-free bidirectional tag-to-index table.

use parking_lot::RwLock;
use smol_str::SmolStr;
use std::collections::HashMap;

#[derive(Default)]
pub struct TagTable {
    tag_to_id: RwLock<HashMap<SmolStr, u32>>,
    id_to_tag: RwLock<Vec<SmolStr>>,
}

impl TagTable {
    #[must_use]
    pub fn new() -> Self {
        Self::default()
    }

    pub fn get_or_register(&self, tag: &str) -> u32 {
        {
            let map = self.tag_to_id.read();
            if let Some(&id) = map.get(tag) {
                return id;
            }
        }
        let mut map = self.tag_to_id.write();
        let mut list = self.id_to_tag.write();
        if let Some(&id) = map.get(tag) {
            return id;
        }
        let id = list.len() as u32;
        let smol = SmolStr::new(tag);
        map.insert(smol.clone(), id);
        list.push(smol);
        id
    }

    #[must_use]
    pub fn get_tag(&self, id: u32) -> Option<SmolStr> {
        let list = self.id_to_tag.read();
        list.get(id as usize).cloned()
    }
}
