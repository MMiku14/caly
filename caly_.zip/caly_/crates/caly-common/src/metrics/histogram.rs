//! Lock-free microsecond atomic latency histogram.

use std::sync::atomic::{AtomicU64, Ordering};
use std::time::Duration;

pub const DNS_SECONDS: &[f64] = &[
    0.0005, 0.001, 0.002, 0.005, 0.010, 0.025, 0.050, 0.100, 0.250, 0.500, 1.0, 2.5,
];

pub const SESSION_DURATION_SECONDS: &[f64] = &[
    0.1, 0.5, 1.0, 5.0, 10.0, 30.0, 60.0, 120.0, 300.0, 600.0, 1800.0, 3600.0,
];

#[derive(Debug, Clone, Default)]
pub struct HistogramSnapshot {
    pub sum: f64,
    pub count: u64,
    pub buckets: Vec<(f64, u64)>,
}

pub struct Histogram {
    bounds: Vec<f64>,
    buckets: Box<[AtomicU64]>,
    count: AtomicU64,
    sum_micros: AtomicU64,
}

impl Histogram {
    #[must_use]
    pub fn new(bounds: &[f64]) -> Self {
        let mut sorted = bounds.to_vec();
        sorted.sort_by(|a, b| a.partial_cmp(b).unwrap_or(std::cmp::Ordering::Equal));
        let num_buckets = sorted.len() + 1; // Includes +Inf
        let buckets = (0..num_buckets).map(|_| AtomicU64::new(0)).collect::<Vec<_>>().into_boxed_slice();
        Self {
            bounds: sorted,
            buckets,
            count: AtomicU64::new(0),
            sum_micros: AtomicU64::new(0),
        }
    }

    #[inline]
    pub fn observe(&self, value_seconds: f64) {
        if value_seconds < 0.0 {
            return;
        }
        let micros = (value_seconds * 1_000_000.0).round() as u64;
        self.sum_micros.fetch_add(micros, Ordering::Relaxed);
        self.count.fetch_add(1, Ordering::Relaxed);

        let mut idx = self.bounds.len();
        for (i, &bound) in self.bounds.iter().enumerate() {
            if value_seconds <= bound {
                idx = i;
                break;
            }
        }
        self.buckets[idx].fetch_add(1, Ordering::Relaxed);
    }

    #[inline]
    pub fn observe_duration(&self, d: Duration) {
        self.observe(d.as_secs_f64());
    }

    #[must_use]
    pub fn snapshot(&self) -> HistogramSnapshot {
        let count = self.count.load(Ordering::Relaxed);
        let sum = (self.sum_micros.load(Ordering::Relaxed) as f64) / 1_000_000.0;
        let mut buckets = Vec::with_capacity(self.bounds.len() + 1);
        let mut cumulative = 0u64;

        for (i, &bound) in self.bounds.iter().enumerate() {
            cumulative += self.buckets[i].load(Ordering::Relaxed);
            buckets.push((bound, cumulative));
        }
        cumulative += self.buckets[self.bounds.len()].load(Ordering::Relaxed);
        buckets.push((f64::INFINITY, cumulative));

        HistogramSnapshot { sum, count, buckets }
    }
}
