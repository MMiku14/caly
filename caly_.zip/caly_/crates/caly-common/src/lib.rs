//! Caly Common — Core unified zero-cost abstractions, metadata, and contracts.
//!
//! # Architecture
//!
//! ```text
//!  ┌──────────────────────────────────────────────────────────┐
//!  │  adapter    ProxyAdapter, UdpSessionEndpoint             │
//!  ├──────────────────────────────────────────────────────────┤
//!  │  metadata   Cache-line aligned SessionMetadata (<=288 B) │
//!  ├──────────────────────────────────────────────────────────┤
//!  │  dns        Dual-plane isolated DnsResolver contract     │
//!  ├──────────────────────────────────────────────────────────┤
//!  │  metrics    Lock-free histograms and aligned counters    │
//!  ├──────────────────────────────────────────────────────────┤
//!  │  protocol   Pure Sans-IO ProtocolStateMachine            │
//!  ├──────────────────────────────────────────────────────────┤
//!  │  relay      DataRelayEngine and streaming contracts      │
//!  └──────────────────────────────────────────────────────────┘
//! ```

pub mod adapter;
pub mod addr_type;
pub mod dns;
pub mod error;
pub mod metadata;
pub mod metrics;
pub mod protocol;
pub mod relay;
pub mod transport;

pub use adapter::{InboundListener, ProxyAdapter, UdpSessionEndpoint};
pub use addr_type::{Socks5AddressType, VlessAddressType};
pub use dns::{DnsError, DnsResolver, ResolveResult};
pub use error::{CalyError, ProxyError, Socks5Error, TransportError};
pub use metadata::{Network, SessionFlags, SessionMetadata, SniffedProtocol};
pub use metrics::{AlignedCounter, Histogram, HistogramSnapshot, TagTable};
pub use protocol::ProtocolStateMachine;
pub use relay::{DataRelayEngine, RelayOutcome};
pub use transport::{StreamType, TransportStream};
