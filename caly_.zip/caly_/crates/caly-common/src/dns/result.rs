//! DNS resolution result representations.

use smallvec::SmallVec;
use std::net::IpAddr;

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum ResolveResult {
    RealIp(SmallVec<[IpAddr; 4]>),
    FakeIp(IpAddr),
}
