//! Dual-plane isolated DNS resolver contract.

use crate::dns::error::DnsError;
use crate::dns::result::ResolveResult;
use crate::dns::stats::DnsStatsSnapshot;
use async_trait::async_trait;
use smallvec::SmallVec;
use smol_str::SmolStr;
use std::net::IpAddr;

#[async_trait]
pub trait DnsResolver: Send + Sync {
    async fn resolve_for_client(&self, domain: &str) -> Result<ResolveResult, DnsError>;
    async fn resolve_for_dial(&self, domain: &str) -> Result<SmallVec<[IpAddr; 4]>, DnsError>;

    async fn resolve_via(&self, domain: &str, tag: Option<&str>) -> Result<SmallVec<[IpAddr; 4]>, DnsError> {
        let _ = tag;
        self.resolve_for_dial(domain).await
    }

    fn lookup_fakeip(&self, ip: IpAddr) -> Option<SmolStr>;
    fn snoop(&self, ip: IpAddr) -> Option<SmolStr>;
    fn gc(&self) {}
    fn clear_cache(&self) -> usize { 0 }
    fn stats(&self) -> DnsStatsSnapshot { DnsStatsSnapshot::default() }
}
