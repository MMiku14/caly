//! DNS subsystem contracts.

pub mod contract;
pub mod error;
pub mod result;
pub mod stats;

pub use contract::DnsResolver;
pub use error::DnsError;
pub use result::ResolveResult;
pub use stats::{DnsServerStat, DnsStatsSnapshot};
