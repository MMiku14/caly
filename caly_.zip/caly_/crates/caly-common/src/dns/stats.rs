//! DNS runtime statistics snapshots.

use crate::metrics::HistogramSnapshot;

#[derive(Debug, Clone, Default)]
pub struct DnsServerStat {
    pub server: String,
    pub queries: u64,
    pub errors: u64,
    pub duration: HistogramSnapshot,
}

#[derive(Debug, Clone, Default)]
pub struct DnsStatsSnapshot {
    pub queries: u64,
    pub cache_hits: u64,
    pub cache_misses: u64,
    pub errors: u64,
    pub fakeip_allocated: u64,
    pub fakeip_released: u64,
    pub fakeip_exhausted: u64,
    pub fakeip_capacity: u64,
    pub servers: Vec<DnsServerStat>,
}
