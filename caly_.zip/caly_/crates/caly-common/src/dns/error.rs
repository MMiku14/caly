//! Core DNS error definitions.

use smol_str::SmolStr;
use thiserror::Error;

#[derive(Error, Debug, Clone, PartialEq, Eq)]
pub enum DnsError {
    #[error("Domain not found (NXDOMAIN): {0}")]
    NotFound(SmolStr),
    #[error("No records returned (NODATA): {0}")]
    EmptyAnswer(SmolStr),
    #[error("DNS server timeout: {0}")]
    Timeout(SmolStr),
    #[error("No upstream DNS configured")]
    NoUpstream,
    #[error("FakeIP address pool exhausted")]
    FakeIpExhausted,
    #[error("CNAME loop detected")]
    CnameLoop,
    #[error("Malformed DNS response: {0}")]
    MalformedResponse(SmolStr),
    #[error("Upstream server failed: {0}")]
    UpstreamFailed(SmolStr),
    #[error("DNS I/O error: {msg}")]
    Io { msg: SmolStr },
    #[error("Configuration parse error: {0}")]
    ParseError(SmolStr),
}

impl From<std::io::Error> for DnsError {
    fn from(e: std::io::Error) -> Self {
        Self::Io { msg: SmolStr::new(e.to_string()) }
    }
}
