//! Relay engine abstractions.

pub mod engine;
pub use engine::{DataRelayEngine, RelayOutcome};
