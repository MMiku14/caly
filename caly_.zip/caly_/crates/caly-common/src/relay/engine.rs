//! Streaming data relay engine contract.

use async_trait::async_trait;

#[derive(Debug, Clone, Copy, Default)]
pub struct RelayOutcome {
    pub bytes_rx: u64,
    pub bytes_tx: u64,
    pub chunks_rx: u64,
    pub chunks_tx: u64,
}

#[async_trait]
pub trait DataRelayEngine: Send + Unpin {
    async fn relay(&mut self, early_data: Option<&[u8]>) -> std::io::Result<RelayOutcome>;
}
