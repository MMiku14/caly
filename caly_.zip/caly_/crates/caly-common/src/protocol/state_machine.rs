//! Pure Sans-IO protocol negotiation state machine contract.

use std::error::Error;

pub trait ProtocolStateMachine {
    type Action;
    type Error: Error + Send + Sync + 'static;

    fn on_network_input(&mut self, data: &[u8]) -> Result<(), Self::Error>;
    fn poll_network_output(&mut self, out_buf: &mut [u8]) -> Option<usize>;
    fn poll_early_data(&mut self, out_buf: &mut [u8]) -> Option<usize>;
    fn handle_tick(&mut self, now_ms: u64) -> Option<Self::Action>;
    fn is_established(&self) -> bool;
}
