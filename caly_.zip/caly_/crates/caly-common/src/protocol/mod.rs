//! Protocol state machine abstractions.

pub mod state_machine;
pub use state_machine::ProtocolStateMachine;
