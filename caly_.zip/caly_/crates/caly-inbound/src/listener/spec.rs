//! Inbound listener specifications.

use crate::socks5::auth::AuthConfig;
use caly_common::adapter::InboundListener;
use smol_str::SmolStr;
use std::net::SocketAddr;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum InboundType {
    Socks5,
    Http,
    Mixed,
    Tproxy,
}

impl InboundType {
    pub fn as_str(&self) -> &'static str {
        match self {
            Self::Socks5 => "socks5",
            Self::Http => "http",
            Self::Mixed => "mixed",
            Self::Tproxy => "tproxy",
        }
    }
}

#[derive(Debug, Clone)]
pub struct InboundSpec {
    pub tag: SmolStr,
    pub inbound_type: InboundType,
    pub listen_addr: SocketAddr,
    pub auth: Option<AuthConfig>,
    pub sniff_enabled: bool,
}

impl InboundSpec {
    pub fn new(
        tag: &str,
        inbound_type: InboundType,
        listen_addr: SocketAddr,
        auth: Option<AuthConfig>,
        sniff_enabled: bool,
    ) -> Self {
        Self {
            tag: SmolStr::new(tag),
            inbound_type,
            listen_addr,
            auth,
            sniff_enabled,
        }
    }
}

impl InboundListener for InboundSpec {
    fn tag(&self) -> &str { self.tag.as_str() }
    fn listener_type(&self) -> &str { self.inbound_type.as_str() }
    fn listen_addr(&self) -> Option<SocketAddr> { Some(self.listen_addr) }
}
