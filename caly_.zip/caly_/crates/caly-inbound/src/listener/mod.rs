//! Inbound listener specifications.

pub mod spec;
pub use spec::{InboundSpec, InboundType};
