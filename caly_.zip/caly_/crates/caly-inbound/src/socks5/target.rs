//! SOCKS5 target address representation.

use smol_str::SmolStr;
use std::net::SocketAddr;

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum TargetAddr {
    Ip(SocketAddr),
    Domain(SmolStr, u16),
}

impl TargetAddr {
    #[must_use]
    pub fn port(&self) -> u16 {
        match self {
            Self::Ip(addr) => addr.port(),
            Self::Domain(_, port) => *port,
        }
    }
}
