//! SOCKS5 RFC 1929 authentication credentials.

use smol_str::SmolStr;

#[derive(Debug, Clone, Default)]
pub struct AuthConfig {
    pub required: bool,
    pub username: Option<SmolStr>,
    pub password: Option<SmolStr>,
}

impl AuthConfig {
    #[must_use]
    pub fn none() -> Self {
        Self { required: false, username: None, password: None }
    }

    #[must_use]
    pub fn new(username: &str, password: &str) -> Self {
        Self {
            required: true,
            username: Some(SmolStr::new(username)),
            password: Some(SmolStr::new(password)),
        }
    }

    #[must_use]
    pub fn is_required(&self) -> bool { self.required }

    #[must_use]
    pub fn verify(&self, username: &[u8], password: &[u8]) -> bool {
        if !self.required { return true; }
        let u_match = self.username.as_ref().map_or(false, |u| u.as_bytes() == username);
        let p_match = self.password.as_ref().map_or(false, |p| p.as_bytes() == password);
        u_match && p_match
    }
}
