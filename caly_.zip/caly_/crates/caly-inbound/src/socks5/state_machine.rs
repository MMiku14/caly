//! Pure Sans-IO SOCKS5 protocol state machine (heapless stack buffers).

use crate::socks5::auth::AuthConfig;
use crate::socks5::command::Socks5Command;
use crate::socks5::target::TargetAddr;
use caly_common::error::Socks5Error;
use caly_common::protocol::ProtocolStateMachine;
use smol_str::SmolStr;
use std::net::{IpAddr, Ipv4Addr, Ipv6Addr, SocketAddr};

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Socks5State {
    Greeting,
    Auth,
    Request,
    Connecting,
    Established,
    Failed,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Socks5Action {
    None,
    NeedOutput,
    Connecting,
    Established,
    Timeout,
    Failed,
}

pub struct Socks5StateMachine {
    state: Socks5State,
    input_buf: heapless::Vec<u8, 1024>,
    output_buf: heapless::Vec<u8, 512>,
    auth_config: AuthConfig,
    target: Option<TargetAddr>,
    command: Option<Socks5Command>,
    timeout_ms: u64,
    last_active_ms: u64,
}

impl Socks5StateMachine {
    #[must_use]
    pub fn new(auth_config: AuthConfig, timeout_ms: u64) -> Self {
        Self {
            state: Socks5State::Greeting,
            input_buf: heapless::Vec::new(),
            output_buf: heapless::Vec::new(),
            auth_config,
            target: None,
            command: None,
            timeout_ms,
            last_active_ms: 0,
        }
    }

    #[must_use]
    pub fn state(&self) -> Socks5State { self.state }
    #[must_use]
    pub fn target(&self) -> Option<&TargetAddr> { self.target.as_ref() }
    #[must_use]
    pub fn command(&self) -> Option<Socks5Command> { self.command }
    #[must_use]
    pub fn has_output(&self) -> bool { !self.output_buf.is_empty() }
    #[must_use]
    pub fn has_early_data(&self) -> bool {
        self.state == Socks5State::Established && !self.input_buf.is_empty()
    }

    pub fn on_connected(&mut self, bind_addr: SocketAddr) -> Result<(), Socks5Error> {
        if self.state != Socks5State::Connecting {
            return Err(Socks5Error::InvalidState);
        }
        self.output_buf.clear();
        let _ = self.output_buf.extend_from_slice(&[0x05, 0x00, 0x00]);
        match bind_addr {
            SocketAddr::V4(v4) => {
                let _ = self.output_buf.push(0x01);
                let _ = self.output_buf.extend_from_slice(&v4.ip().octets());
                let _ = self.output_buf.extend_from_slice(&v4.port().to_be_bytes());
            }
            SocketAddr::V6(v6) => {
                let _ = self.output_buf.push(0x04);
                let _ = self.output_buf.extend_from_slice(&v6.ip().octets());
                let _ = self.output_buf.extend_from_slice(&v6.port().to_be_bytes());
            }
        }
        self.state = Socks5State::Established;
        Ok(())
    }

    pub fn on_error(&mut self, rep: u8) {
        self.output_buf.clear();
        let _ = self.output_buf.extend_from_slice(&[0x05, rep, 0x00, 0x01, 0, 0, 0, 0, 0, 0]);
        self.state = Socks5State::Failed;
    }

    fn advance(&mut self) -> Result<(), Socks5Error> {
        loop {
            match self.state {
                Socks5State::Greeting => {
                    if self.input_buf.len() < 2 { return Ok(()); }
                    if self.input_buf[0] != 0x05 {
                        self.state = Socks5State::Failed;
                        return Err(Socks5Error::UnsupportedVersion);
                    }
                    let nmethods = self.input_buf[1] as usize;
                    let total = 2 + nmethods;
                    if self.input_buf.len() < total { return Ok(()); }
                    let methods = &self.input_buf[2..total];
                    if self.auth_config.is_required() {
                        if !methods.contains(&0x02) {
                            let _ = self.output_buf.extend_from_slice(&[0x05, 0xFF]);
                            self.state = Socks5State::Failed;
                            return Err(Socks5Error::NoAcceptableAuth);
                        }
                        let _ = self.output_buf.extend_from_slice(&[0x05, 0x02]);
                        let _ = self.input_buf.drain(..total);
                        self.state = Socks5State::Auth;
                    } else {
                        if !methods.contains(&0x00) {
                            let _ = self.output_buf.extend_from_slice(&[0x05, 0xFF]);
                            self.state = Socks5State::Failed;
                            return Err(Socks5Error::NoAcceptableAuth);
                        }
                        let _ = self.output_buf.extend_from_slice(&[0x05, 0x00]);
                        let _ = self.input_buf.drain(..total);
                        self.state = Socks5State::Request;
                    }
                }
                Socks5State::Auth => {
                    if self.input_buf.len() < 2 { return Ok(()); }
                    if self.input_buf[0] != 0x01 {
                        self.state = Socks5State::Failed;
                        return Err(Socks5Error::UnsupportedAuthVersion);
                    }
                    let ulen = self.input_buf[1] as usize;
                    if self.input_buf.len() < 2 + ulen + 1 { return Ok(()); }
                    let plen = self.input_buf[2 + ulen] as usize;
                    let total = 2 + ulen + 1 + plen;
                    if self.input_buf.len() < total { return Ok(()); }
                    let username = &self.input_buf[2..2 + ulen];
                    let password = &self.input_buf[3 + ulen..total];
                    if self.auth_config.verify(username, password) {
                        let _ = self.output_buf.extend_from_slice(&[0x01, 0x00]);
                        let _ = self.input_buf.drain(..total);
                        self.state = Socks5State::Request;
                    } else {
                        let _ = self.output_buf.extend_from_slice(&[0x01, 0x01]);
                        self.state = Socks5State::Failed;
                        return Err(Socks5Error::AuthFailed);
                    }
                }
                Socks5State::Request => {
                    if self.input_buf.len() < 4 { return Ok(()); }
                    if self.input_buf[0] != 0x05 {
                        self.state = Socks5State::Failed;
                        return Err(Socks5Error::UnsupportedVersion);
                    }
                    let cmd = match self.input_buf[1] {
                        0x01 => Socks5Command::Connect,
                        0x03 => Socks5Command::UdpAssociate,
                        _ => {
                            self.state = Socks5State::Failed;
                            return Err(Socks5Error::UnsupportedCommand);
                        }
                    };
                    self.command = Some(cmd);

                    let atyp = self.input_buf[3];
                    let addr_len = match atyp {
                        0x01 => 4,
                        0x04 => 16,
                        0x03 => {
                            if self.input_buf.len() < 5 { return Ok(()); }
                            1 + self.input_buf[4] as usize
                        }
                        _ => {
                            self.state = Socks5State::Failed;
                            return Err(Socks5Error::UnsupportedAddressType);
                        }
                    };
                    let total = 4 + addr_len + 2;
                    if self.input_buf.len() < total { return Ok(()); }

                    let raw_addr = &self.input_buf[4..4 + addr_len];
                    let raw_port = &self.input_buf[4 + addr_len..total];
                    let port = u16::from_be_bytes([raw_port[0], raw_port[1]]);

                    let target = match atyp {
                        0x01 => {
                            let octets = [raw_addr[0], raw_addr[1], raw_addr[2], raw_addr[3]];
                            TargetAddr::Ip(SocketAddr::new(IpAddr::V4(Ipv4Addr::from(octets)), port))
                        }
                        0x04 => {
                            let mut octets = [0u8; 16];
                            octets.copy_from_slice(raw_addr);
                            TargetAddr::Ip(SocketAddr::new(IpAddr::V6(Ipv6Addr::from(octets)), port))
                        }
                        0x03 => {
                            let domain_bytes = &raw_addr[1..];
                            let domain_str = std::str::from_utf8(domain_bytes)
                                .map_err(|_| Socks5Error::MalformedAddress)?;
                            TargetAddr::Domain(SmolStr::new(domain_str), port)
                        }
                        _ => unreachable!(),
                    };

                    self.target = Some(target);
                    let _ = self.input_buf.drain(..total);
                    self.state = Socks5State::Connecting;
                    return Ok(());
                }
                Socks5State::Connecting | Socks5State::Established | Socks5State::Failed => {
                    return Ok(());
                }
            }
        }
    }
}

impl ProtocolStateMachine for Socks5StateMachine {
    type Action = Socks5Action;
    type Error = Socks5Error;

    fn on_network_input(&mut self, data: &[u8]) -> Result<(), Self::Error> {
        let available = self.input_buf.capacity() - self.input_buf.len();
        let to_take = data.len().min(available);
        if to_take < data.len() {
            return Err(Socks5Error::BufferOverflow);
        }
        self.input_buf.extend_from_slice(&data[..to_take])
            .map_err(|_| Socks5Error::BufferOverflow)?;
        self.advance()
    }

    fn poll_network_output(&mut self, out_buf: &mut [u8]) -> Option<usize> {
        if self.output_buf.is_empty() { return None; }
        let n = self.output_buf.len().min(out_buf.len());
        out_buf[..n].copy_from_slice(&self.output_buf[..n]);
        let _ = self.output_buf.drain(..n);
        Some(n)
    }

    fn poll_early_data(&mut self, out_buf: &mut [u8]) -> Option<usize> {
        if self.state != Socks5State::Established || self.input_buf.is_empty() {
            return None;
        }
        let n = self.input_buf.len().min(out_buf.len());
        out_buf[..n].copy_from_slice(&self.input_buf[..n]);
        let _ = self.input_buf.drain(..n);
        Some(n)
    }

    fn handle_tick(&mut self, now_ms: u64) -> Option<Self::Action> {
        if self.last_active_ms == 0 { self.last_active_ms = now_ms; }
        if now_ms.saturating_sub(self.last_active_ms) > self.timeout_ms {
            self.state = Socks5State::Failed;
            return Some(Socks5Action::Timeout);
        }
        if !self.output_buf.is_empty() { return Some(Socks5Action::NeedOutput); }
        match self.state {
            Socks5State::Connecting => Some(Socks5Action::Connecting),
            Socks5State::Established => Some(Socks5Action::Established),
            Socks5State::Failed => Some(Socks5Action::Failed),
            _ => Some(Socks5Action::None),
        }
    }

    fn is_established(&self) -> bool {
        self.state == Socks5State::Established
    }
}
