//! Linux TProxy transparent interception and self-loop guards.

pub mod listener;
pub use listener::{check_routing_loop, create_tproxy_listener, get_original_dst};
