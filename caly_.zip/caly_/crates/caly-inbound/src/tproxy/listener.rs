//! Linux TProxy transparent proxy interception.

use std::net::SocketAddr;
use tokio::net::TcpStream;

pub fn create_tproxy_listener(
    listen_addr: SocketAddr,
    backlog: i32,
) -> std::io::Result<tokio::net::TcpListener> {
    use socket2::{Domain, Protocol, Socket, Type};

    let domain = if listen_addr.is_ipv6() { Domain::IPV6 } else { Domain::IPV4 };
    let socket = Socket::new(domain, Type::STREAM, Some(Protocol::TCP))?;
    socket.set_reuse_address(true)?;

    #[cfg(all(unix, not(target_os = "solaris"), not(target_os = "illumos")))]
    socket.set_reuse_port(true)?;

    #[cfg(target_os = "linux")]
    unsafe {
        use std::os::unix::io::AsRawFd;
        let opt: libc::c_int = 1;
        let (level, optname) = if listen_addr.is_ipv4() {
            (libc::SOL_IP, libc::IP_TRANSPARENT)
        } else {
            (libc::SOL_IPV6, libc::IPV6_TRANSPARENT)
        };
        let _ = libc::setsockopt(
            socket.as_raw_fd(),
            level,
            optname,
            &opt as *const _ as *const libc::c_void,
            std::mem::size_of_val(&opt) as libc::socklen_t,
        );
    }

    socket.set_nonblocking(true)?;
    socket.bind(&listen_addr.into())?;
    socket.listen(backlog)?;

    let std_listener: std::net::TcpListener = socket.into();
    tokio::net::TcpListener::from_std(std_listener)
}

pub fn get_original_dst(stream: &TcpStream) -> std::io::Result<SocketAddr> {
    stream.local_addr()
}

#[must_use]
pub fn check_routing_loop(target_addr: SocketAddr, listener_addr: SocketAddr) -> bool {
    if target_addr.port() == listener_addr.port() {
        if target_addr.ip() == listener_addr.ip()
            || target_addr.ip().is_loopback()
            || listener_addr.ip().is_unspecified()
        {
            return true;
        }
    }
    false
}
