//! HTTP proxy protocol handling.

pub mod parser;
pub use parser::{HttpInbound, HttpRequestType};
