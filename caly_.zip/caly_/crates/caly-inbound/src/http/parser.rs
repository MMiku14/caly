//! HTTP CONNECT tunnel and forward proxy parser.

use caly_common::error::CalyError;
use smol_str::SmolStr;

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum HttpRequestType {
    Connect { host: SmolStr, port: u16, header_end: usize },
    Forward {
        method: SmolStr,
        uri: SmolStr,
        host: SmolStr,
        port: u16,
        header_end: usize,
        rewritten_header: Vec<u8>,
    },
}

pub struct HttpInbound;

impl HttpInbound {
    pub fn find_header_end(buf: &[u8]) -> Option<usize> {
        buf.windows(4).position(|w| w == b"\r\n\r\n").map(|p| p + 4)
    }

    pub fn parse_request(buf: &[u8]) -> Result<Option<HttpRequestType>, CalyError> {
        let header_end = match Self::find_header_end(buf) {
            Some(end) => end,
            None => return Ok(None),
        };

        let header_bytes = &buf[..header_end];
        let header_str = match std::str::from_utf8(header_bytes) {
            Ok(s) => s,
            Err(_) => return Err(CalyError::Protocol("HTTP header non UTF-8".to_string())),
        };

        let first_line = match header_str.lines().next() {
            Some(line) => line,
            None => return Ok(None),
        };

        let parts: Vec<&str> = first_line.split_whitespace().collect();
        if parts.len() < 3 {
            return Err(CalyError::Protocol("Malformed HTTP request line".to_string()));
        }

        let method = parts[0];
        let uri = parts[1];

        if method.eq_ignore_ascii_case("CONNECT") {
            let (host, port) = Self::parse_host_port(uri)?;
            return Ok(Some(HttpRequestType::Connect {
                host: SmolStr::new(host.to_ascii_lowercase()),
                port,
                header_end,
            }));
        }

        let (host, port, origin_path) = Self::parse_forward_uri(uri, header_str)?;
        let rewritten_header = Self::rewrite_forward_request(header_str, method, &host, port, &origin_path)?;

        Ok(Some(HttpRequestType::Forward {
            method: SmolStr::new(method),
            uri: SmolStr::new(uri),
            host: SmolStr::new(host.to_ascii_lowercase()),
            port,
            header_end,
            rewritten_header,
        }))
    }

    pub fn parse_host_port(target: &str) -> Result<(String, u16), CalyError> {
        let trimmed = target.trim();
        if trimmed.starts_with('[') {
            if let Some(close_bracket) = trimmed.find(']') {
                let host = &trimmed[1..close_bracket];
                let rest = &trimmed[close_bracket + 1..];
                if let Some(colon) = rest.find(':') {
                    let port_str = &rest[colon + 1..];
                    let port = port_str.parse::<u16>().map_err(|_| {
                        CalyError::Protocol(format!("Invalid port: {port_str}"))
                    })?;
                    return Ok((host.to_string(), port));
                }
            }
            return Err(CalyError::Protocol(format!("Malformed IPv6 target: {target}")));
        }

        if let Some(colon) = trimmed.rfind(':') {
            let host = &trimmed[..colon];
            let port_str = &trimmed[colon + 1..];
            let port = port_str.parse::<u16>().map_err(|_| {
                CalyError::Protocol(format!("Invalid port: {port_str}"))
            })?;
            Ok((host.to_string(), port))
        } else {
            Ok((trimmed.to_string(), 80))
        }
    }

    fn parse_forward_uri(uri: &str, header_str: &str) -> Result<(String, u16, String), CalyError> {
        if uri.starts_with("http://") || uri.starts_with("https://") {
            let scheme_end = uri.find("://").unwrap() + 3;
            let rest = &uri[scheme_end..];
            let slash_pos = rest.find('/').unwrap_or(rest.len());
            let host_port_part = &rest[..slash_pos];
            let path_part = if slash_pos < rest.len() { &rest[slash_pos..] } else { "/" };

            let (host, port) = Self::parse_host_port(host_port_part)?;
            Ok((host, port, path_part.to_string()))
        } else {
            let mut host_hdr = None;
            for line in header_str.lines().skip(1) {
                if let Some(colon) = line.find(':') {
                    if line[..colon].trim().eq_ignore_ascii_case("Host") {
                        host_hdr = Some(line[colon + 1..].trim());
                        break;
                    }
                }
            }
            let host_str = host_hdr.ok_or_else(|| {
                CalyError::Protocol("Forward request missing Host header".to_string())
            })?;
            let (host, port) = Self::parse_host_port(host_str)?;
            Ok((host, port, uri.to_string()))
        }
    }

    fn rewrite_forward_request(
        header_str: &str,
        method: &str,
        host: &str,
        port: u16,
        origin_path: &str,
    ) -> Result<Vec<u8>, CalyError> {
        let mut rewritten = Vec::with_capacity(header_str.len() + 64);
        rewritten.extend_from_slice(format!("{method} {origin_path} HTTP/1.1\r\n").as_bytes());

        let mut has_host = false;
        for line in header_str.lines().skip(1) {
            let trimmed = line.trim();
            if trimmed.is_empty() { break; }
            if let Some(colon) = trimmed.find(':') {
                let name = trimmed[..colon].trim();
                let value = trimmed[colon + 1..].trim();
                if name.eq_ignore_ascii_case("Proxy-Connection") || name.eq_ignore_ascii_case("Connection") {
                    continue;
                }
                if name.eq_ignore_ascii_case("Host") { has_host = true; }
                rewritten.extend_from_slice(name.as_bytes());
                rewritten.extend_from_slice(b": ");
                rewritten.extend_from_slice(value.as_bytes());
                rewritten.extend_from_slice(b"\r\n");
            }
        }

        if !has_host {
            if port == 80 {
                rewritten.extend_from_slice(format!("Host: {host}\r\n").as_bytes());
            } else {
                rewritten.extend_from_slice(format!("Host: {host}:{port}\r\n").as_bytes());
            }
        }

        rewritten.extend_from_slice(b"Connection: close\r\n\r\n");
        Ok(rewritten)
    }

    #[must_use]
    pub fn build_connect_response() -> &'static [u8] {
        b"HTTP/1.1 200 Connection Established\r\nProxy-Agent: Caly/1.0\r\n\r\n"
    }
}
