//! Slowloris connection probing circuit breaker.

use std::time::Duration;
use thiserror::Error;
use tokio::net::TcpStream;

#[derive(Error, Debug)]
pub enum HandshakeError {
    #[error("Slowloris first-byte timeout")]
    SlowlorisTimeout,
    #[error("Peer closed before sending handshake")]
    PeerClosed,
    #[error("I/O error: {0}")]
    Io(#[from] std::io::Error),
}

pub const DEFAULT_SLOWLORIS_TIMEOUT: Duration = Duration::from_millis(1000);

pub async fn await_first_byte_guarded(
    stream: &TcpStream,
    timeout: Duration,
) -> Result<u8, HandshakeError> {
    let mut peek_buf = [0u8; 1];
    match tokio::time::timeout(timeout, stream.peek(&mut peek_buf)).await {
        Ok(Ok(n)) if n > 0 => Ok(peek_buf[0]),
        Ok(Ok(_)) => Err(HandshakeError::PeerClosed),
        Ok(Err(e)) => Err(HandshakeError::Io(e)),
        Err(_) => Err(HandshakeError::SlowlorisTimeout),
    }
}
