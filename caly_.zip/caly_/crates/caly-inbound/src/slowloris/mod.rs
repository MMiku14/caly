//! Slowloris protection.

pub mod guard;
pub use guard::{await_first_byte_guarded, HandshakeError, DEFAULT_SLOWLORIS_TIMEOUT};
