//! Linux virtual network TUN device interface.

pub mod device;
pub mod packet;

pub use device::TunDevice;
pub use packet::{parse_ip_packet, IpPacket};
