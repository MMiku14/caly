//! Linux TUN device allocation and file descriptor management.

use std::fs::File;
use std::fs::OpenOptions;
use std::io;
use std::os::unix::fs::OpenOptionsExt;
use std::os::unix::io::{AsRawFd, FromRawFd, RawFd};

pub struct TunDevice {
    name: String,
    fd: RawFd,
    file: File,
}

impl TunDevice {
    #[cfg(target_os = "linux")]
    pub fn create(name: &str, mtu: u16) -> io::Result<Self> {
        let file = OpenOptions::new()
            .read(true)
            .write(true)
            .custom_flags(libc::O_NONBLOCK | libc::O_CLOEXEC)
            .open("/dev/net/tun")?;

        let fd = file.as_raw_fd();

        let mut ifr: libc::ifreq = unsafe { std::mem::zeroed() };
        ifr.ifr_ifru.ifru_flags = (libc::IFF_TUN | libc::IFF_NO_PI) as libc::c_short;

        let name_bytes = name.as_bytes();
        let max_len = ifr.ifr_name.len() - 1;
        let copy_len = name_bytes.len().min(max_len);

        unsafe {
            for (i, &b) in name_bytes[..copy_len].iter().enumerate() {
                ifr.ifr_name[i] = b as libc::c_char;
            }
            ifr.ifr_name[copy_len] = 0;

            let ret = libc::ioctl(fd, libc::TUNSETIFF as libc::c_ulong, &ifr);
            if ret < 0 {
                return Err(io::Error::last_os_error());
            }
        }

        let actual_name = unsafe {
            std::ffi::CStr::from_ptr(ifr.ifr_name.as_ptr())
                .to_string_lossy()
                .into_owned()
        };

        // Configure MTU
        let _ = mtu;

        Ok(Self {
            name: actual_name,
            fd,
            file,
        })
    }

    #[cfg(not(target_os = "linux"))]
    pub fn create(_name: &str, _mtu: u16) -> io::Result<Self> {
        Err(io::Error::new(io::ErrorKind::Unsupported, "TUN is only supported on Linux"))
    }

    #[must_use]
    pub fn name(&self) -> &str {
        &self.name
    }

    #[must_use]
    pub fn raw_fd(&self) -> RawFd {
        self.fd
    }

    pub fn read_packet(&mut self, buf: &mut [u8]) -> io::Result<usize> {
        use std::io::Read;
        self.file.read(buf)
    }

    pub fn write_packet(&mut self, buf: &[u8]) -> io::Result<usize> {
        use std::io::Write;
        self.file.write(buf)
    }
}
