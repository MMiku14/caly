//! Raw IP packet parsing and validation.

use caly_common::metadata::Network;
use std::net::{IpAddr, Ipv4Addr, Ipv6Addr, SocketAddr};

#[derive(Debug, Clone)]
pub struct IpPacket<'a> {
    pub src_addr: SocketAddr,
    pub dst_addr: SocketAddr,
    pub network: Network,
    pub payload: &'a [u8],
}

pub fn parse_ip_packet(buf: &[u8]) -> Option<IpPacket<'_>> {
    if buf.is_empty() {
        return None;
    }

    let version = (buf[0] >> 4) & 0x0F;
    match version {
        4 => parse_ipv4(buf),
        6 => parse_ipv6(buf),
        _ => None,
    }
}

fn parse_ipv4(buf: &[u8]) -> Option<IpPacket<'_>> {
    if buf.len() < 20 { return None; }
    let ihl = (buf[0] & 0x0F) as usize * 4;
    if buf.len() < ihl { return None; }

    let protocol = buf[9];
    let src_ip = Ipv4Addr::new(buf[12], buf[13], buf[14], buf[15]);
    let dst_ip = Ipv4Addr::new(buf[16], buf[17], buf[18], buf[19]);

    let ip_payload = &buf[ihl..];

    match protocol {
        6 => { // TCP
            if ip_payload.len() < 20 { return None; }
            let src_port = u16::from_be_bytes([ip_payload[0], ip_payload[1]]);
            let dst_port = u16::from_be_bytes([ip_payload[2], ip_payload[3]]);
            let tcp_hdr_len = ((ip_payload[12] >> 4) as usize) * 4;
            if ip_payload.len() < tcp_hdr_len { return None; }
            Some(IpPacket {
                src_addr: SocketAddr::new(IpAddr::V4(src_ip), src_port),
                dst_addr: SocketAddr::new(IpAddr::V4(dst_ip), dst_port),
                network: Network::Tcp,
                payload: &ip_payload[tcp_hdr_len..],
            })
        }
        17 => { // UDP
            if ip_payload.len() < 8 { return None; }
            let src_port = u16::from_be_bytes([ip_payload[0], ip_payload[1]]);
            let dst_port = u16::from_be_bytes([ip_payload[2], ip_payload[3]]);
            Some(IpPacket {
                src_addr: SocketAddr::new(IpAddr::V4(src_ip), src_port),
                dst_addr: SocketAddr::new(IpAddr::V4(dst_ip), dst_port),
                network: Network::Udp,
                payload: &ip_payload[8..],
            })
        }
        _ => None,
    }
}

fn parse_ipv6(buf: &[u8]) -> Option<IpPacket<'_>> {
    if buf.len() < 40 { return None; }
    let next_header = buf[6];
    let mut src_octets = [0u8; 16];
    src_octets.copy_from_slice(&buf[8..24]);
    let src_ip = Ipv6Addr::from(src_octets);

    let mut dst_octets = [0u8; 16];
    dst_octets.copy_from_slice(&buf[24..40]);
    let dst_ip = Ipv6Addr::from(dst_octets);

    let ip_payload = &buf[40..];

    match next_header {
        6 => { // TCP
            if ip_payload.len() < 20 { return None; }
            let src_port = u16::from_be_bytes([ip_payload[0], ip_payload[1]]);
            let dst_port = u16::from_be_bytes([ip_payload[2], ip_payload[3]]);
            let tcp_hdr_len = ((ip_payload[12] >> 4) as usize) * 4;
            if ip_payload.len() < tcp_hdr_len { return None; }
            Some(IpPacket {
                src_addr: SocketAddr::new(IpAddr::V6(src_ip), src_port),
                dst_addr: SocketAddr::new(IpAddr::V6(dst_ip), dst_port),
                network: Network::Tcp,
                payload: &ip_payload[tcp_hdr_len..],
            })
        }
        17 => { // UDP
            if ip_payload.len() < 8 { return None; }
            let src_port = u16::from_be_bytes([ip_payload[0], ip_payload[1]]);
            let dst_port = u16::from_be_bytes([ip_payload[2], ip_payload[3]]);
            Some(IpPacket {
                src_addr: SocketAddr::new(IpAddr::V6(src_ip), src_port),
                dst_addr: SocketAddr::new(IpAddr::V6(dst_ip), dst_port),
                network: Network::Udp,
                payload: &ip_payload[8..],
            })
        }
        _ => None,
    }
}
