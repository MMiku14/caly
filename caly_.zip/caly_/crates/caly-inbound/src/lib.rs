//! Caly Inbound — Interception, Sans-IO state machines, HTTP/TProxy adapters, and TUN virtual network driver.
//!
//! # Architecture
//!
//! ```text
//!  ┌──────────────────────────────────────────────────────────┐
//!  │  tun        Linux virtual TUN device driver & IP parser  │
//!  ├──────────────────────────────────────────────────────────┤
//!  │  listener   InboundSpec unified declaration              │
//!  ├──────────────────────────────────────────────────────────┤
//!  │  slowloris  1000ms first-byte timeout circuit breaker    │
//!  ├──────────────────────────────────────────────────────────┤
//!  │  tproxy     Linux IP_TRANSPARENT & self-loop prevention  │
//!  ├──────────────────────────────────────────────────────────┤
//!  │  http       HTTP CONNECT & origin-form close rewrite     │
//!  ├──────────────────────────────────────────────────────────┤
//!  │  socks5     Heapless Sans-IO SOCKS5 + early data         │
//!  └──────────────────────────────────────────────────────────┘
//! ```

pub mod http;
pub mod listener;
pub mod slowloris;
pub mod socks5;
pub mod tproxy;
pub mod tun;

pub use http::{HttpInbound, HttpRequestType};
pub use listener::{InboundSpec, InboundType};
pub use slowloris::{await_first_byte_guarded, HandshakeError, DEFAULT_SLOWLORIS_TIMEOUT};
pub use socks5::{AuthConfig, Socks5Action, Socks5Command, Socks5State, Socks5StateMachine, TargetAddr};
pub use tproxy::{check_routing_loop, create_tproxy_listener, get_original_dst};
pub use tun::{parse_ip_packet, IpPacket, TunDevice};
