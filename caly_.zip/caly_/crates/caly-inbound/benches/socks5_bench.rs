use criterion::{criterion_group, criterion_main, Criterion};
use caly_common::protocol::ProtocolStateMachine;
use caly_inbound::socks5::{AuthConfig, Socks5StateMachine};
use std::hint::black_box;

fn bench_socks5_greeting(c: &mut Criterion) {
    let greeting = [0x05, 0x01, 0x00];
    c.bench_function("socks5/greeting", |b| {
        b.iter(|| {
            let mut sm = Socks5StateMachine::new(AuthConfig::none(), 5000);
            let _ = sm.on_network_input(black_box(&greeting));
        })
    });
}

criterion_group!(benches, bench_socks5_greeting);
criterion_main!(benches);
