use caly_inbound::http::{HttpInbound, HttpRequestType};

#[test]
fn test_http_connect_tunnel() {
    let req = b"CONNECT [::1]:8443 HTTP/1.1\r\nHost: [::1]:8443\r\n\r\n";
    let parsed = HttpInbound::parse_request(req).unwrap().unwrap();

    match parsed {
        HttpRequestType::Connect { host, port, .. } => {
            assert_eq!(host.as_str(), "::1");
            assert_eq!(port, 8443);
        }
        _ => panic!("Expected CONNECT"),
    }
}
