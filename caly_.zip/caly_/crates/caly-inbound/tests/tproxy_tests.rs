use caly_inbound::tproxy::check_routing_loop;

#[test]
fn test_self_loop_detected() {
    let addr = "127.0.0.1:1080".parse().unwrap();
    assert!(check_routing_loop(addr, addr));
}
