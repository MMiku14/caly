use caly_inbound::listener::{InboundSpec, InboundType};
use caly_common::adapter::InboundListener;

#[test]
fn test_inbound_spec_listener_trait() {
    let spec = InboundSpec::new(
        "socks-in",
        InboundType::Socks5,
        "127.0.0.1:1080".parse().unwrap(),
        None,
        true,
    );
    assert_eq!(spec.tag(), "socks-in");
    assert_eq!(spec.listener_type(), "socks5");
}
