use caly_common::metadata::Network;
use caly_inbound::tun::parse_ip_packet;

#[test]
fn test_parse_ipv4_tcp_packet() {
    let mut packet = vec![
        0x45, 0x00, 0x00, 0x28, // IPv4, IHL 5, Total len 40
        0x12, 0x34, 0x40, 0x00, // ID, Flags (DF)
        0x40, 0x06, 0x00, 0x00, // TTL 64, Protocol 6 (TCP), checksum
        192, 168, 1, 100,       // Src IP
        1, 1, 1, 1,             // Dst IP
        0x04, 0x00, 0x01, 0xBB, // Src Port 1024, Dst Port 443
        0x00, 0x00, 0x00, 0x01, // Seq
        0x00, 0x00, 0x00, 0x00, // Ack
        0x50, 0x02, 0x20, 0x00, // Data offset 5 (20 bytes), SYN flag
        0x00, 0x00, 0x00, 0x00, // Checksum, urgent pointer
    ];

    let parsed = parse_ip_packet(&packet).expect("valid TCP packet");
    assert_eq!(parsed.network, Network::Tcp);
    assert_eq!(parsed.src_addr.to_string(), "192.168.1.100:1024");
    assert_eq!(parsed.dst_addr.to_string(), "1.1.1.1:443");
}
