use caly_common::protocol::ProtocolStateMachine;
use caly_inbound::socks5::{AuthConfig, Socks5Command, Socks5State, Socks5StateMachine, TargetAddr};

#[test]
fn test_socks5_domain_connect_flow() {
    let mut sm = Socks5StateMachine::new(AuthConfig::none(), 5000);
    sm.on_network_input(&[0x05, 0x01, 0x00]).unwrap();

    let mut out = [0u8; 16];
    let n = sm.poll_network_output(&mut out).unwrap();
    assert_eq!(&out[..n], &[0x05, 0x00]);

    let mut req = vec![0x05, 0x01, 0x00, 0x03, 10];
    req.extend_from_slice(b"google.com");
    req.extend_from_slice(&443u16.to_be_bytes());

    sm.on_network_input(&req).unwrap();
    assert_eq!(sm.state(), Socks5State::Connecting);
    assert_eq!(sm.command(), Some(Socks5Command::Connect));

    match sm.target().unwrap() {
        TargetAddr::Domain(d, port) => {
            assert_eq!(d.as_str(), "google.com");
            assert_eq!(*port, 443);
        }
        _ => panic!("Expected domain target"),
    }
}
