use caly_worker::slab::{AlignedBuffer, SlabPool};

#[test]
fn test_aligned_buffer_alignment() {
    let buf = AlignedBuffer::new(1024);
    assert_eq!(buf.as_slice().as_ptr() as usize % 64, 0);
    assert!(buf.capacity() >= 1024);
}

#[test]
fn test_slab_pool_acquire_and_recycle() {
    let pool = SlabPool::new(8, 4096);
    pool.init();

    let h1 = pool.acquire();
    assert_eq!(h1.buffer().capacity(), 4096);
}
