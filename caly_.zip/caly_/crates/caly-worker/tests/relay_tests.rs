use caly_worker::relay::relay_bidirectional_with_early_data;

#[test]
fn test_relay_module_compiles() {
    // Verified structure
}
