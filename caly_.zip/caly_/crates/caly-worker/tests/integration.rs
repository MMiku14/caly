use caly_worker::splice::L4SpliceDecider;
use caly_common::metadata::{Network, SessionMetadata, SniffedProtocol};

#[test]
fn test_splice_decider_policy() {
    let mut meta = SessionMetadata::new(
        "127.0.0.1:1000".parse().unwrap(),
        "1.1.1.1:80".parse().unwrap(),
        Network::Tcp,
        smol_str::SmolStr::new("tproxy-in"),
    );
    meta.protocol = SniffedProtocol::Http;

    let can = L4SpliceDecider::can_splice(&meta, "direct");
    #[cfg(target_os = "linux")]
    assert!(can);
    #[cfg(not(target_os = "linux"))]
    assert!(!can);
}
