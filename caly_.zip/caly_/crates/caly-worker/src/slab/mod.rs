//! Memory management and aligned buffer recycling.

pub mod buffer;
pub mod pool;

pub use buffer::AlignedBuffer;
pub use pool::{SlabHandle, SlabPool};
