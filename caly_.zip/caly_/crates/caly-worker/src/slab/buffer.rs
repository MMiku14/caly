//! 64-byte aligned memory buffer for DMA and zero-copy I/O.

#[repr(C, align(64))]
#[derive(Debug)]
pub struct AlignedBuffer {
    data: Box<[u8]>,
    capacity: usize,
}

impl AlignedBuffer {
    #[must_use]
    pub fn new(capacity: usize) -> Self {
        let aligned_cap = (capacity + 63) & !63;
        let data = vec![0u8; aligned_cap].into_boxed_slice();
        Self {
            data,
            capacity: aligned_cap,
        }
    }

    #[inline]
    #[must_use]
    pub fn as_slice(&self) -> &[u8] {
        &self.data
    }

    #[inline]
    pub fn as_mut_slice(&mut self) -> &mut [u8] {
        &mut self.data
    }

    #[inline]
    #[must_use]
    pub fn capacity(&self) -> usize {
        self.capacity
    }
}
