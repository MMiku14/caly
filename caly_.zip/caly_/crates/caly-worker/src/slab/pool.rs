//! Thread-local slab pool with lock-free recycling.

use crate::slab::buffer::AlignedBuffer;
use parking_lot::Mutex;
use std::sync::Arc;

pub struct SlabPool {
    chunk_size: usize,
    capacity: usize,
    free_list: Mutex<Vec<AlignedBuffer>>,
}

impl SlabPool {
    #[must_use]
    pub fn new(capacity: usize, chunk_size: usize) -> Self {
        Self {
            chunk_size,
            capacity,
            free_list: Mutex::new(Vec::with_capacity(capacity)),
        }
    }

    pub fn init(&self) {
        let mut list = self.free_list.lock();
        for _ in 0..self.capacity {
            list.push(AlignedBuffer::new(self.chunk_size));
        }
    }

    #[must_use]
    pub fn acquire(&self) -> SlabHandle {
        let mut list = self.free_list.lock();
        let buf = list.pop().unwrap_or_else(|| AlignedBuffer::new(self.chunk_size));
        SlabHandle {
            buffer: Some(buf),
            pool: None,
        }
    }

    pub fn acquire_managed(self: &Arc<Self>) -> SlabHandle {
        let mut list = self.free_list.lock();
        let buf = list.pop().unwrap_or_else(|| AlignedBuffer::new(self.chunk_size));
        SlabHandle {
            buffer: Some(buf),
            pool: Some(Arc::clone(self)),
        }
    }

    fn release(&self, buf: AlignedBuffer) {
        let mut list = self.free_list.lock();
        if list.len() < self.capacity {
            list.push(buf);
        }
    }
}

pub struct SlabHandle {
    buffer: Option<AlignedBuffer>,
    pool: Option<Arc<SlabPool>>,
}

impl SlabHandle {
    #[inline]
    #[must_use]
    pub fn buffer(&self) -> &AlignedBuffer {
        self.buffer.as_ref().unwrap()
    }

    #[inline]
    pub fn buffer_mut(&mut self) -> &mut AlignedBuffer {
        self.buffer.as_mut().unwrap()
    }
}

impl Drop for SlabHandle {
    fn drop(&mut self) {
        if let (Some(buf), Some(pool)) = (self.buffer.take(), self.pool.take()) {
            pool.release(buf);
        }
    }
}
