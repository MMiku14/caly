//! Bidirectional data relay pump with TCP half-close support, dead-lock prevention, and early data injection.

use caly_common::relay::RelayOutcome;
use caly_transport::ConcreteStream;
use std::io;
use std::time::Duration;
use tokio::io::{AsyncRead, AsyncReadExt, AsyncWrite, AsyncWriteExt};
use tokio::net::TcpStream;

#[derive(Debug, Clone, Copy)]
pub struct RelayTuning {
    pub idle_timeout: Duration,
    pub half_close_grace: Duration,
    pub upstream_close_grace: Duration,
}

impl Default for RelayTuning {
    fn default() -> Self {
        Self {
            idle_timeout: Duration::from_secs(60),
            half_close_grace: Duration::from_secs(5),
            upstream_close_grace: Duration::from_secs(3),
        }
    }
}

pub async fn relay_bidirectional(
    inbound: TcpStream,
    outbound: ConcreteStream,
) -> io::Result<RelayOutcome> {
    relay_bidirectional_with_early_data(inbound, outbound, None).await
}

pub async fn relay_bidirectional_with_early_data(
    inbound: TcpStream,
    outbound: ConcreteStream,
    early_data: Option<&[u8]>,
) -> io::Result<RelayOutcome> {
    relay_bidirectional_safe(inbound, outbound, early_data, RelayTuning::default()).await
}

pub async fn relay_bidirectional_safe(
    inbound: TcpStream,
    mut outbound: ConcreteStream,
    early_data: Option<&[u8]>,
    tuning: RelayTuning,
) -> io::Result<RelayOutcome> {
    let mut early_written = 0u64;

    // Strict write timeout prevents output zero-window hangs
    if let Some(early) = early_data {
        if !early.is_empty() {
            tokio::time::timeout(tuning.idle_timeout, outbound.write_all(early))
                .await
                .map_err(|_| io::Error::new(io::ErrorKind::TimedOut, "Timeout writing early data"))??;
            tokio::time::timeout(tuning.idle_timeout, outbound.flush())
                .await
                .map_err(|_| io::Error::new(io::ErrorKind::TimedOut, "Timeout flushing early data"))??;
            early_written = early.len() as u64;
        }
    }

    let (in_r, in_w) = inbound.into_split();
    let (out_r, out_w) = tokio::io::split(outbound);

    let (c2s_tx, c2s_rx) = tokio::sync::watch::channel(false);
    let (s2c_tx, s2c_rx) = tokio::sync::watch::channel(false);

    let c2s_pump = pump_stream_half_close(in_r, out_w, c2s_tx, s2c_rx, tuning, true);
    let s2c_pump = pump_stream_half_close(out_r, in_w, s2c_tx, c2s_rx, tuning, false);

    let (res_c2s, res_s2c) = tokio::join!(c2s_pump, s2c_pump);

    match (res_c2s, res_s2c) {
        (Ok(c2s_bytes), Ok(s2c_bytes)) => Ok(RelayOutcome {
            bytes_rx: s2c_bytes,
            bytes_tx: c2s_bytes + early_written,
            chunks_rx: 0,
            chunks_tx: 0,
        }),
        (Err(e), _) => Err(e),
        (_, Err(e)) => Err(e),
    }
}

async fn pump_stream_half_close<R, W>(
    mut reader: R,
    mut writer: W,
    my_done_tx: tokio::sync::watch::Sender<bool>,
    mut peer_done_rx: tokio::sync::watch::Receiver<bool>,
    tuning: RelayTuning,
    is_client_to_server: bool,
) -> io::Result<u64>
where
    R: AsyncRead + Unpin,
    W: AsyncWrite + Unpin,
{
    let mut total_bytes = 0u64;
    let mut buf = vec![0u8; 32768];
    let mut grace_deadline: Option<tokio::time::Instant> = None;

    let peer_grace = if is_client_to_server {
        tuning.upstream_close_grace
    } else {
        tuning.half_close_grace
    };

    loop {
        let read_timeout = match grace_deadline {
            Some(dl) => dl.saturating_duration_since(tokio::time::Instant::now()),
            None => tuning.idle_timeout,
        };

        if read_timeout.is_zero() {
            let _ = my_done_tx.send(true);
            return Ok(total_bytes);
        }

        tokio::select! {
            biased;

            read_res = tokio::time::timeout(read_timeout, reader.read(&mut buf)) => {
                match read_res {
                    Ok(Ok(0)) => {
                        let _ = writer.shutdown().await;
                        let _ = my_done_tx.send(true);
                        return Ok(total_bytes);
                    }
                    Ok(Ok(n)) => {
                        writer.write_all(&buf[..n]).await?;
                        total_bytes += n as u64;
                    }
                    Ok(Err(e)) => {
                        let _ = my_done_tx.send(true);
                        return Err(e);
                    }
                    Err(_) => {
                        let _ = my_done_tx.send(true);
                        if grace_deadline.is_some() {
                            return Ok(total_bytes);
                        }
                        return Err(io::Error::new(io::ErrorKind::TimedOut, "Relay idle timeout"));
                    }
                }
            }

            change_res = peer_done_rx.changed() => {
                if change_res.is_ok() && *peer_done_rx.borrow() && grace_deadline.is_none() {
                    grace_deadline = Some(tokio::time::Instant::now() + peer_grace);
                }
            }
        }
    }
}
