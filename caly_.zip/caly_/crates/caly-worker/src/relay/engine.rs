//! Implementation of Caly Common DataRelayEngine trait.

use crate::relay::pump::relay_bidirectional_with_early_data;
use async_trait::async_trait;
use caly_common::relay::{DataRelayEngine, RelayOutcome};
use caly_transport::ConcreteStream;
use std::io;
use tokio::net::TcpStream;

pub struct StandardDataRelay {
    inbound: Option<TcpStream>,
    outbound: Option<ConcreteStream>,
}

impl StandardDataRelay {
    #[must_use]
    pub fn new(inbound: TcpStream, outbound: ConcreteStream) -> Self {
        Self {
            inbound: Some(inbound),
            outbound: Some(outbound),
        }
    }
}

#[async_trait]
impl DataRelayEngine for StandardDataRelay {
    async fn relay(&mut self, early_data: Option<&[u8]>) -> io::Result<RelayOutcome> {
        let inbound = self.inbound.take().ok_or_else(|| {
            io::Error::new(io::ErrorKind::NotConnected, "Relay already executed")
        })?;
        let outbound = self.outbound.take().ok_or_else(|| {
            io::Error::new(io::ErrorKind::NotConnected, "Relay already executed")
        })?;
        relay_bidirectional_with_early_data(inbound, outbound, early_data).await
    }
}
