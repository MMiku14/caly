//! Linux zero-copy splice relay engine.

use crate::splice::pipe::SplicePipe;
use caly_common::metadata::SessionMetadata;
use std::io;
use std::os::unix::io::RawFd;

pub struct L4SpliceDecider;

impl L4SpliceDecider {
    #[must_use]
    pub fn can_splice(meta: &SessionMetadata, outbound_tag: &str) -> bool {
        #[cfg(target_os = "linux")]
        {
            let is_direct = outbound_tag == "direct";
            let no_encryption = true;
            let sniff_complete = meta.protocol != caly_common::metadata::SniffedProtocol::Unknown;
            is_direct && no_encryption && sniff_complete
        }
        #[cfg(not(target_os = "linux"))]
        {
            let _ = (meta, outbound_tag);
            false
        }
    }
}

#[cfg(target_os = "linux")]
pub fn splice_stream_to_stream(
    in_fd: RawFd,
    out_fd: RawFd,
    pipe: &SplicePipe,
    max_bytes: usize,
) -> io::Result<usize> {
    let flags = libc::SPLICE_F_NONBLOCK | libc::SPLICE_F_MOVE;

    let n_in = unsafe {
        libc::splice(
            in_fd,
            std::ptr::null_mut(),
            pipe.write_fd,
            std::ptr::null_mut(),
            max_bytes,
            flags,
        )
    };

    if n_in < 0 {
        return Err(io::Error::last_os_error());
    }
    if n_in == 0 {
        return Ok(0);
    }

    let mut written = 0usize;
    let to_write = n_in as usize;

    while written < to_write {
        let n_out = unsafe {
            libc::splice(
                pipe.read_fd,
                std::ptr::null_mut(),
                out_fd,
                std::ptr::null_mut(),
                to_write - written,
                flags,
            )
        };
        if n_out < 0 {
            return Err(io::Error::last_os_error());
        }
        if n_out == 0 {
            break;
        }
        written += n_out as usize;
    }

    Ok(written)
}
