//! Linux zero-copy splice relaying.

pub mod engine;
pub mod pipe;

pub use engine::L4SpliceDecider;
#[cfg(target_os = "linux")]
pub use engine::splice_stream_to_stream;
pub use pipe::SplicePipe;
