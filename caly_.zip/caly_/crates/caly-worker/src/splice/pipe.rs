//! Anonymous Linux pipe allocation and buffer capacity tuning.

use std::io;
use std::os::unix::io::RawFd;

pub struct SplicePipe {
    pub read_fd: RawFd,
    pub write_fd: RawFd,
}

impl SplicePipe {
    #[cfg(target_os = "linux")]
    pub fn create(capacity: usize) -> io::Result<Self> {
        let mut fds = [0 as libc::c_int; 2];
        let res = unsafe {
            libc::pipe2(
                fds.as_mut_ptr(),
                libc::O_NONBLOCK | libc::O_CLOEXEC,
            )
        };
        if res < 0 {
            return Err(io::Error::last_os_error());
        }

        let read_fd = fds[0];
        let write_fd = fds[1];

        if capacity > 0 {
            unsafe {
                let _ = libc::fcntl(write_fd, libc::F_SETPIPE_SZ, capacity as libc::c_int);
            }
        }

        Ok(Self { read_fd, write_fd })
    }

    #[cfg(not(target_os = "linux"))]
    pub fn create(_capacity: usize) -> io::Result<Self> {
        Err(io::Error::new(io::ErrorKind::Unsupported, "splice is only supported on Linux"))
    }
}

impl Drop for SplicePipe {
    fn drop(&mut self) {
        unsafe {
            let _ = libc::close(self.read_fd);
            let _ = libc::close(self.write_fd);
        }
    }
}
