//! Caly Worker — Thread-per-core I/O scheduler, ByteSlab memory fabric, and zero-copy Linux splice relay.
//!
//! # Architecture
//!
//! ```text
//!  ┌──────────────────────────────────────────────────────────┐
//!  │  scheduler  Thread-per-core pin + SO_REUSEPORT loop      │
//!  ├──────────────────────────────────────────────────────────┤
//!  │  relay      DataRelayEngine + Bi-directional streaming   │
//!  ├──────────────────────────────────────────────────────────┤
//!  │  splice     Linux splice(2) zero-copy kernel pipe relay  │
//!  ├──────────────────────────────────────────────────────────┤
//!  │  slab       64-byte aligned AlignedBuffer & SlabPool     │
//!  └──────────────────────────────────────────────────────────┘
//! ```

pub mod relay;
pub mod scheduler;
pub mod slab;
pub mod splice;

pub use relay::{relay_bidirectional, relay_bidirectional_with_early_data, StandardDataRelay};
pub use scheduler::{set_current_thread_affinity, WorkerLoop};
pub use slab::{AlignedBuffer, SlabHandle, SlabPool};
pub use splice::{L4SpliceDecider, SplicePipe};
