//! CPU affinity and core pinning.

pub fn set_current_thread_affinity(core_id: usize) {
    #[cfg(target_os = "linux")]
    unsafe {
        let cpus = num_cpus();
        if cpus > 0 {
            let mut cpuset: libc::cpu_set_t = std::mem::zeroed();
            libc::CPU_ZERO(&mut cpuset);
            libc::CPU_SET(core_id % cpus, &mut cpuset);
            let tid = libc::pthread_self();
            let _ = libc::pthread_setaffinity_np(tid, std::mem::size_of::<libc::cpu_set_t>(), &cpuset);
        }
    }
    #[cfg(not(target_os = "linux"))]
    let _ = core_id;
}

#[cfg(target_os = "linux")]
pub fn num_cpus() -> usize {
    let n = unsafe { libc::sysconf(libc::_SC_NPROCESSORS_ONLN) };
    if n > 0 { n as usize } else { 1 }
}

#[cfg(not(target_os = "linux"))]
pub fn num_cpus() -> usize { 1 }
