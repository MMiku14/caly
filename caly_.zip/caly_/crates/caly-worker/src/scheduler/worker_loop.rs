//! Thread-per-core Worker Loop driving Sans-IO state machines, SO_REUSEPORT, and async I/O.

use crate::relay::relay_bidirectional_with_early_data;
use crate::scheduler::thread_pin::set_current_thread_affinity;
use crate::slab::SlabPool;
use arc_swap::ArcSwap;
use caly_common::adapter::ProxyAdapter;
use caly_common::dns::DnsResolver;
use caly_common::metadata::Network;
use caly_inbound::http::{HttpInbound, HttpRequestType};
use caly_inbound::socks5::{AuthConfig, Socks5Command, Socks5StateMachine, TargetAddr};
use caly_rules::RuleEngine;
use caly_session::context::SessionContext;
use caly_session::guard::{ConnectionGuard, SessionMetricsTracker};
use caly_transport::StreamBuilder;
use socket2::{Domain, Protocol, Socket, Type};
use std::collections::HashMap;
use std::net::SocketAddr;
use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::Arc;
use std::time::Duration;
use tokio::io::{AsyncReadExt, AsyncWriteExt};
use tokio::net::{TcpListener, TcpStream};

pub struct WorkerLoop {
    pub worker_id: usize,
    listen_addr: SocketAddr,
    slab: Arc<SlabPool>,
    rules: Arc<ArcSwap<RuleEngine>>,
    dns: Arc<dyn DnsResolver>,
    outbounds: Arc<HashMap<String, Arc<dyn ProxyAdapter>>>,
    metrics: Arc<SessionMetricsTracker>,
    session_counter: AtomicU64,
}

impl WorkerLoop {
    #[must_use]
    pub fn new(
        worker_id: usize,
        listen_addr: SocketAddr,
        rules: Arc<ArcSwap<RuleEngine>>,
        dns: Arc<dyn DnsResolver>,
        outbounds: Arc<HashMap<String, Arc<dyn ProxyAdapter>>>,
        metrics: Arc<SessionMetricsTracker>,
    ) -> Self {
        let slab = Arc::new(SlabPool::new(1024, 16384));
        slab.init();

        Self {
            worker_id,
            listen_addr,
            slab,
            rules,
            dns,
            outbounds,
            metrics,
            session_counter: AtomicU64::new(1),
        }
    }

    pub async fn run(self: Arc<Self>) -> Result<(), std::io::Error> {
        set_current_thread_affinity(self.worker_id);

        let domain = if self.listen_addr.is_ipv6() { Domain::IPV6 } else { Domain::IPV4 };
        let socket = Socket::new(domain, Type::STREAM, Some(Protocol::TCP))?;
        socket.set_reuse_address(true)?;

        #[cfg(all(unix, not(target_os = "solaris"), not(target_os = "illumos")))]
        let _ = socket.set_reuse_port(true);

        socket.set_nonblocking(true)?;
        socket.bind(&self.listen_addr.into())?;
        socket.listen(1024)?;

        let std_listener: std::net::TcpListener = socket.into();
        let listener = TcpListener::from_std(std_listener)?;

        tracing::info!(
            worker_id = self.worker_id,
            listen_addr = %self.listen_addr,
            "Worker loop listening with SO_REUSEPORT"
        );

        loop {
            match listener.accept().await {
                Ok((inbound_stream, peer_addr)) => {
                    let worker = Arc::clone(&self);
                    tokio::spawn(async move {
                        worker.handle_connection(inbound_stream, peer_addr).await;
                    });
                }
                Err(err) => {
                    tracing::error!(worker_id = self.worker_id, error = %err, "Accept failure");
                    tokio::time::sleep(Duration::from_millis(50)).await;
                }
            }
        }
    }

    async fn handle_connection(
        &self,
        inbound_stream: TcpStream,
        peer_addr: SocketAddr,
    ) {
        let session_id = self.session_counter.fetch_add(1, Ordering::Relaxed);
        let _guard = ConnectionGuard::new(session_id, Arc::clone(&self.metrics));

        let mut peek_buf = [0u8; 1];
        match inbound_stream.peek(&mut peek_buf).await {
            Ok(1..) => {}
            _ => return,
        }

        let first_byte = peek_buf[0];

        if first_byte == 0x05 {
            self.handle_socks5(session_id, inbound_stream, peer_addr).await;
        } else {
            self.handle_http(session_id, inbound_stream, peer_addr).await;
        }
    }

    async fn handle_socks5(
        &self,
        session_id: u64,
        mut inbound_stream: TcpStream,
        peer_addr: SocketAddr,
    ) {
        let mut socks5 = Socks5StateMachine::new(AuthConfig::none(), 30_000);
        let mut buf = [0u8; 512];

        let target = loop {
            match inbound_stream.read(&mut buf).await {
                Ok(0) => return,
                Ok(n) => {
                    use caly_common::protocol::ProtocolStateMachine;
                    if let Err(e) = socks5.on_network_input(&buf[..n]) {
                        tracing::debug!(session_id, error = ?e, "SOCKS5 input error");
                        socks5.on_error(0x01);
                        let mut out = [0u8; 16];
                        if let Some(out_n) = socks5.poll_network_output(&mut out) {
                            let _ = inbound_stream.write_all(&out[..out_n]).await;
                            let _ = inbound_stream.flush().await;
                        }
                        return;
                    }

                    let mut out = [0u8; 512];
                    while let Some(out_n) = socks5.poll_network_output(&mut out) {
                        if let Err(e) = inbound_stream.write_all(&out[..out_n]).await {
                            tracing::debug!(session_id, error = %e, "SOCKS5 write error");
                            return;
                        }
                    }

                    if let Some(target) = socks5.target().cloned() {
                        break target;
                    }
                }
                Err(e) => {
                    tracing::debug!(session_id, error = %e, "SOCKS5 read failure");
                    return;
                }
            }
        };

        if socks5.command() == Some(Socks5Command::UdpAssociate) {
            let _ = socks5.on_connected(self.listen_addr);
            let mut out = [0u8; 512];
            use caly_common::protocol::ProtocolStateMachine;
            while let Some(out_n) = socks5.poll_network_output(&mut out) {
                let _ = inbound_stream.write_all(&out[..out_n]).await;
            }
            let mut dummy = [0u8; 1];
            while let Ok(n) = inbound_stream.read(&mut dummy).await {
                if n == 0 { break; }
            }
            return;
        }

        let (dst_addr, domain_name) = match target {
            TargetAddr::Ip(addr) => (addr, None),
            TargetAddr::Domain(ref domain, port) => {
                match self.dns.resolve_for_dial(domain.as_str()).await {
                    Ok(ips) if !ips.is_empty() => {
                        (SocketAddr::new(ips[0], port), Some(domain.clone()))
                    }
                    _ => {
                        tracing::warn!(session_id, domain = %domain, "DNS resolution failed");
                        socks5.on_error(0x04);
                        let mut out = [0u8; 16];
                        use caly_common::protocol::ProtocolStateMachine;
                        if let Some(out_n) = socks5.poll_network_output(&mut out) {
                            let _ = inbound_stream.write_all(&out[..out_n]).await;
                            let _ = inbound_stream.flush().await;
                        }
                        return;
                    }
                }
            }
        };

        let mut meta = caly_common::metadata::SessionMetadata::new(
            peer_addr,
            dst_addr,
            Network::Tcp,
            smol_str::SmolStr::new("socks-in"),
        );
        if let Some(d) = domain_name {
            meta.set_domain(d.as_str());
        }

        let rules = self.rules.load();
        let outbound_tag = rules.match_outbound(&meta);

        if outbound_tag == "block" {
            tracing::info!(session_id, target = %dst_addr, "Connection blocked by rule policy");
            socks5.on_error(0x02);
            let mut out = [0u8; 16];
            use caly_common::protocol::ProtocolStateMachine;
            if let Some(out_n) = socks5.poll_network_output(&mut out) {
                let _ = inbound_stream.write_all(&out[..out_n]).await;
                let _ = inbound_stream.flush().await;
            }
            return;
        }

        let builder = match StreamBuilder::new(caly_transport::builder::TransportConfig::default()) {
            Ok(b) => b,
            Err(e) => {
                tracing::error!(session_id, error = %e, "Failed to create stream builder");
                socks5.on_error(0x01);
                let mut out = [0u8; 16];
                use caly_common::protocol::ProtocolStateMachine;
                if let Some(out_n) = socks5.poll_network_output(&mut out) {
                    let _ = inbound_stream.write_all(&out[..out_n]).await;
                    let _ = inbound_stream.flush().await;
                }
                return;
            }
        };

        let outbound_stream = match builder.dial(dst_addr).await {
            Ok(s) => s,
            Err(e) => {
                tracing::warn!(session_id, error = %e, target = %dst_addr, "Outbound dial failed");
                socks5.on_error(0x05);
                let mut out = [0u8; 16];
                use caly_common::protocol::ProtocolStateMachine;
                if let Some(out_n) = socks5.poll_network_output(&mut out) {
                    let _ = inbound_stream.write_all(&out[..out_n]).await;
                    let _ = inbound_stream.flush().await;
                }
                return;
            }
        };

        if let Ok(()) = socks5.on_connected(dst_addr) {
            let mut out = [0u8; 512];
            use caly_common::protocol::ProtocolStateMachine;
            while let Some(out_n) = socks5.poll_network_output(&mut out) {
                let _ = inbound_stream.write_all(&out[..out_n]).await;
            }
            let _ = inbound_stream.flush().await;
        }

        let mut ctx = SessionContext::new(session_id, meta, smol_str::SmolStr::new("socks-in"));

        if let Ok(outcome) = relay_bidirectional_with_early_data(inbound_stream, outbound_stream, None).await {
            ctx.stats.add_traffic(outcome.bytes_rx, outcome.bytes_tx);
            tracing::debug!(session_id, rx_bytes = outcome.bytes_rx, tx_bytes = outcome.bytes_tx, "SOCKS5 session completed");
        }
    }

    async fn handle_http(
        &self,
        session_id: u64,
        mut inbound_stream: TcpStream,
        peer_addr: SocketAddr,
    ) {
        let mut buf = [0u8; 4096];
        let n = match inbound_stream.read(&mut buf).await {
            Ok(n) if n > 0 => n,
            _ => return,
        };

        let req = match HttpInbound::parse_request(&buf[..n]) {
            Ok(Some(r)) => r,
            _ => {
                let _ = inbound_stream.write_all(b"HTTP/1.1 400 Bad Request\r\n\r\n").await;
                return;
            }
        };

        match req {
            HttpRequestType::Connect { host, port, header_end } => {
                let dst_ip = match self.dns.resolve_for_dial(host.as_str()).await {
                    Ok(ips) if !ips.is_empty() => ips[0],
                    _ => {
                        let _ = inbound_stream.write_all(b"HTTP/1.1 502 Bad Gateway\r\n\r\n").await;
                        return;
                    }
                };

                let dst_addr = SocketAddr::new(dst_ip, port);
                let mut meta = caly_common::metadata::SessionMetadata::new(
                    peer_addr,
                    dst_addr,
                    Network::Tcp,
                    smol_str::SmolStr::new("http-in"),
                );
                meta.set_domain(host.as_str());

                let rules = self.rules.load();
                let outbound_tag = rules.match_outbound(&meta);

                if outbound_tag == "block" {
                    let _ = inbound_stream.write_all(b"HTTP/1.1 403 Forbidden\r\n\r\n").await;
                    return;
                }

                let builder = match StreamBuilder::new(caly_transport::builder::TransportConfig::default()) {
                    Ok(b) => b,
                    Err(_) => {
                        let _ = inbound_stream.write_all(b"HTTP/1.1 500 Internal Error\r\n\r\n").await;
                        return;
                    }
                };

                let outbound_stream = match builder.dial(dst_addr).await {
                    Ok(s) => s,
                    Err(_) => {
                        let _ = inbound_stream.write_all(b"HTTP/1.1 504 Gateway Timeout\r\n\r\n").await;
                        return;
                    }
                };

                let _ = inbound_stream.write_all(HttpInbound::build_connect_response()).await;

                let early_data = if n > header_end {
                    Some(&buf[header_end..n])
                } else {
                    None
                };

                let mut ctx = SessionContext::new(session_id, meta, smol_str::SmolStr::new("http-in"));

                if let Ok(outcome) = relay_bidirectional_with_early_data(inbound_stream, outbound_stream, early_data).await {
                    ctx.stats.add_traffic(outcome.bytes_rx, outcome.bytes_tx);
                    tracing::debug!(session_id, rx_bytes = outcome.bytes_rx, tx_bytes = outcome.bytes_tx, "HTTP CONNECT session completed");
                }
            }
            HttpRequestType::Forward { .. } => {
                let _ = inbound_stream.write_all(b"HTTP/1.1 501 Not Implemented\r\n\r\n").await;
            }
        }
    }
}
