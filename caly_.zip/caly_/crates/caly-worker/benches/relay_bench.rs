use criterion::{criterion_group, criterion_main, Criterion};
use caly_worker::slab::SlabPool;
use std::hint::black_box;

fn bench_slab_pool_acquire(c: &mut Criterion) {
    let pool = SlabPool::new(16, 4096);
    pool.init();

    c.bench_function("slab/acquire", |b| {
        b.iter(|| {
            let handle = pool.acquire();
            black_box(handle.buffer().capacity())
        })
    });
}

criterion_group!(benches, bench_slab_pool_acquire);
criterion_main!(benches);
