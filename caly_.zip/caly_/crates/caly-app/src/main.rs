//! Caly Proxy Kernel binary entry point.

use caly_app::bootstrap::start_kernel;
use caly_app::config::CalyConfig;
use clap::Parser;
use std::fs;
use std::path::PathBuf;

#[global_allocator]
static GLOBAL: mimalloc::MiMalloc = mimalloc::MiMalloc;

#[derive(Parser, Debug)]
#[command(name = "caly", version = "0.2.0", about = "High-performance memory-efficient proxy kernel")]
struct Args {
    #[arg(short, long, default_value = "config.json")]
    config: PathBuf,

    #[arg(short = 't', long)]
    test: bool,
}

#[tokio::main]
async fn main() -> Result<(), Box<dyn std::error::Error>> {
    let args = Args::parse();

    tracing_subscriber::fmt()
        .with_env_filter(
            tracing_subscriber::EnvFilter::try_from_default_env()
                .unwrap_or_else(|_| tracing_subscriber::EnvFilter::new("info")),
        )
        .init();

    tracing::info!(path = ?args.config, "Loading Caly configuration");

    let content = fs::read_to_string(&args.config).unwrap_or_else(|_| {
        r#"{
            "version": "1.0",
            "inbounds": [{
                "type": "socks5",
                "tag": "socks-in",
                "listen": "127.0.0.1",
                "port": 1080
            }],
            "outbounds": [
                { "type": "direct", "tag": "direct" },
                { "type": "block", "tag": "block" }
            ],
            "routes": {
                "rules": [
                    { "ip_is_private": true, "outbound": "direct" }
                ],
                "final": "direct"
            }
        }"#.to_string()
    });

    let config: CalyConfig = serde_json::from_str(&content)?;

    if args.test {
        caly_app::config::validate_config(&config)?;
        println!("Configuration is valid.");
        return Ok(());
    }

    start_kernel(config).await?;

    tokio::signal::ctrl_c().await?;
    tracing::info!("Received shutdown signal; graceful termination underway.");

    Ok(())
}
