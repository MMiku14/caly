//! Caly Kernel runner, SIGHUP hot-reload supervisor, and Graceful Drain.

use crate::bootstrap::engine_builder::build_all_engines;
use crate::bootstrap::rlimit::bump_nofile_limit;
use crate::config::model::CalyConfig;
use crate::config::validator::validate_config;
use arc_swap::ArcSwap;
use caly_api::metrics::PrometheusMetrics;
use caly_api::server::run_api_server;
use caly_api::state::{AppState, Epoch};
use caly_common::error::CalyError;
use caly_session::guard::SessionMetricsTracker;
use caly_worker::scheduler::WorkerLoop;
use std::net::SocketAddr;
use std::sync::Arc;
use std::time::Duration;
use tokio::sync::watch;

pub async fn start_kernel(config: CalyConfig) -> Result<(), CalyError> {
    validate_config(&config)?;
    bump_nofile_limit(1_048_576);

    let engines = build_all_engines(&config)?;
    let rules_swap = Arc::new(ArcSwap::new(Arc::clone(&engines.rules)));

    let prom_metrics = Arc::new(PrometheusMetrics::new());
    let session_metrics = Arc::new(SessionMetricsTracker::new());

    let initial_epoch = Epoch::new(1, engines.rules, Arc::clone(&engines.dns), Arc::clone(&engines.outbounds));
    let app_state = Arc::new(AppState::new(initial_epoch, prom_metrics));

    let secret = config.experimental.as_ref()
        .and_then(|e| e.clash_api.as_ref())
        .and_then(|c| c.secret.clone());

    if let Some(ref exp) = config.experimental {
        if let Some(ref met) = exp.metrics {
            if let Some(ref prom) = met.prometheus {
                if prom.enabled {
                    if let Ok(addr) = prom.listen.parse::<SocketAddr>() {
                        let state = Arc::clone(&app_state);
                        let s_clone = secret.clone();
                        tokio::spawn(async move {
                            let _ = run_api_server(addr, state, s_clone).await;
                        });
                    }
                }
            }
        }
    }

    let cpus = std::thread::available_parallelism().map(|n| n.get()).unwrap_or(1).clamp(1, 64);
    tracing::info!(workers_per_inbound = cpus, "Spawning Caly worker loops");

    let (shutdown_tx, shutdown_rx) = watch::channel(false);

    for ib in &config.inbounds {
        let listen_ip = ib.listen.parse::<std::net::IpAddr>().unwrap_or(std::net::IpAddr::V4(std::net::Ipv4Addr::LOCALHOST));
        let listen_addr = SocketAddr::new(listen_ip, ib.port);

        for worker_id in 0..cpus {
            let worker = Arc::new(WorkerLoop::new(
                worker_id,
                listen_addr,
                Arc::clone(&rules_swap),
                Arc::clone(&engines.dns),
                Arc::clone(&engines.outbounds),
                Arc::clone(&session_metrics),
            ));

            let mut rx = shutdown_rx.clone();
            tokio::spawn(async move {
                tokio::select! {
                    _ = rx.changed() => {
                        tracing::debug!(worker_id, "Worker received shutdown signal");
                    }
                    res = worker.run() => {
                        if let Err(e) = res {
                            tracing::error!(worker_id, listen_addr = %listen_addr, error = %e, "Worker loop terminated");
                        }
                    }
                }
            });
        }
    }

    tracing::info!("Caly Kernel bootstrap completed. Running.");
    Ok(())
}
