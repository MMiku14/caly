//! Bootstrap engines constructor.

use crate::config::model::CalyConfig;
use caly_common::adapter::ProxyAdapter;
use caly_common::dns::DnsResolver as DnsResolverTrait;
use caly_common::error::CalyError;
use caly_dns::{Config as DnsInternalConfig, DnsResolver};
use caly_outbound::block::BlockAdapter;
use caly_outbound::direct::DirectAdapter;
use caly_outbound::group::SelectorAdapter;
use caly_outbound::registry::InMemoryOutboundRegistry;
use caly_outbound::shadowsocks::ShadowsocksAdapter;
use caly_outbound::socks5::Socks5ClientAdapter;
use caly_outbound::vless::VlessAdapter;
use caly_rules::engine::RuleEngine;
use caly_rules::logic::{RuleCondition, RuleItem};
use smol_str::SmolStr;
use std::collections::HashMap;
use std::net::SocketAddr;
use std::sync::Arc;

pub struct BuiltEngines {
    pub dns: Arc<dyn DnsResolverTrait>,
    pub rules: Arc<RuleEngine>,
    pub outbounds: Arc<HashMap<String, Arc<dyn ProxyAdapter>>>,
}

pub fn build_all_engines(config: &CalyConfig) -> Result<BuiltEngines, CalyError> {
    let dns_json = if let Some(ref dns) = config.dns {
        serde_json::to_string(dns).unwrap_or_else(|_| "{}".to_string())
    } else {
        r#"{"servers":[{"tag":"local","address":"127.0.0.1:53"}],"final_tag":"local"}"#.to_string()
    };

    let dns_cfg = DnsInternalConfig::from_json(&dns_json).map_err(|e| CalyError::Config(e.to_string()))?;
    let dns_resolver = Arc::new(DnsResolver::from_config(&dns_cfg).map_err(|e| CalyError::Config(e.to_string()))?);

    let mut reg = InMemoryOutboundRegistry::new();
    let mut outbounds_map: HashMap<String, Arc<dyn ProxyAdapter>> = HashMap::new();

    for ob in &config.outbounds {
        let adapter: Arc<dyn ProxyAdapter> = match ob.r#type.as_str() {
            "direct" => Arc::new(DirectAdapter::new(&ob.tag)),
            "block" => Arc::new(BlockAdapter::new(&ob.tag)),
            "vless" => {
                let server = ob.server.as_deref().unwrap_or("127.0.0.1");
                let port = ob.server_port.unwrap_or(443);
                let server_addr = format!("{server}:{port}").parse::<SocketAddr>().unwrap_or_else(|_| "127.0.0.1:443".parse().unwrap());
                let mut uuid = [0u8; 16];
                if let Some(ref u_str) = ob.password {
                    let bytes = u_str.as_bytes();
                    let n = bytes.len().min(16);
                    uuid[..n].copy_from_slice(&bytes[..n]);
                }
                Arc::new(VlessAdapter::new(
                    &ob.tag,
                    server_addr,
                    uuid,
                    Some("xtls-rprx-vision"),
                    Some(server),
                    None,
                ))
            }
            "ss2022" => {
                let server = ob.server.as_deref().unwrap_or("127.0.0.1");
                let port = ob.server_port.unwrap_or(8388);
                let server_addr = format!("{server}:{port}").parse::<SocketAddr>().unwrap_or_else(|_| "127.0.0.1:8388".parse().unwrap());
                let mut psk = [0u8; 32];
                if let Some(ref pass) = ob.password {
                    let bytes = pass.as_bytes();
                    let n = bytes.len().min(32);
                    psk[..n].copy_from_slice(&bytes[..n]);
                }
                Arc::new(ShadowsocksAdapter::new(&ob.tag, server_addr, psk))
            }
            "socks5" => {
                let server = ob.server.as_deref().unwrap_or("127.0.0.1");
                let port = ob.server_port.unwrap_or(1080);
                let server_addr = format!("{server}:{port}").parse::<SocketAddr>().unwrap_or_else(|_| "127.0.0.1:1080".parse().unwrap());
                Arc::new(Socks5ClientAdapter::new(&ob.tag, server_addr, None, None))
            }
            _ => Arc::new(DirectAdapter::new(&ob.tag)),
        };
        reg.insert(&ob.tag, Arc::clone(&adapter));
        outbounds_map.insert(ob.tag.clone(), adapter);
    }

    let reg_arc = Arc::new(reg);
    for ob in &config.outbounds {
        if ob.r#type == "selector" {
            let candidates: Vec<&str> = ob.outbounds.as_ref().map_or(vec![], |v| v.iter().map(String::as_str).collect());
            let selector = Arc::new(SelectorAdapter::new(&ob.tag, candidates, Arc::clone(&reg_arc)));
            outbounds_map.insert(ob.tag.clone(), selector);
        }
    }

    let mut rule_items = Vec::new();
    let mut final_tag = "direct".to_string();
    if let Some(ref routes) = config.routes {
        final_tag = routes.r#final.clone();
        for r in &routes.rules {
            if let Some(ref suffixes) = r.domain_suffix {
                for s in suffixes {
                    rule_items.push(RuleItem::new(
                        RuleCondition::DomainSuffix(SmolStr::new(s)),
                        &r.outbound,
                    ));
                }
            }
            if let Some(ref keywords) = r.domain_keyword {
                for k in keywords {
                    rule_items.push(RuleItem::new(
                        RuleCondition::DomainKeyword(SmolStr::new(k)),
                        &r.outbound,
                    ));
                }
            }
            if let Some(ref cidrs) = r.ip_cidr {
                for c in cidrs {
                    if let Ok(net) = c.parse::<ipnet::IpNet>() {
                        rule_items.push(RuleItem::new(RuleCondition::IpCidr(net), &r.outbound));
                    }
                }
            }
            if r.ip_is_private.unwrap_or(false) {
                rule_items.push(RuleItem::new(RuleCondition::IpIsPrivate, &r.outbound));
            }
        }
    }

    let rules = Arc::new(RuleEngine::new(rule_items, &final_tag));

    Ok(BuiltEngines {
        dns: dns_resolver,
        rules,
        outbounds: Arc::new(outbounds_map),
    })
}
