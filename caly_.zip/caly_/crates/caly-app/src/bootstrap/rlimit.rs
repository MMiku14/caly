//! System file descriptor resource limit tuning.

pub fn bump_nofile_limit(desired: u64) {
    #[cfg(target_os = "linux")]
    unsafe {
        let mut rlim: libc::rlimit = std::mem::zeroed();
        if libc::getrlimit(libc::RLIMIT_NOFILE, &mut rlim) == 0 {
            let max_possible = rlim.rlim_max;
            let target = desired.min(max_possible as u64);
            rlim.rlim_cur = target as libc::rlim_t;
            let _ = libc::setrlimit(libc::RLIMIT_NOFILE, &rlim);
        }
    }
    #[cfg(not(target_os = "linux"))]
    let _ = desired;
}
