//! Configuration schema and validation.

pub mod model;
pub mod validator;

pub use model::{CalyConfig, InboundConfig, OutboundConfig, RoutesConfig};
pub use validator::validate_config;
