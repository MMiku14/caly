//! Declarative configuration model.

use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CalyConfig {
    pub version: String,
    pub log: Option<LogConfig>,
    pub dns: Option<DnsConfig>,
    pub inbounds: Vec<InboundConfig>,
    pub outbounds: Vec<OutboundConfig>,
    pub routes: Option<RoutesConfig>,
    pub experimental: Option<ExperimentalConfig>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct LogConfig {
    #[serde(default = "default_log_level")]
    pub level: String,
    #[serde(default = "default_log_format")]
    pub format: String,
    #[serde(default = "default_log_output")]
    pub output: String,
    #[serde(default = "default_true")]
    pub timestamp: bool,
    #[serde(default)]
    pub caller: bool,
}

fn default_log_level() -> String { "info".to_string() }
fn default_log_format() -> String { "json".to_string() }
fn default_log_output() -> String { "stdout".to_string() }
fn default_true() -> bool { true }

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DnsConfig {
    pub servers: Vec<DnsServerConfig>,
    #[serde(default)]
    pub rules: Vec<DnsRuleConfig>,
    pub fakeip: Option<FakeIpConfig>,
    pub cache: Option<DnsCacheConfig>,
    #[serde(default = "default_final_dns")]
    pub r#final: String,
}

fn default_final_dns() -> String { "local".to_string() }

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DnsServerConfig {
    pub tag: String,
    pub address: String,
    #[serde(default = "default_strategy")]
    pub strategy: String,
    #[serde(default = "default_direct")]
    pub detour: String,
}

fn default_strategy() -> String { "prefer_ipv4".to_string() }
fn default_direct() -> String { "direct".to_string() }

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DnsRuleConfig {
    #[serde(default)]
    pub domain_suffix: Vec<String>,
    #[serde(default)]
    pub domain_keyword: Vec<String>,
    pub server: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct FakeIpConfig {
    #[serde(default = "default_true")]
    pub enabled: bool,
    #[serde(default = "default_fakeip_inet4")]
    pub inet4_range: String,
    #[serde(default = "default_fakeip_ttl")]
    pub global_ttl: u64,
}

fn default_fakeip_inet4() -> String { "198.18.0.0/15".to_string() }
fn default_fakeip_ttl() -> u64 { 300 }

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DnsCacheConfig {
    #[serde(default = "default_true")]
    pub enabled: bool,
    #[serde(default = "default_cache_capacity")]
    pub capacity: usize,
    #[serde(default = "default_true")]
    pub optimistic: bool,
    #[serde(default = "default_optimistic_ttl")]
    pub optimistic_ttl: u64,
}

fn default_cache_capacity() -> usize { 4096 }
fn default_optimistic_ttl() -> u64 { 60 }

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct InboundConfig {
    pub r#type: String,
    pub tag: String,
    #[serde(default = "default_listen_addr")]
    pub listen: String,
    pub port: u16,
    #[serde(default = "default_true")]
    pub udp: bool,
    #[serde(default = "default_true")]
    pub sniff: bool,
    #[serde(default = "default_sniff_timeout")]
    pub sniff_timeout: String,
    pub username: Option<String>,
    pub password: Option<String>,
}

fn default_listen_addr() -> String { "127.0.0.1".to_string() }
fn default_sniff_timeout() -> String { "300ms".to_string() }

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct OutboundConfig {
    pub r#type: String,
    pub tag: String,
    pub server: Option<String>,
    pub server_port: Option<u16>,
    pub method: Option<String>,
    pub password: Option<String>,
    pub outbounds: Option<Vec<String>>,
    pub url: Option<String>,
    pub interval: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RoutesConfig {
    pub rules: Vec<RouteRuleItemConfig>,
    #[serde(default = "default_direct")]
    pub r#final: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RouteRuleItemConfig {
    pub domain: Option<Vec<String>>,
    pub domain_suffix: Option<Vec<String>>,
    pub domain_keyword: Option<Vec<String>>,
    pub ip_cidr: Option<Vec<String>>,
    pub ip_is_private: Option<bool>,
    pub port: Option<Vec<u16>>,
    pub protocol: Option<String>,
    pub outbound: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ExperimentalConfig {
    pub clash_api: Option<ClashApiConfig>,
    pub metrics: Option<MetricsConfig>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ClashApiConfig {
    pub external_controller: String,
    pub secret: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MetricsConfig {
    pub prometheus: Option<PrometheusConfig>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PrometheusConfig {
    #[serde(default = "default_true")]
    pub enabled: bool,
    pub listen: String,
}
