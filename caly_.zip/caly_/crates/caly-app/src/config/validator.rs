//! Multi-tier semantic configuration validator.

use crate::config::model::CalyConfig;
use caly_common::error::CalyError;
use std::collections::HashSet;

pub fn validate_config(cfg: &CalyConfig) -> Result<(), CalyError> {
    if cfg.version != "1.0" {
        return Err(CalyError::Config(format!("Unsupported config version: {}", cfg.version)));
    }

    if cfg.inbounds.is_empty() {
        return Err(CalyError::Config("At least one inbound must be defined".to_string()));
    }

    if cfg.outbounds.is_empty() {
        return Err(CalyError::Config("At least one outbound must be defined".to_string()));
    }

    let mut outbound_tags = HashSet::new();
    for ob in &cfg.outbounds {
        if !outbound_tags.insert(&ob.tag) {
            return Err(CalyError::Config(format!("Duplicate outbound tag: {}", ob.tag)));
        }

        if ob.r#type == "selector" {
            if let Some(ref candidates) = ob.outbounds {
                if candidates.contains(&ob.tag) {
                    return Err(CalyError::Config(format!(
                        "Selector outbound '{}' cannot contain itself in candidate list",
                        ob.tag
                    )));
                }
            }
        }
    }

    let mut inbound_tags = HashSet::new();
    for ib in &cfg.inbounds {
        if !inbound_tags.insert(&ib.tag) {
            return Err(CalyError::Config(format!("Duplicate inbound tag: {}", ib.tag)));
        }
        if ib.port == 0 {
            return Err(CalyError::Config(format!("Inbound '{}' port cannot be 0", ib.tag)));
        }
    }

    if let Some(ref routes) = cfg.routes {
        if !outbound_tags.contains(&routes.r#final) {
            return Err(CalyError::Config(format!(
                "Routes final outbound tag '{}' not found in declared outbounds",
                routes.r#final
            )));
        }

        for (idx, rule) in routes.rules.iter().enumerate() {
            if !outbound_tags.contains(&rule.outbound) {
                return Err(CalyError::Config(format!(
                    "Rule #{} targets non-existent outbound: '{}'",
                    idx, rule.outbound
                )));
            }

            if let Some(ref cidrs) = rule.ip_cidr {
                for c in cidrs {
                    if c.parse::<ipnet::IpNet>().is_err() {
                        return Err(CalyError::Config(format!(
                            "Rule #{} contains invalid IP CIDR notation: '{}'",
                            idx, c
                        )));
                    }
                }
            }
        }
    }

    Ok(())
}
