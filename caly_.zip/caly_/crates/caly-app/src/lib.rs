//! Caly App — Application bootstrap, configuration validation, and kernel runtime supervisor.
//!
//! # Architecture
//!
//! ```text
//!  ┌──────────────────────────────────────────────────────────┐
//!  │  bootstrap  rlimit bump, engine compilation, kernel run  │
//!  ├──────────────────────────────────────────────────────────┤
//!  │  config     Declarative schema & 3-Tier validation       │
//!  └──────────────────────────────────────────────────────────┘
//! ```

pub mod bootstrap;
pub mod config;

pub use bootstrap::{build_all_engines, bump_nofile_limit, start_kernel};
pub use config::{validate_config, CalyConfig};
