use caly_app::config::{validate_config, CalyConfig};

#[test]
fn test_default_config_parsing() {
    let json = r#"{
        "version": "1.0",
        "inbounds": [{
            "type": "socks5",
            "tag": "socks-in",
            "listen": "127.0.0.1",
            "port": 1080
        }],
        "outbounds": [
            { "type": "direct", "tag": "direct" },
            { "type": "block", "tag": "block" }
        ],
        "routes": {
            "rules": [
                { "ip_is_private": true, "outbound": "direct" }
            ],
            "final": "direct"
        }
    }"#;

    let config: CalyConfig = serde_json::from_str(json).unwrap();
    assert!(validate_config(&config).is_ok());
}
