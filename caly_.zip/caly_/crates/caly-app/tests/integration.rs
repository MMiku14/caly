use caly_app::bootstrap::build_all_engines;
use caly_app::config::CalyConfig;

#[test]
fn test_engine_building() {
    let json = r#"{
        "version": "1.0",
        "inbounds": [{ "type": "socks5", "tag": "s", "port": 1080 }],
        "outbounds": [{ "type": "direct", "tag": "direct" }],
        "routes": { "rules": [], "final": "direct" }
    }"#;

    let config: CalyConfig = serde_json::from_str(json).unwrap();
    assert!(build_all_engines(&config).is_ok());
}
