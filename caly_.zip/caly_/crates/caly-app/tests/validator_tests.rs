use caly_app::config::{validate_config, CalyConfig};

#[test]
fn test_validator_rejects_selector_self_loop() {
    let json = r#"{
        "version": "1.0",
        "inbounds": [{ "type": "socks5", "tag": "s", "port": 1080 }],
        "outbounds": [
            { "type": "selector", "tag": "proxy", "outbounds": ["proxy", "direct"] },
            { "type": "direct", "tag": "direct" }
        ]
    }"#;

    let config: CalyConfig = serde_json::from_str(json).unwrap();
    assert!(validate_config(&config).is_err());
}
