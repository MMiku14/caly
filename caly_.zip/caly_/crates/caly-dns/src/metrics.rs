//! Metrics — process-lifetime and per-epoch counters.
//!
//! Shared by the whole crate: the upstream layer and the resolver/rule
//! layers both report into the same counter set, so this is not an
//! upstream-specific concern. It lives at the crate root (as a private
//! module re-exported by `lib.rs`) precisely because every layer above
//! `foundation` needs to bump the same counters.
//!
//! # Two counter scopes
//!
//! The distinction matters for reload.
//!
//! * **[`ProcessStats`]** — counters that describe the process's whole
//!   life. `client_queries`, `dial_queries`, `errors`. Reloading does
//!   **not** reset them; they are the answer to "how many queries has
//!   this process served".
//!
//! * **[`EpochStats`]** — counters tied to a configuration. `blocked`,
//!   `fallback_hits`, `dnssec_bogus`. Reloading starts them over,
//!   because the new config may have entirely different rules and the
//!   old counts would be meaningless.
//!
//! Conflating the two was a bug in the previous revision: DNSSEC
//! counters kept incrementing after DNSSEC was disabled, and reload
//! silently reset the total query count.
//!
//! # Cache-line alignment
//!
//! Each counter occupies its own 64-byte cache line: `AtomicU64` + 7×
//! `u64` of padding. `repr(C)` pins the field order; without it the
//! compiler could legally reorder the fields and destroy the padding.
//! False sharing between the threads that bump different counters
//! would otherwise dominate the cost of the increments themselves.

use std::sync::atomic::{AtomicU64, Ordering};

// ─────────────────────────────────────────────────────────────────────────────
// Process-lifetime stats
// ─────────────────────────────────────────────────────────────────────────────

/// Counters that survive reloads. Cache-line aligned to prevent false
/// sharing between the threads that bump them.
#[derive(Debug, Default)]
#[repr(C, align(64))]
pub struct ProcessStats {
    /// Queries received on the Client Plane.
    pub client_queries: AtomicU64,
    _pad0: [u64; 7],
    /// Queries received on the Dial Plane.
    pub dial_queries: AtomicU64,
    _pad1: [u64; 7],
    /// Cache lookups that returned a value (fresh or stale).
    pub cache_hits: AtomicU64,
    _pad2: [u64; 7],
    /// Cache lookups that missed entirely.
    pub cache_misses: AtomicU64,
    _pad3: [u64; 7],
    /// Queries that ended in an error of any kind.
    pub errors: AtomicU64,
    _pad4: [u64; 7],
    /// `FakeIP` allocations that failed due to pool exhaustion.
    pub fakeip_exhausted: AtomicU64,
    _pad5: [u64; 7],
}

impl ProcessStats {
    /// Create a fresh counter set.
    #[must_use]
    pub fn new() -> Self {
        Self::default()
    }

    #[inline]
    /// Increment the client-plane query counter.
    pub fn inc_client(&self) {
        self.client_queries.fetch_add(1, Ordering::Relaxed);
    }

    #[inline]
    /// Increment the dial-plane query counter.
    pub fn inc_dial(&self) {
        self.dial_queries.fetch_add(1, Ordering::Relaxed);
    }

    #[inline]
    /// Increment the cache-hit counter.
    pub fn inc_hit(&self) {
        self.cache_hits.fetch_add(1, Ordering::Relaxed);
    }

    #[inline]
    /// Increment the cache-miss counter.
    pub fn inc_miss(&self) {
        self.cache_misses.fetch_add(1, Ordering::Relaxed);
    }

    #[inline]
    /// Increment the error counter.
    pub fn inc_error(&self) {
        self.errors.fetch_add(1, Ordering::Relaxed);
    }

    /// Record a `FakeIP` allocation that failed because the pool was
    /// exhausted. Exposed so operators can alert on it.
    #[inline]
    pub fn inc_fakeip_exhausted(&self) {
        self.fakeip_exhausted.fetch_add(1, Ordering::Relaxed);
    }

    /// Increment one counter by one.
    #[inline]
    pub fn bump(counter: &AtomicU64) {
        counter.fetch_add(1, Ordering::Relaxed);
    }

    /// Read one counter.
    #[inline]
    #[must_use]
    pub fn read(counter: &AtomicU64) -> u64 {
        counter.load(Ordering::Relaxed)
    }

    /// Total queries across both planes.
    #[must_use]
    pub fn total_queries(&self) -> u64 {
        self.client_queries.load(Ordering::Relaxed) + self.dial_queries.load(Ordering::Relaxed)
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Per-epoch stats
// ─────────────────────────────────────────────────────────────────────────────

/// Counters reset on every reload.
///
/// Grouped by theme so the display code can lay them out logically
/// without a flat list of twenty fields.
#[derive(Debug, Default)]
pub struct EpochStats {
    // ── Routing ─────────────────────────────────────────────────────
    /// Queries blocked by a rule.
    pub blocked: AtomicU64,
    /// Queries answered from a predefined rule.
    pub predefined_serves: AtomicU64,

    // ── Fallback ────────────────────────────────────────────────────
    /// Primary upstream failed; fallback succeeded.
    pub fallback_hits: AtomicU64,

    // ── Serve-stale ─────────────────────────────────────────────────
    /// Upstream failed; a stale cache entry was served.
    pub serve_stale_serves: AtomicU64,

    // ── Prefetch ────────────────────────────────────────────────────
    /// Prefetch tasks that ran to completion.
    pub prefetch_refreshes: AtomicU64,
    /// Prefetch candidates skipped because the concurrency cap was hit.
    pub prefetch_skipped: AtomicU64,

    // ── DNSSEC ──────────────────────────────────────────────────────
    /// Answers whose signature validated against a trust anchor.
    pub dnssec_secure: AtomicU64,
    /// Answers with no DNSSEC evidence.
    pub dnssec_insecure: AtomicU64,
    /// Answers whose signature failed validation.
    pub dnssec_bogus: AtomicU64,
}

impl EpochStats {
    /// Create a fresh counter set.
    #[must_use]
    pub fn new() -> Self {
        Self::default()
    }

    /// Reset all epoch-tied counters in-place.
    ///
    /// `Relaxed` throughout: the counters are independent and no
    /// cross-counter ordering is observed by any reader.
    pub fn reset(&self) {
        self.blocked.store(0, Ordering::Relaxed);
        self.predefined_serves.store(0, Ordering::Relaxed);
        self.fallback_hits.store(0, Ordering::Relaxed);
        self.serve_stale_serves.store(0, Ordering::Relaxed);
        self.prefetch_refreshes.store(0, Ordering::Relaxed);
        self.prefetch_skipped.store(0, Ordering::Relaxed);
        self.dnssec_secure.store(0, Ordering::Relaxed);
        self.dnssec_insecure.store(0, Ordering::Relaxed);
        self.dnssec_bogus.store(0, Ordering::Relaxed);
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn process_stats_accumulate() {
        let stats = ProcessStats::new();
        ProcessStats::bump(&stats.client_queries);
        ProcessStats::bump(&stats.client_queries);
        ProcessStats::bump(&stats.dial_queries);
        assert_eq!(stats.total_queries(), 3);
    }

    #[test]
    fn read_returns_current_value() {
        let counter = AtomicU64::new(42);
        assert_eq!(ProcessStats::read(&counter), 42);
    }

    #[test]
    fn epoch_stats_are_independent() {
        let a = EpochStats::new();
        let b = EpochStats::new();
        a.blocked.fetch_add(5, Ordering::Relaxed);
        assert_eq!(a.blocked.load(Ordering::Relaxed), 5);
        assert_eq!(b.blocked.load(Ordering::Relaxed), 0);
    }

    #[test]
    fn stats_are_cache_line_aligned() {
        assert_eq!(std::mem::align_of::<ProcessStats>(), 64);
        assert_eq!(std::mem::size_of::<ProcessStats>() % 64, 0);
    }
}