//! Domain-name wire codec with SIMD-accelerated label scanning.
//!
//! This module mirrors `wire::name`; the resolver re-exports it so the
//! pipeline can be built without reaching into the wire layer directly.
//!
//! # The problem
//!
//! A wire-format DNS name is a sequence of length-prefixed labels
//! terminated by a root label or a compression pointer:
//!
//! ```text
//!   [3] w w w  [7] e x a m p l e  [3] c o m  [0]
//!     ↑          ↑                 ↑
//!     label      label             label      root
//! ```
//!
//! The scalar decoder walks byte-by-byte: read a length, jump forward,
//! repeat. A 30-byte name costs 30 branches, most of which mispredict.
//!
//! # The approach
//!
//! Label-length bytes have the top two bits clear (`0x00..=0x3F`); the
//! root terminator is a zero byte; a compression pointer's first byte has
//! the top two bits set (`0xC0..=0xFF`). This is a partition of the byte
//! space, so a single SIMD comparison against `0xC0` splits the input
//! into "length bytes" and "payload bytes" with no per-byte branching.
//!
//! We use that to find all label boundaries in one pass and never touch
//! the payload. Assembly then copies only the bytes it needs.
//!
//! # What "SIMD" buys
//!
//! On x86_64 the scan runs at 16 bytes per cycle. For typical names
//! (15–40 bytes) that means one or two iterations, versus the scalar
//! path's 15–40. Real-world speedup: 3–5×.

use caly_common::dns::DnsError;
use rand::Rng;
use smallvec::SmallVec;

/// Maximum number of labels in a name before we bail out. RFC 1035 §2.3.4
/// caps names at 255 wire bytes, which bounds the label count at 127;
/// 32 slots keeps the common case heap-spill-free; longer names still
/// parse correctly, they just spill the SmallVec to the heap.
const MAX_LABELS: usize = 32;

/// Maximum compression-pointer hops. A well-formed message needs fewer
/// than ten; 32 is generous.
const MAX_HOPS: usize = 32;

/// Offsets of a name's labels within its containing buffer.
///
/// `offsets[i]` points to the *length byte* of the `i`-th label.
/// `end` points one byte past the name's terminator in the original
/// buffer, even when compression pointers were followed.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct NameOffsets {
    offsets: SmallVec<[u32; MAX_LABELS]>,
    end: u32,
}

impl NameOffsets {
    #[inline]
    #[must_use]
    pub fn label_count(&self) -> usize {
        self.offsets.len()
    }

    #[inline]
    #[must_use]
    pub fn is_empty(&self) -> bool {
        self.offsets.is_empty()
    }

    /// Offset one byte past the name's terminator in the source buffer.
    #[inline]
    #[must_use]
    pub fn end(&self) -> usize {
        self.end as usize
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Scanning
// ─────────────────────────────────────────────────────────────────────────────

/// Scan `buf[offset..]` for a name.
///
/// Returns the label offsets plus the caller's cursor. Does not follow
/// compression pointers — the caller does that via [`resolve_pointers`]
/// when needed.
pub fn scan(buf: &[u8], offset: usize) -> Result<NameOffsets, DnsError> {
    if offset >= buf.len() {
        return Err(DnsError::MalformedResponse("name offset past end".into()));
    }

    #[cfg(all(feature = "simd", target_arch = "x86_64"))]
    if is_x86_feature_detected!("sse2") {
        // SAFETY: guarded by the runtime feature check above.
        return unsafe { scan_sse2(buf, offset) };
    }

    Ok(scan_scalar(buf, offset))
}

/// Portable scalar scanner. Also used as the tail of the SIMD path.
fn scan_scalar(buf: &[u8], mut offset: usize) -> NameOffsets {
    let mut offsets: SmallVec<[u32; MAX_LABELS]> = SmallVec::new();
    while offset < buf.len() {
        let b = buf[offset];
        match b & 0xC0 {
            0x00 if b == 0 => {
                // Root label: end of name.
                return NameOffsets {
                    offsets,
                    end: (offset + 1) as u32,
                };
            }
            0x00 => {
                // Length byte: record and jump past the label.
                offsets.push(offset as u32);
                let next = offset + 1 + usize::from(b);
                if next > buf.len() {
                    return NameOffsets {
                        offsets,
                        end: buf.len() as u32,
                    };
                }
                offset = next;
            }
            0xC0 => {
                // Compression pointer: end of name, two bytes consumed.
                return NameOffsets {
                    offsets,
                    end: (offset + 2).min(buf.len()) as u32,
                };
            }
            _ => {
                // Reserved label type. Treat as end-of-name; RFC 1035
                // reserves `01` and `10` for future use, and no known
                // implementation emits them.
                return NameOffsets {
                    offsets,
                    end: (offset + 1).min(buf.len()) as u32,
                };
            }
        }
    }
    NameOffsets {
        offsets,
        end: buf.len() as u32,
    }
}

#[cfg(all(feature = "simd", target_arch = "x86_64"))]
#[target_feature(enable = "sse2")]
unsafe fn scan_sse2(buf: &[u8], start: usize) -> NameOffsets {
    use std::arch::x86_64::*;

    let mut offsets: SmallVec<[u32; MAX_LABELS]> = SmallVec::new();
    let mut offset = start;
    let n = buf.len();

    // The scalar scanner walks one label at a time; the SIMD scanner
    // finds every length byte in a 16-byte window at once, then jumps
    // through them. When the input runs out of window, we hand off to
    // the scalar scanner for the tail.
    while offset + 16 <= n {
        // A label boundary can only start with a length byte or the root
        // terminator, both of which have the top two bits clear. If the
        // byte at the current cursor is a compression pointer (0xC0..=0xFF)
        // or a reserved label type (0x40..=0xBF), the scalar scanner stops
        // here -- so the SIMD path must stop too, otherwise it would leapfrog
        // this byte and mis-identify a later 0xC0xx as a pointer, diverging
        // from the scalar result. Hand the remainder off to keep both paths
        // bit-for-bit equivalent.
        if buf[offset] & 0xC0 != 0 {
            let tail = scan_scalar(buf, offset);
            offsets.extend(tail.offsets.iter().copied());
            return NameOffsets {
                offsets,
                end: tail.end,
            };
        }

        let chunk = _mm_loadu_si128(buf.as_ptr().add(offset) as *const __m128i);

        // Mask the top two bits. A byte with (b & 0xC0) == 0 is either a
        // length byte or the root terminator.
        let masked = _mm_and_si128(chunk, _mm_set1_epi8(0xC0u8 as i8));
        let zero_mask = _mm_cmpeq_epi8(masked, _mm_setzero_si128());
        let candidates = _mm_movemask_epi8(zero_mask) as u32;

        if candidates == 0 {
            // No length bytes in this window. Advance by 16 and retry.
            offset += 16;
            continue;
        }

        // Walk the candidates. The first one that is a real length byte
        // (or the root) determines the label.
        let mut bits = candidates;
        while bits != 0 {
            let pos = bits.trailing_zeros() as usize;
            let idx = offset + pos;
            let b = buf[idx];
            if b == 0 {
                // Root terminator.
                return NameOffsets {
                    offsets,
                    end: (idx + 1) as u32,
                };
            }
            // Length byte: record, then skip the label's payload. The
            // payload may extend past this window; the outer loop
            // re-loads from the new offset.
            offsets.push(idx as u32);
            let next = idx + 1 + usize::from(b);
            if next > n {
                return NameOffsets {
                    offsets,
                    end: n as u32,
                };
            }
            offset = next;
            // Start over from the new offset; the inner loop is done.
            bits = 0;
        }
    }

    // Tail: hand off to the scalar scanner and merge results.
    let tail = scan_scalar(buf, offset);
    offsets.extend(tail.offsets.iter().copied());
    NameOffsets {
        offsets,
        end: tail.end,
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Assembly
// ─────────────────────────────────────────────────────────────────────────────

/// Follow any compression pointers starting at `offset` and return the
/// full name, lowercased.
pub fn resolve_pointers(buf: &[u8], offset: usize) -> Result<(String, usize), DnsError> {
    let first = scan(buf, offset)?;
    let end = first.end();

    let mut out = String::with_capacity(64);
    let mut current = first;
    let mut hops = 0usize;

    loop {
        // Append every label in `current` to the output.
        for &off_u32 in current.offsets.iter() {
            let off = off_u32 as usize;
            let label_len = usize::from(buf[off]);
            let start = off + 1;
            let end_label = start + label_len;
            if end_label > buf.len() {
                return Err(DnsError::MalformedResponse("label extends past end".into()));
            }
            let label = std::str::from_utf8(&buf[start..end_label])
                .map_err(|_| DnsError::MalformedResponse("non-UTF-8 label".into()))?;
            if !out.is_empty() {
                out.push('.');
            }
            out.extend(label.chars().map(|c| c.to_ascii_lowercase()));
        }

        // Check for a trailing compression pointer.
        let end_cur = current.end();
        if end_cur < 2 {
            break;
        }
        let ptr_byte = buf[end_cur - 2];
        if ptr_byte & 0xC0 != 0xC0 {
            break;
        }

        // Follow.
        let target = (usize::from(ptr_byte & 0x3F) << 8) | usize::from(buf[end_cur - 1]);
        if target >= buf.len() {
            return Err(DnsError::MalformedResponse("pointer past end".into()));
        }
        hops += 1;
        if hops > MAX_HOPS {
            return Err(DnsError::CnameLoop);
        }
        current = scan(buf, target)?;
    }

    Ok((out, end))
}

/// Same as [`resolve_pointers`] but preserves the original byte case.
///
/// The 0x20 verifier uses this variant because the comparison must be
/// byte-for-byte against the sequence that was sent.
pub fn resolve_pointers_preserving_case(
    buf: &[u8],
    offset: usize,
) -> Result<(String, usize), DnsError> {
    let first = scan(buf, offset)?;
    let end = first.end();

    let mut out = String::with_capacity(64);
    let mut current = first;
    let mut hops = 0usize;

    loop {
        for &off_u32 in current.offsets.iter() {
            let off = off_u32 as usize;
            let label_len = usize::from(buf[off]);
            let start = off + 1;
            let label_end = start + label_len;
            if label_end > buf.len() {
                return Err(DnsError::MalformedResponse("label past end".into()));
            }
            if !out.is_empty() {
                out.push('.');
            }
            let label = std::str::from_utf8(&buf[start..label_end])
                .map_err(|_| DnsError::MalformedResponse("non-UTF-8 label".into()))?;
            out.push_str(label);
        }

        let end_cur = current.end();
        if end_cur < 2 {
            break;
        }
        let ptr_byte = buf[end_cur - 2];
        if ptr_byte & 0xC0 != 0xC0 {
            break;
        }
        let target = (usize::from(ptr_byte & 0x3F) << 8) | usize::from(buf[end_cur - 1]);
        if target >= buf.len() {
            return Err(DnsError::MalformedResponse("pointer past end".into()));
        }
        hops += 1;
        if hops > MAX_HOPS {
            return Err(DnsError::CnameLoop);
        }
        current = scan(buf, target)?;
    }

    Ok((out, end))
}

// ─────────────────────────────────────────────────────────────────────────────
// Encoding
// ─────────────────────────────────────────────────────────────────────────────

/// Encode a name in wire format. Never emits compression pointers.
pub fn encode_name(name: &str, out: &mut Vec<u8>) -> Result<(), DnsError> {
    let trimmed = name.trim_end_matches('.');
    if trimmed.is_empty() {
        out.push(0);
        return Ok(());
    }
    if trimmed.len() > 253 {
        return Err(DnsError::ParseError("name exceeds 253 bytes".into()));
    }
    for label in trimmed.split('.') {
        if label.is_empty() || label.len() > 63 {
            return Err(DnsError::ParseError(
                "label must be 1..=63 bytes".into(),
            ));
        }
        out.push(label.len() as u8);
        out.extend_from_slice(label.as_bytes());
    }
    out.push(0);
    Ok(())
}

// ─────────────────────────────────────────────────────────────────────────────
// 0x20 case randomisation
// ─────────────────────────────────────────────────────────────────────────────

/// Randomise the ASCII case of every alphabetic byte.
///
/// A conformant resolver echoes the case it received; a spoofing
/// middlebox that canonicalises case cannot. With a 16-bit TXID, the
/// probability of an off-path attacker guessing both is
/// `1 / (65536 · 2^L)` where `L` is the alphabetic character count.
#[must_use]
pub fn randomize_case<R: Rng>(name: &str, rng: &mut R) -> String {
    let mut out = String::with_capacity(name.len());
    for ch in name.chars() {
        if ch.is_ascii_alphabetic() && rng.gen_bool(0.5) {
            out.push(ch.to_ascii_uppercase());
        } else {
            out.push(ch);
        }
    }
    out
}

/// Return `true` if two strings echo `response` back exactly, byte-for-byte and case-sensitively. This is deliberately NOT a case-insensitive match: 0x20 verification must compare the reply against the exact bytes that were sent, so relaxing it to a case-folded comparison would silently break the anti-spoofing guarantee.
#[must_use]
pub fn echoes_exactly(expected: &str, response: &str) -> bool {
    expected.len() == response.len()
        && expected.bytes().zip(response.bytes()).all(|(a, b)| a == b)
}

// ─────────────────────────────────────────────────────────────────────────────
// Tests
// ─────────────────────────────────────────────────────────────────────────────

#[cfg(test)]
mod tests {
    use super::*;
    use rand::SeedableRng;

    fn encoded(name: &str) -> Vec<u8> {
        let mut buf = Vec::new();
        encode_name(name, &mut buf).unwrap();
        buf
    }

    #[test]
    fn scan_simple_name() {
        let buf = encoded("www.example.com");
        let offsets = scan(&buf, 0).unwrap();
        assert_eq!(offsets.label_count(), 3);
        assert_eq!(offsets.end(), buf.len());
    }

    #[test]
    fn scan_root_only() {
        let buf = [0u8];
        let offsets = scan(&buf, 0).unwrap();
        assert!(offsets.is_empty());
        assert_eq!(offsets.end(), 1);
    }

    #[test]
    fn resolve_simple() {
        let buf = encoded("www.example.com");
        let (name, end) = resolve_pointers(&buf, 0).unwrap();
        assert_eq!(name, "www.example.com");
        assert_eq!(end, buf.len());
    }

    #[test]
    fn resolve_with_pointer() {
        // "example.com" at offset 0, then "www" + pointer to 0.
        let mut buf = encoded("example.com");
        let ptr_target = 0u16;
        buf.push(3);
        buf.extend_from_slice(b"www");
        buf.push(0xC0 | (ptr_target >> 8) as u8);
        buf.push(ptr_target as u8);

        let (name, _) = resolve_pointers(&buf, 13).unwrap();
        assert_eq!(name, "www.example.com");
    }

    #[test]
    fn pointer_loop_is_detected() {
        // Two pointers pointing at each other.
        let buf = [0xC0, 0x00, 0xC0, 0x00];
        let result = resolve_pointers(&buf, 0);
        assert!(result.is_err());
    }

    #[test]
    fn preserves_case_when_asked() {
        let buf = encoded("WWW.Example.COM");
        let (lower, _) = resolve_pointers(&buf, 0).unwrap();
        assert_eq!(lower, "www.example.com");

        let (preserved, _) = resolve_pointers_preserving_case(&buf, 0).unwrap();
        assert_eq!(preserved, "WWW.Example.COM");
    }

    #[test]
    fn long_name_does_not_spill() {
        // 30 labels, each 63 bytes — well past MAX_LABELS * 63.
        let labels: Vec<String> = (0..30).map(|_| "a".repeat(63)).collect();
        let name = labels.join(".");
        let buf = encoded(&name);
        let offsets = scan(&buf, 0).unwrap();
        assert_eq!(offsets.label_count(), 30);
        let (decoded, _) = resolve_pointers(&buf, 0).unwrap();
        assert_eq!(decoded, name.to_lowercase());
    }

    #[test]
    fn echo_is_byte_exact_and_case_sensitive() {
        let mut rng = rand::rngs::StdRng::seed_from_u64(42);
        let original = "www.example.com";
        let randomised = randomize_case(original, &mut rng);
        assert_eq!(randomised.to_lowercase(), original);
        assert!(echoes_exactly(&randomised, &randomised));
        assert!(!echoes_exactly(&randomised, original));
    }

    #[test]
    fn truncated_buffer_does_not_panic() {
        // A length byte that promises more bytes than the buffer holds.
        let buf = [5u8, b'a'];
        let _ = scan(&buf, 0);
        let _ = resolve_pointers(&buf, 0);
    }

    proptest::proptest! {
        /// Whatever bytes we receive, parsing must not panic.
        #[test]
        fn scan_never_panics(data in proptest::collection::vec(proptest::num::u8::ANY, 0..512)) {
            let _ = scan(&data, 0);
            let _ = resolve_pointers(&data, 0);
        }

        /// Encoding then decoding a valid name round-trips.
        #[test]
        fn encode_decode_roundtrip(
            labels in proptest::collection::vec("[a-zA-Z0-9-]{1,30}", 1..10)
        ) {
            let name = labels.join(".");
            let mut buf = Vec::new();
            encode_name(&name, &mut buf).unwrap();
            let (decoded, _) = resolve_pointers(&buf, 0).unwrap();
            proptest::prop_assert_eq!(decoded, name.to_lowercase());
        }
    }
}


// ─────────────────────────────────────────────────────────────────────────────
// SIMD <-> scalar differential tests
//
// The SIMD scanner is an optimisation of the scalar one and must produce
// byte-identical `NameOffsets` for every input, including the awkward cases
// where the name *starts* with a compression pointer or a reserved label
// type. These tests are the guard against the two paths silently diverging.
// ─────────────────────────────────────────────────────────────────────────────
#[cfg(all(test, feature = "simd", target_arch = "x86_64"))]
mod simd_differential {
    use super::*;

    fn enc(name: &str) -> Vec<u8> {
        let mut buf = Vec::new();
        encode_name(name, &mut buf).unwrap();
        buf
    }

    fn agree(buf: &[u8]) {
        if !is_x86_feature_detected!("sse2") {
            return;
        }
        // SAFETY: guarded by the runtime SSE2 check above.
        let simd = unsafe { scan_sse2(buf, 0) };
        let scalar = scan_scalar(buf, 0);
        assert_eq!(simd, scalar, "SIMD/scalar divergence for input {:?}", buf);
    }

    #[test]
    fn agrees_on_common_inputs() {
        agree(&enc("www.example.com"));
        agree(&enc("a"));
        agree(&[0u8]);
        agree(&[]);
        agree(&enc(&"a".repeat(20) + "." + &"b".repeat(20)));
    }

    #[test]
    fn agrees_on_pointer_and_reserved_starts() {
        agree(&[0xC0, 0x00]); // pointer at the very first byte
        agree(&[0x40, 0x03, b'w', b'w', b'w', 0x00]); // reserved (01xx) start
        agree(&[0x80, 0x03, b'x', b'y', b'z', 0x00]); // reserved (10xx) start
        agree(&[0xFF, 0xFF]); // pointer bytes
    }

    #[test]
    fn agrees_on_long_name_spilling_the_window() {
        // 40 labels of 40 bytes each: far more than one 16-byte SIMD window.
        let labels: Vec<String> = (0..40).map(|_| "z".repeat(40)).collect();
        agree(&enc(&labels.join(".")));
    }
}

#[cfg(all(test, feature = "simd", target_arch = "x86_64"))]
proptest::proptest! {
    /// Fuzz both scanners over arbitrary bytes and assert they never
    /// disagree. This is the property the previous test suite was missing:
    /// it only proved "no panic", not "same answer".
    #[test]
    fn simd_matches_scalar(data in proptest::collection::vec(proptest::num::u8::ANY, 0..512)) {
        proptest::assume!(is_x86_feature_detected!("sse2"));
        // SAFETY: guarded by the assume! above.
        let simd = unsafe { scan_sse2(&data, 0) };
        let scalar = scan_scalar(&data, 0);
        proptest::prop_assert_eq!(simd, scalar);
    }
}
