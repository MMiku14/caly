//! Upstream server registry and selection.
//!
//! # The boundary
//!
//! The resolver knows which server to *query* — that is the rule
//! engine's job. The selector knows which servers *exist* and how to
//! find one by tag. Splitting the two means the selector is a pure
//! `HashMap` wrapper with no DNS logic, and the rule engine is a pure
//! matcher with no network dependency.
//!
//! # Fallback
//!
//! When the primary server is unhealthy, the resolver walks the
//! fallback list. [`choose_healthy`] encodes that walk: it prefers the
//! primary if it is not `Down`, else the first fallback that is not
//! `Down`, else the primary anyway. The last case matters — a `Down`
//! server may have recovered since its last probe, and refusing to try
//! it guarantees it stays down.

use std::collections::HashMap;
use std::sync::Arc;

use smol_str::SmolStr;

use crate::error::{Error, Result};
use crate::upstream::health::HealthState;
use crate::upstream::server::Server;

/// The set of configured upstream servers.
pub(crate) struct UpstreamSelector {
    servers: HashMap<SmolStr, Arc<Server>>,
    final_tag: SmolStr,
}

impl UpstreamSelector {
    #[must_use]
    pub(crate) fn new(
        servers: HashMap<SmolStr, Arc<Server>>,
        final_tag: SmolStr,
    ) -> Self {
        Self {
            servers,
            final_tag,
        }
    }

    /// Look up a server by tag.
    #[must_use]
    pub(crate) fn get(&self, tag: &str) -> Option<Arc<Server>> {
        self.servers.get(tag).cloned()
    }

    /// Look up a server by tag, or return the `final` server.
    ///
    /// Used by the pipeline after rules have either matched with a
    /// `Route` action or fallen through. A missing tag is a
    /// configuration error the caller already validated against; if it
    /// happens at runtime, the error is `UpstreamNotFound`.
    ///
    /// A `None` argument falls through to `final_tag`, which the
    /// resolver's own validation has already confirmed exists.
    pub(crate) fn get_or_final(&self, tag: Option<&str>) -> Result<Arc<Server>> {
        match tag {
            Some(t) => self.get(t).ok_or_else(|| Error::UpstreamNotFound(SmolStr::new(t))),
            None => self
                .get(self.final_tag.as_str())
                .ok_or_else(|| Error::UpstreamNotFound(self.final_tag.clone())),
        }
    }

    /// Iterate over every configured server.
    pub(crate) fn iter(&self) -> impl Iterator<Item = (&SmolStr, &Arc<Server>)> {
        self.servers.iter()
    }

    /// Number of configured servers.
    #[must_use]
    pub(crate) fn len(&self) -> usize {
        self.servers.len()
    }

    #[must_use]
    pub(crate) fn is_empty(&self) -> bool {
        self.servers.is_empty()
    }
}

/// Choose the next server to try given a primary and a fallback list.
///
/// Prefers the primary if it is not `Down`. Walks the fallback list in
/// order for the first non-`Down` candidate. If everything is `Down`,
/// returns the primary — a `Down` classification is a hint, and a
/// concrete error from the actual transport is more useful than a
/// blanket refusal.
#[must_use]
pub(crate) fn choose_healthy(
    primary: &Arc<Server>,
    fallback: &[Arc<Server>],
) -> Arc<Server> {
    if primary.health_state() != HealthState::Down {
        return Arc::clone(primary);
    }
    for candidate in fallback {
        if candidate.health_state() != HealthState::Down {
            return Arc::clone(candidate);
        }
    }
    // Every candidate is Down. Returning the primary lets the caller
    // surface a concrete transport error instead of a blanket refusal.
    Arc::clone(primary)
}

#[cfg(test)]
mod tests {
    use super::*;

    // Full selection tests require building real `Server` instances,
    // which is more cheaply done in `tests/integration.rs` where a mock
    // transport is available. This module's tests are structural: they
    // verify the selector's map operations and the fallback ordering
    // logic in isolation.

    #[test]
    fn empty_selector_len_is_zero() {
        let selector = UpstreamSelector::new(HashMap::new(), SmolStr::new("final"));
        assert_eq!(selector.len(), 0);
        assert!(selector.is_empty());
    }

    #[test]
    fn missing_tag_is_error() {
        let selector = UpstreamSelector::new(HashMap::new(), SmolStr::new("final"));
        assert!(selector.get_or_final(Some("missing")).is_err());
    }

    #[test]
    fn empty_final_is_error() {
        let selector = UpstreamSelector::new(HashMap::new(), SmolStr::new("final"));
        assert!(selector.get_or_final(None).is_err());
    }
}
