//! Background refresh context.
//!
//! The previous design had a `ResolverInner::clone_handles` method that
//! fabricated an almost-empty `ResolverInner` just to satisfy
//! `tokio::spawn`'s `'static` requirement. That was a workaround for a
//! missing abstraction: **background refresh needs only a tiny,
//! self-contained context**, not the full resolver.
//!
//! This module defines that context explicitly.

use std::net::IpAddr;
use std::sync::Arc;

use smol_str::SmolStr;
use smallvec::SmallVec;

use crate::cache::{CachedAnswer, DnsCache};
use crate::snoop::DnsSnooper;
use crate::upstream::server::Server;
use crate::upstream::ResolvedIps;

/// Everything a background refresh task needs. Constructed by the
/// resolver, owned by the spawned task.
pub struct RefreshContext {
    pub(crate) domain: SmolStr,
    pub(crate) client_hint: Option<IpAddr>,
    pub(crate) upstream: Arc<Server>,
    pub(crate) cache: Arc<DnsCache>,
    pub(crate) snooper: Arc<DnsSnooper>,
}

impl RefreshContext {
    /// Construct a context. Called by the resolver.
    #[must_use]
    pub(crate) fn new(
        domain: SmolStr,
        client_hint: Option<IpAddr>,
        upstream: Arc<Server>,
        cache: Arc<DnsCache>,
        snooper: Arc<DnsSnooper>,
    ) -> Self {
        Self {
            domain,
            client_hint,
            upstream,
            cache,
            snooper,
        }
    }

    /// Run the refresh.
    ///
    /// Never returns an error to the caller — a failed refresh leaves
    /// the existing cache entry alone and is otherwise a no-op. Errors
    /// are logged through `tracing`.
    pub async fn run(self) {
        let outcome = self
            .upstream
            .query_with_hint(&self.domain, self.client_hint)
            .await;

        match outcome {
            Ok(response) => {
                let ips = extract_ips(&response);
                // A NODATA / empty answer is deliberately NOT refreshed:
                // overwriting a good cached entry with nothing would be a
                // downgrade, so we leave the existing entry alone instead.
                if ips.is_empty() {
                    return;
                }
                self.cache.put(
                    &self.domain,
                    &[],
                    CachedAnswer::Resolved(ips.clone()),
                    response.ttl,
                    response.ecs_scope,
                    response.security,
                );
                self.snooper.record(&self.domain, &ips);
            }
            Err(e) => {
                tracing::debug!(
                    domain = %self.domain,
                    error = %e,
                    "background refresh failed"
                );
            }
        }
    }
}

/// Extract A/AAAA addresses from a response.
///
/// The clone is deliberate: the refresh task needs an owned list to
/// hand to the cache and the snooper.
fn extract_ips(response: &ResolvedIps) -> SmallVec<[std::net::IpAddr; 4]> {
    response.ips.clone()
}

