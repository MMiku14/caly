//! Resolver core — construction entry point.
//!
//! This module owns `ResolverInner`, the aggregate that every subsystem
//! hangs off. Wiring is done incrementally: each subsystem (upstream
//! selection, cache, snoop, runtime) lands as a *separate* module and is
//! connected here only once it is ready. Until then this file provides a
//! minimal, compilable construction stub so downstream code
//! (`runtime::epoch`, the pipeline, background refresh) can be built and
//! tested against a real `ResolverInner` type rather than a placeholder.
//!
//! Upstream selection itself deliberately lives in `crate::upstream`
//! (`UpstreamSelector`, `choose_healthy`) and is *not* re-exported from
//! here — the resolver core reaches for it through the module path. Keeping
//! the two apart means this file stays a pure construction seam with no
//! routing logic to test.

// ---------------------------------------------------------------------------
// ResolverInner — construction stub
// ---------------------------------------------------------------------------
//
// Subsystems are wired into the resolver incrementally. The placeholder
// exists so `runtime::epoch` compiles while the pipeline is being built.
pub(crate) struct ResolverInner {
    _private: (),
}

impl ResolverInner {
    /// Build the stub. Subsystems are wired in incrementally; the
    /// placeholder exists so `runtime::epoch` compiles.
    #[allow(dead_code)]
    #[allow(clippy::unnecessary_wraps)]
    pub(crate) const fn build(
        _config: &crate::config::Config,
    ) -> crate::error::Result<Self> {
        Ok(Self { _private: () })
    }
}
