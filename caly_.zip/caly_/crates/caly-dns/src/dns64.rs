//! DNS64 / NAT64 synthesis (RFC 6147).
//!
//! # What it does
//!
//! When an IPv6-only client asks for the AAAA record of an IPv4-only
//! service, an ordinary resolver returns NODATA. A DNS64 resolver does
//! something more useful: it queries the A record instead, embeds the
//! v4 address into a well-known IPv6 prefix, and returns the result as
//! if it had been an AAAA answer all along. Combined with a NAT64
//! gateway — which routes packets addressed to that prefix — this lets
//! IPv6-only hosts reach IPv4-only services without a userspace
//! translator.
//!
//! # Address embedding (RFC 6052 §2.2)
//!
//! ```text
//!   prefix_len    layout
//!   ─────────     ─────────────────────────────────────────────
//!      32         [   prefix   ][  v4  ][ 0 ][  zero padding   ]
//!      40         [   prefix    ][ v4a ][ 0 ][v4b][ zero pad    ]
//!      48         [   prefix     ][ v4a][ 0 ][ v4b ][ zero pad  ]
//!      56         [   prefix      ][v4a][ 0 ][ v4b  ][ zero pad ]
//!      64         [   prefix       ][ 0 ][  v4  ][ zero pad    ]
//!      96         [   prefix               ][  v4  ]
//! ```
//!
//! The `0` byte is the RFC 6052 "u" bit — reserved, always zero.
//! Prefix lengths other than these six are not valid DNS64 prefixes;
//! [`Dns64::new`] rejects them.
//!
//! # Not reverse synthesis
//!
//! This module builds v6 from v4. The reverse — recovering the original
//! v4 from a synthesized v6 — is implemented by [`Dns64::extract`], but
//! the caller is responsible for checking [`Dns64::contains`] first.

use std::net::{IpAddr, Ipv4Addr, Ipv6Addr};

use crate::error::{Error, Result};

/// A configured DNS64 synthesizer.
#[derive(Debug, Clone, Copy)]
pub struct Dns64 {
    prefix: u128,
    prefix_len: u8,
    mask: u128,
}

impl Dns64 {
    /// Parse a CIDR prefix such as `"64:ff9b::/96"`.
    ///
    /// The prefix length must be one of 32, 40, 48, 56, 64, or 96 per
    /// RFC 6052 §2.2. Anything else is rejected at configuration time,
    /// not at query time.
    /// # Errors
    ///
    /// Returns [`Error::Config`] if `spec` is not a valid CIDR string or the prefix
    /// length is not one of 32, 40, 48, 56, 64, or 96.
    pub fn new(spec: &str) -> Result<Self> {
        let (addr_part, len_part) = spec
            .split_once('/')
            .ok_or_else(|| Error::config(format!("DNS64 prefix '{spec}': missing '/'")))?;

        let addr: Ipv6Addr = addr_part
            .trim()
            .parse()
            .map_err(|e| Error::config(format!("DNS64 address '{addr_part}': {e}")))?;

        let prefix_len: u8 = len_part
            .trim()
            .parse()
            .map_err(|e| Error::config(format!("DNS64 prefix length '{len_part}': {e}")))?;

        match prefix_len {
            32 | 40 | 48 | 56 | 64 | 96 => {}
            other => {
                return Err(Error::config(format!(
                    "DNS64 prefix length must be one of 32/40/48/56/64/96, got {other}"
                )));
            }
        }

        // Mask the prefix to canonical form. Validated prefixes are strictly within [32, 96].
        let raw = u128::from(addr);
        let mask = u128::MAX.checked_shl(u32::from(128 - prefix_len)).unwrap_or(0);

        Ok(Self {
            prefix: raw & mask,
            prefix_len,
            mask,
        })
    }

    /// Synthesize a v6 address from a v4 address.
    #[must_use]
    pub fn synthesize(&self, v4: Ipv4Addr) -> Ipv6Addr {
        let mut out = self.prefix.to_be_bytes();
        let v4_octets = v4.octets();

        match self.prefix_len {
            32 => {
                // v4 occupies bytes 4..8.
                out[4..8].copy_from_slice(&v4_octets);
            }
            40 => {
                // v4[0..3] at bytes 5..8, u=0 at byte 8, v4[3] at byte 9.
                out[5..8].copy_from_slice(&v4_octets[..3]);
                out[8] = 0;
                out[9] = v4_octets[3];
            }
            48 => {
                // v4[0..2] at bytes 6..8, u=0 at byte 8, v4[2..4] at 9..11.
                out[6..8].copy_from_slice(&v4_octets[..2]);
                out[8] = 0;
                out[9..11].copy_from_slice(&v4_octets[2..]);
            }
            56 => {
                // v4[0] at byte 7, u=0 at byte 8, v4[1..4] at 9..12.
                out[7] = v4_octets[0];
                out[8] = 0;
                out[9..12].copy_from_slice(&v4_octets[1..]);
            }
            64 => {
                // u=0 at byte 8, v4 at bytes 9..13.
                out[8] = 0;
                out[9..13].copy_from_slice(&v4_octets);
            }
            96 => {
                // /96 has no u-octet; the v4 address occupies the tail.
                out[12..16].copy_from_slice(&v4_octets);
            }
            _ => unreachable!("validated at construction"),
        }

        Ipv6Addr::from(out)
    }

    /// Whether `ip` falls inside the DNS64 prefix.
    ///
    /// The check is a pure prefix comparison. It does not verify that
    /// the address is a well-formed synthesis output; a manual address
    /// in the same prefix is also `contained`. Use
    /// [`Dns64::extract`] to recover the v4 component.
    #[must_use]
    #[inline]
    pub fn contains(&self, ip: Ipv6Addr) -> bool {
        (u128::from(ip) & self.mask) == self.prefix
    }

    /// Extract the v4 address embedded in a synthesized v6 address.
    ///
    /// Returns `None` if `ip` is not inside the prefix. The result is
    /// the original v4 address the synthesizer would have embedded.
    #[must_use]
    pub fn extract(&self, ip: Ipv6Addr) -> Option<Ipv4Addr> {
        if !self.contains(ip) {
            return None;
        }
        let bytes = ip.octets();
        // RFC 6052 §2.2 fixes the u-octet at byte 8 for prefixes
        // shorter than /96; a non-zero value means the input is not a
        // well-formed synthesis output.
        if self.prefix_len <= 64 && bytes[8] != 0 {
            return None;
        }
        let mut v4 = [0u8; 4];
        match self.prefix_len {
            32 => v4.copy_from_slice(&bytes[4..8]),
            40 => {
                v4[..3].copy_from_slice(&bytes[5..8]);
                v4[3] = bytes[9];
            }
            48 => {
                v4[..2].copy_from_slice(&bytes[6..8]);
                v4[2..].copy_from_slice(&bytes[9..11]);
            }
            56 => {
                v4[0] = bytes[7];
                v4[1..].copy_from_slice(&bytes[9..12]);
            }
            64 => v4.copy_from_slice(&bytes[9..13]),
            96 => v4.copy_from_slice(&bytes[12..16]),
            _ => return None,
        }
        Some(Ipv4Addr::from(v4))
    }

    /// The configured prefix length.
    #[must_use]
    pub const fn prefix_len(&self) -> u8 {
        self.prefix_len
    }
}

/// Return `true` if `ip` is inside the Well-Known Prefix `64:ff9b::/96`.
///
/// This is a convenience for callers that do not carry a full [`Dns64`]
/// and only need to recognise the RFC 6052 default.
#[must_use]
pub fn is_well_known_nat64(ip: IpAddr) -> bool {
    const WKP_PREFIX: [u8; 12] = [0x00, 0x64, 0xFF, 0x9B, 0, 0, 0, 0, 0, 0, 0, 0];
    // RFC 6052 §3.1 also defines the local-use prefix 64:ff9b:1::/48.
    const LOCAL_WKP_PREFIX: [u8; 6] = [0x00, 0x64, 0xFF, 0x9B, 0x00, 0x01];

    let IpAddr::V6(v6) = ip else { return false };
    let bytes = v6.octets();
    bytes[..12] == WKP_PREFIX || bytes[..6] == LOCAL_WKP_PREFIX
}

#[cfg(test)]
mod tests {
    use super::*;

    const DEFAULT: &str = "64:ff9b::/96";

    #[test]
    fn wkp_synthesis_is_verbatim() {
        let d = Dns64::new(DEFAULT).unwrap();
        let v4: Ipv4Addr = "192.0.2.33".parse().unwrap();
        let v6 = d.synthesize(v4);
        assert_eq!(v6.to_string(), "64:ff9b::c000:221");
    }

    #[test]
    fn extract_reverses_synthesis() {
        for spec in &["64:ff9b::/96", "2001:db8::/32", "2001:db8:1::/48", "2001:db8:1:2::/64"] {
            let d = Dns64::new(spec).unwrap();
            let v4: Ipv4Addr = "10.20.30.40".parse().unwrap();
            let v6 = d.synthesize(v4);
            assert_eq!(d.extract(v6), Some(v4), "roundtrip failed for {spec}");
        }
    }

    #[test]
    fn contains_matches_only_synthesized_range() {
        let d = Dns64::new(DEFAULT).unwrap();
        let synthesized = d.synthesize("1.2.3.4".parse().unwrap());
        assert!(d.contains(synthesized));
        assert!(!d.contains("::1".parse().unwrap()));
        assert!(!d.contains("2001:db8::1".parse().unwrap()));
    }

    #[test]
    fn every_prefix_length_roundtrips() {
        let v4: Ipv4Addr = "203.0.113.1".parse().unwrap();
        for len in [32u8, 40, 48, 56, 64, 96] {
            // Build a synthetic prefix for each length.
            let raw: u128 = 0x2001_0db8_0000_0000_0000_0000_0000_0000;
            let mask = u128::MAX << (128 - u32::from(len));
            let prefix = raw & mask;
            let spec = format!("{}/{}", Ipv6Addr::from(prefix), len);
            let d = Dns64::new(&spec).unwrap();
            assert_eq!(d.extract(d.synthesize(v4)), Some(v4), "len {len}");
        }
    }

    #[test]
    fn rejects_unsupported_prefix_lengths() {
        assert!(Dns64::new("64:ff9b::/128").is_err());
        assert!(Dns64::new("64:ff9b::/0").is_err());
        assert!(Dns64::new("64:ff9b::/97").is_err());
    }

    #[test]
    fn rejects_malformed_spec() {
        assert!(Dns64::new("64:ff9b::").is_err());
        assert!(Dns64::new("not-an-address/96").is_err());
        assert!(Dns64::new("64:ff9b::/not-a-number").is_err());
    }

    #[test]
    fn well_known_check() {
        assert!(is_well_known_nat64("64:ff9b::c000:221".parse().unwrap()));
        assert!(!is_well_known_nat64("2001:db8::1".parse().unwrap()));
        assert!(!is_well_known_nat64("1.2.3.4".parse().unwrap()));
    }

    #[test]
    fn non_synthesized_in_prefix_extracts_to_something() {
        // An address inside the /96 prefix that was not produced by
        // synthesis still extracts cleanly — the module does not claim
        // to distinguish the two cases.
        let d = Dns64::new(DEFAULT).unwrap();
        let manual: Ipv6Addr = "64:ff9b::1.2.3.4".parse().unwrap();
        assert!(d.contains(manual));
        assert_eq!(d.extract(manual), Some("1.2.3.4".parse().unwrap()));
    }
}
