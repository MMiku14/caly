//! EDNS Client Subnet scopes.
//!
//! # The problem
//!
//! A DNS answer for `cdn.example.com` from a resolver in Tokyo is not
//! the same as from a resolver in London. RFC 7871 lets the resolver
//! tell the authoritative server *where* the client is, and the server
//! returns an answer appropriate to that location.
//!
//! But the same mechanism creates a caching problem: if we cache the
//! Tokyo answer and a London client hits the cache, they get the wrong
//! node. RFC 7871 §7.3.1 solves this with the response's
//! `scope_prefix` field: it tells the resolver how much of the client
//! address the answer is valid for. `scope_prefix = 0` means "everyone";
//! a nonzero value means "clients within this prefix".
//!
//! # The slot model
//!
//! A cache entry for a name holds a small list of slots, each tagged
//! with a scope. Lookup picks the most specific slot containing the
//! client hint, falling back to the scope-less slot.
//!
//! Scope keys are `(network, prefix_len)` with the network already
//! masked, so two scopes are equal iff their keys are equal. This makes
//! hashing the scope trivial and comparison exact.

use std::net::{IpAddr, Ipv4Addr, Ipv6Addr};
use std::sync::Arc;

use crate::cache::entry::CacheEntry;

/// A masked subnet.
///
/// The `network` field is already masked to `prefix`, so two scopes
/// are equal iff their keys are equal. This makes hashing and
/// comparison trivial on the lookup path.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub struct EcsScope {
    /// Network address, already masked to `prefix`.
    pub network: IpAddr,
    /// Number of significant bits.
    pub prefix: u8,
}

impl EcsScope {
    /// Build a scope by masking `ip` to `prefix`.
    ///
    /// A prefix of zero yields the unspecified address of the family,
    /// which matches every client of that family.
    #[must_use]
    pub fn from_client(ip: IpAddr, prefix: u8) -> Self {
        Self {
            network: mask_ip(ip, prefix),
            prefix,
        }
    }

    /// Whether `ip` falls within this scope.
    #[must_use]
    pub fn contains(&self, ip: IpAddr) -> bool {
        mask_ip(ip, self.prefix) == self.network
    }
}

/// One slot in a name's slot list.
///
/// `scope` is `None` for the scope-less slot, which matches any
/// client hint that does not match a more specific slot. A name may
/// hold at most `MAX_SLOTS_PER_NAME` slots; a new scope beyond that
/// evicts the oldest.
#[derive(Debug, Clone)]
pub struct EcsSlot {
    /// The scope this slot is keyed by, or `None` for the global slot.
    pub scope: Option<EcsScope>,
    /// The entry.
    pub entry: Arc<CacheEntry>,
}

/// Mask an address to `prefix` bits, saturating the prefix at the
/// family's width.
fn mask_ip(ip: IpAddr, prefix: u8) -> IpAddr {
    match ip {
        IpAddr::V4(v4) => IpAddr::V4(mask_v4(v4, prefix.min(32))),
        IpAddr::V6(v6) => IpAddr::V6(mask_v6(v6, prefix.min(128))),
    }
}

fn mask_v4(ip: Ipv4Addr, prefix: u8) -> Ipv4Addr {
    if prefix == 0 {
        return Ipv4Addr::UNSPECIFIED;
    }
    if prefix >= 32 {
        return ip;
    }
    // At this point 1 <= prefix < 32, so `32 - prefix` fits in 5 bits
    // and `checked_shl` is provably in range.
    let mask = u32::MAX << (32 - u32::from(prefix));
    Ipv4Addr::from(u32::from(ip) & mask)
}

fn mask_v6(ip: Ipv6Addr, prefix: u8) -> Ipv6Addr {
    if prefix == 0 {
        return Ipv6Addr::UNSPECIFIED;
    }
    if prefix >= 128 {
        return ip;
    }
    // At this point 1 <= prefix < 128, so `128 - prefix` fits in 7 bits
    // and `checked_shl` is provably in range.
    let mask = u128::MAX << (128 - u32::from(prefix));
    Ipv6Addr::from(u128::from(ip) & mask)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn masks_v4_to_prefix() {
        let scope = EcsScope::from_client("1.2.3.4".parse().unwrap(), 24);
        assert_eq!(scope.network, "1.2.3.0".parse::<IpAddr>().unwrap());
        assert_eq!(scope.prefix, 24);
    }

    #[test]
    fn contains_respects_prefix() {
        let scope = EcsScope::from_client("1.2.3.4".parse().unwrap(), 24);
        assert!(scope.contains("1.2.3.99".parse().unwrap()));
        assert!(!scope.contains("1.2.4.1".parse().unwrap()));
    }

    #[test]
    fn zero_prefix_matches_everything_of_that_family() {
        let scope = EcsScope::from_client("1.2.3.4".parse().unwrap(), 0);
        assert!(scope.contains("9.9.9.9".parse().unwrap()));
    }

    #[test]
    fn v4_and_v6_do_not_cross() {
        let scope = EcsScope::from_client("1.2.3.4".parse().unwrap(), 24);
        assert!(!scope.contains("::1".parse().unwrap()));
    }

    #[test]
    fn equivalent_scopes_are_equal() {
        let a = EcsScope::from_client("1.2.3.4".parse().unwrap(), 24);
        let b = EcsScope::from_client("1.2.3.99".parse().unwrap(), 24);
        assert_eq!(a, b);
    }
}
