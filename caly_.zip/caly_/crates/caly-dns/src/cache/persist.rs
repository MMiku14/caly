//! On-disk cache persistence.
//!
//! # The goal
//!
//! A resolver that has just started is cold: every query goes upstream.
//! On a machine that restarts daily, that cold period is a recurring
//! cost. Persisting the cache eliminates most of it.
//!
//! # Format
//!
//! A versioned binary format:
//!
//! ```text
//!   magic:       b"CALYCACH"   (8 bytes)
//!   version:     u16           (2 bytes)
//!   saved_at:    u64           (8 bytes, Unix epoch seconds)
//!   count:       u32           (4 bytes)
//!   entries:     [entry; count]
//! ```
//!
//! Each entry:
//!
//! ```text
//!   domain_len:      u16
//!   domain:          bytes
//!   answer_tag:      u8   (0 = Resolved, 1 = NxDomain, 2 = Empty)
//!   ip_count:        u16  (only if answer_tag == 0)
//!   ips:             [family: u8, addr: bytes]
//!   chain_len:       u16
//!   chain:           [u16 len, bytes]
//!   remaining_ttl:   u32
//!   remaining_optim: u32
//! ```
//!
//! # Freshness on load
//!
//! Remaining TTLs are stored as *durations*, not absolute times. On
//! load, the age of the file is subtracted from each duration; entries
//! whose optimistic window has fully elapsed are dropped.
//!
//! # Atomic write
//!
//! The file is written to a `.tmp` sibling and renamed over the target.
//! A crash mid-write leaves the previous snapshot intact; the new file
//! either exists complete or not at all.

use std::io::{Cursor, Read, Write};
use std::net::{IpAddr, Ipv4Addr, Ipv6Addr};
use std::path::{Path, PathBuf};
use std::sync::Arc;
use std::time::{Duration, SystemTime, UNIX_EPOCH};

use smallvec::SmallVec;
use smol_str::SmolStr;

use crate::cache::{CachedAnswer, DnsCache, SnapshotEntry};

/// File magic. A mismatch is a hard error, so a random file cannot
/// be mistaken for a cache snapshot.
const MAGIC: &[u8; 8] = b"CALYCACH";
/// On-disk format version. Bump when the layout changes; old files
/// are rejected with `PersistError::Version`.
const VERSION: u16 = 1;

/// Errors from persistence.
#[derive(Debug, thiserror::Error)]
pub enum PersistError {
    #[error("I/O error: {0}")]
    /// The underlying I/O operation failed.
    Io(#[from] std::io::Error),
    #[error("invalid file format: {0}")]
    /// The file is structurally invalid.
    Invalid(&'static str),
    #[error("unsupported file version: {0}")]
    /// The file's format version is not the one this build reads.
    Version(u16),
}

/// The cache persistence driver.
pub struct CachePersister {
    path: PathBuf,
    cache: Arc<DnsCache>,
}

impl CachePersister {
    /// Construct a persister for `path`, backed by `cache`.
    #[must_use]
    pub const fn new(path: PathBuf, cache: Arc<DnsCache>) -> Self {
        Self { path, cache }
    }

    /// Load a snapshot and hydrate the cache.
    ///
    /// Returns the number of entries restored. A missing file returns
    /// `Ok(0)`, not an error: the first startup has no snapshot to
    /// restore from.
    /// # Errors
    ///
    /// Returns [`PersistError`] if reading or parsing the snapshot fails.
    pub fn load(&self) -> Result<usize, PersistError> {
        match self.try_load() {
            Ok(n) => Ok(n),
            Err(PersistError::Io(e)) if e.kind() == std::io::ErrorKind::NotFound => {
                Ok(0)
            }
            Err(e) => Err(e),
        }
    }

    fn try_load(&self) -> Result<usize, PersistError> {
        let bytes = std::fs::read(&self.path)?;
        let mut cursor = Cursor::new(bytes.as_slice());

        let mut magic = [0u8; 8];
        cursor.read_exact(&mut magic)?;
        if &magic != MAGIC {
            return Err(PersistError::Invalid("bad magic"));
        }

        let version = read_u16(&mut cursor)?;
        if version != VERSION {
            return Err(PersistError::Version(version));
        }

        let saved_at = read_u64(&mut cursor)?;
        let now = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .map_or(saved_at, |d| d.as_secs());
        let age_secs = now.saturating_sub(saved_at);

        let count = read_u32(&mut cursor)? as usize;
        // A snapshot with more than a million entries is treated as
        // corrupt; refusing it keeps a hostile file from pinning the
        // process during restore.
        if count > 1_000_000 {
            return Err(PersistError::Invalid("persisted count exceeds safety threshold (1,000,000)"));
        }
        let mut restored = 0;
        for _ in 0..count {
            let Some(entry) = read_entry(&mut cursor, age_secs)? else {
                // A single expired entry must not abort the restore;
                // keep reading so the healthy entries behind it are
                // recovered.
                continue;
            };
            self.cache.restore(entry);
            restored += 1;
        }
        Ok(restored)
    }

    /// Write the current cache to disk.
    ///
    /// Uses write-to-temp-then-rename so a crash mid-write cannot
    /// corrupt the previous snapshot.
    /// # Errors
    ///
    /// Returns [`PersistError`] if serializing or writing the snapshot fails.
    pub fn save(&self) -> Result<usize, PersistError> {
        let snapshot = self.cache.snapshot();
        let saved_at = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .map_or(0, |d| d.as_secs());

        let mut buffer = Vec::with_capacity(256 + snapshot.len() * 96);
        buffer.extend_from_slice(MAGIC);
        buffer.extend_from_slice(&VERSION.to_be_bytes());
        buffer.extend_from_slice(&saved_at.to_be_bytes());
        let snap_len = u32::try_from(snapshot.len()).unwrap_or(u32::MAX);
        buffer.extend_from_slice(&snap_len.to_be_bytes());

        for entry in &snapshot {
            write_entry(&mut buffer, entry)?;
        }

        // `with_extension` replaces the existing extension, so a cache
        // path already ending in `.tmp` would collide with itself.
        let tmp = self.path.with_extension("tmp");
        // Create parent directories on demand so the first cold-start
        // save does not fail on a missing directory.
        if let Some(parent) = tmp.parent() {
            let _ = std::fs::create_dir_all(parent);
        }
        {
            let mut file = std::fs::File::create(&tmp)?;
            file.write_all(&buffer)?;
            file.sync_all()?;
        }
        std::fs::rename(&tmp, &self.path)?;
        Ok(snapshot.len())
    }
}

/// RAII guard that saves on drop.
///
/// Hold this for the lifetime of the process; it runs
/// [`CachePersister::save`] on shutdown. A failure to save is logged
/// but never propagated, because a `Drop` impl cannot return an error.
#[must_use = "hold the guard for the process lifetime; it saves on drop"]
#[allow(dead_code)]
pub struct PersistGuard {
    persister: Arc<CachePersister>,
    path: PathBuf,
}

impl PersistGuard {
    /// Create a new persistence guard.
    #[allow(dead_code)]
    pub fn new(persister: Arc<CachePersister>) -> Self {
        let path = persister.path.clone();
        Self { persister, path }
    }
}

impl Drop for PersistGuard {
    fn drop(&mut self) {
        match self.persister.save() {
            Ok(n) => tracing::debug!(
                path = %self.path.display(),
                entries = n,
                "cache persisted on shutdown"
            ),
            Err(e) => tracing::warn!(
                path = %self.path.display(),
                error = %e,
                "cache persistence failed on shutdown"
            ),
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Wire helpers
// ─────────────────────────────────────────────────────────────────────────────

fn write_entry(buf: &mut Vec<u8>, entry: &SnapshotEntry) -> Result<(), PersistError> {
    let domain_bytes = entry.domain.as_bytes();
    let domain_len = u16::try_from(domain_bytes.len())
        .map_err(|_| PersistError::Invalid("domain too long"))?;
    buf.extend_from_slice(&domain_len.to_be_bytes());
    buf.extend_from_slice(domain_bytes);

    match &entry.answer {
        CachedAnswer::Resolved(ips) => {
            buf.push(0);
            let count = u16::try_from(ips.len())
                .map_err(|_| PersistError::Invalid("too many IPs"))?;
            buf.extend_from_slice(&count.to_be_bytes());
            for ip in ips {
                write_ip(buf, *ip);
            }
        }
        CachedAnswer::NxDomain => buf.push(1),
        CachedAnswer::Empty => buf.push(2),
    }

    let chain_len = u16::try_from(entry.cname_chain.len())
        .map_err(|_| PersistError::Invalid("chain too long"))?;
    buf.extend_from_slice(&chain_len.to_be_bytes());
    for hop in &entry.cname_chain {
        let bytes = hop.as_bytes();
        let len = u16::try_from(bytes.len())
            .map_err(|_| PersistError::Invalid("chain element too long"))?;
        buf.extend_from_slice(&len.to_be_bytes());
        buf.extend_from_slice(bytes);
    }

    let valid = u32::try_from(entry.remaining_valid.as_secs().min(u64::from(u32::MAX))).unwrap_or(u32::MAX);
    let optim = u32::try_from(entry.remaining_optimistic.as_secs().min(u64::from(u32::MAX))).unwrap_or(u32::MAX);
    buf.extend_from_slice(&valid.to_be_bytes());
    buf.extend_from_slice(&optim.to_be_bytes());
    Ok(())
}

fn read_entry(
    cursor: &mut Cursor<&[u8]>,
    age_secs: u64,
) -> Result<Option<SnapshotEntry>, PersistError> {
    // A truncated entry is not an error: it means the file was cut
    // short. We stop reading and return what we have.
    let Ok(domain) = read_string(cursor) else {
        return Ok(None);
    };
    let domain = SmolStr::new(domain);

    // A truncated entry terminates the scan; the caller keeps what it
    // already restored.
    let Ok(tag) = read_u8(cursor) else {
        return Ok(None);
    };

    let answer = match tag {
        0 => {
            let count = read_u16(cursor)?;
            let mut ips: SmallVec<[IpAddr; 4]> = SmallVec::new();
            for _ in 0..count {
                ips.push(read_ip(cursor)?);
            }
            CachedAnswer::Resolved(ips)
        }
        1 => CachedAnswer::NxDomain,
        2 => CachedAnswer::Empty,
        _ => return Err(PersistError::Invalid("unknown answer tag")),
    };

    let chain_len = read_u16(cursor)?;
    let mut chain: SmallVec<[SmolStr; 2]> = SmallVec::new();
    for _ in 0..chain_len {
        // A malformed chain element ends this entry, not the whole file.
        let Ok(hop) = read_string(cursor) else {
            return Ok(None);
        };
        chain.push(SmolStr::new(hop));
    }

    let valid_secs = u64::from(read_u32(cursor)?);
    let optim_secs = u64::from(read_u32(cursor)?);

    // Age the entry by the time the process was down.
    let remaining_valid = valid_secs.saturating_sub(age_secs);
    let remaining_optimistic = optim_secs.saturating_sub(age_secs);
    if remaining_optimistic == 0 {
        return Ok(None);
    }

    Ok(Some(SnapshotEntry {
        domain,
        answer,
        cname_chain: chain,
        remaining_valid: Duration::from_secs(remaining_valid),
        remaining_optimistic: Duration::from_secs(remaining_optimistic),
    }))
}

fn write_ip(buf: &mut Vec<u8>, ip: IpAddr) {
    match ip {
        IpAddr::V4(v4) => {
            buf.push(4);
            buf.extend_from_slice(&v4.octets());
        }
        IpAddr::V6(v6) => {
            buf.push(6);
            buf.extend_from_slice(&v6.octets());
        }
    }
}

fn read_ip(cursor: &mut Cursor<&[u8]>) -> Result<IpAddr, PersistError> {
    match read_u8(cursor)? {
        4 => {
            let mut octets = [0u8; 4];
            cursor.read_exact(&mut octets)?;
            Ok(IpAddr::V4(Ipv4Addr::from(octets)))
        }
        6 => {
            let mut octets = [0u8; 16];
            cursor.read_exact(&mut octets)?;
            Ok(IpAddr::V6(Ipv6Addr::from(octets)))
        }
        _ => Err(PersistError::Invalid("bad IP family")),
    }
}

fn read_string(cursor: &mut Cursor<&[u8]>) -> Result<String, PersistError> {
    let len = read_u16(cursor)? as usize;
    let mut buf = vec![0u8; len];
    cursor.read_exact(&mut buf)?;
    String::from_utf8(buf).map_err(|_| PersistError::Invalid("non-UTF-8 string"))
}

/// Read one byte from the cursor, mapping I/O failure into the
/// persistence error type.
fn read_u8(cursor: &mut Cursor<&[u8]>) -> Result<u8, PersistError> {
    let mut buf = [0u8; 1];
    cursor.read_exact(&mut buf)?;
    Ok(buf[0])
}

fn read_u16(cursor: &mut Cursor<&[u8]>) -> Result<u16, PersistError> {
    let mut buf = [0u8; 2];
    cursor.read_exact(&mut buf)?;
    Ok(u16::from_be_bytes(buf))
}

fn read_u32(cursor: &mut Cursor<&[u8]>) -> Result<u32, PersistError> {
    let mut buf = [0u8; 4];
    cursor.read_exact(&mut buf)?;
    Ok(u32::from_be_bytes(buf))
}

fn read_u64(cursor: &mut Cursor<&[u8]>) -> Result<u64, PersistError> {
    let mut buf = [0u8; 8];
    cursor.read_exact(&mut buf)?;
    Ok(u64::from_be_bytes(buf))
}

/// Read only the entry count from a file. Used by tests and diagnostics.
#[allow(dead_code)]
pub fn peek_entry_count(path: &Path) -> Result<usize, PersistError> {
    let bytes = std::fs::read(path)?;
    let mut cursor = Cursor::new(bytes.as_slice());
    let mut magic = [0u8; 8];
    cursor.read_exact(&mut magic)?;
    if &magic != MAGIC {
        return Err(PersistError::Invalid("bad magic"));
    }
    let _ = read_u16(&mut cursor)?;
    let _ = read_u64(&mut cursor)?;
    Ok(read_u32(&mut cursor)? as usize)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn peek_on_missing_file_errors() {
        let result = peek_entry_count(Path::new("/nonexistent/path/for/test"));
        assert!(result.is_err());
    }
}
