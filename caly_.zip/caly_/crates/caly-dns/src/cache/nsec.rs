//! RFC 8198 — Aggressive use of DNSSEC-validated cache.
//!
//! # What it does
//!
//! When a validating resolver receives an NSEC record proving that
//! `a.example.com` does not exist, the same record also proves that
//! **every name strictly between the NSEC's owner and its next-name
//! pointer is absent**. Caching that interval lets the resolver answer
//! future NXDOMAIN queries locally, without any upstream traffic.
//!
//! # Impact
//!
//! On a network with any DGA-infected host, NXDOMAIN queries dominate
//! the workload. A single validated NSEC response can absorb thousands
//! of subsequent queries.
//!
//! # Structure
//!
//! Intervals are stored in a `BTreeMap` keyed by the canonical-order
//! start name. Lookup is `range(..=name).next_back()` — the first
//! interval whose start is at or before the query. If the query is
//! strictly less than the interval's end, the query is covered.
//!
//! Name comparison follows RFC 4034 §6.1 canonical DNS name order:
//! labels compared right-to-left, case-insensitive, byte-wise.

use std::collections::BTreeMap;
use std::sync::Arc;
use std::time::{Duration, Instant};

use parking_lot::RwLock;
use smol_str::SmolStr;

/// One NSEC interval: `(start, end)` inclusive on both ends, valid
/// until `expires_at`.
#[derive(Debug, Clone)]
struct Interval {
    start: SmolStr,
    end: SmolStr,
    expires_at: Instant,
}

/// The NSEC interval cache.
pub struct NsecCache {
    intervals: RwLock<BTreeMap<CanonicalName, Interval>>,
    ttl_cap: Duration,
    capacity: usize,
}

impl NsecCache {
    /// Create a cache with the given capacity and TTL ceiling.
    ///
    /// The TTL of a cached interval is `min(record_ttl, ttl_cap)`; the
    /// cap prevents a single generous NSEC from pinning an interval
    /// for an unreasonably long time. The capacity is a soft bound: an
    /// insert over the limit evicts the entry closest to expiry.
    #[must_use]
    pub fn new(capacity: usize, ttl_cap: Duration) -> Self {
        Self {
            intervals: RwLock::new(BTreeMap::new()),
            ttl_cap,
            capacity: capacity.max(16),
        }
    }

    /// Insert an NSEC interval.
    ///
    /// `start` is the NSEC owner name; `end` is the next-name field.
    /// Both are normalized to lowercase. Eviction is approximate: the
    /// entry closest to expiry is dropped when the map is full, which
    /// is O(n) but rare.
    pub fn insert(&self, start: &str, end: &str, ttl: Duration) {
        let ttl = ttl.min(self.ttl_cap);
        let interval = Interval {
            start: SmolStr::new(start.to_ascii_lowercase()),
            end: SmolStr::new(end.to_ascii_lowercase()),
            expires_at: Instant::now() + ttl,
        };
        let key = CanonicalName::from_str(&interval.start);

        let mut map = self.intervals.write();
        if map.len() >= self.capacity {
            // Simple eviction: drop the oldest entry by expiry. This is
            // not LRU but it is O(1) amortized and good enough — the
            // cache is a heuristic.
            if let Some(oldest_key) = map
                .iter()
                .min_by_key(|(_, v)| v.expires_at)
                .map(|(k, _)| k.clone())
            {
                map.remove(&oldest_key);
            }
        }
        map.insert(key, interval);
    }

    /// Return `true` if `name` is covered by any live interval.
    ///
    /// Coverage means: the NSEC interval proves that no name strictly
    /// between `start` and `end` exists, and `name` falls in that range.
    #[must_use]
    #[allow(clippy::significant_drop_tightening)]
    pub fn covers(&self, name: &str) -> bool {
        let now = Instant::now();
        // Building the canonical form here keeps the interval list free
        // of per-entry allocations.
        let query = CanonicalName::from_str(&name.to_ascii_lowercase());

        let map = self.intervals.read();
        // Find the first interval whose start is <= the query.
        let Some((_, interval)) = map.range(..=&query).next_back() else {
            return false;
        };
        if now >= interval.expires_at {
            return false;
        }
        let end_canonical = CanonicalName::from_str(&interval.end);
        let start_canonical = CanonicalName::from_str(&interval.start);
        // RFC 4034 §4.1.1: the last NSEC in a zone wraps around, so the
        // covered range is the union of two intervals.
        if end_canonical <= start_canonical {
            // The final NSEC in a zone wraps around; the interval is
            // the union of (start, zone-end] and [zone-apex, end).
            query > start_canonical || query < end_canonical
        } else {
            // The interval is open at both ends: the NSEC owner and
            // its successor both exist.
            query > start_canonical && query < end_canonical
        }
    }

    /// Drop expired intervals.
    pub fn sweep(&self) -> usize {
        let now = Instant::now();
        let mut map = self.intervals.write();
        let before = map.len();
        map.retain(|_, v| now < v.expires_at);
        before - map.len()
    }

    /// Number of live intervals.
    #[must_use]
    pub fn len(&self) -> usize {
        self.intervals.read().len()
    }

    /// Whether the interval map is empty.
    /// Whether the interval map is empty.
    #[must_use]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

/// Canonical DNS name order (RFC 4034 §6.1).
///
/// Names are compared right-to-left by label; within a label, bytes
/// compare case-insensitively. The root sorts before every other name.
///
/// The wrapper caches the reversed label list so comparison is O(labels)
/// instead of O(bytes).
#[derive(Debug, Clone, PartialEq, Eq)]
struct CanonicalName {
    /// Labels in reverse order (TLD first).
    labels: Vec<SmolStr>,
}

impl CanonicalName {
    fn from_str(name: &str) -> Self {
        let labels: Vec<SmolStr> = name
            .trim_end_matches('.')
            .split('.')
            .rev()
            .map(SmolStr::new)
            .collect();
        Self { labels }
    }
}

impl PartialOrd for CanonicalName {
    fn partial_cmp(&self, other: &Self) -> Option<std::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl Ord for CanonicalName {
    /// RFC 4034 §6.1 canonical order: compare labels right-to-left,
    /// then by bytes within a label.
    fn cmp(&self, other: &Self) -> std::cmp::Ordering {
        use std::cmp::Ordering;
        let mut a = self.labels.iter();
        let mut b = other.labels.iter();
        loop {
            match (a.next(), b.next()) {
                (Some(la), Some(lb)) => {
                    let ord = la.as_bytes().cmp(lb.as_bytes());
                    if ord != Ordering::Equal {
                        return ord;
                    }
                }
                (None, None) => return Ordering::Equal,
                (None, Some(_)) => return Ordering::Less,
                (Some(_), None) => return Ordering::Greater,
            }
        }
    }
}

/// Shared handle used by the resolver.
pub type SharedNsecCache = Arc<NsecCache>;

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn covers_names_in_interval() {
        let cache = NsecCache::new(64, Duration::from_secs(3600));
        cache.insert("example.com", "f.example.com", Duration::from_secs(300));
        assert!(cache.covers("e.example.com"));
        assert!(!cache.covers("f.example.com"));
        assert!(!cache.covers("example.com"));
    }

    #[test]
    fn expired_interval_does_not_cover() {
        let cache = NsecCache::new(64, Duration::ZERO);
        cache.insert("a.com", "z.com", Duration::ZERO);
        // TTL capped to zero → immediately expired.
        std::thread::sleep(Duration::from_millis(2));
        assert!(!cache.covers("m.com"));
    }

    #[test]
    fn canonical_order_handles_labels_right_to_left() {
        let a = CanonicalName::from_str("example.com");
        let b = CanonicalName::from_str("test.com");
        // Both share "com"; "example" < "test".
        assert!(a < b);

        let c = CanonicalName::from_str("example.org");
        // "com" < "org".
        assert!(a < c);
    }

    #[test]
    fn case_insensitive() {
        let a = CanonicalName::from_str("Example.COM");
        let b = CanonicalName::from_str("example.com");
        assert_eq!(a, b);
    }
}
