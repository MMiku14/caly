//! Cache entries.
//!
//! # The three windows
//!
//! A record carries three deadlines, each with a different
//! caller-facing meaning:
//!
//! ```text
//!   ┌──────────────┬───────────────────────┬─────────────────────┐
//!   │ valid_until  │ optimistic_until      │ serve_stale_until   │
//!   │   Fresh      │   Stale               │   ServeStale        │
//!   └──────────────┴───────────────────────┴─────────────────────┘
//!          TTL          + optimistic_ttl          + 24 hours
//! ```
//!
//! * **Fresh** — answer immediately; no upstream contact.
//! * **Stale** — answer immediately; refresh in the background. This is
//!   the stale-while-revalidate pattern: the client never blocks.
//! * **`ServeStale`** — try upstream first; only fall back to the record
//!   if the upstream is confirmed unreachable. This is RFC 8767: a
//!   resolver that never SERVFAILs because its upstream is briefly down.
//!
//! # Security status
//!
//! Each entry records whether its contents were DNSSEC-validated. The
//! cache refuses to replace a `Secure` entry with a non-`Secure` one at
//! the same scope — that would be a downgrade attack.
//!
//! # Ownership
//!
//! Entries are stored as `Arc<CacheEntry>` inside the cache. A hit
//! returns the `Arc`; the caller holds it for the duration of the
//! response. When the cache evicts an entry, the caller's reference
//! keeps it alive until they are done. This is why the cache can be
//! "cleared" without invalidating in-flight reads.

use std::net::IpAddr;
use std::sync::Arc;
use std::time::{Duration, Instant};

use smallvec::SmallVec;
use smol_str::SmolStr;

/// The answer a cache entry carries.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum CachedAnswer {
    /// One or more addresses.
    Resolved(SmallVec<[IpAddr; 4]>),
    /// The name does not exist (RFC 8020 cut).
    NxDomain,
    /// The name exists but has no records of the queried type.
    Empty,
}

/// DNSSEC status of a record.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub enum SecurityStatus {
    /// No DNSSEC evidence.
    #[default]
    Insecure,
    /// A validated RRSIG chains to a trust anchor.
    Secure,
    /// A signature exists but does not verify.
    Bogus,
}

/// The three deadlines of a cache record.
#[derive(Debug, Clone, Copy)]
pub struct ValidityWindow {
    /// End of the authoritative TTL.
    pub valid_until: Instant,
    /// End of the stale-while-revalidate window.
    pub optimistic_until: Instant,
    /// End of the RFC 8767 serve-stale window.
    pub serve_stale_until: Instant,
}

impl ValidityWindow {
    /// Compute a window from a TTL and a grace duration.
    #[must_use]
    pub fn new(now: Instant, ttl: Duration, grace: Duration) -> Self {
        // A TTL that overflows the clock is clamped to one day.
        // `checked_add` is used throughout so a gigantic upstream TTL
        // cannot panic the cache.
        let valid_until = now
            .checked_add(ttl)
            .unwrap_or(now + Duration::from_hours(24));
        let optimistic_until = valid_until.checked_add(grace).unwrap_or(valid_until);
        let serve_stale_until = optimistic_until.checked_add(SERVE_STALE_EXTENSION).unwrap_or(optimistic_until);
        Self {
            valid_until,
            optimistic_until,
            serve_stale_until,
        }
    }

    /// Classify a moment relative to the window.
    ///
    /// Returns `None` once the record has aged past every window. The
    /// three live states correspond to the three deadlines documented
    /// on the module.
    #[must_use]
    pub fn classify(&self, now: Instant) -> Option<crate::cache::CacheStatus> {
        use crate::cache::CacheStatus;
        if now < self.valid_until {
            Some(CacheStatus::Fresh)
        } else if now < self.optimistic_until {
            Some(CacheStatus::Stale)
        } else if now < self.serve_stale_until {
            Some(CacheStatus::ServeStale)
        } else {
            None
        }
    }

    /// Whether the entry is still usable at all.
    #[must_use]
    pub fn is_live_at(&self, now: Instant) -> bool {
        now < self.serve_stale_until
    }
}

/// How long serve-stale extends past the optimistic window.
///
/// RFC 8767 recommends a ceiling of one to three days; one day keeps
/// the resolver from returning answers that are too old to be useful.
const SERVE_STALE_EXTENSION: Duration = Duration::from_hours(24);

/// One cache record.
#[derive(Debug)]
pub struct CacheEntry {
    /// The answer.
    pub answer: CachedAnswer,
    /// CNAME chain between the queried name and the terminal target.
    pub cname_chain: SmallVec<[SmolStr; 2]>,
    /// Freshness windows.
    pub window: ValidityWindow,
    /// DNSSEC status.
    pub security: SecurityStatus,
}

impl CacheEntry {
    /// Construct a fresh entry.
    #[must_use]
    pub fn new(
        answer: CachedAnswer,
        cname_chain: SmallVec<[SmolStr; 2]>,
        ttl: Duration,
        grace: Duration,
        security: SecurityStatus,
    ) -> Self {
        Self {
            answer,
            cname_chain,
            window: ValidityWindow::new(Instant::now(), ttl, grace),
            security,
        }
    }

    /// Produce a snapshot suitable for serialization.
    ///
    /// Returns `None` if the entry has fully expired.
    #[must_use]
    pub fn snapshot_at(
        &self,
        domain: SmolStr,
        now: Instant,
    ) -> Option<SnapshotEntry> {
        if !self.window.is_live_at(now) {
            return None;
        }
        Some(SnapshotEntry {
            domain,
            answer: self.answer.clone(),
            cname_chain: self.cname_chain.clone(),
            remaining_valid: self.window.valid_until.saturating_duration_since(now),
            remaining_optimistic: self
                .window
                .optimistic_until
                .saturating_duration_since(now),
        })
    }

    /// Restore an entry from a snapshot.
    ///
    /// Snapshots deliberately omit security status; restored entries
    /// are `Insecure` so the resolver re-validates on the next query
    /// when DNSSEC is enabled. Re-validating is cheaper than trusting a
    /// stale `Secure` flag across a restart.
    #[must_use]
    pub fn from_snapshot(snapshot: SnapshotEntry, now: Instant) -> Self {
        Self {
            answer: snapshot.answer,
            cname_chain: snapshot.cname_chain,
            window: ValidityWindow {
                valid_until: now + snapshot.remaining_valid,
                optimistic_until: now + snapshot.remaining_optimistic,
                serve_stale_until: now
                    + snapshot.remaining_optimistic
                    + SERVE_STALE_EXTENSION,
            },
            security: SecurityStatus::Insecure,
        }
    }
}

/// A serializable view of a cache entry.
///
/// The security status is deliberately omitted: a persisted `Secure`
/// flag cannot be trusted across a restart, so the loader resets it
/// to `Insecure`.
#[derive(Debug, Clone)]
pub struct SnapshotEntry {
    /// The name this entry was stored under.
    pub domain: SmolStr,
    /// The cached DNS answer.
    pub answer: CachedAnswer,
    /// The CNAME chain traversed to reach the target answer.
    pub cname_chain: SmallVec<[SmolStr; 2]>,
    /// Authoritative TTL still remaining at snapshot time.
    pub remaining_valid: Duration,
    /// Optimistic window still remaining at snapshot time.
    pub remaining_optimistic: Duration,
}

// Arc alias used throughout the cache.
#[allow(dead_code)]
pub type SharedEntry = Arc<CacheEntry>;

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn window_classifies_each_phase() {
        let now = Instant::now();
        let w = ValidityWindow::new(now, Duration::from_secs(10), Duration::from_secs(20));

        // Well within TTL.
        assert_eq!(
            w.classify(now + Duration::from_secs(5)),
            Some(crate::cache::CacheStatus::Fresh)
        );
        // Past TTL, within grace.
        assert_eq!(
            w.classify(now + Duration::from_secs(15)),
            Some(crate::cache::CacheStatus::Stale)
        );
        // Past grace, within serve-stale.
        assert_eq!(
            w.classify(now + Duration::from_secs(3600)),
            Some(crate::cache::CacheStatus::ServeStale)
        );
        // Past every window.
        assert_eq!(w.classify(now + Duration::from_secs(100_000)), None);
    }

    #[test]
    fn snapshot_roundtrip() {
        let entry = CacheEntry::new(
            CachedAnswer::Resolved(smallvec::smallvec![
                "192.0.2.1".parse().unwrap(),
            ]),
            SmallVec::new(),
            Duration::from_secs(300),
            Duration::from_secs(60),
            SecurityStatus::Secure,
        );
        let snapshot = entry
            .snapshot_at(SmolStr::new("example.com"), Instant::now())
            .unwrap();
        assert_eq!(snapshot.domain, "example.com");

        let restored = CacheEntry::from_snapshot(snapshot, Instant::now());
        // Security is reset to Insecure on restore.
        assert_eq!(restored.security, SecurityStatus::Insecure);
    }
}
