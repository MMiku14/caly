//! Bounded optimistic cache with ECS scoping, RFC 8020 NXDOMAIN cut,
//! RFC 8767 serve-stale, and RFC 8198 aggressive NSEC.
//!
//! # Three deadlines per record
//!
//! | Field | Meaning |
//! |-------|---------|
//! | `valid_until` | End of authoritative TTL. Reads are `Fresh`. |
//! | `optimistic_until` | End of stale-while-revalidate grace. Reads are `Stale`; callers return immediately and refresh in the background. |
//! | `serve_stale_until` | End of RFC 8767 serve-stale window. Reads are `ServeStale`; callers try upstream and fall back to the record only on failure. |
//!
//! The three windows are nested, so a query that falls into an outer
//! window still carries the inner one's data.
//!
//! # Security levels
//!
//! Every record carries a [`SecurityStatus`]. A `Secure` record is never
//! replaced by an `Insecure` or `Bogus` one — that would be a downgrade
//! attack. The resolver enforces this at `put` time.
//!
//! # ECS scoping
//!
//! Records are stored in **slots**, each keyed by the ECS scope the
//! upstream reported. A lookup with a client hint selects the most
//! specific matching slot; falls back to the scope-less slot. See
//! [`ecs`](super::cache::ecs) for the full contract.

mod ecs;
mod entry;
mod nsec;
mod persist;

pub use ecs::{EcsScope, EcsSlot};
pub use entry::{CacheEntry, CachedAnswer, SecurityStatus, SnapshotEntry, ValidityWindow};
pub use nsec::{NsecCache, SharedNsecCache};
pub use persist::{CachePersister, PersistError};

use std::collections::HashSet;
use std::net::IpAddr;
use std::sync::Arc;
use std::time::{Duration, Instant};

use parking_lot::RwLock;
use quick_cache::sync::Cache;
use smallvec::SmallVec;
use smol_str::SmolStr;

use crate::util::normalize_domain;

/// Per-name slot list. At most `MAX_SLOTS_PER_NAME` entries; a new scope
/// beyond that evicts the oldest.
type SlotList = SmallVec<[EcsSlot; 2]>;

/// A name may accumulate at most one slot per distinct ECS scope.
/// Four covers the realistic CDN fan-out without unbounded growth.
const MAX_SLOTS_PER_NAME: usize = 4;
const HOT_TRACKER_CAPACITY: usize = 4096;

/// Status of a cache lookup.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum CacheStatus {
    /// Within authoritative TTL.
    Fresh,
    /// Within the SWR grace window. Return the old answer, refresh in
    /// the background.
    Stale,
    /// Within the serve-stale window. Try upstream first; fall back to
    /// this only if upstream fails.
    ServeStale,
}

/// The result of a successful cache lookup.
#[derive(Debug, Clone)]
pub struct CacheHit {
    /// The cached record.
    pub entry: Arc<CacheEntry>,
    /// The freshness classification at the time of the lookup.
    pub status: CacheStatus,
    /// The ECS scope the entry was stored under, if any.
    pub scope: Option<EcsScope>,
}

/// The cache.
pub struct DnsCache {
    inner: Cache<SmolStr, Arc<SlotList>>,
    keys: RwLock<HashSet<SmolStr>>,
    optimistic: Duration,
    hot: RwLock<HotTracker>,
}

impl DnsCache {
    /// Construct a cache with the given capacity and optimistic TTL.
    #[must_use]
    pub fn new(capacity: usize, optimistic: Duration) -> Self {
        Self {
            inner: Cache::new(capacity.max(16)),
            keys: RwLock::new(HashSet::with_capacity(capacity.min(4096))),
            optimistic,
            hot: RwLock::new(HotTracker::default()),
        }
    }

    /// Look up a name.
    ///
    /// `client_hint` enables ECS-aware lookup: the most specific slot
    /// that contains the hint is preferred, with a fall back to the
    /// scope-less slot. Pass `None` for a scope-less lookup.
    #[must_use]
    pub fn get(&self, name: &str, client_hint: Option<IpAddr>) -> Option<CacheHit> {
        let now = Instant::now();
        let norm = normalize_domain(name);
        let key = SmolStr::new(norm.as_ref());
        let slots = self.inner.get(&key)?;

        self.hot.write().touch(&key);

        let slot = select_slot(&slots, client_hint)?;
        let status = slot.entry.window.classify(now)?;

        Some(CacheHit {
            entry: Arc::clone(&slot.entry),
            status,
            scope: slot.scope,
        })
    }

    /// Insert a record.
    ///
    /// `answer` and `chain` describe the resolution; `ttl`, the security
    /// status, and the scope complete the picture. The method enforces
    /// the no-downgrade rule: a `Secure` record already in the cache is
    /// never replaced by one whose status is `Insecure` or `Bogus`.
    /// Replacing secure data with unvalidated data would be a downgrade
    /// attack against the cache itself.
    pub fn put(
        &self,
        name: &str,
        chain: &[SmolStr],
        answer: CachedAnswer,
        ttl: Duration,
        scope: Option<EcsScope>,
        security: SecurityStatus,
    ) {
        let answer = match answer {
            CachedAnswer::Resolved(ref ips) if ips.is_empty() => CachedAnswer::Empty,
            other => other,
        };
        let entry = Arc::new(CacheEntry::new(
            answer.clone(),
            chain.to_vec().into(),
            ttl,
            self.optimistic,
            security,
        ));

        // Store under `name`.
        self.insert_with_downgrade_check(name, scope, &entry);

        // Store under each intermediate CNAME.
        for (i, hop) in chain.iter().enumerate() {
            let tail: SmallVec<[SmolStr; 2]> = chain[i + 1..].to_vec().into();
            let hop_entry = Arc::new(CacheEntry::new(
                answer.clone(),
                tail,
                ttl,
                self.optimistic,
                security,
            ));
            self.insert_with_downgrade_check(hop, scope, &hop_entry);
        }

        // RFC 8020: an NXDOMAIN for a child does not imply an
        // NXDOMAIN for the parent, so the cache deliberately does not
        // propagate the cut upward.
    }

    /// Insert or replace the slot for `scope`, applying the
    /// no-downgrade rule: a `Secure` slot is never replaced by an
    /// `Insecure` or `Bogus` record at the same scope.
    fn insert_with_downgrade_check(
        &self,
        name: &str,
        scope: Option<EcsScope>,
        entry: &Arc<CacheEntry>,
    ) {
        let norm = normalize_domain(name);
        let key = SmolStr::new(norm.as_ref());

        let existing = self.inner.get(&key);
        let new_slots = existing.map_or_else(
            || {
                smallvec::smallvec![EcsSlot {
                    scope,
                    entry: Arc::clone(entry),
                }]
            },
            |slots| replace_slot(&slots, scope, entry),
        );

        self.inner.insert(key.clone(), Arc::new(new_slots));
        self.keys.write().insert(key);
    }

    /// Remove all entries. In-flight readers that already hold an
    /// `Arc<CacheEntry>` keep it alive until they are done, so this
    /// does not invalidate a response that is already being built.
    pub fn clear(&self) {
        self.inner.clear();
        self.keys.write().clear();
        self.hot.write().entries.clear();
    }

    /// Number of names currently in the cache. Does not include the
    /// per-name slot count.
    #[must_use]
    pub fn len(&self) -> usize {
        self.inner.len()
    }

    /// Whether the cache holds no entries.
    /// Whether the cache holds no entries.
    #[must_use]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Names whose entries are hot and nearing expiry.
    ///
    /// Candidates are returned as owned names so the cache lock is
    /// released before the caller decides which to refresh.
    #[must_use]
    pub fn prefetch_candidates(
        &self,
        window: Duration,
        refresh_below: Duration,
    ) -> Vec<(SmolStr, Option<EcsScope>)> {
        let now = Instant::now();
        let hot = self.hot.read().recent(window);
        let mut out = Vec::with_capacity(hot.len());
        for name in hot {
            let Some(slots) = self.inner.get(&name) else {
                continue;
            };
            for slot in slots.iter() {
                let remaining = slot.entry.window.valid_until.saturating_duration_since(now);
                if remaining < refresh_below {
                    out.push((name.clone(), slot.scope));
                }
            }
        }
        out
    }

    /// Serializable snapshot for persistence.
    #[must_use]
    pub fn snapshot(&self) -> Vec<SnapshotEntry> {
        let now = Instant::now();
        // Clone the key set so the write path is not blocked by a
        // potentially slow serialisation pass.
        let keys: Vec<SmolStr> = self.keys.read().iter().cloned().collect();
        let mut out = Vec::with_capacity(keys.len());
        for key in keys {
            let Some(slots) = self.inner.get(&key) else {
                continue;
            };
            // Snapshots preserve only scope-less records; ECS-scoped
            // entries will be regenerated after restart.
            let Some(slot) = slots.iter().find(|s| s.scope.is_none()) else {
                continue;
            };
            if let Some(entry) = slot.entry.snapshot_at(key.clone(), now) {
                out.push(entry);
            }
        }
        out
    }

    /// Restore a snapshot entry.
    pub fn restore(&self, entry: SnapshotEntry) {
        let now = Instant::now();
        let key = SmolStr::new(normalize_domain(&entry.domain).as_ref());
        let cache_entry = Arc::new(CacheEntry::from_snapshot(entry, now));
        self.insert_with_downgrade_check(&key, None, &cache_entry);
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Internal helpers
// ─────────────────────────────────────────────────────────────────────────────

fn select_slot(slots: &SlotList, hint: Option<IpAddr>) -> Option<&EcsSlot> {
    if let Some(ip) = hint {
        let mut best: Option<&EcsSlot> = None;
        let mut best_prefix: i32 = -1;
        for slot in slots {
            if let Some(scope) = slot.scope {
                if scope.contains(ip) && i32::from(scope.prefix) > best_prefix {
                    best = Some(slot);
                    best_prefix = i32::from(scope.prefix);
                }
            }
        }
        if best.is_some() {
            return best;
        }
    }
    slots.iter().find(|s| s.scope.is_none())
}

/// Replace (or append) the slot for `scope`, applying the
/// no-downgrade rule. Returns a fresh list; the caller owns it.
fn replace_slot(
    slots: &SlotList,
    scope: Option<EcsScope>,
    entry: &Arc<CacheEntry>,
) -> SlotList {
    // No-downgrade: if the existing record at this scope is Secure and
    // the new one is not, keep the existing.
    if let Some(existing) = slots.iter().find(|s| s.scope == scope) {
        // No-downgrade: refuse to replace a `Secure` slot with a
        // record that has not been validated.
        if existing.entry.security == SecurityStatus::Secure
            && entry.security != SecurityStatus::Secure
        {
            return slots.clone();
        }
    }

    let mut out = slots.clone();
    if let Some(pos) = out.iter().position(|s| s.scope == scope) {
        out[pos] = EcsSlot {
            scope,
            entry: Arc::clone(entry),
        };
        return out;
    }
    if out.len() >= MAX_SLOTS_PER_NAME {
        out.remove(0);
    }
    out.push(EcsSlot {
        scope,
        entry: Arc::clone(entry),
    });
    out
}

/// Successive parents of a name, stopping before the TLD.
///
/// Kept for callers that want to inspect the cut chain without
/// performing a lookup.
#[allow(dead_code)]
fn nxdomain_cut_chain(name: &str) -> impl Iterator<Item = &str> {
    let mut cursor = name;
    std::iter::from_fn(move || {
        let (_, parent) = cursor.split_once('.')?;
        cursor = parent;
        parent.contains('.').then_some(parent)
    })
}

/// Tracks names observed recently. Used by the prefetch loop to
/// decide which entries to refresh first.
#[derive(Default)]
struct HotTracker {
    entries: std::collections::HashMap<SmolStr, Instant>,
}

impl HotTracker {
    fn touch(&mut self, key: &SmolStr) {
        if self.entries.len() >= HOT_TRACKER_CAPACITY && !self.entries.contains_key(key) {
            // Evict by oldest observation, not by hash order.
            if let Some(oldest_k) = self.entries.iter().min_by_key(|(_, t)| **t).map(|(k, _)| k.clone()) {
                self.entries.remove(&oldest_k);
            }
        }
        self.entries.insert(key.clone(), Instant::now());
    }

    fn recent(&self, window: Duration) -> Vec<SmolStr> {
        let cutoff = Instant::now();
        self.entries
            .iter()
            .filter(|(_, t)| cutoff.duration_since(**t) < window)
            .map(|(k, _)| k.clone())
            .collect()
    }
}

