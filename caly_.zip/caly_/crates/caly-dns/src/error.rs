//! Unified error type.
//!
//! Every fallible operation in the crate returns [`Result`]. The error
//! enum carries enough structure that callers can decide policy without
//! string matching: whether to retry, whether to fall back, whether to
//! surface to the client.

use smol_str::SmolStr;
use thiserror::Error;

/// The crate's result type.
pub type Result<T, E = Error> = std::result::Result<T, E>;

/// All errors this crate produces.
#[non_exhaustive]
#[derive(Debug, Error)]
pub enum Error {
    // ── Configuration ────────────────────────────────────────────────
    #[error("configuration error: {0}")]
    /// Invalid configuration.
    Config(SmolStr),

    // ── Wire format ──────────────────────────────────────────────────
    #[error("malformed message: {0}")]
    /// Static strings keep the hot path allocation-free.
    Malformed(&'static str),

    #[error("message too large: {0} bytes")]
    /// A wire message exceeded the size limit.
    MessageTooLarge(usize),

    #[error("CNAME chain exceeded maximum depth")]
    /// The CNAME chain exceeded the maximum depth.
    CnameLoop,

    // ── Protocol / Policy Extensions (Purified) ─────────────────────
    #[error("EDNS framing error: {0}")]
    /// An EDNS option or framing was malformed.
    Edns(SmolStr),

    #[error("DNS64 synthesis error: {0}")]
    /// DNS64 synthesis failed.
    Dns64(SmolStr),

    // ── Upstream ─────────────────────────────────────────────────────
    #[error("upstream '{tag}' is unavailable: {reason}")]
    /// An upstream server could not be reached or refused the query.
    UpstreamUnavailable {
        /// The configured tag of the failed upstream.
        tag: SmolStr,
        /// A short description of the failure.
        reason: SmolStr,
    },

    #[error("upstream '{0}' not found")]
    /// The configured upstream tag does not exist.
    UpstreamNotFound(SmolStr),

    #[error("upstream '{tag}' timed out after {elapsed_ms} ms")]
    /// An upstream server did not answer within its budget.
    UpstreamTimeout {
        /// The configured tag of the timed-out upstream.
        tag: SmolStr,
        /// How long the exchange ran before the budget expired.
        elapsed_ms: u64,
    },

    #[error("all upstreams exhausted for '{0}'")]
    /// Every upstream in the fallback chain failed.
    AllUpstreamsFailed(SmolStr),

    #[error("circuit breaker open for '{0}'")]
    /// The circuit breaker for the upstream is open.
    CircuitOpen(SmolStr),

    // ── DNS semantics ────────────────────────────────────────────────
    #[error("domain '{0}' does not exist")]
    /// The queried name does not exist.
    NxDomain(SmolStr),

    #[error("no records of the requested type for '{0}'")]
    /// The name exists but has no records of the requested type.
    NoData(SmolStr),

    // ── DNSSEC ───────────────────────────────────────────────────────
    #[error("DNSSEC validation failed for '{0}'")]
    /// DNSSEC validation failed for the answer.
    DnssecBogus(SmolStr),

    #[error("DNSSEC signature expired")]
    /// A DNSSEC signature is outside its validity window.
    DnssecExpired,

    // ── Cache ────────────────────────────────────────────────────────
    #[error("cache persistence failed: {0}")]
    /// Reading or writing the cache snapshot failed.
    Persistence(SmolStr),

    // ── Resource exhaustion ──────────────────────────────────────────
    #[error("FakeIP pool exhausted")]
    /// The `FakeIP` pool has no free slots.
    FakeIpExhausted,

    #[error("query rate limit exceeded")]
    /// The client exceeded the response rate limit.
    RateLimited,

    // ── I/O ──────────────────────────────────────────────────────────
    #[error("I/O error: {0}")]
    /// An underlying I/O operation failed.
    Io(#[from] std::io::Error),
}

impl Error {
    /// Build a configuration error from any string-like value.
    ///
    /// Accepts `&str`, `String`, and `SmolStr`, so call sites do not
    /// have to spell out the conversion.
    pub fn config(msg: impl Into<SmolStr>) -> Self {
        Self::Config(msg.into())
    }

    /// Whether this error is strictly an upstream network timeout.
    ///
    /// A circuit breaker being `open` is *not* a timeout: the upstream was
    /// never contacted. Test [`Error::is_circuit_open`] for that condition.
    #[must_use]
    pub const fn is_timeout(&self) -> bool {
        matches!(self, Self::UpstreamTimeout { .. })
    }

    /// Whether the upstream circuit breaker is open (the request was
    /// short-circuited before any network exchange).
    #[must_use]
    pub const fn is_circuit_open(&self) -> bool {
        matches!(self, Self::CircuitOpen(_))
    }

    /// Build an `UpstreamTimeout` from a typed duration so callers
    /// never pass a raw millisecond count by mistake.
    #[must_use]
    pub fn upstream_timeout(tag: impl Into<SmolStr>, duration: std::time::Duration) -> Self {
        Self::UpstreamTimeout {
            tag: tag.into(),
            elapsed_ms: u64::try_from(duration.as_millis()).unwrap_or(u64::MAX),
        }
    }

    /// Whether this error was caused by DNSSEC validation failure.
    #[must_use]
    pub const fn is_dnssec(&self) -> bool {
        matches!(self, Self::DnssecBogus(_) | Self::DnssecExpired)
    }

    /// Whether retrying against *another* upstream could succeed.
    ///
    /// Transport-level failures are retryable: a timeout, an unreachable
    /// host, an I/O error, or a breaker that is currently open on *this*
    /// upstream all mean a different upstream may still answer. Semantic
    /// failures (`NxDomain`, `NoData`, `DnssecBogus`) are not — every
    /// upstream would return the same authoritative answer.
    #[must_use]
    pub const fn is_retryable(&self) -> bool {
        matches!(
            self,
            Self::UpstreamTimeout { .. }
                | Self::UpstreamUnavailable { .. }
                | Self::Io(_)
                | Self::CircuitOpen(_)
        )
    }

    /// The concrete RCODE this error maps to when it is surfaced to a
    /// client, or `None` when no DNS-level code applies.
    ///
    /// Errors that have no RCODE of their own (`None` here) are not
    /// silently swallowed: the caller resolves them to a policy default,
    /// conventionally `SERVFAIL`. Errors that already carry a meaningful
    /// answer (including `DnssecBogus`/`Config`, which we report as
    /// `SERVFAIL`) return their code directly.
    #[must_use]
    pub const fn rcode(&self) -> Option<u8> {
        use crate::wire::{RCODE_FORMERR, RCODE_NOERROR, RCODE_NOTIMP, RCODE_NXDOMAIN, RCODE_REFUSED, RCODE_SERVFAIL};
        match self {
            Self::NxDomain(_) => Some(RCODE_NXDOMAIN),
            Self::NoData(_) => Some(RCODE_NOERROR),
            Self::Malformed(_) | Self::Edns(_) => Some(RCODE_FORMERR),
            Self::DnssecBogus(_)
            | Self::DnssecExpired
            | Self::Config(_)
            | Self::CircuitOpen(_) => Some(RCODE_SERVFAIL),
            Self::RateLimited | Self::FakeIpExhausted => Some(RCODE_REFUSED),
            Self::UpstreamNotFound(_) => Some(RCODE_NOTIMP),
            _ => None,
        }
    }
}

/// Convert a `caly-common` DNS error into ours.
///
/// The `caly-common` crate defines a wider interface than we need; this
/// adapter keeps our public error type lean while preserving the ability
/// to implement the common `DnsResolver` trait.
impl From<caly_common::dns::DnsError> for Error {
    fn from(e: caly_common::dns::DnsError) -> Self {
        use caly_common::dns::DnsError as Common;
        match e {
            Common::NotFound(name) => Self::NxDomain(name),
            Common::EmptyAnswer(name) => Self::NoData(name),
            Common::Timeout(tag) => Self::UpstreamTimeout {
                tag,
                elapsed_ms: 0,
            },
            Common::NoUpstream => Self::AllUpstreamsFailed(SmolStr::new_static("(none)")),
            Common::FakeIpExhausted => Self::FakeIpExhausted,
            Common::CnameLoop => Self::CnameLoop,
            Common::MalformedResponse(msg) | Common::UpstreamFailed(msg) => {
                Self::UpstreamUnavailable {
                    tag: SmolStr::new_static("(unknown)"),
                    reason: msg,
                }
            }
            Common::Io { msg, .. } => Self::UpstreamUnavailable {
                tag: SmolStr::new_static("(io)"),
                reason: msg,
            },
            Common::ParseError(msg) => Self::Config(msg),
            _ => Self::UpstreamUnavailable {
                tag: SmolStr::new_static("(unknown)"),
                reason: SmolStr::new_static("unspecified"),
            },
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn retryable_classification() {
        assert!(Error::UpstreamTimeout {
            tag: "cf".into(),
            elapsed_ms: 200,
        }
        .is_retryable());
        assert!(!Error::NxDomain("example.com".into()).is_retryable());
        assert!(!Error::DnssecBogus("example.com".into()).is_retryable());
        // An open breaker on this upstream must be failover-eligible.
        assert!(Error::CircuitOpen("cf".into()).is_retryable());
    }

    #[test]
    fn timeout_is_not_the_same_as_circuit_open() {
        let timeout = Error::UpstreamTimeout {
            tag: "cf".into(),
            elapsed_ms: 200,
        };
        let open = Error::CircuitOpen("cf".into());
        assert!(timeout.is_timeout());
        assert!(!open.is_timeout()); // breaker open was never a timeout
        assert!(!timeout.is_circuit_open());
        assert!(open.is_circuit_open());
    }

    #[test]
    fn rcode_mapping() {
        assert_eq!(Error::NxDomain("x".into()).rcode(), Some(3));
        assert_eq!(Error::NoData("x".into()).rcode(), Some(0));
        assert_eq!(Error::Config("x".into()).rcode(), Some(2));
    }
}

impl PartialEq for Error {
    fn eq(&self, other: &Self) -> bool {
        match (self, other) {
            (Self::Malformed(a), Self::Malformed(b)) => a == b,
            (Self::MessageTooLarge(a), Self::MessageTooLarge(b)) => a == b,
            (Self::CnameLoop, Self::CnameLoop)
            | (Self::DnssecExpired, Self::DnssecExpired)
            | (Self::FakeIpExhausted, Self::FakeIpExhausted)
            | (Self::RateLimited, Self::RateLimited) => true,
            (
                Self::UpstreamUnavailable { tag: t1, reason: r1 },
                Self::UpstreamUnavailable { tag: t2, reason: r2 },
            ) => t1 == t2 && r1 == r2,
            (
                Self::UpstreamTimeout { tag: t1, elapsed_ms: e1 },
                Self::UpstreamTimeout { tag: t2, elapsed_ms: e2 },
            ) => t1 == t2 && e1 == e2,
            (Self::Config(a), Self::Config(b))
            | (Self::UpstreamNotFound(a), Self::UpstreamNotFound(b))
            | (Self::AllUpstreamsFailed(a), Self::AllUpstreamsFailed(b))
            | (Self::CircuitOpen(a), Self::CircuitOpen(b))
            | (Self::NxDomain(a), Self::NxDomain(b))
            | (Self::NoData(a), Self::NoData(b))
            | (Self::DnssecBogus(a), Self::DnssecBogus(b))
            | (Self::Persistence(a), Self::Persistence(b))
            | (Self::Edns(a), Self::Edns(b))
            | (Self::Dns64(a), Self::Dns64(b)) => a == b,
            (Self::Io(a), Self::Io(b)) => a.kind() == b.kind(),
            _ => false,
        }
    }
}
