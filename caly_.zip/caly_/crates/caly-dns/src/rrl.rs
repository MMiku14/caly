//! Response Rate Limiting (draft-vixie-dnsext-dns-rrl).
//!
//! # The threat
//!
//! DNS is an amplification vector. An attacker sends a small query
//! with a spoofed source address; the server sends a much larger
//! response to that address. The amplification factor for a typical
//! query is 30–70×; for ANY-record queries it has historically exceeded
//! 100×.
//!
//! # The defence
//!
//! RRL limits the *response* rate, keyed by a coarse tuple:
//!
//! ```text
//!   (client subnet, query name, query type)
//! ```
//!
//! A legitimate client never triggers it. An attacker spoofing a
//! victim's address triggers it immediately, and the victim is spared.
//!
//! # Slip — the recovery path
//!
//! If every limited response were dropped, legitimate clients sharing
//! a subnet with an attacker would suffer transient failures. The
//! `slip` parameter sends a truncated (`TC=1`) response every Nth time
//! a bucket is exhausted. The client retries over TCP, where source
//! addresses cannot be spoofed, and the legitimate traffic gets
//! through.
//!
//! # Token bucket
//!
//! Each bucket holds a fractional number of tokens. Tokens refill at
//! `qps` per second, capped at `qps`. A query consumes one token;
//! if none are available, the response is dropped (or truncated).

use std::net::{IpAddr, Ipv4Addr, Ipv6Addr};
use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::Arc;
use std::time::Instant;

use parking_lot::Mutex;
use quick_cache::sync::Cache;
use smol_str::SmolStr;

use crate::util::normalize_domain;

/// The decision RRL returns for one response.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum RrlVerdict {
    /// Send the response normally.
    Pass,
    /// Drop the response.
    Drop,
    /// Send a truncated response so the client retries over TCP.
    Truncate,
}

/// Tuning for the limiter.
#[derive(Debug, Clone, Copy)]
pub struct Config {
    /// Responses per second, per bucket.
    pub qps: f64,
    /// IPv4 prefix length for grouping clients.
    pub ipv4_prefix: u8,
    /// IPv6 prefix length for grouping clients.
    pub ipv6_prefix: u8,
    /// Send a truncated response every Nth drop. `0` disables slipping.
    pub slip: u32,
}

impl Default for Config {
    fn default() -> Self {
        Self {
            qps: 20.0,
            ipv4_prefix: 24,
            ipv6_prefix: 56,
            slip: 2,
        }
    }
}

/// The rate limiter.
pub struct Rrl {
    buckets: Cache<RrlKey, Arc<Mutex<Bucket>>>,
    config: Config,
    drop_counter: AtomicU64,
}

#[derive(Debug, Clone, PartialEq, Eq, Hash)]
struct RrlKey {
    /// The client subnet, already masked.
    subnet: IpAddr,
    /// The query name, lowercased.
    qname: SmolStr,
    /// The query type.
    qtype: u16,
}

struct Bucket {
    /// Fractional tokens; refilled continuously.
    tokens: f64,
    /// Last time tokens were refilled.
    last_refill: Instant,
    /// Consecutive rate-limit events observed *for this bucket only*. Drives
    /// the slip cadence so that one bucket cannot perturb another's.
    drops: u64,
}

impl Rrl {
    /// Construct a limiter with the given configuration and bucket
    /// capacity. The capacity bounds memory: `capacity` distinct keys
    /// are tracked; beyond that, the least valuable are evicted under
    /// `quick_cache`'s policy.
    #[must_use]
    pub fn new(config: Config, capacity: usize) -> Self {
        Self {
            buckets: Cache::new(capacity.max(1)),
            config,
            drop_counter: AtomicU64::new(0),
        }
    }

    /// Check whether a response to `(client, qname, qtype)` may be sent.
    #[must_use]
    pub fn check(&self, client: IpAddr, qname: &str, qtype: u16) -> RrlVerdict {
        let key = RrlKey {
            subnet: mask(client, self.config.ipv4_prefix, self.config.ipv6_prefix),
            // Normalisation borrows when the input is already canonical.
            qname: SmolStr::new(normalize_domain(qname).as_ref()),
            qtype,
        };

        let now = Instant::now();

        // `quick_cache` inserts atomically; concurrent callers will either observe
        // an existing bucket or store a newly minted token bucket.
        let bucket = self
            .buckets
            .get_or_insert_with(&key, || {
                // `quick_cache` has no get-or-insert-with-lock, so the
                // closure returns a Result; ours can never fail.
                Ok::<_, std::convert::Infallible>(Arc::new(Mutex::new(
                    Bucket::new(self.config.qps, now),
                )))
            })
            .unwrap_or_else(|never| match never {});
        let verdict = {
            let mut guard = bucket.lock();
            // `checked_duration_since` guards against a non-monotonic
            // clock: a negative interval is treated as zero elapsed.
            let elapsed = now.checked_duration_since(guard.last_refill).unwrap_or(std::time::Duration::ZERO).as_secs_f64();
            guard.tokens = elapsed.mul_add(self.config.qps, guard.tokens).min(self.config.qps);
            guard.last_refill = now;

            if guard.tokens >= 1.0 {
                guard.tokens -= 1.0;
                RrlVerdict::Pass
            } else {
                // Rate-limited. Record the event globally for observability,
                // then decide slip from *this* bucket's own drop count. The
                // previous implementation keyed slip off a single global
                // counter, so traffic on unrelated buckets silently advanced
                // the slip cadence of the bucket being tested — an attacker
                // could exhaust another subnet's slips, defeating recovery.
                self.drop_counter.fetch_add(1, Ordering::Relaxed);
                guard.drops = guard.drops.wrapping_add(1);
                if self.config.slip > 0 && guard.drops % u64::from(self.config.slip) == 0 {
                    RrlVerdict::Truncate
                } else {
                    RrlVerdict::Drop
                }
            }
        };

        verdict
    }

    /// Number of tracked buckets.
    #[must_use]
    pub fn len(&self) -> usize {
        self.buckets.len()
    }

    /// Whether no bucket has ever been created.
    #[must_use]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Total rate-limit events (drops plus slips) since construction.
    #[must_use]
    pub fn limited_total(&self) -> u64 {
        self.drop_counter.load(Ordering::Relaxed)
    }
}

impl Bucket {
    /// Seed a full bucket so the very first query is allowed.
    const fn new(qps: f64, now: Instant) -> Self {
        Self {
            tokens: qps,
            last_refill: now,
            drops: 0,
        }
    }
}

/// Mask an IP to a coarse subnet.
fn mask(addr: IpAddr, v4_prefix: u8, v6_prefix: u8) -> IpAddr {
    match addr {
        IpAddr::V4(v4) => {
            let prefix = v4_prefix.min(32);
            let mask = if prefix == 0 {
                0
            } else {
                u32::MAX.checked_shl(32 - u32::from(prefix)).unwrap_or(0)
            };
            IpAddr::V4(Ipv4Addr::from(u32::from(v4) & mask))
        }
        IpAddr::V6(v6) => {
            let prefix = v6_prefix.min(128);
            let mask = if prefix == 0 {
                0
            } else {
                u128::MAX.checked_shl(128 - u32::from(prefix)).unwrap_or(0)
            };
            IpAddr::V6(Ipv6Addr::from(u128::from(v6) & mask))
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn fast_config(slip: u32) -> Config {
        Config {
            qps: 1.0,
            ipv4_prefix: 24,
            ipv6_prefix: 56,
            slip,
        }
    }

    #[test]
    fn first_query_passes() {
        let rrl = Rrl::new(fast_config(0), 64);
        let client: IpAddr = "1.2.3.4".parse().unwrap();
        assert_eq!(rrl.check(client, "example.com", 1), RrlVerdict::Pass);
    }

    #[test]
    fn bursts_are_limited_from_same_subnet() {
        let rrl = Rrl::new(fast_config(0), 64);
        let client: IpAddr = "1.2.3.4".parse().unwrap();
        assert_eq!(rrl.check(client, "example.com", 1), RrlVerdict::Pass);
        // Immediate follow-up from the same /24 shares the bucket.
        assert_eq!(rrl.check(client, "example.com", 1), RrlVerdict::Drop);
        assert_eq!(rrl.check(client, "example.com", 1), RrlVerdict::Drop);
    }

    #[test]
    fn different_subnets_have_independent_buckets() {
        let rrl = Rrl::new(fast_config(0), 64);
        let a: IpAddr = "1.2.3.4".parse().unwrap();
        let b: IpAddr = "5.6.7.8".parse().unwrap();
        assert_eq!(rrl.check(a, "example.com", 1), RrlVerdict::Pass);
        assert_eq!(rrl.check(b, "example.com", 1), RrlVerdict::Pass);
    }

    #[test]
    fn different_qnames_have_independent_buckets() {
        let rrl = Rrl::new(fast_config(0), 64);
        let client: IpAddr = "1.2.3.4".parse().unwrap();
        assert_eq!(rrl.check(client, "a.com", 1), RrlVerdict::Pass);
        assert_eq!(rrl.check(client, "b.com", 1), RrlVerdict::Pass);
    }

    #[test]
    fn different_qtypes_have_independent_buckets() {
        let rrl = Rrl::new(fast_config(0), 64);
        let client: IpAddr = "1.2.3.4".parse().unwrap();
        assert_eq!(rrl.check(client, "example.com", 1), RrlVerdict::Pass);
        assert_eq!(rrl.check(client, "example.com", 28), RrlVerdict::Pass);
    }

    #[test]
    fn slip_emits_truncated() {
        let rrl = Rrl::new(fast_config(1), 64);
        let client: IpAddr = "1.2.3.4".parse().unwrap();
        rrl.check(client, "example.com", 1);
        // With slip=1, every subsequent limited response is Truncate.
        assert_eq!(rrl.check(client, "example.com", 1), RrlVerdict::Truncate);
    }

    #[test]
    fn slip_cadence_is_per_bucket() {
        // slip=2 -> the 2nd, 4th, ... limited response of a *given* bucket is
        // Truncate. Buckets must not share this counter.
        let rrl = Rrl::new(fast_config(2), 64);
        let a: IpAddr = "1.2.3.4".parse().unwrap();
        let b: IpAddr = "9.9.9.9".parse().unwrap();

        // Bucket A: 1 pass, then drops #1 -> Drop, #2 -> Truncate.
        assert_eq!(rrl.check(a, "x.com", 1), RrlVerdict::Pass);
        assert_eq!(rrl.check(a, "x.com", 1), RrlVerdict::Drop);
        assert_eq!(rrl.check(a, "x.com", 1), RrlVerdict::Truncate);

        // Bucket B starts its own count from zero: a shared global counter
        // (the old behaviour) would have landed B on a Truncate here.
        assert_eq!(rrl.check(b, "x.com", 1), RrlVerdict::Pass);
        assert_eq!(rrl.check(b, "x.com", 1), RrlVerdict::Drop);
        assert_eq!(rrl.check(b, "x.com", 1), RrlVerdict::Truncate);
    }

    #[test]
    fn bucket_refills_over_time() {
        let rrl = Rrl::new(
            Config {
                qps: 1000.0,
                ..fast_config(0)
            },
            64,
        );
        let client: IpAddr = "1.2.3.4".parse().unwrap();
        // Drain the bucket.
        for _ in 0..1000 {
            let _ = rrl.check(client, "example.com", 1);
        }
        std::thread::sleep(std::time::Duration::from_millis(5));
        // After 5 ms at 1000 QPS, ~5 tokens have refilled.
        assert_eq!(rrl.check(client, "example.com", 1), RrlVerdict::Pass);
    }

    #[test]
    fn case_insensitive_qname() {
        let rrl = Rrl::new(fast_config(0), 64);
        let client: IpAddr = "1.2.3.4".parse().unwrap();
        assert_eq!(rrl.check(client, "Example.COM", 1), RrlVerdict::Pass);
        // Same bucket, different case.
        assert_eq!(rrl.check(client, "example.com.", 1), RrlVerdict::Drop);
    }

    #[test]
    fn masking_groups_by_prefix() {
        assert_eq!(
            mask("1.2.3.4".parse().unwrap(), 24, 56),
            "1.2.3.0".parse::<IpAddr>().unwrap()
        );
        assert_eq!(
            mask("1.2.3.4".parse().unwrap(), 16, 56),
            "1.2.0.0".parse::<IpAddr>().unwrap()
        );
    }
}
