//! Graceful shutdown.
//!
//! # The ordering matters
//!
//! SIGTERM can arrive at any moment. Naively aborting every task leaves
//! clients with half-written responses and can lose cache state. This
//! module encodes the correct order:
//!
//! 1. **Stop accepting.** Close listeners. In-flight queries continue.
//! 2. **Drain.** Wait up to `drain_timeout` for in-flight queries to
//!    finish.
//! 3. **Cancel background work.** Prefetch, sweepers, health probes.
//!    These are best-effort and can be cut without consequence.
//! 4. **Persist.** Write the cache to disk.
//!
//! Each phase is bounded by a timeout so a stuck task cannot prevent
//! shutdown indefinitely.

use std::sync::Arc;
use std::time::Duration;

use tokio::sync::watch;
use tokio::task::JoinHandle;

use crate::cache::CachePersister;

/// Configures the shutdown sequence.
#[derive(Debug, Clone, Copy)]
pub struct ShutdownConfig {
    /// How long to wait for in-flight queries to complete.
    pub drain_timeout: Duration,
    /// How long to wait for the cache to persist.
    pub persist_timeout: Duration,
}

impl Default for ShutdownConfig {
    fn default() -> Self {
        Self {
            drain_timeout: Duration::from_secs(8),
            persist_timeout: Duration::from_secs(2),
        }
    }
}

/// A handle to the running instance.
///
/// Cloneable. Dropping every clone is a no-op; only an explicit call to
/// [`Self::shutdown`] (or receiving a signal on the trigger channel)
/// initiates the sequence.
pub struct ShutdownHandle {
    /// The runtime broadcasts the shutdown signal to every task.
    trigger: watch::Sender<ShutdownPhase>,
    /// Listener tasks, awaited before drain begins.
    listener_tasks: Vec<JoinHandle<()>>,
    /// In-flight query count. The runtime increments and decrements this
    /// as queries start and complete.
    in_flight: Arc<std::sync::atomic::AtomicU64>,
    /// Background tasks, aborted in phase 3.
    background_tasks: Vec<JoinHandle<()>>,
    /// Optional cache persister, run in phase 4.
    persister: Option<Arc<CachePersister>>,
    /// Timeouts for each phase.
    config: ShutdownConfig,
}

#[allow(dead_code)]
impl ShutdownHandle {
    pub(crate) const fn new(
        trigger: watch::Sender<ShutdownPhase>,
        in_flight: Arc<std::sync::atomic::AtomicU64>,
        config: ShutdownConfig,
    ) -> Self {
        Self {
            trigger,
            listener_tasks: Vec::new(),
            in_flight,
            background_tasks: Vec::new(),
            persister: None,
            config,
        }
    }

    /// Register listener tasks. They are aborted at the start of the
    /// shutdown sequence, once `Draining` is broadcast.
    pub(crate) fn add_listeners(&mut self, tasks: Vec<JoinHandle<()>>) {
        self.listener_tasks.extend(tasks);
    }

    /// Register background tasks. They are aborted once the in-flight
    /// query count reaches zero (or the drain timeout elapses).
    pub(crate) fn add_background(&mut self, tasks: Vec<JoinHandle<()>>) {
        self.background_tasks.extend(tasks);
    }

    /// Attach a cache persister to be flushed in phase 4.
    pub(crate) fn set_persister(&mut self, persister: Arc<CachePersister>) {
        self.persister = Some(persister);
    }

    /// Run the shutdown sequence.
    pub async fn shutdown(self) {
        tracing::info!("shutdown: phase 1 — closing listeners");
        self.trigger.send_replace(ShutdownPhase::Draining);

        // Phase 1: close listeners. We abort rather than wait, since a
        // listener loop is an infinite accept loop; aborting drops the
        // socket cleanly.
        for task in self.listener_tasks {
            task.abort();
        }

        // Phase 2: drain in-flight queries.
        tracing::info!(
            timeout_secs = self.config.drain_timeout.as_secs(),
            "shutdown: phase 2 — draining in-flight queries"
        );
        let deadline = tokio::time::Instant::now() + self.config.drain_timeout;
        while self
            .in_flight
            .load(std::sync::atomic::Ordering::Relaxed)
            > 0
        {
            if tokio::time::Instant::now() >= deadline {
                tracing::warn!("shutdown: drain timeout reached");
                break;
            }
            tokio::time::sleep(Duration::from_millis(50)).await;
        }

        // Phase 3: cancel background work.
        tracing::info!("shutdown: phase 3 — cancelling background tasks");
        self.trigger.send_replace(ShutdownPhase::Terminating);
        for task in self.background_tasks {
            task.abort();
        }

        // Phase 4: persist.
        if let Some(persister) = self.persister {
            tracing::info!("shutdown: phase 4 — persisting cache");
            let result = tokio::time::timeout(
                self.config.persist_timeout,
                tokio::task::spawn_blocking(move || persister.save()),
            )
            .await;

            match result {
                Ok(Ok(Ok(n))) => tracing::info!(entries = n, "cache persisted"),
                Ok(Ok(Err(e))) => tracing::warn!(error = %e, "cache persist failed"),
                Ok(Err(e)) => tracing::warn!(error = %e, "persist task panicked"),
                Err(_) => tracing::warn!("persist timed out"),
            }
        }

        self.trigger.send_replace(ShutdownPhase::Complete);
        tracing::info!("shutdown: complete");
    }
}

/// Broadcast to all tasks, notifying them of the current phase.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ShutdownPhase {
    /// Normal operation.
    Running,
    /// Listeners are closed and in-flight queries are draining; new
    /// queries are no longer accepted.
    Draining,
    /// Background tasks should stop at their next await point.
    Terminating,
    /// Shutdown finished; the handle is inert.
    Complete,
}

impl ShutdownPhase {
    /// True once the runtime has begun tearing down tasks.
    #[must_use]
    pub const fn is_terminating(self) -> bool {
        matches!(self, Self::Terminating | Self::Complete)
    }
}
