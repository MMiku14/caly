//! Runtime plumbing: background tasks, epoch swapping, shutdown.
//!
//! The snooper lives in `crate::snoop`; this module re-exports only
//! the runtime-owned types.

pub mod background;
pub mod epoch;
pub mod shutdown;

/// Registry of background tasks owned by the runtime.
pub use background::BackgroundSet;
/// Epoch swapping and the shared, reload-surviving state.
pub use epoch::{EpochManager, EpochState, SharedState};
/// Graceful shutdown configuration and the handle that drives it.
pub use shutdown::{ShutdownConfig, ShutdownHandle, ShutdownPhase};

// The snooper is re-exported from its own module so the runtime surface
// stays focused on lifecycle types.
#[allow(unused_imports)]
pub use crate::snoop::DnsSnooper;
