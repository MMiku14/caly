//! Epoch management.
//!
//! # What is an epoch
//!
//! An epoch is an immutable snapshot of the resolver's configuration
//! state. Reloading means building a new epoch and atomically swapping
//! the pointer; in-flight queries continue against the epoch they
//! started in.
//!
//! # What lives in an epoch vs. what does not
//!
//! The **`EpochState`** holds configuration-derived data: rules, upstream
//! servers, DNS64 synthesizer, DNSSEC anchors. All of it is rebuilt from
//! config on reload.
//!
//! The **`SharedState`** holds long-lived data that survives reload:
//! the cache, the '`FakeIP`' pool, the snooper, the NSEC interval cache, the
//! single-flight registry. Reloading the resolver must not throw away a
//! warm cache.
//!
//! The previous design had this backwards: a single `ResolverInner`
//! conflated the two, so every reload dropped the cache and reset the
//! single-flight state.

use std::sync::Arc;

use arc_swap::ArcSwap;

use crate::cache::{DnsCache, NsecCache};
use crate::fakeip::FakeIpPool;
use crate::resolver::ResolverInner;
use crate::snoop::DnsSnooper;

/// Data that survives a reload.
pub struct SharedState {
    /// Shared DNS record cache.
    pub cache: Arc<DnsCache>,
    /// Shared NSEC interval cache.
    pub nsec: Arc<NsecCache>,
    /// The '`FakeIP`' pool, when '`FakeIP`' is enabled.
    pub fakeip: Option<Arc<FakeIpPool>>,
    /// Reverse index from observed IP to recently-seen name.
    pub snooper: Arc<DnsSnooper>,
    /// Counters that span the whole process lifetime.
    /// Process-lifetime counters that survive reloads.
    pub process_stats: Arc<crate::metrics::ProcessStats>,
}

impl SharedState {
    #[must_use]
    /// Create a new runtime epoch.
    pub const fn new(
        cache: Arc<DnsCache>,
        nsec: Arc<NsecCache>,
        fakeip: Option<Arc<FakeIpPool>>,
        snooper: Arc<DnsSnooper>,
        process_stats: Arc<crate::metrics::ProcessStats>,
    ) -> Self {
        Self {
            cache,
            nsec,
            fakeip,
            snooper,
            process_stats,
        }
    }

    /// Spawn the periodic sweep task that clears expired NSEC intervals
    /// and other time-sensitive state.
    ///
    /// The task is owned by the shared state, so it survives a reload.
    #[must_use]
    pub fn spawn_sweep(self: &Arc<Self>) -> tokio::task::JoinHandle<()> {
        let shared = Arc::clone(self);
        tokio::spawn(async move {
            let mut ticker = tokio::time::interval(std::time::Duration::from_secs(30));
            ticker.set_missed_tick_behavior(tokio::time::MissedTickBehavior::Skip);
            loop {
                ticker.tick().await;
                shared.nsec.sweep();
            }
        })
    }
}

/// Data rebuilt from config on every reload.
///
/// Everything in this struct is derived from `Config`; anything that
/// must survive a reload lives on [`SharedState`] instead. A query
/// that starts in one epoch continues to use it even if a newer epoch
/// is swapped in while the query is in flight.
pub struct EpochState {
    /// Monotonically increasing identifier, exposed for observability.
    pub id: u64,
    /// The resolver's operational core.
    #[allow(dead_code)]
    pub(crate) inner: Arc<ResolverInner>,
    /// When this epoch was created.
    pub created_at: std::time::Instant,
}

/// The holder of the current epoch.
pub struct EpochManager {
    shared: Arc<SharedState>,
    current: ArcSwap<EpochState>,
    next_id: std::sync::atomic::AtomicU64,
}

impl EpochManager {
    /// Construct with an initial epoch.
    #[must_use]
    pub fn new(shared: Arc<SharedState>, first: EpochState) -> Self {
        Self {
            shared,
            current: ArcSwap::from_pointee(first),
            next_id: std::sync::atomic::AtomicU64::new(1),
        }
    }

    /// Load the current epoch.
    ///
    /// The returned guard keeps the epoch alive until dropped; the
    /// resolver holds one for the duration of a query.
    #[must_use]
    pub fn load(&self) -> arc_swap::Guard<Arc<EpochState>> {
        self.current.load()
    }

    /// Swap in a new epoch, returning the previous one.
    ///
    /// The caller is responsible for having already built the new
    /// `EpochState`. Any config validation failures must have been
    /// surfaced before this point.
    #[must_use = "the previous epoch is returned so callers can drain it"]
    pub fn swap(&self, next: EpochState) -> Arc<EpochState> {
        self.current.swap(Arc::new(next))
    }

    /// Allocate the next epoch identifier.
    #[must_use]
    pub fn next_id(&self) -> u64 {
        self.next_id
            .fetch_add(1, std::sync::atomic::Ordering::Relaxed)
    }

    /// Borrow the shared state.
    #[must_use]
    pub const fn shared(&self) -> &Arc<SharedState> {
        &self.shared
    }
}
