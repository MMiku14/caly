//! Background task registry.
//!
//! Every long-running task spawned by the resolver — prefetch loops,
//! sweepers, health probes, persistence savers — is registered here.
//! The registry gives shutdown a single handle to cancel everything, and
//! lets metrics count how many tasks are alive.

use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::Arc;

use parking_lot::RwLock;
use tokio::task::JoinHandle;

/// A registry of background tasks.
///
/// Tasks register at spawn time and unregister at completion. The
/// shutdown handle drains the registry and aborts any stragglers.
///
/// Exceeding the registry's soft cap logs a warning but never rejects
/// a task; the cap exists to catch runaway spawning, not to enforce
/// correctness.
#[derive(Default)]
pub struct BackgroundSet {
    next_id: AtomicU64,
    tasks: RwLock<Vec<RegisteredTask>>,
    live: AtomicU64,
    max: usize,
}

#[allow(dead_code)]
struct RegisteredTask {
    id: u64,
    handle: JoinHandle<()>,
    label: &'static str,
}

impl BackgroundSet {
    /// Create a registry with a soft cap on task count.
    ///
    /// Exceeding the cap does not reject the task — it logs a warning.
    /// The cap exists to catch runaway spawning, not to enforce
    /// correctness.
    #[must_use]
    pub const fn new(max: usize) -> Self {
        Self {
            next_id: AtomicU64::new(1),
            tasks: RwLock::new(Vec::new()),
            live: AtomicU64::new(0),
            max,
        }
    }

    /// Register a task.
    ///
    /// Returns the task ID, useful for logging.
    pub fn register(&self, label: &'static str, handle: JoinHandle<()>) -> u64 {
        let id = self.next_id.fetch_add(1, Ordering::Relaxed);
        let count = self.live.fetch_add(1, Ordering::Relaxed) + 1;
        if usize::try_from(count).unwrap_or(usize::MAX) > self.max {
            tracing::warn!(
                label,
                live = count,
                max = self.max,
                "background task count exceeds soft cap"
            );
        }
        self.tasks.write().push(RegisteredTask { id, handle, label });
        id
    }

    /// Prune finished tasks. Called periodically by the runtime to keep
    /// the vector bounded.
    pub fn reap(&self) {
        let mut tasks = self.tasks.write();
        let before = tasks.len();
        tasks.retain(|t| {
            if t.handle.is_finished() {
                self.live.fetch_sub(1, Ordering::Relaxed);
                false
            } else {
                true
            }
        });
        let removed = before - tasks.len();
        drop(tasks);
        if removed > 0 {
            tracing::trace!(removed, "reaped finished background tasks");
        }
    }

    /// Number of live tasks.
    #[must_use]
    pub fn live(&self) -> u64 {
        self.live.load(Ordering::Relaxed)
    }

    /// Take every handle, leaving the registry empty.
    #[cfg(test)]
    pub(crate) fn take_all(&self) -> Vec<JoinHandle<()>> {
        let mut tasks = self.tasks.write();
        let taken = std::mem::take(&mut *tasks);
        self.live.store(0, Ordering::Relaxed);
        taken.into_iter().map(|t| t.handle).collect()
    }

    /// Spawn the periodic reaper.
    ///
    /// The reaper calls [`reap`](Self::reap) every sixty seconds. It is
    /// not itself registered with the set: doing so would make the
    /// set's live count permanently non-zero.
    pub fn spawn_reaper(self: &Arc<Self>) -> JoinHandle<()> {
        let registry = Arc::clone(self);
        tokio::spawn(async move {
            let mut ticker = tokio::time::interval(std::time::Duration::from_secs(60));
            ticker.set_missed_tick_behavior(tokio::time::MissedTickBehavior::Skip);
            loop {
                ticker.tick().await;
                registry.reap();
            }
        })
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::time::Duration;

    #[tokio::test]
    async fn register_and_reap() {
        let set = BackgroundSet::new(16);
        let handle = tokio::spawn(async {
            tokio::time::sleep(Duration::from_millis(10)).await;
        });
        set.register("test", handle);
        assert_eq!(set.live(), 1);

        tokio::time::sleep(Duration::from_millis(30)).await;
        set.reap();
        assert_eq!(set.live(), 0);
    }

    #[tokio::test]
    async fn take_all_drains() {
        let set = BackgroundSet::new(16);
        for _ in 0..3 {
            let h = tokio::spawn(async {
                tokio::time::sleep(Duration::from_secs(60)).await;
            });
            set.register("test", h);
        }
        assert_eq!(set.live(), 3);
        let taken = set.take_all();
        assert_eq!(taken.len(), 3);
        assert_eq!(set.live(), 0);
        for h in taken {
            h.abort();
        }
    }
}
