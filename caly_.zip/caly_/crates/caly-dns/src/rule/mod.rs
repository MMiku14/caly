//! Routing rules.
//!
//! # What a rule does
//!
//! A rule matches a domain by one or more of four criteria — exact,
//! suffix, keyword, regex — and produces an [`Action`]. Rules are
//! evaluated in declaration order; the first match wins.
//!
//! # Why order matters
//!
//! Operators expect to write:
//!
//! ```json
//! [
//!   { "domain": ["ads.example.com"], "action": "block" },
//!   { "domain_suffix": ["example.com"], "action": "route", "server": "fast" }
//! ]
//! ```
//!
//! and have the first line win for `ads.example.com`. Any engine that
//! resolves to the "best" match rather than the "first" match produces
//! surprising results here. This engine resolves to the minimum rule
//! index among all matches; because indices are assigned in declaration
//! order, that is the same as "first match wins".
//!
//! # Structure
//!
//! ```text
//!   engine.rs   — DnsRuleEngine, the orchestrator
//!   trie.rs     — reversed-label suffix trie
//!   compile.rs  — RuleConfig → CompiledRule
//! ```
//!
//! The three files exist because the three concerns are separable:
//! *What does a suffix match look like* is different from *what does the
//! engine do with a match* is different from *how do we build both from
//! config*.

mod compile;
mod engine;
mod trie;

pub use engine::{Action, DnsRuleEngine, Match as RuleMatch};
