//! Compilation from config to the runtime representation.
//!
//! # Rule-set expansion
//!
//! `rule_set: ["ads", "cn"]` is sugar for inlining the two named
//! bundles' patterns. Expansion happens once at compile time; the
//! runtime never sees a reference to a rule set.
//!
//! # What "compile" produces
//!
//! Not a monolithic structure but five parallel artifacts:
//!
//! * `Vec<CompiledRule>` — actions, indexed by rule number.
//! * `HashMap<Box<str>, usize>` — exact matchers, mapping to rule
//!   number.
//! * `Vec<(SmolStr, usize)>` — suffix matchers, un-indexed because the
//!   `SuffixIndex` decides between linear and trie.
//! * `Vec<String>` — regex patterns, in the order they will be passed
//!   to `RegexSet::new`.
//! * `Vec<usize>` — rule indices that require the linear pass.
//!
//! Each artifact serves exactly one consumer. Keeping them separate
//! means a change to one (say, a better exact matcher) does not affect
//! the others.

use std::collections::HashMap;

use smol_str::SmolStr;

use crate::config::{PredefinedAnswer, RuleAction, RuleConfig, RuleSetConfig};
use crate::util::normalize_domain;

/// A rule, compiled.
#[derive(Debug)]
pub struct CompiledRule {
    /// The upstream tag. Empty for actions that do not route.
    pub tag: SmolStr,
    /// What to do when this rule matches.
    pub action: RuleAction,
    /// Static answer for `Predefined`.
    pub predefined: Option<PredefinedAnswer>,
    /// Lowercased keyword patterns.
    pub keywords: Vec<SmolStr>,
    /// Indices into the engine's `RegexSet`.
    pub regex_indexes: Vec<usize>,
}

/// The five artifacts a compilation produces.
///
/// The tuple order is stable: rules, exact matchers, suffix entries,
/// regex patterns, and the list of rule indices that need a linear pass.
pub type CompileOutput = (
    Vec<CompiledRule>,
    HashMap<Box<str>, usize>,
    Vec<(SmolStr, usize)>,
    Vec<String>,
    Vec<usize>,
);

/// Expand rule sets and compile every rule.
pub fn compile_rules(
    rules: Vec<RuleConfig>,
    rule_sets: &HashMap<String, RuleSetConfig>,
) -> Result<CompileOutput, String> {
    let expanded = expand_rule_sets(rules, rule_sets)?;

    let mut compiled: Vec<CompiledRule> = Vec::with_capacity(expanded.len());
    let mut exact: HashMap<Box<str>, usize> = HashMap::new();
    let mut suffix_entries: Vec<(SmolStr, usize)> = Vec::new();
    let mut regex_patterns: Vec<String> = Vec::new();
    let mut linear: Vec<usize> = Vec::new();

    for (index, rule) in expanded.iter().enumerate() {
        // Exact matchers.
        for pattern in &rule.domain {
            let key = normalize_domain(pattern);
            if !key.is_empty() {
                exact.entry(Box::<str>::from(key.as_ref())).or_insert(index);
            }
        }

        // Suffix matchers.
        for pattern in &rule.domain_suffix {
            let suffix = normalize_domain(pattern);
            let suffix = suffix.trim_start_matches('.');
            if !suffix.is_empty() {
                suffix_entries.push((SmolStr::new(suffix), index));
            }
        }

        // Regex matchers; the shared set will be built by the engine.
        let mut regex_indexes = Vec::with_capacity(rule.domain_regex.len());
        for pattern in &rule.domain_regex {
            regex_indexes.push(regex_patterns.len());
            regex_patterns.push(pattern.clone());
        }

        // Keywords.
        let keywords: Vec<SmolStr> = rule
            .domain_keyword
            .iter()
            .map(|k| SmolStr::new(k.to_ascii_lowercase()))
            .collect();

        // Record the rule for the linear pass if it needs one.
        if !keywords.is_empty() || !regex_indexes.is_empty() {
            linear.push(index);
        }

        compiled.push(CompiledRule {
            tag: SmolStr::new(rule.server.as_deref().unwrap_or("")),
            action: rule.action,
            predefined: rule.predefined.clone(),
            keywords,
            regex_indexes,
        });
    }

    Ok((compiled, exact, suffix_entries, regex_patterns, linear))
}

/// Expand `rule_set` references, mutating the rules in place.
fn expand_rule_sets(
    rules: Vec<RuleConfig>,
    rule_sets: &HashMap<String, RuleSetConfig>,
) -> Result<Vec<RuleConfig>, String> {
    let mut out = Vec::with_capacity(rules.len());
    for mut rule in rules {
        for reference in std::mem::take(&mut rule.rule_set) {
            let set = rule_sets
                .get(&reference)
                .ok_or_else(|| format!("unknown rule_set '{reference}'"))?;
            rule.domain.extend(set.domain.iter().cloned());
            rule.domain_suffix.extend(set.domain_suffix.iter().cloned());
            rule.domain_keyword.extend(set.domain_keyword.iter().cloned());
            rule.domain_regex.extend(set.domain_regex.iter().cloned());
        }
        out.push(rule);
    }
    Ok(out)
}

#[cfg(test)]
mod tests {
    use super::*;

    fn route(domains: &[&str], suffix: &[&str], tag: &str) -> RuleConfig {
        RuleConfig {
            domain: domains.iter().map(|s| s.to_string()).collect(),
            domain_suffix: suffix.iter().map(|s| s.to_string()).collect(),
            domain_keyword: Vec::new(),
            domain_regex: Vec::new(),
            rule_set: Vec::new(),
            action: RuleAction::Route,
            server: Some(tag.into()),
            predefined: None,
        }
    }

    #[test]
    fn exact_normalized_on_compile() {
        let (_, exact, _, _, _) = compile_rules(
            vec![route(&["Example.COM."], &[], "t")],
            &HashMap::new(),
        )
        .unwrap();
        assert!(exact.contains_key("example.com"));
    }

    #[test]
    fn suffix_strips_leading_dot() {
        let (_, _, suffixes, _, _) = compile_rules(
            vec![route(&[], &[".google.com"], "t")],
            &HashMap::new(),
        )
        .unwrap();
        assert_eq!(suffixes[0].0.as_str(), "google.com");
    }

    #[test]
    fn rule_set_expands_patterns() {
        let mut sets = HashMap::new();
        sets.insert(
            "ads".into(),
            RuleSetConfig {
                domain: vec!["ads.example.com".into()],
                domain_suffix: vec!["ads-suffix.example".into()],
                domain_keyword: Vec::new(),
                domain_regex: Vec::new(),
            },
        );

        let mut rule = route(&[], &[], "t");
        rule.rule_set = vec!["ads".into()];

        let (_, exact, suffixes, _, _) =
            compile_rules(vec![rule], &sets).unwrap();
        assert!(exact.contains_key("ads.example.com"));
        assert_eq!(suffixes.len(), 1);
    }

    #[test]
    fn unknown_rule_set_is_error() {
        let mut rule = route(&[], &[], "t");
        rule.rule_set = vec!["missing".into()];
        assert!(compile_rules(vec![rule], &HashMap::new()).is_err());
    }
}
