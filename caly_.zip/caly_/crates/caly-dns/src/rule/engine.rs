//! The rule engine.
//!
//! # The split between matchers
//!
//! A rule carries up to four matchers: exact, suffix, keyword, regex.
//! The engine indexes them differently because their cost profiles are
//! different:
//!
//! * **Exact** — a `HashMap` lookup. O(1) hash, no allocation.
//! * **Suffix** — a [`SuffixIndex`] that picks between a linear scan
//!   (small rule sets) and a reversed-label trie (large ones).
//! * **Keyword and regex** — kept in a "linear" list. Scanned in rule
//!   order with a short-circuit that stops the scan as soon as the
//!   current best cannot be beaten.
//!
//! The keyword/regex list is sorted by rule index, so the short-circuit
//! is exact: if the best-known candidate is at index `k`, and the scan
//! has reached index `k` or beyond, no later rule can produce a lower
//! index.
//!
//! # First-match-wins
//!
//! Rules are declared in order. The engine returns the *minimum* rule
//! index among all matches, which is the same as the first match.

use std::collections::HashMap;

use regex::RegexSet;
use smol_str::SmolStr;

use crate::config::{PredefinedAnswer, RuleAction, RuleConfig, RuleSetConfig};
use crate::rule::compile::{CompiledRule, compile_rules};
use crate::rule::trie::SuffixIndex;
use crate::util::normalize_domain;

// ─────────────────────────────────────────────────────────────────────────────
// Outcome
// ─────────────────────────────────────────────────────────────────────────────

/// What a matched rule says to do.
#[derive(Debug, Clone)]
pub enum Action<'a> {
    /// Route to the named upstream tag.
    Route(&'a str),
    /// Answer with a static set of addresses.
    Predefined(&'a PredefinedAnswer),
    /// Force `FakeIP` allocation.
    Fakeip,
    /// Return NXDOMAIN.
    Block,
}

/// The result of a lookup.
#[derive(Debug, Clone)]
pub enum Match<'a> {
    /// No rule matched. The caller uses the engine's `final` tag.
    Fallthrough,
    /// A rule matched.
    Action(Action<'a>),
}

// ─────────────────────────────────────────────────────────────────────────────
// Engine
// ─────────────────────────────────────────────────────────────────────────────

/// The compiled rule engine.
pub struct DnsRuleEngine {
    rules: Vec<CompiledRule>,
    exact: HashMap<Box<str>, usize>,
    suffix: SuffixIndex,
    regex_set: Option<RegexSet>,
    /// Rule indices requiring a linear pass, in ascending order.
    linear: Vec<usize>,
    final_tag: SmolStr,
}

impl std::fmt::Debug for DnsRuleEngine {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("DnsRuleEngine")
            .field("rules", &self.rules.len())
            .field("exact", &self.exact.len())
            .field("suffix", &self.suffix.kind_name())
            .field("linear", &self.linear.len())
            .field("final_tag", &self.final_tag)
            .finish_non_exhaustive()
    }
}

impl DnsRuleEngine {
    /// Compile a rule list, expanding `rule_set` references.
    ///
    /// Returns `Err` on the first invalid regex, unknown rule-set
    /// reference, or malformed rule. The regex set is shared across
    /// every rule, so this is also where the set is built.
    /// # Errors
    ///
    /// Returns an error string if any domain regex fails to compile.
    pub fn try_new(
        rules: Vec<RuleConfig>,
        rule_sets: &HashMap<String, RuleSetConfig>,
        final_tag: &str,
    ) -> Result<Self, String> {
        let (rules, exact, suffix_entries, regex_patterns, linear) =
            compile_rules(rules, rule_sets)?;

        let suffix = SuffixIndex::new(suffix_entries);

        let regex_set = if regex_patterns.is_empty() {
            None
        } else {
            Some(
                RegexSet::new(&regex_patterns)
                    .map_err(|e| format!("invalid regex: {e}"))?,
            )
        };

        Ok(Self {
            rules,
            exact,
            suffix,
            regex_set,
            linear,
            final_tag: SmolStr::new(final_tag),
        })
    }

    /// Convenience constructor for tests and embedded use.
    ///
    /// # Panics
    /// Panics on invalid regex. Prefer [`Self::try_new`] at configuration
    /// boundaries.
    #[must_use]
    pub fn new(rules: Vec<RuleConfig>, final_tag: &str) -> Self {
        Self::try_new(rules, &HashMap::new(), final_tag)
            .expect("invalid regex in rule set")
    }

    /// The engine's fallback tag.
    #[must_use]
    pub fn final_tag(&self) -> &str {
        self.final_tag.as_str()
    }

    /// Number of compiled rules.
    #[must_use]
    pub const fn len(&self) -> usize {
        self.rules.len()
    }

    /// Whether any rule was compiled.
    #[must_use]
    pub const fn is_empty(&self) -> bool {
        self.rules.is_empty()
    }

    /// Resolve a name to an outcome.
    #[must_use]
    pub fn resolve<'a>(&'a self, name: &str) -> Match<'a> {
        let normalized = normalize_domain(name);
        let query = normalized.as_ref();

        // Exact.
        let mut best = self.exact.get(query).copied();

        // Suffix.
        if let Some(index) = self.suffix.best_match(query) {
            best = Some(best.map_or(index, |b| b.min(index)));
        }

        // Evaluate the regex set once per query; every rule that
        // carries regex indices consults this shared bitset.
        let regex_matches = self.regex_set.as_ref().map(|set| set.matches(query));

        // Linear: keywords and regexes. Because `linear` is sorted
        // ascending, reaching an index greater than the current best
        // means no later rule can beat it.
        for &index in &self.linear {
            if best.is_some_and(|b| b <= index) {
                break;
            }

            let rule = &self.rules[index];

            if rule
                .keywords
                .iter()
                .any(|keyword| query.contains(keyword.as_str()))
            {
                best = Some(best.map_or(index, |b| b.min(index)));
                continue;
            }

            // The regex set is evaluated once, before the loop, so the
            // per-rule iteration only inspects the precomputed bitset.
            if let Some(matches) = &regex_matches {
                if rule.regex_indexes.iter().any(|&i| matches.matched(i)) {
                    best = Some(best.map_or(index, |b| b.min(index)));
                }
            }
        }

        best.map_or(Match::Fallthrough, |index| Match::Action(self.action_at(index)))
    }

    fn action_at(&self, index: usize) -> Action<'_> {
        let rule = &self.rules[index];
        match rule.action {
            RuleAction::Route => Action::Route(rule.tag.as_str()),
            RuleAction::Predefined => Action::Predefined(
                rule.predefined
                    .as_ref()
                    .expect("predefined answer validated at config load"),
            ),
            RuleAction::Fakeip => Action::Fakeip,
            RuleAction::Block => Action::Block,
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Tests
// ─────────────────────────────────────────────────────────────────────────────

#[cfg(test)]
mod tests {
    use super::*;

    fn route(
        domains: &[&str],
        suffixes: &[&str],
        keywords: &[&str],
        regexes: &[&str],
        tag: &str,
    ) -> RuleConfig {
        RuleConfig {
            domain: domains.iter().map(|s| s.to_string()).collect(),
            domain_suffix: suffixes.iter().map(|s| s.to_string()).collect(),
            domain_keyword: keywords.iter().map(|s| s.to_string()).collect(),
            domain_regex: regexes.iter().map(|s| s.to_string()).collect(),
            rule_set: Vec::new(),
            action: RuleAction::Route,
            server: Some(tag.into()),
            predefined: None,
        }
    }

    fn block(suffixes: &[&str]) -> RuleConfig {
        RuleConfig {
            domain: Vec::new(),
            domain_suffix: suffixes.iter().map(|s| s.to_string()).collect(),
            domain_keyword: Vec::new(),
            domain_regex: Vec::new(),
            rule_set: Vec::new(),
            action: RuleAction::Block,
            server: None,
            predefined: None,
        }
    }

    #[test]
    fn exact_matches_only_exact() {
        let engine = DnsRuleEngine::new(
            vec![route(&["example.com"], &[], &[], &[], "direct")],
            "final",
        );
        assert!(matches!(
            engine.resolve("example.com"),
            Match::Action(Action::Route("direct"))
        ));
        assert!(matches!(
            engine.resolve("www.example.com"),
            Match::Fallthrough
        ));
    }

    #[test]
    fn exact_is_case_insensitive() {
        let engine = DnsRuleEngine::new(
            vec![route(&["Example.COM"], &[], &[], &[], "direct")],
            "final",
        );
        assert!(matches!(
            engine.resolve("EXAMPLE.COM."),
            Match::Action(Action::Route("direct"))
        ));
    }

    #[test]
    fn suffix_is_label_aligned() {
        let engine = DnsRuleEngine::new(
            vec![route(&[], &["example.com"], &[], &[], "special")],
            "main",
        );
        assert!(matches!(
            engine.resolve("www.example.com"),
            Match::Action(Action::Route("special"))
        ));
        // Substring match would incorrectly fire here.
        assert!(matches!(
            engine.resolve("notexample.com"),
            Match::Fallthrough
        ));
    }

    #[test]
    fn leading_dot_in_suffix_is_stripped() {
        let engine = DnsRuleEngine::new(
            vec![route(&[], &[".google.com"], &[], &[], "g")],
            "main",
        );
        assert!(matches!(
            engine.resolve("www.google.com"),
            Match::Action(Action::Route("g"))
        ));
    }

    #[test]
    fn first_rule_wins_across_matcher_types() {
        let engine = DnsRuleEngine::new(
            vec![
                route(&[], &["example.com"], &[], &[], "suffix"),
                route(&["a.example.com"], &[], &[], &[], "exact"),
            ],
            "main",
        );
        assert!(matches!(
            engine.resolve("a.example.com"),
            Match::Action(Action::Route("suffix"))
        ));
    }

    #[test]
    fn keyword_matches_substring() {
        let engine = DnsRuleEngine::new(
            vec![route(&[], &[], &["telemetry"], &[], "blocked")],
            "main",
        );
        assert!(matches!(
            engine.resolve("app.telemetry.example"),
            Match::Action(Action::Route("blocked"))
        ));
        assert!(matches!(
            engine.resolve("app.example"),
            Match::Fallthrough
        ));
    }

    #[test]
    fn regex_matches() {
        let engine = DnsRuleEngine::new(
            vec![route(&[], &[], &[], &[r"^ads\d+\.example\.com$"], "blocked")],
            "main",
        );
        assert!(matches!(
            engine.resolve("ads1.example.com"),
            Match::Action(Action::Route("blocked"))
        ));
        assert!(matches!(
            engine.resolve("ads.example.com"),
            Match::Fallthrough
        ));
    }

    #[test]
    fn block_action() {
        let engine = DnsRuleEngine::new(vec![block(&["ads.example"])], "main");
        assert!(matches!(
            engine.resolve("tracker.ads.example"),
            Match::Action(Action::Block)
        ));
    }

    #[test]
    fn fakeip_action() {
        let mut rule = block(&[]);
        rule.domain_suffix = vec!["stream.example".into()];
        rule.action = RuleAction::Fakeip;
        let engine = DnsRuleEngine::new(vec![rule], "main");
        assert!(matches!(
            engine.resolve("a.stream.example"),
            Match::Action(Action::Fakeip)
        ));
    }

    #[test]
    fn predefined_carries_answer() {
        let mut rule = route(&["pinned.example"], &[], &[], &[], "");
        rule.action = RuleAction::Predefined;
        rule.predefined = Some(PredefinedAnswer {
            a: vec!["203.0.113.7".into()],
            aaaa: Vec::new(),
        });
        let engine = DnsRuleEngine::new(vec![rule], "main");
        match engine.resolve("pinned.example") {
            Match::Action(Action::Predefined(answer)) => {
                assert_eq!(answer.a, vec!["203.0.113.7"]);
            }
            other => panic!("expected Predefined, got {other:?}"),
        }
    }

    #[test]
    fn invalid_regex_rejected() {
        assert!(DnsRuleEngine::try_new(
            vec![route(&[], &[], &[], &["["], "x")],
            &HashMap::new(),
            "main",
        )
        .is_err());
    }

    #[test]
    fn rule_set_expansion() {
        let mut sets = HashMap::new();
        sets.insert(
            "ads".to_string(),
            RuleSetConfig {
                domain: Vec::new(),
                domain_suffix: vec!["ads.example".into()],
                domain_keyword: Vec::new(),
                domain_regex: Vec::new(),
            },
        );
        let mut rule = block(&[]);
        rule.rule_set = vec!["ads".into()];
        let engine = DnsRuleEngine::try_new(vec![rule], &sets, "main").unwrap();
        assert!(matches!(
            engine.resolve("x.ads.example"),
            Match::Action(Action::Block)
        ));
    }

    #[test]
    fn unknown_rule_set_rejected() {
        let mut rule = block(&[]);
        rule.rule_set = vec!["missing".into()];
        assert!(
            DnsRuleEngine::try_new(vec![rule], &HashMap::new(), "main").is_err()
        );
    }

    #[test]
    fn empty_engine_always_falls_through() {
        let engine = DnsRuleEngine::new(Vec::new(), "final");
        assert!(matches!(engine.resolve("anything.com"), Match::Fallthrough));
        assert_eq!(engine.final_tag(), "final");
        assert_eq!(engine.len(), 0);
        assert!(engine.is_empty());
    }
}
