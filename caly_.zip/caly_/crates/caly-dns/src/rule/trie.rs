//! Reversed-label suffix index.
//!
//! # Two strategies, chosen by size
//!
//! For small rule sets a linear scan wins: it touches one cache line,
//! has no indirection, and the compiler lowers the tail comparison to a
//! `memcmp` — which is SIMD-accelerated in libc.
//!
//! For large rule sets the trie wins: a query of length `n` costs
//! O(`n`) label comparisons regardless of rule count.
//!
//! The threshold is 32. Below it the linear scan is within noise;
//! above it the trie's asymptotic advantage dominates.
//!
//! # Labels, not substrings
//!
//! The trie is keyed by label: `www.example.com` walks
//! `com` → `example` → `www`. This is the only correct way to match a
//! DNS suffix. A naive substring match against `example.com` would
//! match `notexample.com`, which is a real attack (the classic
//! "suffix trap" that killed a few early proxy implementations).

use std::collections::HashMap;

use smallvec::SmallVec;
use smol_str::SmolStr;

/// Number of suffix rules below which a linear scan beats the trie.
const LINEAR_THRESHOLD: usize = 32;

/// The suffix matcher.
pub enum SuffixIndex {
    /// Linear scan over `(pattern, rule_index)` pairs.
    Linear(Vec<(SmolStr, usize)>),
    /// Reversed-label trie.
    Trie(Trie),
}

impl SuffixIndex {
    /// Build from a list of (pattern, index) pairs.
    ///
    /// Patterns are expected to be already-normalized: lowercased, one
    /// trailing dot removed, leading dot stripped.
    #[must_use]
    pub fn new(entries: Vec<(SmolStr, usize)>) -> Self {
        if entries.len() > LINEAR_THRESHOLD {
            let mut trie = Trie::new();
            for (pattern, index) in entries {
                trie.insert(pattern.as_str(), index);
            }
            Self::Trie(trie)
        } else {
            Self::Linear(entries)
        }
    }

    /// Return the minimum rule index whose suffix matches `name`.
    #[must_use]
    pub fn best_match(&self, name: &str) -> Option<usize> {
        match self {
            Self::Linear(entries) => {
                let mut best: Option<usize> = None;
                for (suffix, index) in entries {
                    if label_aligned_suffix(name, suffix) {
                        best = Some(best.map_or(*index, |b| b.min(*index)));
                    }
                }
                best
            }
            Self::Trie(trie) => trie.best_match(name),
        }
    }

    /// A short name for logging.
    #[must_use]
    pub const fn kind_name(&self) -> &'static str {
        match self {
            Self::Linear(_) => "linear",
            Self::Trie(_) => "trie",
        }
    }
}

/// Return `true` if `name` ends with `suffix` at a label boundary.
///
/// Both arguments are assumed lowercased; no case folding occurs. The
/// bytewise tail comparison lowers to `memcmp`.
#[must_use]
#[inline]
fn label_aligned_suffix(name: &str, suffix: &str) -> bool {
    let n = name.len();
    let s = suffix.len();
    if s == 0 || s > n {
        return false;
    }
    let start = n - s;
    if name.as_bytes()[start..] != suffix.as_bytes()[..] {
        return false;
    }
    start == 0 || name.as_bytes()[start - 1] == b'.'
}

// ─────────────────────────────────────────────────────────────────────────────
// Trie
// ─────────────────────────────────────────────────────────────────────────────

/// A trie over the labels of a domain, stored right-to-left.
///
/// Each node owns its children keyed by label; lookups borrow the label
/// string so no allocation occurs on the query path.
#[derive(Debug)]
pub struct Trie {
    nodes: Vec<Node>,
}

#[derive(Debug, Default)]
struct Node {
    children: HashMap<Box<str>, usize>,
    /// Rule indices whose suffix terminates at this node. A rule set
    /// may have several rules with the same suffix; all are recorded.
    terminals: SmallVec<[usize; 1]>,
}

impl Trie {
    /// A trie with a single root node.
    fn new() -> Self {
        Self {
            nodes: vec![Node::default()],
        }
    }

    /// Insert `suffix` as a terminal for rule `index`.
    fn insert(&mut self, suffix: &str, index: usize) {
        // An empty suffix would match every name, which is never what a
        // rule author intends.
        if suffix.is_empty() {
            return;
        }
        let mut node = 0;
        for label in suffix.rsplit('.') {
            if label.is_empty() {
                continue;
            }
            let next = if let Some(&existing) = self.nodes[node].children.get(label) { existing } else {
                let created = self.nodes.len();
                self.nodes.push(Node::default());
                self.nodes[node]
                    .children
                    .insert(Box::<str>::from(label), created);
                created
            };
            node = next;
        }
        self.nodes[node].terminals.push(index);
    }

    fn best_match(&self, name: &str) -> Option<usize> {
        if self.nodes.is_empty() || name.is_empty() {
            return None;
        }

        let mut best: Option<usize> = None;

        // Record terminals at the root (empty-suffix rules).
        for &index in &self.nodes[0].terminals {
            best = Some(best.map_or(index, |b| b.min(index)));
        }

        let bytes = name.as_bytes();
        let mut end = bytes.len();
        let mut node = 0;

        loop {
            // Find the start of the current label.
            let start = memchr::memrchr(b'.', &bytes[..end]).map_or(0, |pos| pos + 1);
            let label = &name[start..end];

            match self.nodes[node].children.get(label) {
                Some(&next) => {
                    node = next;
                    for &index in &self.nodes[node].terminals {
                        best = Some(best.map_or(index, |b| b.min(index)));
                    }
                }
                None => break,
            }

            if start == 0 {
                break;
            }
            end = start - 1;
        }

        best
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn entries(pairs: &[(&str, usize)]) -> Vec<(SmolStr, usize)> {
        pairs.iter().map(|(s, i)| (SmolStr::new(*s), *i)).collect()
    }

    #[test]
    fn linear_path_matches_label_aligned() {
        let index = SuffixIndex::new(entries(&[("example.com", 0)]));
        assert_eq!(index.best_match("example.com"), Some(0));
        assert_eq!(index.best_match("www.example.com"), Some(0));
        assert_eq!(index.best_match("notexample.com"), None);
    }

    #[test]
    fn trie_path_used_above_threshold() {
        let mut pairs: Vec<(String, usize)> = (0..40)
            .map(|i| (format!("s{i}.example"), i))
            .collect();
        pairs.push(("example.com".into(), 100));
        let index = SuffixIndex::new(
            pairs.iter().map(|(s, i)| (SmolStr::new(s), *i)).collect(),
        );
        assert_eq!(index.kind_name(), "trie");
        assert_eq!(index.best_match("x.s0.example"), Some(0));
        assert_eq!(index.best_match("x.example.com"), Some(100));
    }

    #[test]
    fn trie_returns_minimum_index() {
        // Two overlapping suffixes; the earlier rule wins.
        let mut pairs: Vec<(String, usize)> = (0..50)
            .map(|i| (format!("u{i}.net"), i))
            .collect();
        pairs.push(("example.com".into(), 5));
        pairs.push(("deep.example.com".into(), 20));
        let index = SuffixIndex::new(
            pairs.iter().map(|(s, i)| (SmolStr::new(s), *i)).collect(),
        );
        // Both `example.com` (idx 5) and `deep.example.com` (idx 20)
        // match; the earlier index wins.
        assert_eq!(index.best_match("x.deep.example.com"), Some(5));
    }

    #[test]
    fn best_match_is_minimum_across_depths() {
        // Same index inserted at two depths; the minimum is returned
        // regardless of which node in the trie it lives at.
        let mut pairs: Vec<(String, usize)> = (0..40)
            .map(|i| (format!("x{i}.example"), 100 + i))
            .collect();
        pairs.push(("example".into(), 7));
        pairs.push(("a.example".into(), 3));
        let index = SuffixIndex::new(
            pairs.iter().map(|(s, i)| (SmolStr::new(s), *i)).collect(),
        );
        assert_eq!(index.best_match("b.a.example"), Some(3));
    }
}
