//! Caly DNS — the resolver subsystem for the Caly proxy kernel.
//!
//! # Architecture
//!
//! The crate is organized into **six layers**, each depending only on
//! the layers below it:
//!
//! ```text
//!  ┌──────────────────────────────────────────────────────────┐
//!  │  resolver   Orchestration, pipeline, refresh             │
//!  ├──────────────────────────────────────────────────────────┤
//!  │  rule/rrl/dns64/fakeip/snoop   Policy & stateful helpers │
//!  ├──────────────────────────────────────────────────────────┤
//!  │  cache      Records, NSEC intervals, persistence         │
//!  ├──────────────────────────────────────────────────────────┤
//!  │  upstream   Servers, transports, health, RTT, breaker    │
//!  ├──────────────────────────────────────────────────────────┤
//!  │  wire       Message, name, record, EDNS, DNSSEC          │
//!  ├──────────────────────────────────────────────────────────┤
//!  │  foundation  Error, config, util                         │
//!  └──────────────────────────────────────────────────────────┘
//! ```
//!
//! Dependencies flow **strictly upward**. `upstream` never imports
//! `cache`; `wire` never imports `upstream`; `resolver` is the only
//! module allowed to see the whole tree. Any violation is a bug, not a
//! shortcut.
//!
//! # Design pillars
//!
//! 1. **Types carry the contract.** `RealIp` and `VirtualIp` cannot be
//!    interchanged. A `Validated` `RRset` is not `Validated` until the
//!    validator says so. A `RefreshContext` owns exactly what a
//!    background task needs and nothing more.
//!
//! 2. **Layers do one thing.** `upstream` returns a `DnsMessage`; the
//!    resolver decides what that message *means*. There is no
//!    `ResolvedIps` struct carrying three empty `Vec`s when DNSSEC is
//!    disabled — the resolver extracts only what it needs.
//!
//! 3. **Hot paths allocate once.** Names use `SmolStr`, address lists
//!    use `SmallVec`, and the wire parser writes into a reused buffer.
//!    `#[inline]` is applied where it matters, not sprinkled.
//!
//! 4. **Every `#[cfg]` lives in one place.** Each transport's
//!    construction is a single function under `upstream::builder`;
//!    nothing else in the crate knows which features are enabled.
//!
//! 5. **Shutdown is a first-class concern.** The `runtime::shutdown`
//!    module encodes the ordering — listeners first, then in-flight
//!    queries, then background tasks, then persistence — so no client
//!    ever sees a half-written response.
//!
//! # Quick start
//!
//! ```no_run
//! use caly_dns::Config;
//! use caly_dns::resolver::DnsResolver;
//! use std::sync::Arc;
//!
//! # async fn example() -> Result<(), Box<dyn std::error::Error>> {
//! let cfg = Config::from_json(r#"{
//!     "servers": [{"tag": "cf", "address": "1.1.1.1"}],
//!     "final_tag": "cf"
//! }"#)?;
//! let resolver = Arc::new(DnsResolver::from_config(&cfg)?);
//! let ips = resolver.resolve_dial("example.com").await?;
//! # Ok(())
//! # }
//! ```
//!
//! # Feature flags
//!
//! * `dnssec` — cryptographic validation of `RRsets` (default on).
//! * `simd` — SIMD-accelerated name parsing and lowercase (default on).
//! * `dot`, `doh`, `doq` — encrypted transports.

#![warn(missing_docs)]

pub mod cache;
pub mod config;
pub mod dns64;
pub mod error;
pub mod fakeip;
pub mod resolver;
pub mod rrl;
pub mod rule;
pub mod runtime;
pub mod server;
pub mod snoop;
pub mod upstream;
pub mod util;
pub mod wire;

mod plane;
mod metrics;

// ─────────────────────────────────────────────────────────────────────────────
// Curated public surface
// ─────────────────────────────────────────────────────────────────────────────

pub use config::Config;
pub use error::{Error, Result};

// Shutdown: re-exported for callers that build the runtime.
pub use runtime::shutdown::{ShutdownConfig, ShutdownHandle, ShutdownPhase};

// Planes: the typed isolation that the pipeline enforces.
pub use plane::{RealIp, VirtualIp};

// Metrics: process-lifetime and per-epoch counters.
pub use metrics::{EpochStats, ProcessStats};

// Wire-level DNSSEC types that callers may want to construct or inspect.
pub use wire::dnssec::{DnssecValidator, TrustAnchor, ValidationOutcome};

// Re-export the high-traffic message and record types so downstream
// callers do not have to reach into the wire module directly.
pub use wire::message::{DnsHeader, DnsMessage, DnsQuestion};
pub use wire::record::{DnsRecord, RecordData};

// Re-export the transport kind so callers can inspect which wire
// protocol a server was configured with without importing the
// `upstream` module directly.
pub use upstream::TransportKind as UpstreamTransportKind;
