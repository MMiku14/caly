//! Upstream servers and transports.
//!
//! # The boundary
//!
//! This module takes a name (`&str`) and returns addresses
//! ([`server::ResolvedIps`]). Every uncertainty between those two points
//! lives here: network flakiness, TLS handshakes, timeouts, retries,
//! reconnection, health tracking, anti-spoofing.
//!
//! Nothing above this module knows which transport was used, whether
//! the connection was pooled, or how many retries a query took. Nothing
//! below it knows what a "rule" or a "cache" is.
//!
//! # Structure
//!
//! ```text
//!   builder.rs     — the only place #[cfg] appears
//!   server.rs      — the orchestrator: build, send, verify, extract
//!   transport/     — one file per wire protocol
//!   rtt.rs         — Jacobson/Karels adaptive timeout
//!   breaker.rs     — circuit breaker
//!   cookie.rs      — DNS Cookie state
//!   health.rs      — active health probing
//! ```
//!
//! # Feature handling
//!
//! Transports are gated by feature flags. The **only** module that
//! mentions the flags is [`builder`]. Every other file is written as if
//! all transports exist; if a transport is disabled, `builder` simply
//! cannot be asked to construct one.
//!
//! # Lock-free design
//!
//! Everything on the per-query hot path is lock-free:
//!
//! * circuit-breaker state (packed `AtomicU64`),
//! * health classification (packed `AtomicU64`),
//! * client-cookie generation (compare-and-swap),
//! * RTT estimation (single `AtomicU64`, `fetch_update`).
//!
//! The one read-lock on the hot path is the server-cookie clone in
//! [`cookie::CookieJar::obtain`]; see the module docs for the trade-off.

pub mod breaker;
pub mod builder;
pub mod cookie;
pub mod health;
pub mod rtt;
pub mod server;
pub mod transport;

pub use builder::build;
pub use server::{ResolvedIps, Server, ServerConfig};
pub use transport::TransportKind;

// ─────────────────────────────────────────────────────────────────────────────
// Shared monotonic clock
// ─────────────────────────────────────────────────────────────────────────────

/// Cheap monotonic timestamps shared by the breaker and the health
/// tracker.
///
/// `Instant` is not `Copy` and does not fit in an atomic word; the
/// alternative — a global anchor plus an elapsed count — gives us a
/// `u64` that can be compared, stored, and CAS'd without allocation.
pub(crate) mod clock {
    use std::sync::OnceLock;
    use std::time::Instant;

    /// Microseconds since the process started.
    ///
    /// Wraps at `u64::MAX` microseconds ≈ 584,000 years, which is
    /// longer than any relevant uptime.
    #[inline]
    pub fn now_micros() -> u64 {
        static ANCHOR: OnceLock<Instant> = OnceLock::new();
        let anchor = ANCHOR.get_or_init(Instant::now);
        let micros = anchor.elapsed().as_micros();
        u64::try_from(micros).unwrap_or(u64::MAX)
    }
}