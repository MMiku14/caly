//! Per-server circuit breaker — lock-free.
//!
//! # State machine
//!
//! ```text
//!                    failure threshold
//!        Closed ─────────────────────► Open
//!           ▲                            │
//!           │ success                    │ backoff elapsed
//!           │                            ▼
//!           └──────────────── Half-Open (single probe)
//!                                        │
//!                                        │ failure
//!                                        ▼
//!                                      Open (doubled backoff)
//! ```
//!
//! # Consecutive failures, not rate
//!
//! The counter resets on any success. This is deliberate: a server that
//! fails three times in a row then recovers should not stay open. A
//! rate-based breaker would need a window and a threshold, and the extra
//! state buys nothing for a workload where failure modes are bimodal
//! (upstream up or down).
//!
//! # Representation
//!
//! The state machine lives in a single `AtomicU64`:
//!
//! ```text
//!  bit  63 62 │ 61 ……………………………………………… 0
//!        state │ timestamp (microseconds since process start)
//! ```
//!
//! `Closed` ignores the timestamp; `Open` uses it as "when the current
//! backoff began"; `Half-Open` uses it as "when the admitted probe
//! began". The transition `Open → Half-Open` is a single CAS, so no
//! two threads can be admitted as the probe at once. If the admitted
//! probe never reports an outcome (its enclosing future was dropped
//! or it panicked), the timestamp lets a later caller reclaim the slot
//! after [`BreakerConfig::probe_grace`].
//!
//! `is_open` is the hot path and takes no locks. `record_*` are cold:
//! they are called once per outcome, never per byte.

use std::sync::atomic::{AtomicU32, AtomicU64, Ordering};
use std::time::Duration;

use crate::upstream::clock::now_micros;

// ─────────────────────────────────────────────────────────────────────────────
// Packed-state helpers
// ─────────────────────────────────────────────────────────────────────────────

const STATE_CLOSED: u8 = 0;
const STATE_OPEN: u8 = 1;
const STATE_HALF_OPEN: u8 = 2;

const STATE_SHIFT: u32 = 62;
const TS_MASK: u64 = (1u64 << STATE_SHIFT) - 1;

#[inline]
const fn pack(state: u8, ts_micros: u64) -> u64 {
    ((state as u64) << STATE_SHIFT) | (ts_micros & TS_MASK)
}

#[inline]
const fn unpack(v: u64) -> (u8, u64) {
    ((v >> STATE_SHIFT) as u8, v & TS_MASK)
}

#[inline]
fn dur_to_micros(d: Duration) -> u64 {
    // `as_micros` returns `u128`; the clamp keeps the cast honest
    // without a panic path.
    u64::try_from(d.as_micros()).unwrap_or(u64::MAX)
}

// ─────────────────────────────────────────────────────────────────────────────
// Public tuning
// ─────────────────────────────────────────────────────────────────────────────

/// Breaker tuning.
#[derive(Debug, Clone, Copy)]
pub struct BreakerConfig {
    /// Consecutive failures required to open the breaker. Values below
    /// one are clamped to one.
    pub failure_threshold: u32,
    /// Initial backoff after the first open.
    pub initial_backoff: Duration,
    /// Ceiling on the exponential backoff.
    pub max_backoff: Duration,
    /// Grace period for an admitted probe. If the caller is cancelled
    /// before recording an outcome, the breaker reclaims the probe slot
    /// after this interval so it cannot stay half-open forever.
    pub probe_grace: Duration,
}

impl Default for BreakerConfig {
    fn default() -> Self {
        Self {
            failure_threshold: 3,
            initial_backoff: Duration::from_secs(2),
            max_backoff: Duration::from_secs(60),
            probe_grace: Duration::from_secs(5),
        }
    }
}

/// Pre-converted, invariant-checked tuning. Kept separate so the hot
/// path does not have to convert `Duration` on every probe.
#[derive(Debug, Clone, Copy)]
struct Tuning {
    failure_threshold: u32,
    initial_backoff_micros: u64,
    max_backoff_micros: u64,
    probe_grace_micros: u64,
}

impl Tuning {
    fn from_config(c: BreakerConfig) -> Self {
        let initial = dur_to_micros(c.initial_backoff).max(1);
        let max = dur_to_micros(c.max_backoff).max(initial);
        Self {
            failure_threshold: c.failure_threshold.max(1),
            initial_backoff_micros: initial,
            max_backoff_micros: max,
            probe_grace_micros: dur_to_micros(c.probe_grace).max(1),
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// CircuitBreaker
// ─────────────────────────────────────────────────────────────────────────────

/// Per-server circuit breaker.
pub struct CircuitBreaker {
    tuning: Tuning,
    /// Packed state word. See the module docs.
    state: AtomicU64,
    /// Consecutive failures; reset by any success.
    failures: AtomicU32,
    /// Current backoff in microseconds. `0` means "use the initial
    /// backoff"; non-zero values are always in
    /// `[initial, max]`.
    backoff_micros: AtomicU64,
}

impl Default for CircuitBreaker {
    fn default() -> Self {
        Self::new(BreakerConfig::default())
    }
}

impl CircuitBreaker {
    /// Construct a closed breaker with the given tuning.
    #[must_use]
    pub fn new(config: BreakerConfig) -> Self {
        Self {
            tuning: Tuning::from_config(config),
            state: AtomicU64::new(pack(STATE_CLOSED, 0)),
            failures: AtomicU32::new(0),
            backoff_micros: AtomicU64::new(0),
        }
    }

    /// Whether the breaker is currently open. If it is, the caller
    /// must not attempt a query.
    ///
    /// Lock-free: takes at most one CAS per call, and only when the
    /// breaker is transitioning out of `Open`.
    #[must_use]
    pub fn is_open(&self) -> bool {
        let mut current = self.state.load(Ordering::Acquire);
        loop {
            let (state, ts) = unpack(current);
            let now = now_micros();
            match state {
                STATE_CLOSED => return false,

                STATE_OPEN => {
                    if now.saturating_sub(ts) < self.current_backoff() {
                        return true;
                    }
                    // Backoff elapsed: try to be the probe.
                    let next = pack(STATE_HALF_OPEN, now);
                    match self.state.compare_exchange_weak(
                        current,
                        next,
                        Ordering::AcqRel,
                        Ordering::Acquire,
                    ) {
                        Ok(_) => return false, // we are the probe
                        Err(actual) => {
                            current = actual;
                            continue;
                        }
                    }
                }

                STATE_HALF_OPEN => {
                    // If the admitted probe never reported back, its
                    // slot is stale. Reclaim it: return to `Open` with
                    // a fresh backoff window so a new probe can be
                    // admitted after the next backoff.
                    if now.saturating_sub(ts) >= self.tuning.probe_grace_micros {
                        let next = pack(STATE_OPEN, now);
                        match self.state.compare_exchange_weak(
                            current,
                            next,
                            Ordering::AcqRel,
                            Ordering::Acquire,
                        ) {
                            Ok(_) => return true,
                            Err(actual) => {
                                current = actual;
                                continue;
                            }
                        }
                    }
                    return true;
                }

                // Unknown state: fail closed.
                _ => return true,
            }
        }
    }

    /// Record a successful query. Resets the failure counter, the
    /// backoff, and closes the breaker.
    pub fn record_success(&self) {
        self.failures.store(0, Ordering::Relaxed);
        self.backoff_micros.store(0, Ordering::Relaxed);
        self.state
            .store(pack(STATE_CLOSED, 0), Ordering::Release);
    }

    /// Record a failed query.
    ///
    /// The first `failure_threshold - 1` failures on a closed breaker
    /// are no-ops. The failure that reaches the threshold — and every
    /// failure thereafter, including a failed half-open probe — opens
    /// or re-opens the breaker with a doubled backoff.
    pub fn record_failure(&self) {
        let failures = self.failures.fetch_add(1, Ordering::Relaxed) + 1;
        let current = self.state.load(Ordering::Acquire);
        let (state, _) = unpack(current);

        // Closed and below threshold: stay closed.
        if state == STATE_CLOSED && failures < self.tuning.failure_threshold {
            return;
        }

        // Double the backoff from its current value (or seed it with
        // the initial backoff). `.max(initial)` first ensures a failed
        // half-open probe cannot shrink the interval below the
        // previous value; `.min(max)` caps the growth.
        let prev = self.backoff_micros.load(Ordering::Relaxed);
        let next_backoff = if prev == 0 {
            self.tuning.initial_backoff_micros
        } else {
            prev.saturating_mul(2).min(self.tuning.max_backoff_micros)
        };
        self.backoff_micros.store(next_backoff, Ordering::Relaxed);

        self.state
            .store(pack(STATE_OPEN, now_micros()), Ordering::Release);
    }

    /// The effective backoff for the current open window.
    #[inline]
    fn current_backoff(&self) -> u64 {
        let v = self.backoff_micros.load(Ordering::Relaxed);
        if v == 0 {
            self.tuning.initial_backoff_micros
        } else {
            v
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn fast() -> BreakerConfig {
        BreakerConfig {
            failure_threshold: 2,
            initial_backoff: Duration::from_millis(30),
            max_backoff: Duration::from_millis(120),
            probe_grace: Duration::from_millis(100),
        }
    }

    #[test]
    fn starts_closed() {
        let b = CircuitBreaker::new(fast());
        assert!(!b.is_open());
    }

    #[test]
    fn opens_after_threshold() {
        let b = CircuitBreaker::new(fast());
        b.record_failure();
        assert!(!b.is_open());
        b.record_failure();
        assert!(b.is_open());
    }

    #[test]
    fn success_resets() {
        let b = CircuitBreaker::new(fast());
        b.record_failure();
        b.record_success();
        b.record_failure();
        assert!(!b.is_open());
    }

    #[test]
    fn backoff_recovers() {
        let b = CircuitBreaker::new(fast());
        b.record_failure();
        b.record_failure();
        assert!(b.is_open());
        std::thread::sleep(Duration::from_millis(40));
        assert!(!b.is_open());
    }

    #[test]
    fn backoff_doubles() {
        let b = CircuitBreaker::new(BreakerConfig {
            failure_threshold: 1,
            initial_backoff: Duration::from_millis(20),
            max_backoff: Duration::from_millis(80),
            probe_grace: Duration::from_millis(100),
        });

        b.record_failure();
        std::thread::sleep(Duration::from_millis(30));
        assert!(!b.is_open()); // first backoff elapsed, we are the probe

        b.record_failure(); // doubles to 40 ms
        std::thread::sleep(Duration::from_millis(25));
        assert!(b.is_open()); // still in second backoff
    }

    #[test]
    fn abandoned_probe_is_reclaimed() {
        let b = CircuitBreaker::new(BreakerConfig {
            failure_threshold: 1,
            initial_backoff: Duration::from_millis(20),
            max_backoff: Duration::from_millis(80),
            probe_grace: Duration::from_millis(40),
        });

        b.record_failure();
        std::thread::sleep(Duration::from_millis(30));
        assert!(!b.is_open()); // probe admitted

        // Caller "disappears" without recording.
        std::thread::sleep(Duration::from_millis(60));
        // Slot must have been reclaimed; the next probe window should
        // admit us again.
        let _ = b.is_open(); // transitions back to Open
        std::thread::sleep(Duration::from_millis(25));
        assert!(!b.is_open()); // admitted again
    }

    #[test]
    fn only_one_probe_at_a_time() {
        use std::sync::Arc;
        use std::sync::atomic::AtomicUsize;

        let b = Arc::new(CircuitBreaker::new(BreakerConfig {
            failure_threshold: 1,
            initial_backoff: Duration::from_millis(10),
            max_backoff: Duration::from_millis(10),
            probe_grace: Duration::from_millis(200),
        }));

        b.record_failure();
        std::thread::sleep(Duration::from_millis(20));

        let admitted = Arc::new(AtomicUsize::new(0));
        let mut handles = Vec::new();
        for _ in 0..16 {
            let b = Arc::clone(&b);
            let admitted = Arc::clone(&admitted);
            handles.push(std::thread::spawn(move || {
                if !b.is_open() {
                    admitted.fetch_add(1, Ordering::Relaxed);
                }
            }));
        }
        for h in handles {
            h.join().unwrap();
        }
        assert_eq!(admitted.load(Ordering::Relaxed), 1);
    }
}