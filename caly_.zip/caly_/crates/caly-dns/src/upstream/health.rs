//! Active health probing.
//!
//! # Why passive failure tracking is not enough
//!
//! Circuit breakers react to failures the *user* triggers. A server
//! that responds slowly — say, 800 ms per query — never trips the
//! breaker because it never fails. But it is ten times slower than its
//! sibling, and traffic that lands on it wastes eight hundred
//! milliseconds.
//!
//! Active probing detects this. Every server runs a periodic query
//! against a known-stable name. The result — success or failure, plus
//! the latency — updates a [`HealthTracker`]. The tracker classifies
//! the server as `Healthy`, `Degraded`, or `Down`.
//!
//! # The classification is a hint, not a gate
//!
//! The routing layer uses the classification to prefer a healthy
//! sibling over a degraded one. It does **not** refuse to use a `Down`
//! server: a server marked down by the last probe might be back up by
//! the time of the next query, and refusing to try it would guarantee
//! it stays down.
//!
//! # Only probes drive the tracker
//!
//! User queries are recorded by the circuit breaker and the RTT
//! estimator, not here. Conflating the two sources into one tracker
//! corrupts the consecutive-success/failure counts (which must reflect
//! *probes*) and makes `due_for_probe` fire on the wrong schedule.
//!
//! # Representation
//!
//! `(state, consecutive_failures, consecutive_successes)` live packed
//! in a single `AtomicU64`, updated via `fetch_update`. There is no
//! lock anywhere on the probe path; concurrent recorders serialize
//! through the CAS loop.

use std::sync::atomic::{AtomicBool, AtomicU64, Ordering};
use std::sync::Arc;
use std::time::{Duration, Instant};

use crate::upstream::clock::now_micros;

// ─────────────────────────────────────────────────────────────────────────────
// Packed-state helpers
// ─────────────────────────────────────────────────────────────────────────────

const STATE_HEALTHY: u8 = 0;
const STATE_DEGRADED: u8 = 1;
const STATE_DOWN: u8 = 2;

const ST_SHIFT: u32 = 48;
const FAIL_SHIFT: u32 = 24;
const CNT_MASK: u64 = (1 << 24) - 1;

#[inline]
const fn pack_health(state: u8, failures: u32, successes: u32) -> u64 {
    ((state as u64) << ST_SHIFT)
        | ((failures as u64 & CNT_MASK) << FAIL_SHIFT)
        | (successes as u64 & CNT_MASK)
}

#[inline]
const fn unpack_health(v: u64) -> (u8, u32, u32) {
    (
        (v >> ST_SHIFT) as u8,
        ((v >> FAIL_SHIFT) & CNT_MASK) as u32,
        (v & CNT_MASK) as u32,
    )
}

#[inline]
fn dur_to_micros(d: Duration) -> u64 {
    u64::try_from(d.as_micros()).unwrap_or(u64::MAX)
}

// ─────────────────────────────────────────────────────────────────────────────
// Public API
// ─────────────────────────────────────────────────────────────────────────────

/// Health classification.
///
/// The classification is a hint: the routing layer prefers a healthy
/// sibling over a degraded one, but never refuses to use a `Down`
/// server, because the probe may simply be stale.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum HealthState {
    /// Responding within the threshold.
    Healthy,
    /// Responding, but slower than the threshold.
    Degraded,
    /// Failing probes.
    Down,
}

/// Probing tunables.
#[derive(Debug, Clone, Copy)]
pub struct HealthConfig {
    /// How often to probe.
    pub interval: Duration,
    /// Latency above this marks the server degraded.
    pub degraded_threshold: Duration,
    /// Consecutive failures to mark the server down.
    pub down_after: u32,
    /// Consecutive successes to promote it back to healthy once it is
    /// `Down`. Does not gate the `Degraded → Healthy` transition.
    pub healthy_after: u32,
}

impl Default for HealthConfig {
    fn default() -> Self {
        Self {
            interval: Duration::from_secs(30),
            degraded_threshold: Duration::from_millis(500),
            down_after: 3,
            healthy_after: 2,
        }
    }
}

/// Pre-converted tuning; the hot path never converts a `Duration`.
#[derive(Debug, Clone, Copy)]
struct Tuning {
    interval_micros: u64,
    degraded_threshold_micros: u64,
    down_after: u32,
    healthy_after: u32,
}

impl Tuning {
    fn from_config(c: HealthConfig) -> Self {
        Self {
            interval_micros: dur_to_micros(c.interval).max(1),
            degraded_threshold_micros: dur_to_micros(c.degraded_threshold),
            down_after: c.down_after.max(1),
            healthy_after: c.healthy_after.max(1),
        }
    }
}

/// Runtime health for one server. Lock-free.
///
/// Driven **only** by probes. User-query outcomes belong to the circuit
/// breaker and the RTT estimator.
pub struct HealthTracker {
    tuning: Tuning,
    /// `(state, consecutive_failures, consecutive_successes)` packed.
    state: AtomicU64,
    /// Last observed probe RTT in microseconds; `0` means "none yet".
    last_rtt_micros: AtomicU64,
    /// Microseconds since the process anchor when the last probe was
    /// recorded; `0` means "never probed".
    last_probe_micros: AtomicU64,
    /// Set once the prober has run at least once. Avoids the timestamp
    /// sentinel dance for the "never probed" case.
    ever_probed: AtomicBool,
}

impl HealthTracker {
    /// Construct a tracker, initially classified as `Healthy`.
    #[must_use]
    pub fn new(config: HealthConfig) -> Self {
        Self {
            tuning: Tuning::from_config(config),
            state: AtomicU64::new(pack_health(STATE_HEALTHY, 0, 0)),
            last_rtt_micros: AtomicU64::new(0),
            last_probe_micros: AtomicU64::new(0),
            ever_probed: AtomicBool::new(false),
        }
    }

    /// Current classification. Cheap enough for the hot path.
    #[must_use]
    pub fn state(&self) -> HealthState {
        match unpack_health(self.state.load(Ordering::Acquire)).0 {
            STATE_DEGRADED => HealthState::Degraded,
            STATE_DOWN => HealthState::Down,
            _ => HealthState::Healthy,
        }
    }

    /// Last observed probe RTT, if any.
    #[must_use]
    pub fn last_rtt(&self) -> Option<Duration> {
        let micros = self.last_rtt_micros.load(Ordering::Relaxed);
        (micros > 0).then(|| Duration::from_micros(micros))
    }

    /// Record one probe result. Do not call this from the query path.
    pub fn record(&self, result: ProbeResult) {
        // Timestamp first: a caller that observes `ever_probed == true`
        // is guaranteed to observe a non-zero `last_probe_micros`.
        self.last_probe_micros
            .store(now_micros().max(1), Ordering::Relaxed);
        self.ever_probed.store(true, Ordering::Release);

        match result {
            ProbeResult::Success { rtt } => self.record_success(rtt),
            ProbeResult::Failure => self.record_failure(),
        }
    }

    fn record_success(&self, rtt: Duration) {
        let rtt_micros = dur_to_micros(rtt);
        let threshold = self.tuning.degraded_threshold_micros;
        let healthy_after = self.tuning.healthy_after;

        let _ = self.state.fetch_update(
            Ordering::AcqRel,
            Ordering::Acquire,
            |current| {
                let (state, _, successes) = unpack_health(current);
                let new_successes = successes.saturating_add(1) & (CNT_MASK as u32);

                let new_state = if state == STATE_DOWN && new_successes < healthy_after {
                    // Still accumulating the promotion streak; stay Down.
                    STATE_DOWN
                } else if rtt_micros > threshold {
                    // A revived node that is still slow is Degraded, not
                    // Healthy: promotion does not skip the latency check.
                    STATE_DEGRADED
                } else {
                    STATE_HEALTHY
                };

                Some(pack_health(new_state, 0, new_successes))
            },
        );

        self.last_rtt_micros.store(rtt_micros, Ordering::Relaxed);
    }

    fn record_failure(&self) {
        let down_after = self.tuning.down_after;

        let _ = self.state.fetch_update(
            Ordering::AcqRel,
            Ordering::Acquire,
            |current| {
                let (state, failures, _) = unpack_health(current);
                let new_failures = failures.saturating_add(1) & (CNT_MASK as u32);
                let new_state = if new_failures >= down_after {
                    STATE_DOWN
                } else {
                    state
                };
                Some(pack_health(new_state, new_failures, 0))
            },
        );
    }

    /// How often the prober should run.
    #[must_use]
    pub fn interval(&self) -> Duration {
        Duration::from_micros(self.tuning.interval_micros)
    }

    /// Whether a probe is due.
    ///
    /// The 50 ms grace absorbs spurious wake-ups from the timer wheel
    /// without letting probes drift behind schedule.
    #[must_use]
    pub fn due_for_probe(&self) -> bool {
        if !self.ever_probed.load(Ordering::Acquire) {
            return true;
        }
        let last = self.last_probe_micros.load(Ordering::Acquire);
        let now = now_micros();
        now.saturating_sub(last).saturating_add(50_000) >= self.tuning.interval_micros
    }
}

/// Result of one probe. The `rtt` is measured by the prober, not by
/// the transport, so it includes the full round trip the caller sees.
#[derive(Debug, Clone, Copy)]
pub enum ProbeResult {
    /// The probe completed; `rtt` is the measured round trip.
    Success {
        /// The measured round trip.
        rtt: Duration,
    },
    /// The probe failed, or it exceeded its budget.
    Failure,
}

/// The name the prober uses by default.
///
/// `example.com` is tiny, universally cached, and stable. Operators
/// who run closed networks can override it by supplying a different
/// `Probeable` implementation.
pub const PROBE_NAME: &str = "example.com";

/// Secondary probe name, used when the primary is known to be filtered.
pub const FALLBACK_PROBE_NAME: &str = "cloudflare.com";

/// Spawn a probe loop for one server.
///
/// The `tracker` argument should be the same tracker the server exposes
/// via `Server::health`; passing a different instance will update that
/// other instance and leave the server's own classification stale.
///
/// The returned handle is registered with the runtime's background task
/// set so shutdown cancels it cleanly.
pub fn spawn_prober<S>(
    tracker: Arc<HealthTracker>,
    server: Arc<S>,
) -> tokio::task::JoinHandle<()>
where
    S: Probeable + Send + Sync + 'static,
{
    tokio::spawn(async move {
        // Skip the first tick: `interval` fires immediately, and we do
        // not want to probe before the server has had a chance to run
        // its first real query.
        let mut ticker = tokio::time::interval(tracker.interval());
        // After a suspend/resume, do not fire every missed tick in a
        // burst — probe once and resume the cadence.
        ticker.set_missed_tick_behavior(tokio::time::MissedTickBehavior::Delay);
        ticker.tick().await;

        loop {
            ticker.tick().await;
            let started = Instant::now();
            // Half the interval is the budget: a hung upstream must not
            // stall the prober past the next tick.
            let probe_budget = tracker.interval() / 2;
            let outcome = tokio::time::timeout(probe_budget, server.probe(PROBE_NAME)).await;
            let probe_result = match outcome {
                Ok(Ok(())) => ProbeResult::Success {
                    rtt: started.elapsed(),
                },
                _ => ProbeResult::Failure,
            };
            tracker.record(probe_result);
        }
    })
}

/// Trait implemented by servers that can self-probe.
#[async_trait::async_trait]
pub trait Probeable {
    /// Run one probe against `name`.
    ///
    /// # Errors
    ///
    /// Returns any transport or upstream error the probe encounters.
    async fn probe(&self, name: &str) -> crate::error::Result<()>;
}

#[cfg(test)]
mod tests {
    use super::*;

    fn fast() -> HealthConfig {
        HealthConfig {
            down_after: 2,
            healthy_after: 1,
            degraded_threshold: Duration::from_millis(100),
            ..HealthConfig::default()
        }
    }

    #[test]
    fn starts_healthy() {
        let h = HealthTracker::new(fast());
        assert_eq!(h.state(), HealthState::Healthy);
    }

    #[test]
    fn slow_probe_marks_degraded() {
        let h = HealthTracker::new(fast());
        h.record(ProbeResult::Success {
            rtt: Duration::from_millis(500),
        });
        assert_eq!(h.state(), HealthState::Degraded);
    }

    #[test]
    fn failures_mark_down() {
        let h = HealthTracker::new(fast());
        h.record(ProbeResult::Failure);
        assert_eq!(h.state(), HealthState::Healthy);
        h.record(ProbeResult::Failure);
        assert_eq!(h.state(), HealthState::Down);
    }

    #[test]
    fn recovery_promotes_back() {
        let h = HealthTracker::new(fast());
        h.record(ProbeResult::Failure);
        h.record(ProbeResult::Failure);
        assert_eq!(h.state(), HealthState::Down);
        h.record(ProbeResult::Success {
            rtt: Duration::from_millis(10),
        });
        assert_eq!(h.state(), HealthState::Healthy);
    }

    #[test]
    fn rtt_is_tracked() {
        let h = HealthTracker::new(fast());
        h.record(ProbeResult::Success {
            rtt: Duration::from_millis(42),
        });
        assert_eq!(h.last_rtt(), Some(Duration::from_millis(42)));
    }

    #[test]
    fn fresh_tracker_is_due() {
        let h = HealthTracker::new(fast());
        assert!(h.due_for_probe());
    }

    #[test]
    fn post_probe_is_not_due() {
        let h = HealthTracker::new(HealthConfig {
            interval: Duration::from_secs(60),
            ..fast()
        });
        h.record(ProbeResult::Success {
            rtt: Duration::from_millis(10),
        });
        assert!(!h.due_for_probe());
    }

    #[test]
    fn concurrent_records_do_not_corrupt_state() {
        use std::sync::Arc;

        let h = Arc::new(HealthTracker::new(HealthConfig {
            down_after: 3,
            healthy_after: 1000,
            ..fast()
        }));
        let mut handles = Vec::new();
        for _ in 0..8 {
            let h = Arc::clone(&h);
            handles.push(std::thread::spawn(move || {
                for _ in 0..10 {
                    h.record(ProbeResult::Failure);
                }
            }));
        }
        for handle in handles {
            handle.join().unwrap();
        }
        assert_eq!(h.state(), HealthState::Down);
    }
}