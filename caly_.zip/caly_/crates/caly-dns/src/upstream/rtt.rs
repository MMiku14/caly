//! Adaptive timeout estimator.
//!
//! # The algorithm
//!
//! RFC 6298's retransmission-timeout recurrence, the same one TCP uses:
//!
//! ```text
//!   SRTT   = (1 − α) · SRTT + α · R            α = 1/8
//!   RTTVAR = (1 − β) · RTTVAR + β · |SRTT − R|  β = 1/4
//!   RTO    = SRTT + K · RTTVAR                 K = 4
//! ```
//!
//! The first sample seeds `SRTT = R` and `RTTVAR = R/2`. After that the
//! recurrence runs on every sample.
//!
//! # Why this matters for DNS
//!
//! A fixed timeout is either too short (false positives on a jittery
//! link) or too long (failover waits the whole timeout when an upstream
//! is dead). Adaptive RTO gives a fast upstream a short timeout and a
//! slow one a longer one, without configuration.
//!
//! # Representation
//!
//! `SRTT` and `RTTVAR` are packed into a single `AtomicU64` as two
//! `u32` microsecond values, so the pair is swapped atomically.
//! Samples **must** be single round trips; feeding in a CNAME chain's
//! total latency or a dual-stack max would inflate SRTT and slow every
//! subsequent failure.

use std::sync::atomic::{AtomicU64, Ordering};
use std::time::Duration;

/// Lower bound on a single RTT sample. Anything smaller is almost
/// certainly a measurement artifact rather than a real network RTT.
const SAMPLE_FLOOR: Duration = Duration::from_micros(100);

/// Upper bound on a single RTT sample. Anything larger is treated as a
/// timeout rather than a measurement.
const SAMPLE_CEIL: Duration = Duration::from_secs(10);

#[inline]
const fn pack(srtt: u32, rttvar: u32) -> u64 {
    ((srtt as u64) << 32) | (rttvar as u64)
}

#[inline]
const fn unpack(val: u64) -> (u32, u32) {
    ((val >> 32) as u32, val as u32)
}

/// Adaptive retransmission-timeout estimator.
///
/// Lock-free. The two fields live in a single atomic; a concurrent
/// reader always observes a coherent `(SRTT, RTTVAR)` pair.
pub struct RttEstimator {
    state: AtomicU64,
    min_rto: Duration,
    max_rto: Duration,
}

impl RttEstimator {
    /// Construct an estimator with the given RTO bounds.
    ///
    /// The bounds are normalized so `min_rto <= max_rto`; if the caller
    /// supplies them in reverse, they are swapped rather than panicking.
    #[must_use]
    pub fn new(min_rto: Duration, max_rto: Duration) -> Self {
        let (min_rto, max_rto) = if min_rto <= max_rto {
            (min_rto, max_rto)
        } else {
            (max_rto, min_rto)
        };
        Self {
            state: AtomicU64::new(0),
            min_rto,
            max_rto,
        }
    }

    /// Feed one round-trip sample. Samples outside
    /// `[SAMPLE_FLOOR, SAMPLE_CEIL]` are clamped.
    pub fn update(&self, sample: Duration) {
        let sample = sample.clamp(SAMPLE_FLOOR, SAMPLE_CEIL);
        let sample_micros = u32::try_from(sample.as_micros()).unwrap_or(u32::MAX);

        // `fetch_update` wraps the CAS loop, so the closure is called
        // repeatedly until the store succeeds or a spurious failure
        // exhausts the retry count — either way we never observe a
        // torn pair.
        let _ = self.state.fetch_update(
            Ordering::Relaxed,
            Ordering::Relaxed,
            |current| {
                let (new_srtt, new_rttvar) = if current == 0 {
                    (sample_micros.max(1), (sample_micros / 2).max(1))
                } else {
                    let (srtt, rttvar) = unpack(current);
                    let delta = srtt.abs_diff(sample_micros);
                    let s = ((7 * u64::from(srtt)) + u64::from(sample_micros)) / 8;
                    let v = ((3 * u64::from(rttvar)) + u64::from(delta)) / 4;
                    (
                        u32::try_from(s).unwrap_or(u32::MAX).max(1),
                        u32::try_from(v).unwrap_or(u32::MAX).max(1),
                    )
                };
                Some(pack(new_srtt, new_rttvar))
            },
        );
    }

    /// The current RTO, or `default` if no sample has been taken yet.
    /// The result is clamped to `[min_rto, max_rto]` either way.
    #[must_use]
    pub fn rto(&self, default: Duration) -> Duration {
        let current = self.state.load(Ordering::Relaxed);
        if current == 0 {
            return default.clamp(self.min_rto, self.max_rto);
        }
        let (srtt, rttvar) = unpack(current);
        let rto_micros = u64::from(srtt).saturating_add(4 * u64::from(rttvar));
        Duration::from_micros(rto_micros).clamp(self.min_rto, self.max_rto)
    }

    /// Current smoothed RTT, if any sample has been taken.
    #[must_use]
    pub fn srtt(&self) -> Option<Duration> {
        let current = self.state.load(Ordering::Relaxed);
        if current == 0 {
            None
        } else {
            let (srtt, _) = unpack(current);
            Some(Duration::from_micros(u64::from(srtt)))
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    const MIN: Duration = Duration::from_millis(50);
    const MAX: Duration = Duration::from_secs(5);

    #[test]
    fn unseeded_returns_default() {
        let e = RttEstimator::new(MIN, MAX);
        let default = Duration::from_secs(2);
        assert_eq!(e.rto(default), default);
        assert!(e.srtt().is_none());
    }

    #[test]
    fn first_sample_seeds() {
        let e = RttEstimator::new(MIN, MAX);
        e.update(Duration::from_millis(100));
        // SRTT = 100, RTTVAR = 50 → RTO = 300 ms.
        assert_eq!(e.rto(Duration::from_secs(1)), Duration::from_millis(300));
    }

    #[test]
    fn clamps_to_min() {
        let e = RttEstimator::new(Duration::from_millis(200), MAX);
        e.update(Duration::from_millis(10));
        // Computed RTO is 30 ms; clamp up.
        assert_eq!(e.rto(Duration::from_secs(1)), Duration::from_millis(200));
    }

    #[test]
    fn clamps_to_max() {
        let e = RttEstimator::new(MIN, Duration::from_millis(500));
        e.update(Duration::from_secs(1));
        // SRTT = 1000 ms, way above max.
        assert_eq!(e.rto(Duration::from_secs(1)), Duration::from_millis(500));
    }

    #[test]
    fn reversed_bounds_do_not_panic() {
        let e = RttEstimator::new(Duration::from_secs(5), Duration::from_millis(100));
        e.update(Duration::from_millis(50));
        let _ = e.rto(Duration::from_secs(1));
        let _ = e.rto(Duration::from_secs(1));
    }

    #[test]
    fn converges_toward_stable_rtt() {
        let e = RttEstimator::new(MIN, MAX);
        for _ in 0..50 {
            e.update(Duration::from_millis(100));
        }
        let rto = e.rto(Duration::from_secs(1));
        assert!(rto >= Duration::from_millis(100));
        assert!(rto <= Duration::from_millis(150));
    }

    #[test]
    fn variance_grows_with_jitter() {
        let stable = RttEstimator::new(MIN, MAX);
        for _ in 0..20 {
            stable.update(Duration::from_millis(100));
        }

        let jittery = RttEstimator::new(MIN, MAX);
        for _ in 0..20 {
            jittery.update(if alternate() {
                Duration::from_millis(100)
            } else {
                Duration::from_millis(500)
            });
        }

        assert!(jittery.rto(Duration::from_secs(1)) > stable.rto(Duration::from_secs(1)));
    }

    #[test]
    fn concurrent_updates_converge() {
        use std::sync::Arc;

        let e = Arc::new(RttEstimator::new(MIN, MAX));
        let mut handles = Vec::new();
        for _ in 0..8 {
            let e = Arc::clone(&e);
            handles.push(std::thread::spawn(move || {
                for _ in 0..100 {
                    e.update(Duration::from_millis(100));
                }
            }));
        }
        for handle in handles {
            handle.join().unwrap();
        }
        // SRTT should sit near 100 ms and RTTVAR near zero.
        let srtt = e.srtt().unwrap();
        assert!(srtt >= Duration::from_millis(95));
        assert!(srtt <= Duration::from_millis(105));
    }

    /// Deterministic alternator; kept reproducible rather than random.
    fn alternate() -> bool {
        use std::sync::atomic::{AtomicBool, Ordering};
        static FLIP: AtomicBool = AtomicBool::new(false);
        FLIP.fetch_xor(true, Ordering::Relaxed)
    }
}