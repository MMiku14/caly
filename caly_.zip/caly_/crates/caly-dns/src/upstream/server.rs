//! The `Server` type — one configured upstream.
//!
//! # Responsibilities
//!
//! * Encapsulate a transport behind a `query`/`query_with_hint`
//!   interface.
//! * Apply anti-poisoning: 0x20 case randomisation, DNS Cookies, ECS.
//! * Verify the response before returning it.
//! * Track RTT and health.
//! * Extract the information the resolver actually needs —
//!   addresses, CNAME chain, ECS scope, DNSSEC material.
//!
//! # What it does not do
//!
//! * Understand rules (the resolver picks the server).
//! * Understand caching (the resolver decides what TTL to cache for).
//! * Understand DNSSEC (the resolver validates; this layer only
//!   collects the RRSIGs and DNSKEYs and passes them up).

use std::net::IpAddr;
use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::Arc;
use std::time::{Duration, Instant};

use caly_common::metrics::Histogram;
use rand::Rng;
use smallvec::SmallVec;
use smol_str::SmolStr;

use crate::cache::{EcsScope, SecurityStatus};
use crate::config::{AntiPoisonConfig, ResolveStrategy};
use crate::error::{Error, Result};
use crate::upstream::breaker::CircuitBreaker;
use crate::upstream::cookie::CookieJar;
use crate::upstream::health::{HealthConfig, HealthState, HealthTracker, Probeable};
use crate::upstream::rtt::RttEstimator;
use crate::upstream::transport::Transport;
use crate::wire::edns::{ClientSubnet, DnsCookie, EdnsOption};
use crate::wire::message::DnsMessage;
use crate::wire::name::{case_matches, randomize_case};
use crate::wire::record::{DnsRecord, RecordData};
use crate::wire::{TYPE_A, TYPE_AAAA, TYPE_CNAME};

// ─────────────────────────────────────────────────────────────────────────────
// Bounds
// ─────────────────────────────────────────────────────────────────────────────

/// Lower bound for a clamped TTL. Below this, TTL=0 responses would
/// defeat the cache.
const MIN_TTL_SECS: u64 = 10;

/// Upper bound for a clamped TTL. Above this, staleness stops being
/// bounded in any useful sense.
const MAX_TTL_SECS: u64 = 86_400;

/// Floor on the RTT estimator's lower bound. Below this, a fast upstream
/// would get an RTO so short that the estimator would fire on its own
/// scheduling jitter.
const MIN_RTO_FLOOR: Duration = Duration::from_millis(200);

// ─────────────────────────────────────────────────────────────────────────────
// Public types
// ─────────────────────────────────────────────────────────────────────────────

/// Configuration for a server.
#[derive(Debug, Clone)]
pub struct ServerConfig {
    /// Unique tag identifying the server.
    pub tag: String,
    /// Address-family preference.
    pub strategy: ResolveStrategy,
    /// Outbound detour tag; reserved for future use.
    pub detour: String,
    /// Per-query timeout before the RTT estimator takes over.
    pub base_timeout: Duration,
    /// ECS prefix length; `None` disables ECS.
    pub client_subnet: Option<u8>,
    /// Anti-spoofing measures applied to every query.
    pub anti_poison: AntiPoisonConfig,
}

/// The result of a successful lookup.
///
/// This is the crate's **upstream-layer output**. Everything above it
/// reads only these fields. The DNSSEC records are the one exception —
/// they are passed through raw so the resolver's validator can process
/// them without this layer knowing what validation means.
#[derive(Debug, Clone)]
pub struct ResolvedIps {
    /// A and AAAA addresses, in the order the server returned them.
    pub ips: SmallVec<[IpAddr; 4]>,
    /// Minimum TTL across all records contributing to `ips`.
    pub ttl: Duration,
    /// CNAME chain between the queried name and the terminal target.
    pub cname_chain: SmallVec<[SmolStr; 2]>,
    /// ECS scope of the answer, if the server echoed one.
    pub ecs_scope: Option<EcsScope>,
    /// DNSSEC status. `Insecure` unless the resolver's validator has
    /// been run.
    pub security: SecurityStatus,
    /// `RRset` for DNSSEC validation.
    pub rrset_records: Vec<DnsRecord>,
    /// RRSIGs covering the `RRset`.
    pub rrsig_records: Vec<DnsRecord>,
    /// DNSKEYs observed in the same response.
    pub dnskey_records: Vec<DnsRecord>,
}

// ─────────────────────────────────────────────────────────────────────────────
// Server
// ─────────────────────────────────────────────────────────────────────────────

/// A configured upstream.
pub struct Server {
    cfg: ServerConfig,
    transport: Box<dyn Transport>,

    // Anti-poisoning state.
    cookie_jar: CookieJar,

    // Observability.
    queries: AtomicU64,
    errors: AtomicU64,
    poisons_detected: AtomicU64,
    duration_histogram: Histogram,

    // Reliability.
    rtt: RttEstimator,
    breaker: CircuitBreaker,
    health: Arc<HealthTracker>,
}

impl std::fmt::Debug for Server {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("Server")
            .field("tag", &self.cfg.tag)
            .field("strategy", &self.cfg.strategy)
            .field("kind", &self.transport.kind().name())
            .field("health", &self.health.state())
            .finish_non_exhaustive()
    }
}

impl Server {
    /// Construct a server. Transport construction is the builder's job.
    #[must_use]
    pub fn new(cfg: ServerConfig, transport: Box<dyn Transport>) -> Self {
        let base_timeout = cfg.base_timeout;
        Self {
            cfg,
            transport,
            cookie_jar: CookieJar::new(),
            queries: AtomicU64::new(0),
            errors: AtomicU64::new(0),
            poisons_detected: AtomicU64::new(0),
            duration_histogram: Histogram::new(caly_common::metrics::DNS_SECONDS),
            // `RttEstimator::new` normalizes the bounds, so a
            // `base_timeout` below the floor collapses to a bounded
            // range instead of panicking the first `clamp`.
            rtt: RttEstimator::new(MIN_RTO_FLOOR, base_timeout),
            breaker: CircuitBreaker::default(),
            health: Arc::new(HealthTracker::new(HealthConfig::default())),
        }
    }

    /// The server's tag.
    #[must_use]
    pub fn tag(&self) -> &str {
        &self.cfg.tag
    }

    /// Current health classification. Driven by active probing only.
    #[must_use]
    pub fn health_state(&self) -> HealthState {
        self.health.state()
    }

    /// Borrow the health tracker. The prober task drives it.
    #[must_use]
    pub const fn health(&self) -> &Arc<HealthTracker> {
        &self.health
    }

    /// Number of poisons detected.
    ///
    /// A poison is a response whose TXID, case echo, or cookie does not
    /// match what the server sent. Exposed for observability so
    /// operators can alert on the rate.
    #[must_use]
    pub fn poisons_detected(&self) -> u64 {
        self.poisons_detected.load(Ordering::Relaxed)
    }

    /// Query without a client hint.
    ///
    /// # Errors
    ///
    /// Returns an error if the upstream query fails or the circuit
    /// breaker is open.
    pub async fn query(&self, name: &str) -> Result<ResolvedIps> {
        self.query_with_hint(name, None).await
    }

    /// Query with a client hint for ECS.
    ///
    /// # Errors
    ///
    /// Returns an error if the upstream query fails or the circuit
    /// breaker is open.
    #[tracing::instrument(skip(self), fields(tag = %self.cfg.tag))]
    pub async fn query_with_hint(
        &self,
        name: &str,
        client_hint: Option<IpAddr>,
    ) -> Result<ResolvedIps> {
        if self.breaker.is_open() {
            return Err(Error::CircuitOpen(SmolStr::new(&self.cfg.tag)));
        }

        self.queries.fetch_add(1, Ordering::Relaxed);
        let started = Instant::now();

        match self.dispatch(name, client_hint).await {
            Ok(resolved) => {
                self.duration_histogram.observe_duration(started.elapsed());
                self.breaker.record_success();
                Ok(resolved)
            }
            Err(e) => {
                self.errors.fetch_add(1, Ordering::Relaxed);
                self.breaker.record_failure();
                Err(e)
            }
        }
    }

    /// The effective timeout for this query.
    fn effective_timeout(&self) -> Duration {
        self.rtt.rto(self.cfg.base_timeout)
    }

    // ─────────────────────────────────────────────────────────────────────
    // Strategy dispatch
    // ─────────────────────────────────────────────────────────────────────

    async fn dispatch(&self, name: &str, client_hint: Option<IpAddr>) -> Result<ResolvedIps> {
        match self.cfg.strategy {
            ResolveStrategy::Ipv4Only => self.query_single(name, TYPE_A, client_hint).await,
            ResolveStrategy::Ipv6Only => self.query_single(name, TYPE_AAAA, client_hint).await,
            ResolveStrategy::PreferIpv4 => self.query_dual(name, Pref::V4First, client_hint).await,
            ResolveStrategy::PreferIpv6 => self.query_dual(name, Pref::V6First, client_hint).await,
            ResolveStrategy::DualStack => self.query_dual(name, Pref::Interleave, client_hint).await,
        }
    }

    async fn query_single(
        &self,
        name: &str,
        qtype: u16,
        client_hint: Option<IpAddr>,
    ) -> Result<ResolvedIps> {
        let outcome = self.query_with_cname(name, qtype, 0, client_hint).await?;
        Ok(ResolvedIps {
            ips: outcome.ips,
            ttl: outcome.ttl,
            cname_chain: outcome.chain,
            ecs_scope: outcome.scope,
            security: SecurityStatus::Insecure,
            rrset_records: outcome.rrset,
            rrsig_records: outcome.rrsigs,
            dnskey_records: outcome.dnskeys,
        })
    }

    async fn query_dual(
        &self,
        name: &str,
        pref: Pref,
        client_hint: Option<IpAddr>,
    ) -> Result<ResolvedIps> {
        let (v4_res, v6_res) = tokio::join!(
            self.query_with_cname(name, TYPE_A, 0, client_hint),
            self.query_with_cname(name, TYPE_AAAA, 0, client_hint),
        );
        let (v4, v6) = match (v4_res, v6_res) {
            (Err(e4), Err(e6)) => {
                if !matches!(e4, Error::NxDomain(_) | Error::NoData(_)) {
                    return Err(e4);
                }
                return Err(e6);
            }
            (v4, v6) => (v4.ok(), v6.ok()),
        };

        // Merge the two outcomes. The order of `ips` depends on the
        // strategy; the TTL is the minimum across both answers.
        let mut ips: SmallVec<[IpAddr; 4]> = SmallVec::new();
        let mut ttl = Duration::from_secs(MAX_TTL_SECS);
        let mut chain: SmallVec<[SmolStr; 2]> = SmallVec::new();
        let mut scope: Option<EcsScope> = None;
        let mut rrset = Vec::new();
        let mut rrsigs = Vec::new();
        let mut dnskeys = Vec::new();

        match pref {
            Pref::Interleave => {
                let mut v4_iter = v4.as_ref().map(|o| o.ips.iter()).into_iter().flatten();
                let mut v6_iter = v6.as_ref().map(|o| o.ips.iter()).into_iter().flatten();
                loop {
                    let next_v6 = v6_iter.next();
                    let next_v4 = v4_iter.next();
                    if next_v6.is_none() && next_v4.is_none() {
                        break;
                    }
                    if let Some(ip) = next_v6 {
                        ips.push(*ip);
                    }
                    if let Some(ip) = next_v4 {
                        ips.push(*ip);
                    }
                }
                for outcome in [&v6, &v4].into_iter().flatten() {
                    ttl = ttl.min(outcome.ttl);
                    if chain.is_empty() && !outcome.chain.is_empty() {
                        chain.clone_from(&outcome.chain);
                    }
                    if scope.is_none() {
                        scope = outcome.scope;
                    }
                    rrset.extend(outcome.rrset.iter().cloned());
                    rrsigs.extend(outcome.rrsigs.iter().cloned());
                    dnskeys.extend(outcome.dnskeys.iter().cloned());
                }
            }
            Pref::V4First | Pref::V6First => {
                let order = if matches!(pref, Pref::V4First) {
                    [&v4, &v6]
                } else {
                    [&v6, &v4]
                };
                for outcome in order.into_iter().flatten() {
                    ips.extend(outcome.ips.iter().copied());
                    ttl = ttl.min(outcome.ttl);
                    if chain.is_empty() && !outcome.chain.is_empty() {
                        chain.clone_from(&outcome.chain);
                    }
                    if scope.is_none() {
                        scope = outcome.scope;
                    }
                    rrset.extend(outcome.rrset.iter().cloned());
                    rrsigs.extend(outcome.rrsigs.iter().cloned());
                    dnskeys.extend(outcome.dnskeys.iter().cloned());
                }
            }
        }

        if ips.is_empty() {
            return Err(Error::NoData(SmolStr::new(name)));
        }

        Ok(ResolvedIps {
            ips,
            ttl,
            cname_chain: chain,
            ecs_scope: scope,
            security: SecurityStatus::Insecure,
            rrset_records: rrset,
            rrsig_records: rrsigs,
            dnskey_records: dnskeys,
        })
    }

    // ─────────────────────────────────────────────────────────────────────
    // Single-query path with CNAME chasing
    // ─────────────────────────────────────────────────────────────────────

    #[allow(clippy::too_many_lines)]
    async fn query_with_cname(
        &self,
        name: &str,
        qtype: u16,
        depth: usize,
        client_hint: Option<IpAddr>,
    ) -> Result<SingleOutcome> {
        const MAX_CNAME_DEPTH: usize = 8;
        if depth > MAX_CNAME_DEPTH {
            return Err(Error::CnameLoop);
        }

        // `ThreadRng` is not `Send`; scope it so it drops before any
        // await point.
        let (txid, wire_name, options, sent_cookie) = {
            let mut rng = rand::thread_rng();
            let txid: u16 = rng.gen();
            let wire_name = if self.cfg.anti_poison.randomize_case {
                randomize_case(name, &mut rng)
            } else {
                name.to_owned()
            };
            let (options, sent_cookie) = self.build_edns_options(client_hint, &mut rng);
            (txid, wire_name, options, sent_cookie)
        };
        let query = DnsMessage::new_query_with_options(txid, &wire_name, qtype, options);
        let wire = query.serialize_query()?;

        let started = Instant::now();
        let response = self
            .transport
            .exchange(&wire, self.effective_timeout())
            .await?;
        // Sample a *single* exchange. Feeding the CNAME chain's total
        // latency (or `query_dual`'s max) into the estimator would
        // inflate SRTT and stretch every subsequent failure detection.
        self.rtt.update(started.elapsed());

        self.verify_response(&response, txid, &wire_name, sent_cookie)?;

        match response.header.rcode() {
            crate::wire::RCODE_NOERROR => {}
            crate::wire::RCODE_NXDOMAIN => return Err(Error::NxDomain(SmolStr::new(name))),
            code => {
                return Err(Error::UpstreamUnavailable {
                    tag: SmolStr::new(&self.cfg.tag),
                    reason: SmolStr::new(format!("RCODE {code}")),
                });
            }
        }

        // Extract records. The minimum TTL only considers records that
        // carry the answer — RRSIG/DNSKEY TTLs are protocol artifacts
        // and would drag the cached entry's lifetime down for no reason.
        let mut ips: SmallVec<[IpAddr; 4]> = SmallVec::new();
        let mut min_ttl_secs = u32::MAX;
        let mut local_cnames: SmallVec<[SmolStr; 2]> = SmallVec::new();
        let mut rrset = Vec::new();
        let mut rrsigs = Vec::new();
        let mut dnskeys = Vec::new();

        for record in &response.answers {
            match &record.data {
                RecordData::A(v4) if qtype == TYPE_A => {
                    min_ttl_secs = min_ttl_secs.min(record.ttl);
                    ips.push(IpAddr::V4(*v4));
                }
                RecordData::Aaaa(v6) if qtype == TYPE_AAAA => {
                    min_ttl_secs = min_ttl_secs.min(record.ttl);
                    ips.push(IpAddr::V6(*v6));
                }
                RecordData::Cname(target) => {
                    min_ttl_secs = min_ttl_secs.min(record.ttl);
                    local_cnames.push(target.clone());
                }
                RecordData::Rrsig(_) => rrsigs.push(record.clone()),
                RecordData::Dnskey(_) => dnskeys.push(record.clone()),
                _ => {}
            }
        }

        // RFC 4034 & 4035: keep pure, homogeneous RRsets for accurate
        // DNSSEC verification.
        if !ips.is_empty() {
            for record in &response.answers {
                if record.rtype == qtype {
                    rrset.push(record.clone());
                }
            }
        } else if !local_cnames.is_empty() {
            for record in &response.answers {
                if record.rtype == TYPE_CNAME {
                    rrset.push(record.clone());
                }
            }
        }

        let ttl = clamp_ttl(min_ttl_secs);
        let scope = extract_ecs_scope(&response, client_hint);

        if !ips.is_empty() {
            return Ok(SingleOutcome {
                ips,
                ttl,
                chain: local_cnames,
                scope,
                rrset,
                rrsigs,
                dnskeys,
            });
        }

        if let Some(target) = local_cnames.last().cloned() {
            let inner = Box::pin(self.query_with_cname(
                target.as_str(),
                qtype,
                depth + 1,
                client_hint,
            ))
            .await?;
            let mut chain = local_cnames;
            chain.extend(inner.chain);
            return Ok(SingleOutcome {
                ips: inner.ips,
                ttl: ttl.min(inner.ttl),
                chain,
                scope: inner.scope,
                rrset: inner.rrset,
                rrsigs: inner.rrsigs,
                dnskeys: inner.dnskeys,
            });
        }

        Err(Error::NoData(SmolStr::new(name)))
    }

    // ─────────────────────────────────────────────────────────────────────
    // EDNS options and response verification
    // ─────────────────────────────────────────────────────────────────────

    fn build_edns_options<R: Rng>(
        &self,
        client_hint: Option<IpAddr>,
        rng: &mut R,
    ) -> (SmallVec<[EdnsOption; 2]>, Option<DnsCookie>) {
        let mut options = SmallVec::new();

        // ECS must precede the cookie so a middlebox that inspects the
        // option list sees the scope before the authentication token.
        // (RFC 7871 §7.1.1 places no ordering requirement on the
        // sender; this is a local policy.)
        if let (Some(prefix), Some(ip)) = (self.cfg.client_subnet, client_hint) {
            options.push(EdnsOption::ClientSubnet(ClientSubnet::new(ip, prefix)));
        }

        let cookie = if self.cfg.anti_poison.dns_cookie {
            self.cookie_jar.obtain(rng)
        } else {
            None
        };
        if let Some(c) = cookie {
            options.push(EdnsOption::Cookie(c));
        }

        (options, cookie)
    }

    fn verify_response(
        &self,
        response: &DnsMessage,
        txid: u16,
        sent_name: &str,
        sent_cookie: Option<DnsCookie>,
    ) -> Result<()> {
        // Transaction identifier. A mismatch is almost always a stray
        // datagram; count it as a poison so operators can see the rate.
        if response.header.id != txid {
            self.poisons_detected.fetch_add(1, Ordering::Relaxed);
            return Err(Error::Malformed("TXID mismatch"));
        }

        // 0x20 case echo.
        if self.cfg.anti_poison.randomize_case {
            let echoed = response
                .questions
                .first()
                .map_or("", |q| q.name_raw.trim_end_matches('.'));
            let expected = sent_name.trim_end_matches('.');
            // The server either preserves our case (checked) or
            // lowercases everything (accepted). Accepting the lowercase
            // form costs nothing against a real attacker — they can
            // trivially lowercase — but it prevents dropping 100% of
            // benign responses from resolvers that do not implement
            // 0x20.
            if !case_matches(expected, echoed) && echoed != expected.to_ascii_lowercase() {
                self.poisons_detected.fetch_add(1, Ordering::Relaxed);
                return Err(Error::Malformed("0x20 case mismatch"));
            }
        }

        // DNS Cookie echo.
        if let Some(sent) = sent_cookie {
            let returned = response
                .opt()
                .and_then(crate::wire::edns::OptRecord::find_cookie);
            match returned {
                Some(DnsCookie {
                    client,
                    server: Some(s),
                }) if client == sent.client => {
                    self.cookie_jar.store(&client, &s);
                }
                Some(_) => {
                    self.poisons_detected.fetch_add(1, Ordering::Relaxed);
                    return Err(Error::Malformed("cookie mismatch"));
                }
                None if sent.server.is_some() => {
                    self.poisons_detected.fetch_add(1, Ordering::Relaxed);
                    return Err(Error::Malformed("server cookie dropped"));
                }
                None => {
                    // Server does not speak cookies. Tolerate a few
                    // misses before latching off — a single dropped
                    // OPT record should not permanently disable the
                    // option.
                    self.cookie_jar.record_miss();
                }
            }
        }

        Ok(())
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Probeable
// ─────────────────────────────────────────────────────────────────────────────

#[async_trait::async_trait]
impl Probeable for Server {
    async fn probe(&self, name: &str) -> Result<()> {
        // A probe is a cheap query; the result is discarded. Success
        // means the transport and the upstream both answered.
        self.query(name).await.map(|_| ())
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Internal types
// ─────────────────────────────────────────────────────────────────────────────

/// One query's worth of resolved data, before it is merged into a
/// `ResolvedIps`.
#[derive(Debug)]
struct SingleOutcome {
    ips: SmallVec<[IpAddr; 4]>,
    ttl: Duration,
    chain: SmallVec<[SmolStr; 2]>,
    scope: Option<EcsScope>,
    rrset: Vec<DnsRecord>,
    rrsigs: Vec<DnsRecord>,
    dnskeys: Vec<DnsRecord>,
}

/// Address-family ordering applied when merging an A and an AAAA
/// answer.
#[derive(Debug, Clone, Copy)]
enum Pref {
    /// Interleave the two families, IPv6 first.
    Interleave,
    /// Emit all IPv4 addresses, then all IPv6 addresses.
    V4First,
    /// Emit all IPv6 addresses, then all IPv4 addresses.
    V6First,
}

// ─────────────────────────────────────────────────────────────────────────────
// Helpers
// ─────────────────────────────────────────────────────────────────────────────

/// Clamp an upstream TTL into a sane range.
fn clamp_ttl(seconds: u32) -> Duration {
    Duration::from_secs(u64::from(seconds).clamp(MIN_TTL_SECS, MAX_TTL_SECS))
}

/// Extract the ECS scope the server reported.
///
/// Per RFC 7871 §7.3.1, `scope_prefix == 0` means "this answer applies
/// to everyone"; we cache such answers without a scope.
fn extract_ecs_scope(response: &DnsMessage, client_hint: Option<IpAddr>) -> Option<EcsScope> {
    let hint = client_hint?;
    let opt = response.opt()?;
    let cs = opt.find_client_subnet()?;
    if cs.scope_prefix == 0 {
        return None;
    }
    Some(EcsScope::from_client(hint, cs.scope_prefix))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn clamp_bounds_ttl() {
        assert_eq!(clamp_ttl(0), Duration::from_secs(10));
        assert_eq!(clamp_ttl(5), Duration::from_secs(10));
        assert_eq!(clamp_ttl(3600), Duration::from_secs(3600));
        assert_eq!(clamp_ttl(u32::MAX), Duration::from_secs(86_400));
    }

    #[test]
    fn short_base_timeout_does_not_panic() {
        // Regression: a `base_timeout` below `MIN_RTO_FLOOR` used to
        // panic on the *second* `effective_timeout` call.
        let base_timeout = Duration::from_millis(50);
        let est = RttEstimator::new(MIN_RTO_FLOOR, base_timeout);
        est.update(Duration::from_millis(50));
        let _ = est.rto(base_timeout); // must not panic
        let _ = est.rto(base_timeout);
    }
}