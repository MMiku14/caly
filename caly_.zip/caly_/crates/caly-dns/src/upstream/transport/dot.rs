//! DNS-over-TLS transport with connection pooling.
//!
//! # The problem with a fresh connection per query
//!
//! `DoT` carries the same length-prefixed framing as TCP (RFC 7766 §8)
//! over a TLS session. A naive implementation dials a fresh connection
//! per query. That costs:
//!
//! * One TCP handshake (~1 RTT).
//! * One TLS handshake (~1–2 RTT).
//! * One session teardown.
//!
//! On a 30 ms RTT link, that is 60–120 ms of overhead per query. For a
//! resolver whose whole point is latency, that is disqualifying.
//!
//! # The pool
//!
//! This transport keeps a small pool of idle TLS connections. A query
//! tries an idle connection first, verifies it is still usable by
//! writing to it (TCP+TLS has no cheap liveness probe), and only dials a
//! fresh one on failure. Idle connections older than
//! [`IDLE_TIMEOUT`] are discarded.
//!
//! # Connection reuse is not pipelining
//!
//! At most one query is in flight on a connection at a time. RFC 7766
//! permits multiple queries on one connection, but the responses can
//! arrive out of order, and demultiplexing them requires a pending-query
//! map per connection. This transport does not do that; it serialises.
//! For an upstream that supports it, `pool_size` connections run in
//! parallel, which is enough for realistic resolver traffic.

use std::net::SocketAddr;
use std::sync::Arc;
use std::time::{Duration, Instant};

use parking_lot::Mutex;
use rustls::ClientConfig;
use tokio::io::{AsyncReadExt, AsyncWriteExt};
use tokio::net::TcpStream;
use tokio::time::timeout;
use tokio_rustls::client::TlsStream;
use tokio_rustls::TlsConnector;

use crate::error::{Error, Result};
use crate::upstream::transport::{Transport, TransportKind, TransportError};
use crate::wire::message::DnsMessage;

/// How long an idle connection may sit before we discard it.
///
/// Chosen below the 10-second NAT timeout that many consumer routers
/// apply to TCP: a connection we think is alive but the NAT has
/// forgotten will fail its first use, which the transport detects and
/// recovers from. Thirty seconds trades a small reconnection rate for
/// a low idle footprint.
const IDLE_TIMEOUT: Duration = Duration::from_secs(30);

/// Maximum number of idle connections kept per server. Above this,
/// a returned connection is dropped instead of pooled.
const MAX_IDLE: usize = 4;

/// `DoT` transport.
///
/// A small pool of idle TLS connections is kept per server. A query
/// tries a pooled connection first and dials fresh only when the
/// pooled one has gone stale.
pub struct DotTransport {
    upstream: SocketAddr,
    server_name: String,
    tls_config: Arc<ClientConfig>,
    idle: Mutex<Vec<IdleConnection>>,
}

struct IdleConnection {
    stream: TlsStream<TcpStream>,
    since: Instant,
}

impl DotTransport {
    /// Construct a transport. `tls_config` must be built with the right
    /// root certificates; the transport does not add any.
    #[must_use]
    pub fn new(
        upstream: SocketAddr,
        server_name: String,
        tls_config: Arc<ClientConfig>,
    ) -> Self {
        Self {
            upstream,
            server_name,
            tls_config,
            idle: Mutex::new(Vec::with_capacity(MAX_IDLE)),
        }
    }

    /// Pop the freshest idle connection, if any.
    fn take_idle(&self) -> Option<TlsStream<TcpStream>> {
        let mut pool = self.idle.lock();
        // Discard stale entries before handing a stream to the caller.
        pool.retain(|entry| entry.since.elapsed() < IDLE_TIMEOUT);
        while let Some(entry) = pool.pop() {
            if entry.since.elapsed() < IDLE_TIMEOUT {
                return Some(entry.stream);
            }
            // Older than the idle timeout: drop it and try the next.
        }
        None
    }

    /// Return a still-usable connection to the pool.
    fn return_idle(&self, stream: TlsStream<TcpStream>) {
        let mut pool = self.idle.lock();
        if pool.len() >= MAX_IDLE {
            return;
        }
        pool.push(IdleConnection {
            stream,
            since: Instant::now(),
        });
    }

    /// Dial a fresh TLS connection.
    async fn dial(&self, budget: Duration) -> Result<TlsStream<TcpStream>> {
        let tcp = timeout(budget, TcpStream::connect(self.upstream))
            .await
            .map_err(|_| Error::from(TransportError::Timeout))?
            .map_err(Error::Io)?;
        let _ = tcp.set_nodelay(true);

        let server_name = rustls::pki_types::ServerName::try_from(
            self.server_name.clone(),
        )
        .map_err(|e| {
            Error::from(TransportError::TlsHandshake(format!(
                "invalid server name: {e}"
            )))
        })?;

        let connector = TlsConnector::from(Arc::clone(&self.tls_config));
        let tls = timeout(budget, connector.connect(server_name, tcp))
            .await
            .map_err(|_| Error::from(TransportError::Timeout))?
            .map_err(|e| {
                Error::from(TransportError::TlsHandshake(e.to_string()))
            })?;

        Ok(tls)
    }

    /// Run one query over a connection. Returns the connection on
    /// success so the caller can put it back in the pool.
    #[allow(clippy::result_large_err)]
    async fn exchange_on(
        stream: TlsStream<TcpStream>,
        message: &[u8],
        budget: Duration,
    ) -> std::result::Result<(DnsMessage, TlsStream<TcpStream>), (Error, TlsStream<TcpStream>)> {
        let mut stream = stream;
        let deadline = tokio::time::Instant::now() + budget;

        let Ok(len) = u16::try_from(message.len()) else {
            return Err((
                Error::from(TransportError::Protocol("query too large")),
                stream,
            ));
        };

        // Write.
        let remaining = deadline.saturating_duration_since(tokio::time::Instant::now());
        let write_result = timeout(remaining, async {
            stream.write_all(&len.to_be_bytes()).await?;
            stream.write_all(message).await?;
            stream.flush().await
        })
        .await;

        match write_result {
            Ok(Ok(())) => {}
            Ok(Err(e)) => return Err((Error::Io(e), stream)),
            Err(_) => return Err((Error::from(TransportError::Timeout), stream)),
        }

        // Read length.
        let remaining = deadline.saturating_duration_since(tokio::time::Instant::now());
        let len_result = timeout(remaining, async {
            let mut buf = [0u8; 2];
            stream.read_exact(&mut buf).await?;
            Ok::<_, std::io::Error>(usize::from(u16::from_be_bytes(buf)))
        })
        .await;

        let response_len = match len_result {
            Ok(Ok(n)) => n,
            Ok(Err(e)) => return Err((Error::Io(e), stream)),
            Err(_) => return Err((Error::from(TransportError::Timeout), stream)),
        };

        if response_len < 12 {
            return Err((Error::Malformed("TCP response shorter than header"), stream));
        }

        // Read body.
        let remaining = deadline.saturating_duration_since(tokio::time::Instant::now());
        let mut buffer = vec![0u8; response_len];
        let body_result = timeout(remaining, stream.read_exact(&mut buffer)).await;

        match body_result {
            Ok(Ok(_)) => {}
            Ok(Err(e)) => return Err((Error::Io(e), stream)),
            Err(_) => return Err((Error::from(TransportError::Timeout), stream)),
        }

        match DnsMessage::parse(&buffer) {
            Ok(msg) => Ok((msg, stream)),
            Err(e) => Err((e, stream)),
        }
    }
}

#[async_trait::async_trait]
impl Transport for DotTransport {
    async fn exchange(&self, message: &[u8], budget: Duration) -> Result<DnsMessage> {
        let started = tokio::time::Instant::now();

        // First attempt: pooled connection.
        if let Some(stream) = self.take_idle() {
            match Self::exchange_on(stream, message, budget).await {
                Ok((response, stream)) => {
                    self.return_idle(stream);
                    return Ok(response);
                }
                Err((_err, _stream)) => {
                    tracing::debug!(
                        upstream = %self.upstream,
                        "idle DoT connection failed; dialing fresh"
                    );
                }
            }
        }

        // Second attempt: accurately subtract elapsed budget to avoid timeout inflation
        let elapsed = started.elapsed();
        let remaining = budget
            .checked_sub(elapsed)
            .ok_or(Error::from(TransportError::Timeout))?;
        let stream = self.dial(remaining).await?;
        let elapsed_dial = started.elapsed();
        let remaining_after_dial = budget
            .checked_sub(elapsed_dial)
            .ok_or(Error::from(TransportError::Timeout))?;
        match Self::exchange_on(stream, message, remaining_after_dial).await {
            Ok((response, stream)) => {
                self.return_idle(stream);
                Ok(response)
            }
            Err((err, _stream)) => Err(err),
        }
    }

    fn kind(&self) -> TransportKind {
        TransportKind::Tls
    }

    fn reap_idle(&self) {
        let mut pool = self.idle.lock();
        pool.retain(|entry| entry.since.elapsed() < IDLE_TIMEOUT);
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn empty_tls_config() -> Arc<ClientConfig> {
        Arc::new(
            ClientConfig::builder()
                .with_root_certificates(rustls::RootCertStore::empty())
                .with_no_client_auth(),
        )
    }

    #[test]
    fn constructs() {
        let addr: SocketAddr = "1.1.1.1:853".parse().unwrap();
        let _ = DotTransport::new(addr, "cloudflare-dns.com".into(), empty_tls_config());
    }

    #[test]
    fn idle_pool_respects_max() {
        // Inserting more than MAX_IDLE would require a live connection;
        // we just check the constant is used consistently by ensuring
        // the pool is empty at start.
        let addr: SocketAddr = "1.1.1.1:853".parse().unwrap();
        let transport = DotTransport::new(addr, "cloudflare-dns.com".into(), empty_tls_config());
        assert_eq!(transport.idle.lock().len(), 0);
    }
}
