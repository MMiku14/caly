//! TCP transport.
//!
//! # Framing
//!
//! RFC 7766 §8 specifies a two-byte length prefix on every message. The
//! transport reads that prefix, then reads exactly the announced number
//! of bytes. A short read is a protocol error; the server lied about
//! its message length.
//!
//! # Why TCP at all
//!
//! Two reasons. First, UDP responses larger than the advertised EDNS0
//! payload size set the TC bit; the resolver retries over TCP. Second,
//! TCP has no spoofing surface — an off-path attacker cannot inject a
//! packet into an established stream.

use std::net::SocketAddr;
use std::time::Duration;

use tokio::io::{AsyncReadExt, AsyncWriteExt};
use tokio::net::TcpStream;
use tokio::time::timeout;

use crate::error::{Error, Result};
use crate::upstream::transport::{Transport, TransportKind, TransportError};
use crate::wire::message::DnsMessage;

/// TCP transport bound to a fixed upstream address.
pub struct TcpTransport {
    upstream: SocketAddr,
}

impl TcpTransport {
    /// Construct a TCP transport bound to `upstream`.
    #[must_use]
    pub const fn new(upstream: SocketAddr) -> Self {
        Self { upstream }
    }
}

#[async_trait::async_trait]
impl Transport for TcpTransport {
    async fn exchange(&self, message: &[u8], budget: Duration) -> Result<DnsMessage> {
        // The whole exchange must fit in `budget`, including connect.
        let deadline = tokio::time::Instant::now() + budget;

        let mut stream = timeout(
            budget,
            TcpStream::connect(self.upstream),
        )
        .await
        .map_err(|_| Error::from(TransportError::Timeout))?
        .map_err(Error::Io)?;

        // Disable Nagle: a DNS query is small and we want it on the wire
        // immediately.
        let _ = stream.set_nodelay(true);

        let remaining = deadline.saturating_duration_since(tokio::time::Instant::now());

        // Write: length prefix, then payload.
        let len = u16::try_from(message.len())
            .map_err(|_| Error::from(TransportError::Protocol("query too large")))?;

        timeout(remaining, async {
            stream.write_all(&len.to_be_bytes()).await?;
            stream.write_all(message).await?;
            stream.flush().await
        })
        .await
        .map_err(|_| Error::from(TransportError::Timeout))?
        .map_err(Error::Io)?;

        // Read: length prefix, then payload.
        let remaining = deadline.saturating_duration_since(tokio::time::Instant::now());

        let response_len = timeout(remaining, async {
            let mut len_buf = [0u8; 2];
            stream.read_exact(&mut len_buf).await?;
            Ok::<_, std::io::Error>(usize::from(u16::from_be_bytes(len_buf)))
        })
        .await
        .map_err(|_| Error::from(TransportError::Timeout))?
        .map_err(Error::Io)?;

        // Reject an empty response and any length the two-byte prefix
        // cannot actually represent.
        if !(12..=65535).contains(&response_len) {
            return Err(Error::Malformed("invalid TCP response length"));
        }

        let remaining = deadline.saturating_duration_since(tokio::time::Instant::now());

        let mut buffer = vec![0u8; response_len];
        timeout(remaining, stream.read_exact(&mut buffer))
            .await
            .map_err(|_| Error::from(TransportError::Timeout))?
            .map_err(Error::Io)?;

        DnsMessage::parse(&buffer)
    }

    fn kind(&self) -> TransportKind {
        TransportKind::Tcp
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn constructs() {
        let addr: SocketAddr = "8.8.8.8:53".parse().unwrap();
        let _ = TcpTransport::new(addr);
    }
}
