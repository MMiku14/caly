//! DNS-over-QUIC transport (RFC 9250).
//!
//! # Shape
//!
//! DoQ is QUIC with the ALPN identifier `doq`. Each query occupies its
//! own bidirectional stream; the connection is shared across queries.
//! The framing is the same two-byte length prefix as TCP and DoT.
//!
//! # Endpoint lifecycle
//!
//! A `quinn::Endpoint` binds a UDP socket and owns the QUIC state machine
//! for every connection it manages. It is created once per server and
//! reused: a fresh endpoint per query would leak UDP sockets and
//! defeat QUIC's connection migration.
//!
//! # Connection lifecycle
//!
//! The transport holds at most one connection to the server. If it
//! closes (idle timeout, peer shutdown, network change), the next query
//! opens a fresh one. QUIC's 0-RTT mode makes reconnection cheap when
//! the peer supports it.

use std::net::SocketAddr;
use std::sync::Arc;
use std::time::Duration;

use parking_lot::Mutex;
use quinn::{ClientConfig, Connection, Endpoint};
use rustls::ClientConfig as RustlsClientConfig;
use tokio::io::{AsyncReadExt, AsyncWriteExt};
use tokio::sync::OnceCell;

use crate::error::{Error, Result};
use crate::upstream::transport::{Transport, TransportKind, TransportError};
use crate::wire::message::DnsMessage;

/// The ALPN identifier RFC 9250 §4.1 mandates for DoQ.
///
/// A server that presents any other ALPN is rejected at the TLS
/// handshake; there is no in-band downgrade path.
const ALPN: &[u8] = b"doq";

/// DoQ transport.
///
/// At most one QUIC connection is kept per server; a query whose
/// connection has closed opens a fresh one. QUIC's 0-RTT mode makes
/// reconnection cheap when the peer supports it.
pub struct DoqTransport {
    upstream: SocketAddr,
    server_name: String,
    tls_config: Arc<RustlsClientConfig>,
    endpoint: OnceCell<Endpoint>,
    connection: Mutex<Option<Connection>>,
}

impl DoqTransport {
    /// Construct a transport. `tls_config` must have ALPN `doq` set;
    /// [`build_tls_config`] produces a suitable one.
    #[must_use]
    pub fn new(
        upstream: SocketAddr,
        server_name: String,
        tls_config: Arc<RustlsClientConfig>,
    ) -> Self {
        Self {
            upstream,
            server_name,
            tls_config,
            endpoint: OnceCell::new(),
            connection: Mutex::new(None),
        }
    }

    /// Get or create the endpoint.
    async fn endpoint(&self) -> Result<&Endpoint> {
        self.endpoint
            .get_or_try_init(|| async {
                let bind: SocketAddr = if self.upstream.is_ipv6() {
                    SocketAddr::from(([0u16; 8], 0))
                } else {
                    SocketAddr::from(([0u8; 4], 0))
                };
                let mut endpoint = Endpoint::client(bind).map_err(|e| {
                    Error::Config(format!("failed to bind DoQ endpoint: {e}"))
                })?;

                let client_config = self.build_client_config()?;
                endpoint.set_default_client_config(client_config);
                Ok(endpoint)
            })
            .await
    }

    fn build_client_config(&self) -> Result<ClientConfig> {
        let crypto = quinn::crypto::rustls::QuicClientConfig::try_from(
            Arc::clone(&self.tls_config),
        )
        .map_err(|e| Error::Config(format!("DoQ TLS config: {e}")))?;
        Ok(ClientConfig::new(Arc::new(crypto)))
    }

    /// Get an existing connection, or dial a new one.
    async fn connection(&self, budget: Duration) -> Result<Connection> {
        // Fast path: existing connection still open.
        {
            let guard = self.connection.lock();
            if let Some(conn) = guard.as_ref() {
                // `close_reason` is None while the connection is live.
                if conn.close_reason().is_none() {
                    return Ok(conn.clone());
                }
            }
        }

        // Slow path: dial.
        let endpoint = self.endpoint().await?;
        let server_name = rustls::pki_types::ServerName::try_from(
            self.server_name.clone(),
        )
        .map_err(|e| {
            Error::from(TransportError::TlsHandshake(format!(
                "invalid DoQ server name: {e}"
            )))
        })?;

        let connecting = endpoint
            .connect(self.upstream, &server_name)
            .map_err(|e| {
                Error::from(TransportError::TlsHandshake(format!(
                    "DoQ connect: {e}"
                )))
            })?;

        let conn = tokio::time::timeout(budget, connecting)
            .await
            .map_err(|_| Error::from(TransportError::Timeout))?
            .map_err(|e| {
                Error::from(TransportError::TlsHandshake(format!(
                    "DoQ handshake: {e}"
                )))
            })?;

        *self.connection.lock() = Some(conn.clone());
        Ok(conn)
    }
}

/// Build a TLS config suitable for DoQ.
pub fn build_tls_config() -> Result<Arc<RustlsClientConfig>> {
    let mut roots = rustls::RootCertStore::empty();
    for anchor in webpki_roots::TLS_SERVER_ROOTS.iter().cloned() {
        roots.roots.push(anchor);
    }
    let mut config = RustlsClientConfig::builder()
        .with_root_certificates(roots)
        .with_no_client_auth();
    config.alpn_protocols = vec![ALPN.to_vec()];
    Ok(Arc::new(config))
}

#[async_trait::async_trait]
impl Transport for DoqTransport {
    async fn exchange(&self, message: &[u8], budget: Duration) -> Result<DnsMessage> {
        let deadline = tokio::time::Instant::now() + budget;
        // Subtract the handshake time from the budget before opening
        // the stream so a slow handshake cannot push past the deadline.
        let remaining = deadline.saturating_duration_since(tokio::time::Instant::now());
        let conn = self.connection(remaining).await?;

        let remaining = deadline.saturating_duration_since(tokio::time::Instant::now());
        let (mut send, mut recv) = tokio::time::timeout(
            remaining,
            conn.open_bi(),
        )
        .await
        .map_err(|_| Error::from(TransportError::Timeout))?
        .map_err(|e| Error::Io(std::io::Error::other(e)))?;

        let len = u16::try_from(message.len())
            .map_err(|_| Error::from(TransportError::Protocol("query too large")))?;

        // Write length, then payload. RFC 9250 §4.2.
        let remaining = deadline.saturating_duration_since(tokio::time::Instant::now());
        tokio::time::timeout(remaining, async {
            send.write_all(&len.to_be_bytes()).await?;
            send.write_all(message).await?;
            send.finish()
        })
        .await
        .map_err(|_| Error::from(TransportError::Timeout))?
        .map_err(|e| Error::Io(std::io::Error::other(e)))?;

        // Read response.
        let remaining = deadline.saturating_duration_since(tokio::time::Instant::now());
        let response = tokio::time::timeout(remaining, async {
            let mut len_buf = [0u8; 2];
            recv.read_exact(&mut len_buf).await?;
            let response_len = usize::from(u16::from_be_bytes(len_buf));
            if response_len < 12 {
                return Err(std::io::Error::other(
                    "DoQ response shorter than DNS header",
                ));
            }
            let mut buffer = vec![0u8; response_len];
            recv.read_exact(&mut buffer).await?;
            Ok::<_, std::io::Error>(buffer)
        })
        .await
        .map_err(|_| Error::from(TransportError::Timeout))?
        .map_err(Error::Io)?;

        DnsMessage::parse(&response)
    }

    fn kind(&self) -> TransportKind {
        TransportKind::Quic
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn tls_config_has_doq_alpn() {
        let cfg = build_tls_config().unwrap();
        assert_eq!(cfg.alpn_protocols, vec![b"doq".to_vec()]);
    }
}
