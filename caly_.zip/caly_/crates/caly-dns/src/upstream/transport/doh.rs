//! DNS-over-HTTPS transport (RFC 8484).
//!
//! # Shape
//!
//! A DoH query is an HTTP/2 POST of the wire-format message with
//! `Content-Type: application/dns-message`. The response is the same
//! content type, carrying the wire-format answer.
//!
//! # Why `reqwest`
//!
//! DoH sits on top of an HTTP stack, and rewriting HTTP/2, ALPN, HPACK,
//! and connection management is a project of its own. `reqwest`
//! provides them and integrates with `rustls`, which we already use
//! elsewhere. The transport is a thin wrapper: it does not introduce
//! any behaviour beyond what the HTTP client already provides.
//!
//! # Connection reuse
//!
//! `reqwest` pools HTTP/2 connections per host. That pooling is the
//! reason we use it rather than a fresh `hyper` connection per query:
//! the HTTP/2 multiplexer amortises the TLS handshake across every
//! query to the same endpoint.

use std::time::Duration;

use reqwest::Client;

use crate::error::{Error, Result};
use crate::upstream::transport::{Transport, TransportKind, TransportError};
use crate::wire::message::DnsMessage;

/// The media type RFC 8484 §4.1 mandates for both request and
/// response bodies.
const CONTENT_TYPE: &str = "application/dns-message";

/// DoH transport.
pub struct DohTransport {
    url: String,
    client: Client,
}

impl DohTransport {
    /// Construct a transport.
    ///
    /// The `client` should be built with HTTP/2 enabled and a per-host
    /// idle connection pool. [`build_client`] produces a suitable one.
    #[must_use]
    pub fn new(url: String, client: Client) -> Self {
        Self { url, client }
    }
}

/// Build an HTTP client suited to DoH.
///
/// * HTTP/2 with adaptive windows: DoH benefits from a larger window
///   because DNS responses can exceed the default 64 KiB stream limit
///   in edge cases, and the multiplexer handles many queries at once.
/// * Small idle pool: DoH is a low-QPS workload per endpoint.
/// * Per-request timeout set to a generous value; the transport applies
///   its own, tighter budget.
pub fn build_client(url: &str, timeout: Duration) -> Result<Client> {
    let parsed = url::Url::parse(url)
        .map_err(|e| Error::Config(format!("invalid DoH URL '{url}': {e}")))?;
    if parsed.scheme() != "https" {
        return Err(Error::Config(format!(
            "DoH URL must use https, got {}",
            parsed.scheme()
        )));
    }
    Client::builder()
        .http2_adaptive_window(true)
        .pool_max_idle_per_host(4)
        .timeout(timeout)
        .build()
        .map_err(|e| Error::Config(format!("failed to build DoH client: {e}")))
}

#[async_trait::async_trait]
impl Transport for DohTransport {
    async fn exchange(&self, message: &[u8], budget: Duration) -> Result<DnsMessage> {
        let started = tokio::time::Instant::now();
        let response = tokio::time::timeout(
            budget,
            self.client
                .post(&self.url)
                .header("Content-Type", CONTENT_TYPE)
                .header("Accept", CONTENT_TYPE)
                .body(message.to_vec())
                .send(),
        )
        .await
        .map_err(|_| Error::from(TransportError::Timeout))?
        .map_err(|e| {
            Error::UpstreamUnavailable {
                tag: smol_str::SmolStr::new_static("(doh)"),
                reason: smol_str::SmolStr::new(e.to_string()),
            }
        })?;

        if !response.status().is_success() {
            return Err(Error::UpstreamUnavailable {
                tag: smol_str::SmolStr::new_static("(doh)"),
                reason: smol_str::SmolStr::new(format!("HTTP {}", response.status())),
            });
        }

        let elapsed = started.elapsed();
        let remaining = budget
            .checked_sub(elapsed)
            .ok_or(Error::from(TransportError::Timeout))?;
        let body = tokio::time::timeout(remaining, response.bytes())
            .await
            .map_err(|_| Error::from(TransportError::Timeout))?
            .map_err(|e| Error::Io(std::io::Error::other(e)))?;

        DnsMessage::parse(&body)
    }

    fn kind(&self) -> TransportKind {
        TransportKind::Https
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn client_built_from_https_url() {
        let client = build_client("https://1.1.1.1/dns-query", Duration::from_secs(2));
        assert!(client.is_ok());
    }

    #[test]
    fn non_https_url_rejected() {
        let result = build_client("http://1.1.1.1/dns-query", Duration::from_secs(2));
        assert!(result.is_err());
    }
}
