//! UDP transport.
//!
//! # The classic path
//!
//! UDP is the original DNS transport. It is stateless, one-shot, and
//! cheap. The transport here binds a fresh socket per query, connects it
//! to the upstream address (which installs a kernel-level source filter),
//! sends the message, and reads the response.
//!
//! # Why a fresh socket per query
//!
//! Reusing a UDP socket across queries requires either demultiplexing
//! responses by TXID — which duplicates the transport's work — or
//! serialising queries, which defeats concurrency. A fresh socket is
//! one `bind` and one `connect`, both cheap, and it lets the kernel
//! drop any datagram that arrives from the wrong address.
//!
//! On a deployment where this cost matters, `DoT` or `DoQ` is the right
//! answer, not UDP socket pooling.

use std::net::SocketAddr;
use std::time::Duration;

use tokio::net::UdpSocket;
use tokio::time::timeout;

use crate::error::{Error, Result};
use crate::upstream::transport::{Transport, TransportKind, TransportError};
use crate::wire::message::DnsMessage;
use crate::wire::EDNS0_UDP_PAYLOAD;

/// UDP transport bound to a fixed upstream address.
pub struct UdpTransport {
    upstream: SocketAddr,
}

impl UdpTransport {
    /// Construct a UDP transport bound to `upstream`.
    #[must_use]
    pub const fn new(upstream: SocketAddr) -> Self {
        Self { upstream }
    }

    /// Bind a local socket. The address family mirrors the upstream's
    /// so the kernel does not need to translate.
    async fn bind_local(&self) -> Result<UdpSocket> {
        let bind_addr: SocketAddr = if self.upstream.is_ipv6() {
            SocketAddr::from(([0u16; 8], 0))
        } else {
            SocketAddr::from(([0u8; 4], 0))
        };
        UdpSocket::bind(bind_addr).await.map_err(Error::Io)
    }
}

#[async_trait::async_trait]
impl Transport for UdpTransport {
    async fn exchange(&self, message: &[u8], budget: Duration) -> Result<DnsMessage> {
        let socket = self.bind_local().await?;

        // `connect` installs a kernel-level filter: datagrams whose
        // source is not `self.upstream` never reach `recv`.
        socket.connect(self.upstream).await.map_err(Error::Io)?;

        // Use an absolute deadline so the send and the receive share
        // a single budget instead of each getting a full one.
        let deadline = tokio::time::Instant::now() + budget;

        // Send.
        let remaining = deadline.saturating_duration_since(tokio::time::Instant::now());
        timeout(remaining, socket.send(message))
            .await
            .map_err(|_| Error::from(TransportError::Timeout))?
            .map_err(Error::Io)?;

        // Receive.
        let remaining = deadline.saturating_duration_since(tokio::time::Instant::now());
        let mut buffer = [0u8; 4096];
        let n = timeout(remaining, socket.recv(&mut buffer))
            .await
            .map_err(|_| Error::from(TransportError::Timeout))?
            .map_err(Error::Io)?;

        DnsMessage::parse(&buffer[..n])
    }

    fn kind(&self) -> TransportKind {
        TransportKind::Udp
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn constructs_with_v4() {
        let addr: SocketAddr = "1.1.1.1:53".parse().unwrap();
        let _ = UdpTransport::new(addr);
    }

    #[test]
    fn constructs_with_v6() {
        let addr: SocketAddr = "[2606:4700:4700::1111]:53".parse().unwrap();
        let _ = UdpTransport::new(addr);
    }
}
