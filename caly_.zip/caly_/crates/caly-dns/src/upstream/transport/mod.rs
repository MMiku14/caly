//! Transport abstraction.
//!
//! # The contract
//!
//! A transport sends one length-prefixed DNS message and reads one
//! response. That is the entirety of the interface. Everything else —
//! connection reuse, retry, TLS, HTTP/2 multiplexing — is a private
//! implementation detail of a specific transport.
//!
//! # Why a trait and not an enum
//!
//! An enum would force every match arm on the query path. The transport
//! is fixed at server construction, so there is no reason for the hot
//! path to pay for dynamic dispatch. But the trait object is only ever
//! stored once per server and called once per query — the `dyn` cost is
//! a vtable lookup, negligible compared to the syscall that follows.

pub mod tcp;
pub mod udp;

#[cfg(feature = "dot")]
pub mod dot;

#[cfg(feature = "doh")]
pub mod doh;

#[cfg(feature = "doq")]
pub mod doq;

use std::time::Duration;

use crate::error::{Error, Result};

// ─────────────────────────────────────────────────────────────────────────────
// Transport kind
// ─────────────────────────────────────────────────────────────────────────────

/// The wire protocol a transport uses.
///
/// This is an enum rather than a trait method because the resolver
/// sometimes needs to know the kind without a vtable call — for
/// example, to decide whether to enable ECS (which is meaningful only
/// over encrypted transports).
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum TransportKind {
    /// Plain UDP transport (RFC 1035).
    Udp,
    /// Plain TCP transport with a two-byte length prefix (RFC 7766).
    Tcp,
    #[cfg(feature = "dot")]
    /// DNS-over-TLS (RFC 7858).
    Tls,
    #[cfg(feature = "doh")]
    /// DNS-over-HTTPS (RFC 8484).
    Https,
    #[cfg(feature = "doq")]
    /// DNS-over-QUIC (RFC 9250).
    Quic,
}

impl TransportKind {
    /// Whether this transport is encrypted end-to-end.
    #[must_use]
    pub const fn is_encrypted(self) -> bool {
        match self {
            Self::Udp | Self::Tcp => false,
            #[cfg(feature = "dot")]
            Self::Tls => true,
            #[cfg(feature = "doh")]
            Self::Https => true,
            #[cfg(feature = "doq")]
            Self::Quic => true,
        }
    }

    /// A short human-readable name, for logging.
    #[must_use]
    pub const fn name(self) -> &'static str {
        match self {
            Self::Udp => "udp",
            Self::Tcp => "tcp",
            #[cfg(feature = "dot")]
            Self::Tls => "tls",
            #[cfg(feature = "doh")]
            Self::Https => "https",
            #[cfg(feature = "doq")]
            Self::Quic => "quic",
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Transport trait
// ─────────────────────────────────────────────────────────────────────────────

/// A DNS transport.
///
/// Implementations must be `Send + Sync` because a single `Server` is
/// shared across every concurrent query to the same upstream.
///
/// The `timeout` argument bounds the entire exchange, including any
/// connection setup; a pooled implementation that finds its cached
/// connection dead must dial a fresh one within the same budget.
#[async_trait::async_trait]
pub trait Transport: Send + Sync {
    /// Send `message` and return the response.
    ///
    /// `timeout` is the total budget for the exchange, including
    /// connection setup. Implementations that pool connections still
    /// honour this bound: a cached connection that is dead must not
    /// stall the query past `timeout`.
    async fn exchange(
        &self,
        message: &[u8],
        timeout: Duration,
    ) -> Result<crate::wire::message::DnsMessage>;

    /// The wire protocol.
    fn kind(&self) -> TransportKind;

    /// Best-effort cleanup of idle state.
    ///
    /// Called by the health prober on a low-frequency cadence.
    /// Implementations that hold no idle state can leave the default
    /// no-op.
    fn reap_idle(&self) {}
}

// ─────────────────────────────────────────────────────────────────────────────
// Errors
// ─────────────────────────────────────────────────────────────────────────────

/// Errors a transport can produce.
///
/// Most transport errors map to [`Error::Io`] or
/// [`Error::UpstreamUnavailable`] via `?` in the calling code. This
/// enum exists for the cases where a transport wants to signal
/// something more specific.
#[derive(Debug, thiserror::Error)]
pub enum TransportError {
    #[error("connection timed out")]
    /// The exchange did not complete within its budget.
    Timeout,
    #[error("connection refused")]
    /// The upstream refused the connection.
    Refused,
    #[error("TLS handshake failed: {0}")]
    /// The TLS handshake failed. The string carries the peer's diagnostic.
    TlsHandshake(String),
    #[error("protocol violation: {0}")]
    /// The peer violated the transport's framing rules.
    Protocol(&'static str),
}

impl From<TransportError> for Error {
    fn from(e: TransportError) -> Self {
        match e {
            TransportError::Timeout => Self::UpstreamTimeout {
                tag: smol_str::SmolStr::new_static("(transport)"),
                elapsed_ms: 0,
            },
            other => Self::UpstreamUnavailable {
                tag: smol_str::SmolStr::new_static("(transport)"),
                reason: smol_str::SmolStr::new(other.to_string()),
            },
        }
    }
}
