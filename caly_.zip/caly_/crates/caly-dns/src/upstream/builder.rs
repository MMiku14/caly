//! Server construction — the only place `#[cfg]` appears.
//!
//! # Why centralize
//!
//! The previous design scattered `#[cfg(feature = "dot")]` across the
//! resolver's build function. Adding a new transport meant touching
//! three separate match statements. Now: one match, one file.
//!
//! Everything outside this module is written as if all transports exist.
//! If a feature is off, the corresponding `TransportKind` variant does
//! not exist, and the match here cannot reference it. The compiler
//! enforces the correspondence.

use std::sync::Arc;
use std::time::Duration;

use crate::config::{AntiPoisonConfig, Endpoint, ServerConfig};
use crate::error::{Error, Result};
use crate::upstream::server::{Server, ServerConfig as ServerRuntimeConfig};
use crate::upstream::transport::{Transport, TransportKind};

/// Build a fully-initialized server from a config entry.
///
/// The returned server is ready to accept queries. Any error is fatal
/// to configuration loading — the caller propagates it.
///
/// # Errors
///
/// Returns [`Error::Config`] if endpoint parsing or transport
/// construction fails.
pub fn build(entry: &ServerConfig, anti_poison: AntiPoisonConfig) -> Result<Server> {
    let (endpoint, kind) = entry.parse_endpoint().map_err(Error::config)?;
    let transport = build_transport(kind, endpoint, entry.timeout_ms)?;

    let cfg = ServerRuntimeConfig {
        tag: entry.tag.clone(),
        strategy: entry.strategy,
        detour: entry.detour.clone(),
        base_timeout: Duration::from_millis(entry.timeout_ms),
        client_subnet: entry.client_subnet,
        anti_poison,
    };

    Ok(Server::new(cfg, transport))
}

// ─────────────────────────────────────────────────────────────────────────────
// Per-transport dispatch
// ─────────────────────────────────────────────────────────────────────────────

fn build_transport(
    kind: TransportKind,
    endpoint: Endpoint,
    timeout_ms: u64,
) -> Result<Box<dyn Transport>> {
    match kind {
        TransportKind::Udp => {
            let addr = endpoint.into_socket().map_err(Error::config)?;
            Ok(Box::new(crate::upstream::transport::udp::UdpTransport::new(addr)))
        }
        TransportKind::Tcp => {
            let addr = endpoint.into_socket().map_err(Error::config)?;
            Ok(Box::new(crate::upstream::transport::tcp::TcpTransport::new(addr)))
        }
        #[cfg(feature = "dot")]
        TransportKind::Tls => {
            let addr = endpoint.into_socket().map_err(Error::config)?;
            let tls = shared_tls_config();
            Ok(Box::new(crate::upstream::transport::dot::DotTransport::new(
                addr,
                addr.ip().to_string(),
                tls,
            )))
        }
        #[cfg(feature = "doh")]
        TransportKind::Https => {
            let url = endpoint.into_url().map_err(Error::config)?;
            let client = crate::upstream::transport::doh::build_client(
                &url,
                Duration::from_millis(timeout_ms),
            )?;
            Ok(Box::new(crate::upstream::transport::doh::DohTransport::new(
                url, client,
            )))
        }
        #[cfg(feature = "doq")]
        TransportKind::Quic => {
            let addr = endpoint.into_socket().map_err(Error::config)?;
            let tls = crate::upstream::transport::doq::build_tls_config()?;
            Ok(Box::new(crate::upstream::transport::doq::DoqTransport::new(
                addr,
                addr.ip().to_string(),
                tls,
            )))
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Shared TLS roots
// ─────────────────────────────────────────────────────────────────────────────

/// The root certificate store, built once.
///
/// `DoT` and `DoQ` share this store. `DoH` delegates TLS to `reqwest`,
/// which carries its own root store; enabling `doh` alone therefore
/// does not pull in `webpki-roots`.
///
/// `OnceLock` ensures the `WebPKI` bundle is parsed once regardless of
/// how many TLS upstreams the config declares.
#[cfg(any(feature = "dot", feature = "doq"))]
fn shared_tls_config() -> Arc<rustls::ClientConfig> {
    use std::sync::OnceLock;
    static CONFIG: OnceLock<Arc<rustls::ClientConfig>> = OnceLock::new();
    Arc::clone(CONFIG.get_or_init(|| {
        let mut roots = rustls::RootCertStore::empty();
        for anchor in webpki_roots::TLS_SERVER_ROOTS.iter().cloned() {
            roots.roots.push(anchor);
        }
        Arc::new(
            rustls::ClientConfig::builder()
                .with_root_certificates(roots)
                .with_no_client_auth(),
        )
    }))
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::config::ResolveStrategy;

    fn udp_entry() -> ServerConfig {
        ServerConfig {
            tag: "test".into(),
            address: "1.1.1.1".into(),
            strategy: ResolveStrategy::default(),
            detour: "direct".into(),
            timeout_ms: 2500,
            client_subnet: None,
        }
    }

    #[test]
    fn builds_udp_server() {
        let server = build(&udp_entry(), AntiPoisonConfig::default());
        assert!(server.is_ok());
    }

    #[test]
    fn rejects_unknown_scheme() {
        let mut entry = udp_entry();
        entry.address = "ftp://example.com".into();
        assert!(build(&entry, AntiPoisonConfig::default()).is_err());
    }

    #[cfg(feature = "doh")]
    #[test]
    fn builds_doh_server() {
        let mut entry = udp_entry();
        entry.address = "https://cloudflare-dns.com/dns-query".into();
        let server = build(&entry, AntiPoisonConfig::default());
        assert!(server.is_ok());
    }
}