//! DNS Cookie state (RFC 7873).
//!
//! # Lifecycle
//!
//! 1. The first query to an upstream sends only the client half — eight
//!    random bytes chosen once and reused for the lifetime of the jar.
//! 2. If the server responds with a server half, that value is
//!    remembered and replayed on subsequent queries.
//! 3. If the server responds without a server half repeatedly, the jar
//!    latches off.
//!
//! # Why latching off matters
//!
//! A server that does not speak cookies will silently ignore the option
//! but respond anyway. Without latching, every query to such a server
//! carries eight wasted bytes. The latch detects this once and stops.
//!
//! # Concurrency
//!
//! The **client cookie** is the value on the hot path. It is written
//! exactly once, read on every query, and stored packed in an
//! [`AtomicU64`] — a compare-and-swap is the only synchronization
//! required, no matter how many threads call [`CookieJar::obtain`]
//! concurrently.
//!
//! The **server cookie** changes rarely (once per upstream, then only
//! if the server rotates it) but is read on every query. Storing it in
//! a short-lived read lock keeps the code simple; a truly lock-free
//! swap of up to 32 bytes would need hazard pointers or a seqlock, and
//! the read-lock fast path is already a single atomic on the
//! uncontended case.

use std::sync::atomic::{AtomicBool, AtomicU64, AtomicU8, Ordering};

use parking_lot::RwLock;
use rand::Rng;
use smallvec::SmallVec;

use crate::wire::edns::DnsCookie;

/// Consecutive responses without a cookie before the jar latches off.
const COOKIE_MISS_THRESHOLD: u8 = 3;

/// Per-upstream cookie jar.
#[derive(Debug, Default)]
pub struct CookieJar {
    /// The client cookie, packed big-endian into the low 8 bytes of
    /// `u64`. `0` is the "not yet generated" sentinel; a genuine
    /// random zero is rejected by the CAS path, which retries.
    client: AtomicU64,
    /// The server cookie, once received (RFC 7873 allows 8..=32 bytes).
    /// Written rarely, read on every query.
    server: RwLock<Option<SmallVec<[u8; 32]>>>,
    /// Set once the jar has latched off.
    disabled: AtomicBool,
    /// Consecutive responses without a cookie option.
    misses: AtomicU8,
}

impl CookieJar {
    /// A fresh jar with no client cookie generated yet.
    #[must_use]
    pub fn new() -> Self {
        Self::default()
    }

    /// Return the cookie to include in the next query, or `None` if the
    /// server has been marked as not supporting them.
    ///
    /// The client half is generated with a compare-and-swap, so a
    /// concurrent first use on many threads converges on the same
    /// eight bytes.
    pub fn obtain<R: Rng>(&self, rng: &mut R) -> Option<DnsCookie> {
        if self.disabled.load(Ordering::Acquire) {
            return None;
        }
        let client = self.client_or_init(rng);
        let server = self.server.read().clone();
        Some(DnsCookie { client, server })
    }

    /// Remember the server cookie returned for our client cookie.
    ///
    /// The check ensures we do not accept a server half that was
    /// returned for a different client half — an attacker could
    /// otherwise poison the jar by sending a forged response with a
    /// mismatched client cookie.
    pub fn store(&self, client: &[u8; 8], server: &[u8]) {
        if self.disabled.load(Ordering::Acquire) {
            return;
        }
        let expected = self.client.load(Ordering::Acquire);
        if expected == 0 || expected.to_ne_bytes() != *client {
            return;
        }
        *self.server.write() = Some(SmallVec::from_slice(server));
        self.misses.store(0, Ordering::Relaxed);
    }

    /// Record one response with no cookie option. Latches the jar off
    /// after [`COOKIE_MISS_THRESHOLD`] consecutive misses.
    pub fn record_miss(&self) {
        let count = self.misses.fetch_add(1, Ordering::AcqRel).saturating_add(1);
        if count >= COOKIE_MISS_THRESHOLD {
            self.disabled.store(true, Ordering::Release);
        }
    }

    /// Force the jar off. Used by configuration overrides and tests.
    pub fn disable(&self) {
        self.disabled.store(true, Ordering::Release);
    }

    /// Whether the jar has been disabled.
    #[must_use]
    pub fn is_disabled(&self) -> bool {
        self.disabled.load(Ordering::Acquire)
    }

    /// Load the client cookie, generating and installing one with a CAS
    /// on first use.
    fn client_or_init<R: Rng>(&self, rng: &mut R) -> [u8; 8] {
        loop {
            let existing = self.client.load(Ordering::Acquire);
            if existing != 0 {
                return existing.to_ne_bytes();
            }
            let mut fresh = [0u8; 8];
            rng.fill(&mut fresh);
            let packed = u64::from_ne_bytes(fresh);
            if packed == 0 {
                // 2⁻⁶⁴ chance; a zero draw would alias the sentinel.
                continue;
            }
            match self
                .client
                .compare_exchange(0, packed, Ordering::AcqRel, Ordering::Acquire)
            {
                Ok(_) => return fresh,
                Err(actual) => return actual.to_ne_bytes(),
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use rand::SeedableRng;

    #[test]
    fn first_query_has_only_client_half() {
        let jar = CookieJar::new();
        let mut rng = rand::rngs::StdRng::seed_from_u64(1);
        let cookie = jar.obtain(&mut rng).unwrap();
        assert!(cookie.server.is_none());
        assert_ne!(cookie.client, [0u8; 8]);
    }

    #[test]
    fn client_cookie_is_stable() {
        let jar = CookieJar::new();
        let mut rng = rand::rngs::StdRng::seed_from_u64(1);
        let first = jar.obtain(&mut rng).unwrap();
        let second = jar.obtain(&mut rng).unwrap();
        assert_eq!(first.client, second.client);
    }

    #[test]
    fn server_half_is_remembered() {
        let jar = CookieJar::new();
        let mut rng = rand::rngs::StdRng::seed_from_u64(1);
        let first = jar.obtain(&mut rng).unwrap();
        jar.store(&first.client, &[0xAA; 8]);
        let second = jar.obtain(&mut rng).unwrap();
        assert_eq!(second.server, Some([0xAA; 8]));
    }

    #[test]
    fn mismatched_client_is_rejected() {
        let jar = CookieJar::new();
        let mut rng = rand::rngs::StdRng::seed_from_u64(1);
        let _ = jar.obtain(&mut rng).unwrap();
        jar.store(&[0xFF; 8], &[0xAA; 8]);
        let second = jar.obtain(&mut rng).unwrap();
        assert!(second.server.is_none());
    }

    #[test]
    fn disabled_jar_returns_none() {
        let jar = CookieJar::new();
        jar.disable();
        let mut rng = rand::rngs::StdRng::seed_from_u64(1);
        assert!(jar.obtain(&mut rng).is_none());
        assert!(jar.is_disabled());
    }

    #[test]
    fn latching_off_requires_a_streak() {
        let jar = CookieJar::new();
        let mut rng = rand::rngs::StdRng::seed_from_u64(1);
        let _ = jar.obtain(&mut rng).unwrap();

        jar.record_miss();
        jar.record_miss();
        assert!(!jar.is_disabled());

        jar.record_miss();
        assert!(jar.is_disabled());
    }

    #[test]
    fn server_half_resets_miss_streak() {
        let jar = CookieJar::new();
        let mut rng = rand::rngs::StdRng::seed_from_u64(1);
        let first = jar.obtain(&mut rng).unwrap();

        jar.record_miss();
        jar.record_miss();
        jar.store(&first.client, &[0xAA; 8]);
        jar.record_miss();
        jar.record_miss();

        assert!(!jar.is_disabled());
    }

    #[test]
    fn concurrent_first_use_converges() {
        use std::sync::Arc;

        let jar = Arc::new(CookieJar::new());
        let mut handles = Vec::new();
        for seed in 0..16u64 {
            let jar = Arc::clone(&jar);
            handles.push(std::thread::spawn(move || {
                let mut rng = rand::rngs::StdRng::seed_from_u64(seed);
                jar.obtain(&mut rng).unwrap().client
            }));
        }
        let clients: Vec<[u8; 8]> = handles.into_iter().map(|h| h.join().unwrap()).collect();
        let first = clients[0];
        assert!(clients.iter().all(|c| *c == first));
    }
}