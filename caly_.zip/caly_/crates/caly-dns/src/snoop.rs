//! Reverse index from observed IP to recently-seen domain.
//!
//! # Why
//!
//! When the Client Plane returns a real IP (`FakeIP` disabled, or the
//! name excluded), the resulting connection arrives at the proxy with
//! only a numeric destination. To route it, the proxy needs a name —
//! or, more precisely, needs a name *if one is available*, to evaluate
//! name-based rules.
//!
//! Snooping fills this gap. Every DNS response the resolver produces is
//! recorded here, mapping each returned address to the name that
//! resolved to it. A later connection to that address looks up the
//! reverse index and recovers the name.
//!
//! # Not authoritative
//!
//! The mapping is best-effort and time-bounded. Many names share a CDN
//! address; the last one wins. The consumer treats a snooped name as a
//! *hint*, never as ground truth. This is why the module is small —
//! nothing depends on it being correct, only on it being useful.

use std::collections::HashMap;
use std::net::IpAddr;
use std::time::{Duration, Instant};

use parking_lot::RwLock;
use smol_str::SmolStr;

use crate::util::normalize_domain;

/// Upper bound on the reverse index. Beyond this, the oldest entries
/// are evicted on insertion so a hostile workload cannot grow the map
/// without limit.
const MAX_SNOOP_ENTRIES: usize = 32_768;

/// How many entries to drop when the bound is reached. Batching eviction
/// keeps the amortised cost of an insert below O(n).
const SNOOP_EVICT_BATCH: usize = 128;

/// The reverse index.
pub struct DnsSnooper {
    table: RwLock<HashMap<IpAddr, Entry>>,
    ttl: Duration,
}

#[derive(Debug, Clone)]
struct Entry {
    domain: SmolStr,
    observed_at: Instant,
}

impl DnsSnooper {
    /// Construct with a TTL.
    ///
    /// Twelve minutes is a reasonable default: long enough to bridge a
    /// TCP handshake or a slow TLS negotiation, short enough that a
    /// stale entry cannot mislead a long-lived session.
    #[must_use]
    pub fn new(ttl: Duration) -> Self {
        Self {
            table: RwLock::new(HashMap::with_capacity(2048)),
            ttl,
        }
    }

    /// Record that `name` resolved to the given addresses.
    pub fn record(&self, name: &str, ips: &[IpAddr]) {
        if ips.is_empty() {
            return;
        }
        let norm = normalize_domain(name);
        let key = SmolStr::new(norm.as_ref());
        let now = Instant::now();

        let mut table = self.table.write();
        if table.len() >= MAX_SNOOP_ENTRIES {
            // Bounded sample batch to prevent latency spikes under write lock
            let mut victim_pairs: Vec<(IpAddr, Instant)> = table
                .iter()
                .take(SNOOP_EVICT_BATCH * 4)
                .map(|(&k, v)| (k, v.observed_at))
                .collect();
            victim_pairs.sort_unstable_by_key(|&(_, t)| t);
            for (k, _) in victim_pairs.into_iter().take(SNOOP_EVICT_BATCH) {
                table.remove(&k);
            }
        }
        for &ip in ips {
            table.insert(
                ip,
                Entry {
                    domain: key.clone(),
                    observed_at: now,
                },
            );
        }
    }

    /// Look up a name for `ip`, if a recent observation exists.
    #[must_use]
    pub fn lookup(&self, ip: IpAddr) -> Option<SmolStr> {
        let now = Instant::now();
        let table = self.table.read();
        let entry = table.get(&ip)?;
        // A non-monotonic clock makes `Instant::elapsed` panic; mirror
        // `sweep_expired` and treat a clock going backwards as "expired".
        let is_fresh = now
            .checked_duration_since(entry.observed_at)
            .is_some_and(|d| d < self.ttl);
        let domain = entry.domain.clone();
        drop(table);
        is_fresh.then_some(domain)
    }

    /// Drop expired entries. Returns the number removed.
    pub fn sweep_expired(&self) -> usize {
        let now = Instant::now();
        let ttl = self.ttl;
        let mut table = self.table.write();
        let before = table.len();
        // A non-monotonic clock makes `elapsed` panic; treat the
        // result as "expired" rather than propagating the panic.
        table.retain(|_, entry| {
            now.checked_duration_since(entry.observed_at)
                .is_some_and(|d| d < ttl)
        });
        before - table.len()
    }

    /// Number of entries currently recorded.
    #[must_use]
    pub fn len(&self) -> usize {
        self.table.read().len()
    }

    /// Whether the reverse index is empty.
    #[must_use]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Configured retention TTL.
    #[must_use]
    pub const fn ttl(&self) -> Duration {
        self.ttl
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn record_then_lookup() {
        let snooper = DnsSnooper::new(Duration::from_secs(60));
        let ip: IpAddr = "1.2.3.4".parse().unwrap();
        snooper.record("Example.COM.", &[ip]);
        assert_eq!(snooper.lookup(ip).as_deref(), Some("example.com"));
    }

    #[test]
    fn expired_entry_misses() {
        let snooper = DnsSnooper::new(Duration::ZERO);
        let ip: IpAddr = "1.2.3.4".parse().unwrap();
        snooper.record("example.com", &[ip]);
        std::thread::sleep(Duration::from_millis(2));
        assert!(snooper.lookup(ip).is_none());
    }

    #[test]
    fn last_record_wins() {
        let snooper = DnsSnooper::new(Duration::from_secs(60));
        let ip: IpAddr = "1.2.3.4".parse().unwrap();
        snooper.record("first.com", &[ip]);
        snooper.record("second.com", &[ip]);
        assert_eq!(snooper.lookup(ip).as_deref(), Some("second.com"));
    }

    #[test]
    fn sweep_removes_expired() {
        let snooper = DnsSnooper::new(Duration::ZERO);
        snooper.record("a.com", &["1.1.1.1".parse().unwrap()]);
        snooper.record("b.com", &["2.2.2.2".parse().unwrap()]);
        std::thread::sleep(Duration::from_millis(2));
        assert_eq!(snooper.sweep_expired(), 2);
        assert!(snooper.is_empty());
    }
}
