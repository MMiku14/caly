//! Plane isolation newtypes.
//!
//! # The invariant
//!
//! The Client Plane may return a real address or a `FakeIP`. The Dial
//! Plane may only return a real address. A `FakeIP` that escapes to the
//! dialer causes an immediate, silent hang: the address is routable in
//! the kernel's eyes but nothing answers it.
//!
//! This module makes that escape impossible by construction. `RealIp`
//! and `VirtualIp` are distinct types; no implicit conversion exists
//! between them; and the pipeline returns them in different variants.
//!
//! # Why newtypes and not a single enum
//!
//! An enum would work, but it would not be enforced: the dialer could
//! still pattern-match on the wrong variant. A newtype gives the
//! compiler a chance to reject code that never runs the right branch.
//! The cost is one extra line at each boundary; the benefit is that
//! the boundary cannot be crossed accidentally.

use std::net::IpAddr;

/// A real, routable address produced by the Dial Plane.
///
/// Constructed only where the pipeline has resolved a name to an
/// actual network address. Not `Clone` from a `VirtualIp`; the
/// compiler enforces the separation.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, PartialOrd, Ord)]
pub struct RealIp(IpAddr);

impl RealIp {
    /// Wrap an address.
    #[inline]
    #[must_use]
    pub const fn new(ip: IpAddr) -> Self {
        Self(ip)
    }

    /// Unwrap the address. `const` so it can be used in match guards
    /// and const contexts.
    #[inline]
    #[must_use]
    pub const fn get(self) -> IpAddr {
        self.0
    }
}

impl From<IpAddr> for RealIp {
    #[inline]
    fn from(ip: IpAddr) -> Self {
        Self(ip)
    }
}

impl From<std::net::Ipv4Addr> for RealIp {
    #[inline]
    fn from(ip: std::net::Ipv4Addr) -> Self {
        Self(IpAddr::V4(ip))
    }
}

impl From<std::net::Ipv6Addr> for RealIp {
    #[inline]
    fn from(ip: std::net::Ipv6Addr) -> Self {
        Self(IpAddr::V6(ip))
    }
}

impl From<RealIp> for IpAddr {
    #[inline]
    fn from(r: RealIp) -> Self {
        r.0
    }
}

impl std::fmt::Display for RealIp {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        self.0.fmt(f)
    }
}

impl std::ops::Deref for RealIp {
    type Target = IpAddr;
    #[inline]
    fn deref(&self) -> &Self::Target {
        &self.0
    }
}

impl AsRef<IpAddr> for RealIp {
    #[inline]
    fn as_ref(&self) -> &IpAddr {
        &self.0
    }
}

impl std::borrow::Borrow<IpAddr> for RealIp {
    #[inline]
    fn borrow(&self) -> &IpAddr {
        &self.0
    }
}

impl RealIp {
    /// Whether this is an IPv4 address.
    #[inline]
    #[must_use]
    pub const fn is_ipv4(&self) -> bool {
        matches!(self.0, IpAddr::V4(_))
    }

    /// Whether this is an IPv6 address.
    #[inline]
    #[must_use]
    pub const fn is_ipv6(&self) -> bool {
        matches!(self.0, IpAddr::V6(_))
    }

    /// Whether this is a loopback address.
    #[inline]
    #[must_use]
    pub const fn is_loopback(&self) -> bool {
        self.0.is_loopback()
    }

    /// Whether this is the unspecified address.
    #[inline]
    #[must_use]
    pub const fn is_unspecified(&self) -> bool {
        self.0.is_unspecified()
    }

    /// Whether this is a multicast address.
    #[inline]
    #[must_use]
    pub const fn is_multicast(&self) -> bool {
        self.0.is_multicast()
    }

    /// Whether this is a private (RFC 1918) or unique-local address.
    /// Useful when the resolver wants to keep a leaked private
    /// address from escaping to the dial plane.
    #[inline]
    #[must_use]
    pub const fn is_private(&self) -> bool {
        match self.0 {
            IpAddr::V4(v4) => v4.is_private(),
            // RFC 4193 unique-local addresses live in fc00::/7.
            IpAddr::V6(v6) => (v6.segments()[0] & 0xfe00) == 0xfc00,
        }
    }

    /// Pair this address with a port, allocating nothing.
    #[inline]
    #[must_use]
    pub const fn to_socket_addr(&self, port: u16) -> std::net::SocketAddr {
        std::net::SocketAddr::new(self.0, port)
    }
}


/// A virtual `FakeIP`, meaningful only to the interceptor.
///
/// Never handed to the dialer. The pipeline returns it as part of
/// `ClientAnswer::Virtual`, which the dialer's caller does not accept.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, PartialOrd, Ord)]
pub struct VirtualIp(IpAddr);

impl VirtualIp {
    /// Wrap an address.
    #[inline]
    #[must_use]
    pub const fn new(ip: IpAddr) -> Self {
        Self(ip)
    }

    /// Unwrap.
    #[inline]
    #[must_use]
    pub const fn get(self) -> IpAddr {
        self.0
    }
}

impl From<IpAddr> for VirtualIp {
    #[inline]
    fn from(ip: IpAddr) -> Self {
        Self(ip)
    }
}

// There is deliberately no `From<VirtualIp> for IpAddr`.
// A caller who needs the raw address must go through
// `expose_virtual_addr`, which reads as an audited boundary.

impl std::fmt::Display for VirtualIp {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        self.0.fmt(f)
    }
}

// `VirtualIp` deliberately does not implement `Deref<Target = IpAddr>`:
// implicit coercion would let a downstream caller cross the plane
// boundary without noticing.
impl VirtualIp {
    /// Unwrap only under an explicit, audited boundary.
    #[inline]
    #[must_use]
    pub const fn expose_virtual_addr(&self) -> IpAddr {
        self.0
    }
}

// VirtualIp deliberately removes AsRef<IpAddr> and Borrow<IpAddr> implementations
// to prevent generic networking functions from accidentally stripping type isolation.

impl VirtualIp {
    /// Whether this is an IPv4 address.
    #[inline]
    #[must_use]
    pub const fn is_ipv4(&self) -> bool {
        matches!(self.0, IpAddr::V4(_))
    }

    /// Whether this is an IPv6 address.
    #[inline]
    #[must_use]
    pub const fn is_ipv6(&self) -> bool {
        matches!(self.0, IpAddr::V6(_))
    }

    /// Whether this is a loopback address.
    #[inline]
    #[must_use]
    pub const fn is_loopback(&self) -> bool {
        self.0.is_loopback()
    }

    /// Whether this is a multicast address.
    #[inline]
    #[must_use]
    pub const fn is_multicast(&self) -> bool {
        self.0.is_multicast()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn roundtrip_real() {
        let ip: IpAddr = "192.0.2.1".parse().unwrap();
        let real: RealIp = ip.into();
        assert_eq!(real.get(), ip);
        let back: IpAddr = real.into();
        assert_eq!(back, ip);
    }

    #[test]
    fn roundtrip_virtual() {
        let ip: IpAddr = "198.18.0.1".parse().unwrap();
        let virt: VirtualIp = ip.into();
        assert_eq!(virt.get(), ip);
    }

    #[test]
    fn real_and_virtual_are_distinct() {
        // The types themselves cannot be compared, which is the point.
        // This test exists to document that fact.
        fn takes_real(_: RealIp) {}
        fn takes_virtual(_: VirtualIp) {}
        let ip: IpAddr = "192.0.2.1".parse().unwrap();
        takes_real(RealIp::new(ip));
        takes_virtual(VirtualIp::new(ip));
    }
}
