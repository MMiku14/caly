//! Small shared primitives.
//!
//! # What lives here
//!
//! Only three things, each used by more than one module:
//!
//! * [`normalize_domain`] — the single canonical form for domain names.
//! * [`fnv1a`] — a deterministic 64-bit hash. FNV is chosen over
//!   `DefaultHasher` because it is stable across processes and versions;
//!   `FakeIP` allocation depends on that stability.
//! * [`ascii_lowercase`] — SIMD-accelerated where available.
//!
//! # What does not live here
//!
//! Anything with a domain-specific meaning. Cache eviction, RTT
//! estimation, name parsing — each of those has a home. This module is
//! deliberately named `util` and not `helpers` because the two are not
//! the same: helpers grow without bound, utilities have a contract.

use std::borrow::Cow;

// ─────────────────────────────────────────────────────────────────────────────
// Domain normalization
// ─────────────────────────────────────────────────────────────────────────────

/// Canonicalize a domain name.
///
/// The canonical form is:
///
/// 1. Leading and trailing ASCII whitespace is stripped.
/// 2. **One** trailing root dot is removed.
/// 3. The result is ASCII-lowercased.
///
/// A borrowed slice is returned when the input is already canonical, so
/// the hot path avoids allocation. The lowercase pass is SIMD-accelerated
/// on `x86_64` and aarch64; a scalar fallback preserves identical
/// behaviour when the `simd` feature is off.
///
/// # Examples
///
/// ```
/// use caly_dns::util::normalize_domain;
///
/// assert_eq!(normalize_domain("  Example.COM.  "), "example.com");
/// assert_eq!(normalize_domain("example.com"), "example.com");
/// // Exactly one trailing dot is stripped, leaving the second intact.
/// assert_eq!(normalize_domain("example.com.."), "example.com.");
/// ```
///
/// The root name stays as `.`; callers that need an empty string should
/// trim it themselves.
#[inline]
#[must_use]
pub fn normalize_domain(raw: &str) -> Cow<'_, str> {
    let trimmed = raw.trim();
    // The lone root label is preserved as `.` rather than being
    // stripped down to an empty string.
    let stripped = if trimmed == "." {
        "."
    } else if let Some(s) = trimmed.strip_suffix('.') {
        s
    } else {
        trimmed
    };
    if stripped.bytes().any(|b| b.is_ascii_uppercase()) {
        Cow::Owned(ascii_lowercase(stripped))
    } else {
        Cow::Borrowed(stripped)
    }
}

/// ASCII-lowercase a string.
///
/// Multi-byte UTF-8 sequences pass through unchanged; the SIMD path
/// preserves any byte with the high bit set.
#[must_use]
pub fn ascii_lowercase(input: &str) -> String {
    let mut out = String::with_capacity(input.len());
    out.push_str(input);
    // SAFETY: the operation only transforms ASCII uppercase bytes ('A'..='Z')
    // to their lowercase equivalents ('a'..='z'). Multi-byte UTF-8 sequences all
    // have the high bit (0x80) set on every byte, so they will never match the
    // range [0x41, 0x5A] and are strictly preserved unchanged. Thus UTF-8 validity is maintained.
    unsafe {
        let bytes = out.as_mut_vec();
        lowercase_in_place(bytes);
    }
    out
}

/// # Safety
///
/// `bytes` must be the backing storage of a `String` whose current
/// contents are valid UTF-8. The function only modifies ASCII uppercase
/// bytes, which cannot create an invalid UTF-8 sequence.
#[cfg(all(feature = "simd", target_arch = "x86_64"))]
unsafe fn lowercase_in_place(bytes: &mut [u8]) {
    if is_x86_feature_detected!("sse2") {
        lowercase_sse2(bytes);
    } else {
        lowercase_scalar(bytes);
    }
}

#[cfg(all(feature = "simd", target_arch = "x86_64"))]
#[target_feature(enable = "sse2")]
#[allow(clippy::wildcard_imports)]
unsafe fn lowercase_sse2(bytes: &mut [u8]) {
    use std::arch::x86_64::*;

    let n = bytes.len();
    let mut i = 0;
    // Range check: `'A' - 1 < b < 'Z' + 1`.
    let upper_lo = _mm_set1_epi8(0x40); // 'A' - 1
    let upper_hi = _mm_set1_epi8(0x5B); // 'Z' + 1
    let delta = _mm_set1_epi8(0x20); // the amount to add

    while i + 16 <= n {
        let chunk = _mm_loadu_si128(bytes.as_ptr().add(i).cast());
        let above_lo = _mm_cmpgt_epi8(chunk, upper_lo);
        let below_hi = _mm_cmpgt_epi8(upper_hi, chunk);
        let is_upper = _mm_and_si128(above_lo, below_hi);
        let add = _mm_and_si128(is_upper, delta);
        let result = _mm_add_epi8(chunk, add);
        _mm_storeu_si128(bytes.as_mut_ptr().add(i).cast(), result);
        i += 16;
    }
    lowercase_scalar(&mut bytes[i..]);
}

/// # Safety
///
/// Same contract as the x86_64 variant: `bytes` must back a valid
/// UTF-8 `String`, and only ASCII uppercase bytes are modified.
#[cfg(all(feature = "simd", target_arch = "aarch64"))]
unsafe fn lowercase_in_place(bytes: &mut [u8]) {
    if std::arch::is_aarch64_feature_detected!("neon") {
        lowercase_neon(bytes);
    } else {
        lowercase_scalar(bytes);
    }
}

#[cfg(all(feature = "simd", target_arch = "aarch64"))]
#[target_feature(enable = "neon")]
unsafe fn lowercase_neon(bytes: &mut [u8]) {
    use std::arch::aarch64::*;

    let n = bytes.len();
    let mut i = 0;
    let lo = vdupq_n_u8(0x40);
    let hi = vdupq_n_u8(0x5B);
    let delta = vdupq_n_u8(0x20);

    while i + 16 <= n {
        let chunk = vld1q_u8(bytes.as_ptr().add(i));
        let above_lo = vcgtq_u8(chunk, lo);
        let below_hi = vcltq_u8(chunk, hi);
        let is_upper = vandq_u8(above_lo, below_hi);
        let add = vandq_u8(is_upper, delta);
        let result = vaddq_u8(chunk, add);
        vst1q_u8(bytes.as_mut_ptr().add(i), result);
        i += 16;
    }
    lowercase_scalar(&mut bytes[i..]);
}

/// # Safety
///
/// Same contract as the SIMD variants: `bytes` backs a valid UTF-8
/// `String`, and only ASCII uppercase bytes are touched.
#[cfg(not(all(
    feature = "simd",
    any(target_arch = "x86_64", target_arch = "aarch64")
)))]
unsafe fn lowercase_in_place(bytes: &mut [u8]) {
    lowercase_scalar(bytes);
}

#[inline]
fn lowercase_scalar(bytes: &mut [u8]) {
    for b in bytes.iter_mut() {
        if b.is_ascii_uppercase() {
            *b += 0x20;
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// FNV-1a
// ─────────────────────────────────────────────────────────────────────────────

/// Deterministic 64-bit FNV-1a hash.
///
/// Chosen over `std`'s `DefaultHasher` because the value is stable
/// across processes and compiler versions. `FakeIP` allocation uses the
/// hash as a slot hint, and that stability is what makes the mapping
/// reproducible across restarts.
///
/// Not cryptographically secure; not intended to be.
#[inline]
#[must_use]
pub fn fnv1a(bytes: &[u8]) -> u64 {
    const OFFSET_BASIS: u64 = 0xcbf2_9ce4_8422_2325;
    const PRIME: u64 = 0x0000_0100_0000_01b3;

    let mut hash = OFFSET_BASIS;
    // Four bytes per iteration trims loop overhead; the hash chain
    // itself stays strictly serial, as FNV-1a requires.
    let (chunks, remainder) = bytes.as_chunks::<4>();
    for chunk in chunks {
        hash = (hash ^ u64::from(chunk[0])).wrapping_mul(PRIME);
        hash = (hash ^ u64::from(chunk[1])).wrapping_mul(PRIME);
        hash = (hash ^ u64::from(chunk[2])).wrapping_mul(PRIME);
        hash = (hash ^ u64::from(chunk[3])).wrapping_mul(PRIME);
    }
    for &byte in remainder {
        hash = (hash ^ u64::from(byte)).wrapping_mul(PRIME);
    }
    hash
}

// ─────────────────────────────────────────────────────────────────────────────
// Tests
// ─────────────────────────────────────────────────────────────────────────────

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn normalize_strips_and_lowercases() {
        assert_eq!(normalize_domain("  Example.COM.  "), "example.com");
        assert_eq!(normalize_domain("EXAMPLE.COM"), "example.com");
    }

    #[test]
    fn normalize_strips_at_most_one_dot() {
        assert_eq!(normalize_domain("example.com.."), "example.com.");
    }

    #[test]
    fn normalize_borrows_when_canonical() {
        assert!(matches!(
            normalize_domain("example.com"),
            Cow::Borrowed(_)
        ));
        assert!(matches!(
            normalize_domain("Example.com"),
            Cow::Owned(_)
        ));
    }

    #[test]
    fn lowercase_matches_reference() {
        for input in [
            "",
            "a",
            "ABC",
            "aBcDeFgHiJkLmNoPqRsTuVwXyZ",
            "hello world 123",
            "ÀÉÎÕÜ", // non-ASCII must pass through unchanged
        ] {
            let ours = ascii_lowercase(input);
            let reference: String = input
                .chars()
                .map(|c| if c.is_ascii_uppercase() { c.to_ascii_lowercase() } else { c })
                .collect();
            assert_eq!(ours, reference, "mismatch on {input:?}");
        }
    }

    #[test]
    fn lowercase_is_utf8_safe() {
        // Multi-byte UTF-8: the SIMD path must not corrupt it.
        let input = "日本語.example.com";
        let lowered = ascii_lowercase(input);
        assert_eq!(lowered, "日本語.example.com");
        // Verify it is still valid UTF-8 by round-tripping.
        let _ = lowered.as_str();
    }

    #[test]
    fn fnv1a_is_stable() {
        assert_eq!(fnv1a(b"example.com"), fnv1a(b"example.com"));
        assert_ne!(fnv1a(b"a.com"), fnv1a(b"b.com"));
    }

    #[test]
    fn fnv1a_known_value() {
        // FNV-1a of empty input is the offset basis.
        assert_eq!(fnv1a(b""), 0xcbf2_9ce4_8422_2325);
    }
}
