//! Configuration schema.
//!
//! # Design
//!
//! The config is a plain data structure. Nothing in it has behaviour;
//! validation and construction of runtime objects happen elsewhere.
//! This keeps the config serializable, comparable, and diffable — which
//! matters when it arrives via a REST endpoint or a file watcher.
//!
//! Every field has a default where one is sensible. `serde`'s
//! `deny_unknown_fields` is applied everywhere: a typo in a config key
//! is a startup error, not a silently ignored line.
//!
//! # Validation
//!
//! [`Config::validate`] checks every cross-field invariant the runtime
//! will later depend on:
//!
//! * No duplicate server tags.
//! * `final` refers to an existing tag.
//! * Every rule's `server` field refers to an existing tag.
//! * Every `rule_set` reference resolves.
//! * Every regex compiles.
//! * Every CIDR parses.
//! * DNSSEC is either fully specified or fully absent.
//!
//! Failing validation is a startup error. The runtime never sees a
//! config that has not passed.

use std::collections::{HashMap, HashSet};
use std::net::{IpAddr, SocketAddr};
use std::path::PathBuf;

use serde::{Deserialize, Serialize};

use crate::error::{Error, Result};

// ─────────────────────────────────────────────────────────────────────────────
// Top-level
// ─────────────────────────────────────────────────────────────────────────────

/// The complete DNS configuration.
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Config {
    /// Upstream servers, indexed by tag.
    pub servers: Vec<ServerConfig>,

    /// Routing rules, evaluated in declaration order.
    #[serde(default)]
    pub rules: Vec<RuleConfig>,

    /// Named matcher bundles, referenced by rules.
    #[serde(default)]
    pub rule_sets: HashMap<String, RuleSetConfig>,

    /// The tag a query routes to when no rule matches.
    #[serde(default = "default_final_tag")]
    pub final_tag: String,

    /// Static host overrides.
    #[serde(default)]
    pub hosts: HashMap<String, Vec<String>>,

    /// `FakeIP` allocation.
    #[serde(default)]
    pub fakeip: FakeIpConfig,

    /// Cache behaviour.
    #[serde(default)]
    pub cache: CacheConfig,

    /// Upstreams to try when the primary fails.
    #[serde(default)]
    pub fallback: Vec<String>,

    /// DNS64 synthesis.
    pub dns64: Option<Dns64Config>,

    /// DNSSEC validation.
    #[serde(default)]
    pub dnssec: DnssecConfig,

    /// Anti-poisoning measures applied to every upstream.
    #[serde(default)]
    pub anti_poison: AntiPoisonConfig,

    /// Local DNS server bound to loopback.
    pub local_server: Option<LocalServerConfig>,

    /// Cache persistence.
    pub persistence: Option<PersistenceConfig>,

    /// Query types rejected without upstream traffic.
    #[serde(default)]
    pub blocked_query_types: Vec<QueryType>,
}

fn default_final_tag() -> String {
    "default".into()
}

impl Config {
    /// Parse a JSON string.
    /// # Errors
    ///
    /// Returns [`Error::Config`] if JSON deserialization or validation fails.
    pub fn from_json(json: &str) -> Result<Self> {
        let cfg: Self = serde_json::from_str(json)
            .map_err(|e| Error::config(format!("JSON parse: {e}")))?;
        cfg.validate().map_err(Error::config)?;
        Ok(cfg)
    }

    /// Check every cross-field invariant.
    /// # Errors
    ///
    /// Returns an error string describing any invariant violation.
    pub fn validate(&self) -> std::result::Result<(), String> {
        self.validate_servers()?;
        self.validate_rules()?;
        self.validate_hosts()?;
        self.validate_fakeip()?;
        self.validate_cache()?;
        self.validate_fallback()?;
        self.validate_dns64()?;
        self.validate_dnssec()?;
        self.validate_local_server()?;
        Ok(())
    }

    /// Reject empty hostnames and unparseable addresses in `hosts`.
    fn validate_hosts(&self) -> std::result::Result<(), String> {
        for (host, ips) in &self.hosts {
            if host.trim().is_empty() {
                return Err("hosts contains empty hostname".into());
            }
            for ip_str in ips {
                ip_str.parse::<IpAddr>().map_err(|e| {
                    format!("hosts entry for '{host}' has invalid IP '{ip_str}': {e}")
                })?;
            }
        }
        Ok(())
    }

    // ─────────────────────────────────────────────────────────────────────
    // Server validation
    // ─────────────────────────────────────────────────────────────────────

    fn validate_servers(&self) -> std::result::Result<(), String> {
        if self.servers.is_empty() {
            return Err("at least one server is required".into());
        }
        let mut tags = HashSet::with_capacity(self.servers.len());
        for entry in &self.servers {
            if !tags.insert(entry.tag.as_str()) {
                return Err(format!("duplicate server tag: {}", entry.tag));
            }
            // An ECS prefix is a valid value for either family, so the only
            // universal upper bound is 128 (a v4 ECS prefix should still be
            // <= 32, but that cross-family refinement is left to the encoder).
            if let Some(sub) = entry.client_subnet {
                if sub > 128 {
                    return Err(format!(
                        "server '{}': client_subnet prefix {sub} exceeds 128",
                        entry.tag
                    ));
                }
            }
            entry.parse_endpoint()?;
        }
        if !tags.contains(self.final_tag.as_str()) {
            return Err(format!(
                "final_tag '{}' does not match any server",
                self.final_tag
            ));
        }
        Ok(())
    }

    // ─────────────────────────────────────────────────────────────────────
    // Rule validation
    // ─────────────────────────────────────────────────────────────────────

    fn validate_rules(&self) -> std::result::Result<(), String> {
        let tags: HashSet<&str> = self.servers.iter().map(|s| s.tag.as_str()).collect();

        for (index, rule) in self.rules.iter().enumerate() {
            for pattern in &rule.domain_regex {
                regex::Regex::new(pattern).map_err(|e| {
                    format!("rule #{index}: invalid regex '{pattern}': {e}")
                })?;
            }
            // Every rule_set reference must resolve.
            for reference in &rule.rule_set {
                if !self.rule_sets.contains_key(reference) {
                    return Err(format!(
                        "rule #{index}: unknown rule_set '{reference}'"
                    ));
                }
            }

            // Action-specific checks.
            match rule.action {
                RuleAction::Route => {
                    let tag = rule.server.as_deref().ok_or_else(|| {
                        format!("rule #{index}: action 'route' requires a server")
                    })?;
                    if !tags.contains(tag) {
                        return Err(format!(
                            "rule #{index}: unknown server tag '{tag}'"
                        ));
                    }
                }
                RuleAction::Predefined => {
                    let answer = rule.predefined.as_ref().ok_or_else(|| {
                        format!(
                            "rule #{index}: action 'predefined' requires an answer"
                        )
                    })?;
                    if answer.a.is_empty() && answer.aaaa.is_empty() {
                        return Err(format!(
                            "rule #{index}: predefined answer must list at least one address"
                        ));
                    }
                    for ip in answer.a.iter().chain(&answer.aaaa) {
                        ip.parse::<IpAddr>().map_err(|e| {
                            format!("rule #{index}: invalid address '{ip}': {e}")
                        })?;
                    }
                }
                RuleAction::Block | RuleAction::Fakeip => {}
            }
        }
        Ok(())
    }

    // ─────────────────────────────────────────────────────────────────────
    // FakeIP validation
    // ─────────────────────────────────────────────────────────────────────

    fn validate_fakeip(&self) -> std::result::Result<(), String> {
        if !self.fakeip.enabled {
            return Ok(());
        }
        crate::fakeip::IpRange4::parse(&self.fakeip.inet4_range)?;
        crate::fakeip::IpRange6::parse(&self.fakeip.inet6_range)?;
        Ok(())
    }

    // ─────────────────────────────────────────────────────────────────────
    // Cache validation
    // ─────────────────────────────────────────────────────────────────────

    fn validate_cache(&self) -> std::result::Result<(), String> {
        if self.cache.enabled && self.cache.capacity == 0 {
            return Err("cache.capacity must be positive when the cache is enabled".into());
        }
        if self.cache.enabled && self.cache.prefetch.enabled {
            if self.cache.prefetch.max_concurrent == 0 {
                return Err("cache.prefetch.max_concurrent must be positive".into());
            }
            if self.cache.prefetch.interval_secs == 0 {
                return Err("cache.prefetch.interval_secs must be positive".into());
            }
            if self.cache.prefetch.refresh_below_secs == 0 {
                return Err("cache.prefetch.refresh_below_secs must be positive".into());
            }
        }
        Ok(())
    }

    // ─────────────────────────────────────────────────────────────────────
    // Fallback validation
    // ─────────────────────────────────────────────────────────────────────

    fn validate_fallback(&self) -> std::result::Result<(), String> {
        let tags: HashSet<&str> = self.servers.iter().map(|s| s.tag.as_str()).collect();
        for tag in &self.fallback {
            if !tags.contains(tag.as_str()) {
                return Err(format!("fallback: unknown server tag '{tag}'"));
            }
        }
        Ok(())
    }

    // ─────────────────────────────────────────────────────────────────────
    // DNS64 validation
    // ─────────────────────────────────────────────────────────────────────

    fn validate_dns64(&self) -> std::result::Result<(), String> {
        if let Some(dns64) = &self.dns64 {
            if dns64.enabled {
                parse_cidr(&dns64.prefix)
                    .map_err(|e| format!("dns64.prefix: {e}"))?;
            }
        }
        Ok(())
    }

    // ─────────────────────────────────────────────────────────────────────
    // DNSSEC validation
    // ─────────────────────────────────────────────────────────────────────

    fn validate_dnssec(&self) -> std::result::Result<(), String> {
        if self.dnssec.enabled
            && self.dnssec.anchors.is_empty()
            && self.dnssec.anchor_file.is_none()
        {
            return Err(
                "dnssec.enabled requires either 'anchors' or 'anchor_file'".into(),
            );
        }
        Ok(())
    }

    // ─────────────────────────────────────────────────────────────────────
    // Local server validation
    // ─────────────────────────────────────────────────────────────────────

    fn validate_local_server(&self) -> std::result::Result<(), String> {
        let Some(ls) = &self.local_server else {
            return Ok(());
        };
        if ls.listen.is_empty() {
            return Err("local_server.listen must not be empty".into());
        }
        for addr in &ls.listen {
            addr.parse::<SocketAddr>()
                .map_err(|e| format!("local_server.listen '{addr}': {e}"))?;
        }
        if let Some(rrl) = &ls.rate_limit {
            if rrl.responses_per_second == 0 {
                return Err("rate_limit.responses_per_second must be positive".into());
            }
            if rrl.ipv4_prefix == 0 || rrl.ipv4_prefix > 32 {
                return Err("rate_limit.ipv4_prefix must be in 1..=32".into());
            }
            if rrl.ipv6_prefix == 0 || rrl.ipv6_prefix > 128 {
                return Err("rate_limit.ipv6_prefix must be in 1..=128".into());
            }
        }
        Ok(())
    }
}

/// Parse a CIDR string; returns the address and prefix length.
fn parse_cidr(spec: &str) -> std::result::Result<(IpAddr, u8), String> {
    let (addr, prefix) = spec
        .split_once('/')
        .ok_or_else(|| format!("invalid CIDR '{spec}': missing '/'"))?;
    let addr: IpAddr = addr
        .trim()
        .parse()
        .map_err(|e| format!("invalid address in '{spec}': {e}"))?;
    let prefix: u8 = prefix
        .trim()
        .parse()
        .map_err(|e| format!("invalid prefix in '{spec}': {e}"))?;
    let max = if addr.is_ipv4() { 32 } else { 128 };
    if prefix > max {
        return Err(format!("prefix length {prefix} exceeds maximum {max}"));
    }
    Ok((addr, prefix))
}

// ─────────────────────────────────────────────────────────────────────────────
// Server entry
// ─────────────────────────────────────────────────────────────────────────────

/// One upstream server.
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct ServerConfig {
    /// Unique tag.
    pub tag: String,

    /// Endpoint. Accepts `IP`, `IP:port`, or a `scheme://` prefix.
    pub address: String,

    /// Address-family preference.
    #[serde(default)]
    pub strategy: ResolveStrategy,

    /// Outbound detour tag. Reserved for future use; currently
    /// informational.
    #[serde(default = "default_detour")]
    pub detour: String,

    /// Per-query timeout in milliseconds.
    #[serde(default = "default_timeout_ms")]
    pub timeout_ms: u64,

    /// EDNS Client Subnet prefix length. `None` disables ECS.
    #[serde(default)]
    pub client_subnet: Option<u8>,
}

fn default_detour() -> String {
    "direct".into()
}

const fn default_timeout_ms() -> u64 {
    2500
}

impl ServerConfig {
    /// Parse the endpoint.
    ///
    /// Returns the parsed endpoint and the transport kind. Unknown
    /// schemes and malformed addresses are errors, never silent
    /// fallbacks.
    /// # Errors
    ///
    /// Returns an error string if the address scheme or socket is invalid.
    pub fn parse_endpoint(
        &self,
    ) -> std::result::Result<(crate::config::Endpoint, crate::upstream::TransportKind), String> {
        use crate::upstream::TransportKind;

        let (scheme, rest) = match self.address.split_once("://") {
            Some((s, r)) => (s, r),
            None => ("", self.address.as_str()),
        };

        match scheme {
            "" | "udp" => Ok((
                Endpoint::Socket(parse_socket(rest, 53, &self.tag)?),
                TransportKind::Udp,
            )),
            "tcp" => Ok((
                Endpoint::Socket(parse_socket(rest, 53, &self.tag)?),
                TransportKind::Tcp,
            )),
            #[cfg(feature = "dot")]
            "tls" => Ok((
                Endpoint::Socket(parse_socket(rest, 853, &self.tag)?),
                TransportKind::Tls,
            )),
            #[cfg(feature = "doh")]
            "https" => Ok((Endpoint::Url(self.address.clone()), TransportKind::Https)),
            #[cfg(feature = "doq")]
            "quic" => Ok((
                Endpoint::Socket(parse_socket(rest, 853, &self.tag)?),
                TransportKind::Quic,
            )),
            other => Err(format!(
                "server '{}': unsupported scheme '{other}://'",
                self.tag
            )),
        }
    }
}

fn parse_socket(
    raw: &str,
    default_port: u16,
    tag: &str,
) -> std::result::Result<SocketAddr, String> {
    // Accept `host`, `host:port`, and `[v6]` / `[v6]:port`.
    let with_port = if raw.parse::<SocketAddr>().is_ok() {
        raw.to_owned()
    } else if raw.starts_with('[') && raw.ends_with(']') {
        format!("{raw}:{default_port}")
    } else if let Ok(ip) = raw.parse::<std::net::IpAddr>() {
        match ip {
            std::net::IpAddr::V4(_) => format!("{raw}:{default_port}"),
            std::net::IpAddr::V6(_) => format!("[{raw}]:{default_port}"),
        }
    } else if !raw.contains(':') {
        format!("{raw}:{default_port}")
    } else {
        raw.to_owned()
    };
    with_port
        .parse()
        .map_err(|e| format!("server '{tag}': invalid address '{raw}': {e}"))
}

/// A server's endpoint: either a socket or a URL.
#[derive(Debug, Clone)]
pub enum Endpoint {
    /// Used by UDP, TCP, `DoT`, and `DoQ`.
    Socket(SocketAddr),
    /// Used by `DoH`.
    Url(String),
}

impl Endpoint {
    /// Extract the socket, or error if this is a URL.
    /// # Errors
    ///
    /// Returns an error string if this endpoint is a URL instead of a socket.
    pub fn into_socket(self) -> std::result::Result<SocketAddr, String> {
        match self {
            Self::Socket(addr) => Ok(addr),
            Self::Url(_) => Err("expected a socket address, got a URL".into()),
        }
    }

    /// Extract the URL, or error if this is a socket.
    /// # Errors
    ///
    /// Returns an error string if this endpoint is a socket instead of a URL.
    pub fn into_url(self) -> std::result::Result<String, String> {
        match self {
            Self::Url(url) => Ok(url),
            Self::Socket(_) => Err("expected a URL, got a socket address".into()),
        }
    }
}

/// Address-family preference for an upstream.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum ResolveStrategy {
    /// Query A and AAAA; return A first.
    #[default]
    PreferIpv4,
    /// Query A and AAAA; return AAAA first.
    PreferIpv6,
    /// Only query A.
    Ipv4Only,
    /// Only query AAAA.
    Ipv6Only,
    /// Interleave A and AAAA in the answer.
    DualStack,
}

// ─────────────────────────────────────────────────────────────────────────────
// Rules
// ─────────────────────────────────────────────────────────────────────────────

/// What a rule does when it matches.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum RuleAction {
    /// Route to the named server.
    #[default]
    Route,
    /// Answer with a static address set.
    Predefined,
    /// Force `FakeIP` allocation.
    Fakeip,
    /// Return NXDOMAIN.
    Block,
}

/// One routing rule.
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct RuleConfig {
    /// Exact-match patterns.
    #[serde(default)]
    pub domain: Vec<String>,
    /// Suffix-match patterns.
    #[serde(default)]
    pub domain_suffix: Vec<String>,
    /// Substring-match patterns.
    #[serde(default)]
    pub domain_keyword: Vec<String>,
    /// Regex patterns.
    #[serde(default)]
    pub domain_regex: Vec<String>,
    /// Named rule-set references.
    #[serde(default)]
    pub rule_set: Vec<String>,

    /// What to do when the rule matches.
    #[serde(default)]
    pub action: RuleAction,

    /// Target server, for `action = route`.
    pub server: Option<String>,

    /// Static answer, for `action = predefined`.
    pub predefined: Option<PredefinedAnswer>,
}

/// A static address set.
#[derive(Debug, Clone, Serialize, Deserialize, Default)]
#[serde(deny_unknown_fields)]
pub struct PredefinedAnswer {
    /// IPv4 addresses as dotted-quad strings.
    #[serde(default)]
    pub a: Vec<String>,
    /// IPv6 addresses as standard textual form.
    #[serde(default)]
    pub aaaa: Vec<String>,
}

/// A reusable matcher bundle.
#[derive(Debug, Clone, Serialize, Deserialize, Default)]
#[serde(deny_unknown_fields)]
pub struct RuleSetConfig {
    /// Exact domain names to match.
    #[serde(default)]
    pub domain: Vec<String>,
    /// Domain suffixes to match.
    #[serde(default)]
    pub domain_suffix: Vec<String>,
    /// Keywords within domain names to match.
    #[serde(default)]
    pub domain_keyword: Vec<String>,
    /// Regular expressions to match against domain names.
    #[serde(default)]
    pub domain_regex: Vec<String>,
}

// ─────────────────────────────────────────────────────────────────────────────
// FakeIP
// ─────────────────────────────────────────────────────────────────────────────

/// `FakeIP` pool configuration.
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct FakeIpConfig {
    /// Whether `FakeIP` allocation is enabled.
    ///
    /// Defaults to `false` (opt-in) and matches [`FakeIpConfig::default`]:
    /// `{}` and a wholly-absent `fakeip` key now behave identically.
    #[serde(default)]
    pub enabled: bool,
    /// IPv4 CIDR block the pool allocates from.
    #[serde(default = "default_fakeip_v4")]
    pub inet4_range: String,
    /// IPv6 CIDR block the pool allocates from.
    #[serde(default = "default_fakeip_v6")]
    pub inet6_range: String,
    /// Lifetime of an allocation, in seconds.
    #[serde(default = "default_fakeip_ttl")]
    pub global_ttl: u64,
    /// Suffix patterns that must never receive a `FakeIP`.
    #[serde(default)]
    pub exclude: Vec<String>,
}

impl Default for FakeIpConfig {
    fn default() -> Self {
        Self {
            enabled: false,
            inet4_range: default_fakeip_v4(),
            inet6_range: default_fakeip_v6(),
            global_ttl: default_fakeip_ttl(),
            exclude: Vec::new(),
        }
    }
}

const fn yes() -> bool {
    true
}
fn default_fakeip_v4() -> String {
    "198.18.0.0/15".into()
}
fn default_fakeip_v6() -> String {
    "fc00::/18".into()
}
const fn default_fakeip_ttl() -> u64 {
    300
}

// ─────────────────────────────────────────────────────────────────────────────
// Cache
// ─────────────────────────────────────────────────────────────────────────────

/// Cache configuration.
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct CacheConfig {
    /// Whether cache lookups and storage are enabled.
    #[serde(default = "yes")]
    pub enabled: bool,
    /// Maximum number of cache entries.
    #[serde(default = "default_cache_capacity")]
    pub capacity: usize,
    /// Stale-while-revalidate window, in seconds.
    #[serde(default = "default_optimistic_ttl")]
    pub optimistic_ttl: u64,
    /// Proactive refresh tuning.
    #[serde(default)]
    pub prefetch: PrefetchConfig,
}

impl Default for CacheConfig {
    fn default() -> Self {
        Self {
            enabled: true,
            capacity: default_cache_capacity(),
            optimistic_ttl: default_optimistic_ttl(),
            prefetch: PrefetchConfig::default(),
        }
    }
}

const fn default_cache_capacity() -> usize {
    4096
}
const fn default_optimistic_ttl() -> u64 {
    60
}

/// Proactive prefetch tuning.
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct PrefetchConfig {
    /// Whether proactive background cache prefetching is enabled.
    #[serde(default = "yes")]
    pub enabled: bool,
    /// How often the prefetch loop runs.
    #[serde(default = "default_prefetch_interval")]
    pub interval_secs: u64,
    /// Refresh entries whose remaining TTL falls below this.
    #[serde(default = "default_prefetch_threshold")]
    pub refresh_below_secs: u64,
    /// Upper bound on concurrent prefetches.
    #[serde(default = "default_prefetch_concurrency")]
    pub max_concurrent: usize,
}

impl Default for PrefetchConfig {
    fn default() -> Self {
        Self {
            enabled: true,
            interval_secs: default_prefetch_interval(),
            refresh_below_secs: default_prefetch_threshold(),
            max_concurrent: default_prefetch_concurrency(),
        }
    }
}

const fn default_prefetch_interval() -> u64 {
    30
}
const fn default_prefetch_threshold() -> u64 {
    15
}
const fn default_prefetch_concurrency() -> usize {
    32
}

// ─────────────────────────────────────────────────────────────────────────────
// DNS64
// ─────────────────────────────────────────────────────────────────────────────

/// DNS64 / NAT64 synthesis.
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Dns64Config {
    /// Whether DNS64 / NAT64 synthesis is enabled.
    ///
    /// Defaults to `false`: synthesis must be requested explicitly, because
    /// silently rewriting AAAA answers is a breaking behaviour change for
    /// downstream resolvers.
    #[serde(default)]
    pub enabled: bool,
    /// The NAT64 prefix in CIDR form.
    #[serde(default = "default_dns64_prefix")]
    pub prefix: String,
    /// Synthesize even when an AAAA answer exists.
    #[serde(default)]
    pub always_synthesize: bool,
}

fn default_dns64_prefix() -> String {
    "64:ff9b::/96".into()
}

// ─────────────────────────────────────────────────────────────────────────────
// DNSSEC
// ─────────────────────────────────────────────────────────────────────────────

/// DNSSEC validation.
#[derive(Debug, Clone, Default, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct DnssecConfig {
    /// Whether DNSSEC validation is enabled.
    #[serde(default)]
    pub enabled: bool,
    /// Trust anchors, base64-encoded DNSKEY RDATA.
    #[serde(default)]
    pub anchors: Vec<String>,
    /// Alternative: load anchors from a zone file.
    pub anchor_file: Option<PathBuf>,
    /// When `true`, `Bogus` answers are returned instead of SERVFAIL.
    #[serde(default)]
    pub allow_bogus: bool,
    /// Whether to validate on the Client Plane. Off by default, because
    /// that plane usually returns `FakeIPs`.
    #[serde(default)]
    pub validate_client_plane: bool,
}

impl DnssecConfig {
    /// Build the trust anchor this configuration describes.
    /// # Errors
    ///
    /// Returns an error string if loading or parsing the trust anchor fails.
    pub fn build_anchor(&self) -> std::result::Result<crate::wire::dnssec::TrustAnchor, String> {
        use crate::wire::dnssec::TrustAnchor;
        self.anchor_file.as_ref().map_or_else(
            || TrustAnchor::from_base64(".", &self.anchors).map_err(|e| format!("anchors: {e}")),
            |path| TrustAnchor::from_file(path).map_err(|e| format!("anchor_file: {e}")),
        )
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Anti-poisoning
// ─────────────────────────────────────────────────────────────────────────────

/// Anti-poisoning measures applied to every upstream.
#[derive(Debug, Clone, Copy, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct AntiPoisonConfig {
    /// Randomise the case of the query name and verify the echo.
    #[serde(default = "yes")]
    pub randomize_case: bool,
    /// Include a DNS Cookie in every query.
    #[serde(default)]
    pub dns_cookie: bool,
}

impl Default for AntiPoisonConfig {
    fn default() -> Self {
        Self {
            randomize_case: true,
            dns_cookie: false,
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Local server
// ─────────────────────────────────────────────────────────────────────────────

/// The local DNS server bound to loopback.
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct LocalServerConfig {
    /// Addresses to bind.
    pub listen: Vec<String>,
    /// Maximum UDP response size before setting TC=1.
    #[serde(default = "default_max_udp_size")]
    pub max_udp_size: u16,
    /// Response rate limiting.
    pub rate_limit: Option<RrlConfig>,
    /// Whether to also bind a TCP listener.
    #[serde(default)]
    pub tcp: bool,
}

const fn default_max_udp_size() -> u16 {
    1232
}

/// Response Rate Limiting (draft-vixie-dnsext-dns-rrl).
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct RrlConfig {
    /// Per-bucket response rate limit.
    #[serde(default = "default_rrl_qps")]
    pub responses_per_second: u32,
    /// IPv4 prefix used to group clients.
    #[serde(default = "default_rrl_v4")]
    pub ipv4_prefix: u8,
    /// IPv6 prefix used to group clients.
    #[serde(default = "default_rrl_v6")]
    pub ipv6_prefix: u8,
    /// Send a truncated response every Nth drop.
    #[serde(default = "default_rrl_slip")]
    pub slip: u32,
    /// Maximum number of rate-limiting buckets.
    #[serde(default = "default_rrl_capacity")]
    pub capacity: usize,
}

const fn default_rrl_qps() -> u32 {
    20
}
const fn default_rrl_v4() -> u8 {
    24
}
const fn default_rrl_v6() -> u8 {
    56
}
const fn default_rrl_slip() -> u32 {
    2
}
const fn default_rrl_capacity() -> usize {
    65536
}

// ─────────────────────────────────────────────────────────────────────────────
// Persistence
// ─────────────────────────────────────────────────────────────────────────────

/// Cache persistence.
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct PersistenceConfig {
    /// Path to the cache file.
    pub path: PathBuf,
    /// Periodic save interval. `0` disables periodic saves; the cache is
    /// then only written on shutdown.
    #[serde(default = "default_persist_interval")]
    pub save_interval_secs: u64,
}

const fn default_persist_interval() -> u64 {
    60
}

// ─────────────────────────────────────────────────────────────────────────────
// Query types
// ─────────────────────────────────────────────────────────────────────────────

/// Query types that can be listed in `blocked_query_types`.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
#[serde(rename_all = "UPPERCASE")]
pub enum QueryType {
    /// IPv4 host address.
A,
    /// IPv6 host address.
    Aaaa,
    /// Canonical name.
    Cname,
    /// HTTPS binding.
    Https,
    /// Service binding.
    Svcb,
    /// Text record.
    Txt,
    /// Mail exchange.
    Mx,
    /// Reverse pointer.
    Ptr,
    /// Delegation signer.
    Ds,
    /// DNSSEC public key.
    Dnskey,
    /// DNSSEC signature.
    Rrsig,
    /// Next secure record.
    Nsec,
}

impl QueryType {
    /// The wire-format type code.
    #[must_use]
    pub const fn as_u16(self) -> u16 {
        use crate::wire::{
            TYPE_A, TYPE_AAAA, TYPE_CNAME, TYPE_DNSKEY, TYPE_DS, TYPE_HTTPS, TYPE_MX,
            TYPE_NSEC, TYPE_PTR, TYPE_RRSIG, TYPE_SVCB, TYPE_TXT,
        };
        match self {
            Self::A => TYPE_A,
            Self::Cname => TYPE_CNAME,
            Self::Ptr => TYPE_PTR,
            Self::Mx => TYPE_MX,
            Self::Txt => TYPE_TXT,
            Self::Aaaa => TYPE_AAAA,
            Self::Ds => TYPE_DS,
            Self::Rrsig => TYPE_RRSIG,
            Self::Nsec => TYPE_NSEC,
            Self::Dnskey => TYPE_DNSKEY,
            Self::Svcb => TYPE_SVCB,
            Self::Https => TYPE_HTTPS,
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Tests
// ─────────────────────────────────────────────────────────────────────────────

#[cfg(test)]
mod tests {
    use super::*;

    fn minimal() -> Config {
        Config {
            servers: vec![ServerConfig {
                tag: "default".into(),
                address: "1.1.1.1".into(),
                strategy: ResolveStrategy::default(),
                detour: "direct".into(),
                timeout_ms: 2500,
                client_subnet: None,
            }],
            rules: Vec::new(),
            rule_sets: HashMap::new(),
            final_tag: "default".into(),
            hosts: HashMap::new(),
            fakeip: FakeIpConfig::default(),
            cache: CacheConfig::default(),
            fallback: Vec::new(),
            dns64: None,
            dnssec: DnssecConfig::default(),
            anti_poison: AntiPoisonConfig::default(),
            local_server: None,
            persistence: None,
            blocked_query_types: Vec::new(),
        }
    }

    #[test]
    fn minimal_config_passes_validation() {
        assert!(minimal().validate().is_ok());
    }

    #[test]
    fn empty_servers_rejected() {
        let mut c = minimal();
        c.servers.clear();
        assert!(c.validate().is_err());
    }

    #[test]
    fn duplicate_tag_rejected() {
        let mut c = minimal();
        c.servers.push(c.servers[0].clone());
        assert!(c.validate().is_err());
    }

    #[test]
    fn unknown_final_tag_rejected() {
        let mut c = minimal();
        c.final_tag = "missing".into();
        assert!(c.validate().is_err());
    }

    #[test]
    fn route_without_server_rejected() {
        let mut c = minimal();
        c.rules.push(RuleConfig {
            domain: vec!["x.com".into()],
            domain_suffix: Vec::new(),
            domain_keyword: Vec::new(),
            domain_regex: Vec::new(),
            rule_set: Vec::new(),
            action: RuleAction::Route,
            server: None,
            predefined: None,
        });
        assert!(c.validate().is_err());
    }

    #[test]
    fn unknown_rule_set_rejected() {
        let mut c = minimal();
        c.rules.push(RuleConfig {
            domain: Vec::new(),
            domain_suffix: Vec::new(),
            domain_keyword: Vec::new(),
            domain_regex: Vec::new(),
            rule_set: vec!["missing".into()],
            action: RuleAction::Block,
            server: None,
            predefined: None,
        });
        assert!(c.validate().is_err());
    }

    #[test]
    fn predefined_requires_addresses() {
        let mut c = minimal();
        c.rules.push(RuleConfig {
            domain: vec!["x.com".into()],
            domain_suffix: Vec::new(),
            domain_keyword: Vec::new(),
            domain_regex: Vec::new(),
            rule_set: Vec::new(),
            action: RuleAction::Predefined,
            server: None,
            predefined: Some(PredefinedAnswer::default()),
        });
        assert!(c.validate().is_err());
    }

    #[test]
    fn scheme_parsing_handles_prefixes() {
        let cfg = ServerConfig {
            tag: "t".into(),
            address: "tcp://8.8.8.8:5353".into(),
            strategy: ResolveStrategy::default(),
            detour: "direct".into(),
            timeout_ms: 2500,
            client_subnet: None,
        };
        let (endpoint, kind) = cfg.parse_endpoint().unwrap();
        assert!(matches!(kind, crate::upstream::TransportKind::Tcp));
        if let Endpoint::Socket(addr) = endpoint {
            assert_eq!(addr.port(), 5353);
        } else {
            panic!("expected socket endpoint");
        }
    }

    #[test]
    fn default_port_applied() {
        let cfg = ServerConfig {
            tag: "t".into(),
            address: "1.1.1.1".into(),
            strategy: ResolveStrategy::default(),
            detour: "direct".into(),
            timeout_ms: 2500,
            client_subnet: None,
        };
        let (endpoint, _) = cfg.parse_endpoint().unwrap();
        if let Endpoint::Socket(addr) = endpoint {
            assert_eq!(addr.port(), 53);
        } else {
            panic!("expected socket endpoint");
        }
    }

    #[test]
    fn unknown_scheme_rejected() {
        let cfg = ServerConfig {
            tag: "t".into(),
            address: "ftp://example.com".into(),
            strategy: ResolveStrategy::default(),
            detour: "direct".into(),
            timeout_ms: 2500,
            client_subnet: None,
        };
        assert!(cfg.parse_endpoint().is_err());
    }

    #[test]
    fn json_roundtrip() {
        let c = minimal();
        let json = serde_json::to_string(&c).unwrap();
        let parsed: Config = serde_json::from_str(&json).unwrap();
        assert_eq!(parsed.servers.len(), 1);
    }

    #[test]
    fn fakeip_defaults_to_disabled_and_is_serde_consistent() {
        // Rust Default and serde-default must agree: FakeIP is opt-in, so
        // `FakeIpConfig::default()` and `from_str("{}")` must match.
        assert!(!FakeIpConfig::default().enabled);
        assert!(!serde_json::from_str::<FakeIpConfig>("{}").unwrap().enabled);
        assert!(serde_json::from_str::<FakeIpConfig>(r#"{"enabled": true}"#)
            .unwrap()
            .enabled);
    }

    #[test]
    fn dns64_defaults_to_disabled() {
        assert!(!serde_json::from_str::<Dns64Config>("{}").unwrap().enabled);
    }

    #[test]
    fn zero_ipv6_prefix_rejected() {
        // ipv6_prefix == 0 would collapse every client into one ::/0 bucket.
        let mut c = minimal();
        c.local_server = Some(LocalServerConfig {
            listen: vec!["127.0.0.1:53".into()],
            max_udp_size: 1232,
            rate_limit: Some(RrlConfig {
                responses_per_second: 20,
                ipv4_prefix: 24,
                ipv6_prefix: 0,
                slip: 2,
                capacity: 1024,
            }),
            tcp: false,
        });
        assert!(c.validate().is_err());
    }

    #[test]
    fn oversized_client_subnet_rejected() {
        let mut c = minimal();
        c.servers[0].client_subnet = Some(129);
        assert!(c.validate().is_err());
        c.servers[0].client_subnet = Some(56);
        assert!(c.validate().is_ok());
    }

    #[test]
    fn unknown_field_rejected() {
        let json = r#"{
            "servers": [{"tag": "x", "address": "1.1.1.1"}],
            "final_tag": "x",
            "unknown_field": true
        }"#;
        assert!(serde_json::from_str::<Config>(json).is_err());
    }
}
