//! EDNS0 (RFC 6891).
//!
//! # Where EDNS lives
//!
//! EDNS is not a separate protocol; it is a conventional use of a
//! pseudo-record. An OPT record in the additional section carries:
//!
//! * The sender's UDP payload size (in the record's CLASS field).
//! * Extended RCODE bits (in the record's TTL field).
//! * A list of `(code, data)` options in the RDATA.
//!
//! This module models the option list as a typed enum. The wrapping
//! OPT record itself lives in [`crate::wire::record::RecordData::Opt`].
//!
//! # Options implemented
//!
//! * **Client Subnet** (RFC 7871) — the resolver includes a masked
//!   client address so an authoritative server can return a
//!   CDN-appropriate answer.
//! * **DNS Cookie** (RFC 7873) — an 8-byte client value plus an
//!   optional 8-byte server value. Together with a random TXID, this
//!   makes off-path spoofing infeasible.
//! * **Padding** (RFC 7830) — opaque bytes to pad the query. RFC 8467
//!   recommends padding to 468 bytes for privacy.
//! * **Unknown** — any other option, preserved verbatim.

use std::net::IpAddr;
use smallvec::SmallVec;

use crate::error::{Error, Result};

// ─────────────────────────────────────────────────────────────────────────────
// Option codes (IANA registry)
// ─────────────────────────────────────────────────────────────────────────────

/// Name Server Identifier (RFC 5001).
pub const OPT_NSID: u16 = 3;
/// EDNS Client Subnet (RFC 7871).
pub const OPT_CLIENT_SUBNET: u16 = 8;
/// DNS Cookie (RFC 7873).
pub const OPT_COOKIE: u16 = 10;
/// TCP keepalive (RFC 7828).
pub const OPT_TCP_KEEPALIVE: u16 = 11;
/// EDNS Padding (RFC 7830).
pub const OPT_PADDING: u16 = 12;

// ─────────────────────────────────────────────────────────────────────────────
// Option enum
// ─────────────────────────────────────────────────────────────────────────────

/// An EDNS0 option.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum EdnsOption {
    /// RFC 7871 Client Subnet.
    ClientSubnet(ClientSubnet),
    /// RFC 7873 DNS Cookie.
    Cookie(DnsCookie),
    /// RFC 7830 Padding.
    Padding(Vec<u8>),
    /// An option this build does not interpret.
    Unknown {
        /// The option code, preserved verbatim.
        code: u16,
        /// The option body, preserved verbatim.
        data: Vec<u8>,
    },
}

impl EdnsOption {
    /// The option code.
    #[must_use]
    pub const fn code(&self) -> u16 {
        match self {
            Self::ClientSubnet(_) => OPT_CLIENT_SUBNET,
            Self::Cookie(_) => OPT_COOKIE,
            Self::Padding(_) => OPT_PADDING,
            Self::Unknown { code, .. } => *code,
        }
    }

    /// Total length in wire form, including the 4-byte option header.
    #[must_use]
    pub fn wire_len(&self) -> usize {
        4 + self.body_len()
    }

    fn body_len(&self) -> usize {
        match self {
            Self::ClientSubnet(cs) => {
                // RFC 7871 §6: the ADDRESS field is ceil(prefix/8) bytes.
                let max_bits = if cs.address.is_ipv4() { 32 } else { 128 };
                let needed = usize::from(cs.source_prefix.min(max_bits)).div_ceil(8);
                4 + needed
            }
            Self::Cookie(c) => 8 + c.server.as_ref().map_or(0, |s| s.len()),
            Self::Padding(p) => p.len(),
            Self::Unknown { data, .. } => data.len(),
        }
    }

    /// Encode the full option (header plus body) into `out`.
    ///
    /// # Errors
    ///
    /// Returns [`Error::Malformed`] when the option body is longer than
    /// the 16-bit length field can represent (65535 bytes). We refuse to
    /// encode rather than clamp the length field, because emitting
    /// `65535` while writing more bytes would produce a wire record
    /// whose declared length disagrees with its actual size — a
    /// malformed message that desynchronises every downstream parser.
    pub fn encode(&self, out: &mut Vec<u8>) -> Result<()> {
        // A single option body is at most 65535 bytes, matching the
        // 16-bit length field. Reject, do not clamp.
        let body_len = u16::try_from(self.body_len())
            .map_err(|_| Error::Malformed("EDNS option body exceeds 65535 bytes"))?;
        out.extend_from_slice(&self.code().to_be_bytes());
        out.extend_from_slice(&body_len.to_be_bytes());
        match self {
            Self::ClientSubnet(cs) => cs.encode(out),
            Self::Cookie(c) => c.encode(out),
            Self::Padding(p) => out.extend_from_slice(p),
            Self::Unknown { data, .. } => out.extend_from_slice(data),
        }
        Ok(())
    }

    /// Decode an option's body.
    ///
    /// Returns `None` for structurally invalid payloads. Unknown codes
    /// become `Unknown` and are preserved verbatim, so a round trip
    /// through the parser is lossless for those.
    #[must_use]
    pub fn decode(code: u16, body: &[u8]) -> Option<Self> {
        match code {
            OPT_CLIENT_SUBNET => ClientSubnet::decode(body).map(Self::ClientSubnet),
            OPT_COOKIE => DnsCookie::decode(body).map(Self::Cookie),
            OPT_PADDING => Some(Self::Padding(body.to_vec())),
            other => Some(Self::Unknown {
                code: other,
                data: body.to_vec(),
            }),
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Client Subnet
// ─────────────────────────────────────────────────────────────────────────────

/// RFC 7871 Client Subnet.
///
/// `source_prefix` is the number of significant bits the sender is
/// willing to disclose. `scope_prefix` (in a response) is the number of
/// bits the answer is valid for — `0` means "everyone".
///
/// # Round-trip is NOT byte-lossless
///
/// Unlike [`EdnsOption::Unknown`], a `ClientSubnet` does **not**
/// reproduce the original wire bytes on re-encode. On decode we clamp
/// `scope_prefix` to the family maximum (32/128) and copy only the
/// `ceil(source_prefix / 8)` significant octets, discarding any address
/// padding some servers append. Re-encoding therefore yields a canonical
/// form that may differ from the payload we received. Do not use this
/// variant to build byte-exact re-transmissions; use it only to read the
/// semantic value.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct ClientSubnet {
    /// The address family code: 1 for IPv4, 2 for IPv6.
    pub family: u16,
    /// Number of significant bits the sender discloses.
    pub source_prefix: u8,
    /// Number of bits the answer is valid for; 0 means everyone.
    pub scope_prefix: u8,
    /// The masked address.
    pub address: IpAddr,
}

impl ClientSubnet {
    /// Build a client subnet from an address and prefix length. The
    /// address is masked to the prefix.
    ///
    /// The family code is derived from the address: 1 for IPv4, 2 for
    /// IPv6, as registered by IANA.
    #[must_use]
    pub fn new(address: IpAddr, prefix: u8) -> Self {
        let family = match address {
            IpAddr::V4(_) => 1,
            IpAddr::V6(_) => 2,
        };
        Self {
            family,
            source_prefix: prefix,
            scope_prefix: 0,
            address: mask_address(address, prefix),
        }
    }

    fn encode(&self, out: &mut Vec<u8>) {
        out.extend_from_slice(&self.family.to_be_bytes());
        out.push(self.source_prefix);
        out.push(self.scope_prefix);
        // RFC 7871 §6: emit only the significant bytes, not the full
        // 4- or 16-byte address.
        let max_bits: u8 = if self.address.is_ipv4() { 32 } else { 128 };
        let needed = usize::from(self.source_prefix.min(max_bits)).div_ceil(8);
        match self.address {
            IpAddr::V4(v4) => out.extend_from_slice(&v4.octets()[..needed.min(4)]),
            IpAddr::V6(v6) => out.extend_from_slice(&v6.octets()[..needed.min(16)]),
        }
    }

    fn decode(body: &[u8]) -> Option<Self> {
        if body.len() < 4 {
            return None;
        }
        let family = u16::from_be_bytes([body[0], body[1]]);
        let source_prefix = body[2];
        let scope_prefix = body[3];
        let payload = &body[4..];

        // Per RFC 7871 §6: the ADDRESS field only carries ceil(source_prefix / 8) octets.
        let needed_v4 = usize::from(source_prefix).min(32).div_ceil(8);
        let needed_v6 = usize::from(source_prefix).min(128).div_ceil(8);

        match family {
            1 if source_prefix <= 32 && payload.len() >= needed_v4 => {
                let mut octets = [0u8; 4];
                let copy_len = needed_v4.min(payload.len()).min(4);
                octets[..copy_len].copy_from_slice(&payload[..copy_len]);
                Some(Self {
                    family,
                    source_prefix,
                    scope_prefix: scope_prefix.min(32),
                    address: IpAddr::from(octets),
                })
            }
            2 if source_prefix <= 128 && payload.len() >= needed_v6 => {
                let mut octets = [0u8; 16];
                let copy_len = needed_v6.min(payload.len()).min(16);
                octets[..copy_len].copy_from_slice(&payload[..copy_len]);
                Some(Self {
                    family,
                    source_prefix,
                    scope_prefix: scope_prefix.min(128),
                    address: IpAddr::from(octets),
                })
            }
            _ => None,
        }
    }
}

/// Mask an address to `prefix` bits. Bits below the prefix are zeroed;
/// the boundary byte, when the prefix is not a multiple of eight, keeps
/// only its high `prefix % 8` bits.
fn mask_address(address: IpAddr, prefix: u8) -> IpAddr {
    match address {
        IpAddr::V4(v4) => {
            let keep = usize::from(prefix.min(32));
            let mut bytes = v4.octets();
            // Zero the bytes past the boundary.
            for byte in bytes.iter_mut().skip(keep.div_ceil(8)) {
                *byte = 0;
            }
            // Mask the boundary byte itself.
            if keep % 8 != 0 && keep / 8 < 4 {
                bytes[keep / 8] &= 0xFFu8 << (8 - (keep % 8));
            }
            IpAddr::from(bytes)
        }
        IpAddr::V6(v6) => {
            let keep = usize::from(prefix.min(128));
            let mut bytes = v6.octets();
            for byte in bytes.iter_mut().skip(keep.div_ceil(8)) {
                *byte = 0;
            }
            if keep % 8 != 0 && keep / 8 < 16 {
                bytes[keep / 8] &= 0xFFu8 << (8 - (keep % 8));
            }
            IpAddr::from(bytes)
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// DNS Cookie
// ─────────────────────────────────────────────────────────────────────────────

/// RFC 7873 DNS Cookie.
///
/// The client half is 8 random bytes chosen once per (client, server)
/// pair. The server half is 8 bytes returned by the server; we model
/// only the first 8 of the server's allowed 8–32 because every public
/// resolver returns exactly 8.
///
/// Both halves are compared byte-for-byte on the response path; a
/// mismatch is treated as a spoofing attempt.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct DnsCookie {
    /// The client half, chosen once per (client, server) pair.
    pub client: [u8; 8],
    /// The server half, once the upstream has returned one (RFC 7873 8..=32 bytes).
    pub server: Option<SmallVec<[u8; 32]>>,
}

impl DnsCookie {
    fn encode(&self, out: &mut Vec<u8>) {
        out.extend_from_slice(&self.client);
        if let Some(server) = &self.server {
            out.extend_from_slice(server);
        }
    }

    fn decode(body: &[u8]) -> Option<Self> {
        if body.len() < 8 {
            return None;
        }
        let mut client = [0u8; 8];
        client.copy_from_slice(&body[..8]);
        let server = if body.len() >= 16 {
            let copy_len = (body.len() - 8).min(32);
            let mut server = SmallVec::with_capacity(copy_len);
            server.extend_from_slice(&body[8..8 + copy_len]);
            Some(server)
        } else {
            None
        };
        Some(Self { client, server })
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// OptRecord
// ─────────────────────────────────────────────────────────────────────────────

/// The parsed contents of an OPT pseudo-record's RDATA.
///
/// The UDP payload size and extended RCODE live in the enclosing
/// record's `rclass` and `ttl` fields, not here. This mirrors the wire
/// format: there is exactly one OPT record, and its "class" and "ttl"
/// mean something different from every other record.
#[derive(Debug, Clone, PartialEq, Eq, Default)]
pub struct OptRecord {
    /// The parsed option list.
    pub options: SmallVec<[EdnsOption; 2]>,
}

impl OptRecord {
    /// Parse the option list from an OPT record's RDATA.
    #[must_use]
    pub fn parse(rdata: &[u8]) -> Self {
        let mut options = SmallVec::new();
        let mut cursor = 0;
        while cursor + 4 <= rdata.len() {
            let code = u16::from_be_bytes([rdata[cursor], rdata[cursor + 1]]);
            let len =
                usize::from(u16::from_be_bytes([rdata[cursor + 2], rdata[cursor + 3]]));
            cursor += 4;
            if cursor + len > rdata.len() {
                break;
            }
            if let Some(option) = EdnsOption::decode(code, &rdata[cursor..cursor + len]) {
                options.push(option);
            }
            cursor += len;
        }
        Self { options }
    }

    /// Encode the option list into `out`. Does not write a length
    /// prefix; the caller (the record encoder) computes that.
    ///
    /// # Errors
    ///
    /// Propagates [`EdnsOption::encode`]'s error when any single option
    /// is too large to represent.
    pub fn encode(&self, out: &mut Vec<u8>) -> Result<()> {
        for option in &self.options {
            option.encode(out)?;
        }
        Ok(())
    }

    /// Find an option of the given kind.
    #[must_use]
    pub fn find_cookie(&self) -> Option<DnsCookie> {
        self.options.iter().find_map(|o| match o {
            EdnsOption::Cookie(c) => Some(c.clone()),
            _ => None,
        })
    }

    /// Find the Client Subnet option, if present.
    #[must_use]
    pub fn find_client_subnet(&self) -> Option<ClientSubnet> {
        self.options.iter().find_map(|o| match o {
            EdnsOption::ClientSubnet(cs) => Some(*cs),
            _ => None,
        })
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Tests
// ─────────────────────────────────────────────────────────────────────────────

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn ecs_v4_roundtrip() {
        let cs = ClientSubnet::new("192.168.1.42".parse().unwrap(), 24);
        let mut buf = Vec::new();
        EdnsOption::ClientSubnet(cs).encode(&mut buf).unwrap();
        assert_eq!(u16::from_be_bytes([buf[0], buf[1]]), OPT_CLIENT_SUBNET);
        assert_eq!(u16::from_be_bytes([buf[2], buf[3]]), 8);
        let decoded = EdnsOption::decode(OPT_CLIENT_SUBNET, &buf[4..]).unwrap();
        match decoded {
            EdnsOption::ClientSubnet(d) => {
                assert_eq!(d.source_prefix, 24);
                assert_eq!(d.address, "192.168.1.0".parse::<IpAddr>().unwrap());
            }
            _ => panic!("expected ClientSubnet"),
        }
    }

    #[test]
    fn ecs_v6_roundtrip() {
        let cs = ClientSubnet::new("2001:db8::1".parse().unwrap(), 48);
        let mut buf = Vec::new();
        EdnsOption::ClientSubnet(cs).encode(&mut buf).unwrap();
        let decoded = EdnsOption::decode(OPT_CLIENT_SUBNET, &buf[4..]).unwrap();
        match decoded {
            EdnsOption::ClientSubnet(d) => {
                assert_eq!(d.source_prefix, 48);
            }
            _ => panic!("expected ClientSubnet"),
        }
    }

    #[test]
    fn cookie_roundtrip() {
        let cookie = DnsCookie {
            client: [1, 2, 3, 4, 5, 6, 7, 8],
            server: Some(smallvec::smallvec![9, 10, 11, 12, 13, 14, 15, 16]),
        };
        let mut buf = Vec::new();
        EdnsOption::Cookie(cookie.clone()).encode(&mut buf).unwrap();
        let decoded = EdnsOption::decode(OPT_COOKIE, &buf[4..]).unwrap();
        assert_eq!(decoded, EdnsOption::Cookie(cookie));
    }

    #[test]
    fn unknown_option_is_preserved() {
        let raw = vec![0xDE, 0xAD, 0xBE, 0xEF];
        let decoded = EdnsOption::decode(0x1234, &raw).unwrap();
        match decoded {
            EdnsOption::Unknown { code, data } => {
                assert_eq!(code, 0x1234);
                assert_eq!(data, raw);
            }
            _ => panic!("expected Unknown"),
        }
    }

    #[test]
    fn oversized_option_is_rejected() {
        // An option body larger than 65535 bytes must error, not clamp
        // the length field (the previous behaviour produced a malformed
        // wire record).
        let big = EdnsOption::Padding(vec![0u8; 70_000]);
        let mut buf = Vec::new();
        assert!(big.encode(&mut buf).is_err());
        // Nothing should have been written before the error.
        assert!(buf.is_empty());
    }

    #[test]
    fn opt_record_parses_multiple_options() {
        let cs = ClientSubnet::new("1.2.3.4".parse().unwrap(), 24);
        let cookie = DnsCookie {
            client: [0; 8],
            server: None,
        };
        let mut rdata = Vec::new();
        EdnsOption::ClientSubnet(cs).encode(&mut rdata).unwrap();
        EdnsOption::Cookie(cookie.clone()).encode(&mut rdata).unwrap();
        let opt = OptRecord::parse(&rdata);
        assert_eq!(opt.options.len(), 2);
        assert_eq!(opt.find_client_subnet(), Some(cs));
        assert_eq!(opt.find_cookie(), Some(cookie));
    }

    #[test]
    fn mask_address_handles_partial_byte() {
        let masked = mask_address("255.255.255.255".parse().unwrap(), 5);
        // 5 bits: 11111000 -> 248.0.0.0
        assert_eq!(masked, "248.0.0.0".parse::<IpAddr>().unwrap());
    }
}
