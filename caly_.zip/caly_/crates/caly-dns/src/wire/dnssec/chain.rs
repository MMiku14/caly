//! Full chain-of-trust validation.
//!
//! Verifying a single `RRset` against a DNSKEY is the primitive in
//! [`verify`](super::verify). Building a *chain* — from a trust anchor
//! down through DS records to the DNSKEY that signed the answer — is
//! what this module adds.
//!
//! # The chain
//!
//! ```text
//!     Trust anchor (root KSK)
//!          │
//!          │ signs
//!          ▼
//!     Root DNSKEY RRset
//!          │
//!          │ DS record for .com
//!          ▼
//!     .com DNSKEY RRset
//!          │
//!          │ DS record for example.com
//!          ▼
//!     example.com DNSKEY RRset
//!          │
//!          │ signs
//!          ▼
//!     www.example.com A RRset
//! ```
//!
//! Each arrow is either an RRSIG over the child DNSKEY `RRset`, or a DS
//! record that hashes the child KSK. Both must be present and valid.
//!
//! # Caching
//!
//! Every validated intermediate result is stored in the
//! [`ChainValidator`]'s internal cache. A query that shares a suffix
//! with a previously-validated one reuses the work: the `.com` DNSKEY
//! is only validated once per TTL window, no matter how many `.com`
//! domains are queried.
//!
//! The cache is **bounded**: once it reaches `max_entries`, expired
//! entries are evicted first, and if that is not enough, the oldest
//! half is dropped. This keeps a long-lived resolver from accumulating
//! one entry per zone it has ever seen.
//!
//! # Name normalization
//!
//! Zone names are normalized (lowercased, no trailing dot) before
//! being used as cache keys, so `"Example.COM."` and `"example.com"`
//! share an entry.

use std::collections::HashMap;
use std::sync::Arc;
use std::time::{Duration, Instant};

use parking_lot::RwLock;
use smol_str::SmolStr;

use crate::wire::dnssec::anchor::{normalize_owner, TrustAnchor};
use crate::wire::dnssec::verify::{validate_rrset, validate_rrset_signed_by};
use crate::wire::dnssec::ValidationOutcome;
use crate::wire::record::{DnsRecord, DnskeyRdata, DsRdata, RecordData};

/// Default cap on cached zones.
const DEFAULT_CACHE_CAPACITY: usize = 4096;

/// Result of validating a complete chain.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ChainOutcome {
    /// Every link in the chain validated.
    Secure,
    /// A link was unsigned (no DS record). The delegation is insecure
    /// by design.
    Insecure,
    /// A link was signed but failed validation.
    Bogus,
}

/// Material required to start a chain walk.
///
/// The two variants correspond to the two ways a zone can be vouched
/// for: directly by the validator's own trust anchor, or indirectly via
/// a DS record from the parent.
#[derive(Debug, Clone)]
pub enum ParentMaterial {
    /// Use the validator's own trust anchor. The zone name passed to
    /// [`ChainValidator::validate_zone`] must match an anchor entry.
    Anchor,
    /// Continue the chain from a DS `RRset` returned by the parent.
    Ds(Vec<DnsRecord>),
}

/// The validator.
pub struct ChainValidator {
    /// The trust anchor for the root.
    anchor: Arc<TrustAnchor>,
    /// Cache of validated DNSKEY `RRsets`, keyed by normalized zone name.
    cache: RwLock<HashMap<SmolStr, CachedValidation>>,
    /// How long a validation result stays valid.
    ttl: Duration,
    /// Maximum number of cached zones.
    max_entries: usize,
}

#[derive(Debug, Clone)]
struct CachedValidation {
    outcome: ChainOutcome,
    /// The DNSKEYs that were validated. Retained so a child zone can
    /// chain from them without re-querying.
    keys: Vec<DnskeyRdata>,
    validated_at: Instant,
}

impl ChainValidator {
    /// Construct a validator with the given root anchor.
    #[must_use]
    pub fn new(anchor: Arc<TrustAnchor>) -> Self {
        Self {
            anchor,
            cache: RwLock::new(HashMap::with_capacity(64)),
            ttl: Duration::from_secs(3600),
            max_entries: DEFAULT_CACHE_CAPACITY,
        }
    }

    /// Set the validation cache TTL.
    ///
    /// The default is one hour, below the minimum TTL of a typical
    /// DNSKEY `RRset`, so a cached result cannot outlive the records it
    /// was derived from.
    #[must_use]
    pub const fn with_ttl(mut self, ttl: Duration) -> Self {
        self.ttl = ttl;
        self
    }

    /// Set the maximum number of cached zones.
    #[must_use]
    pub const fn with_capacity(mut self, cap: usize) -> Self {
        self.max_entries = if cap == 0 { 1 } else { cap };
        self
    }

    /// Validate a leaf `RRset` given the DNSKEY `RRset` of its zone.
    ///
    /// The caller must have already validated the zone's DNSKEY `RRset`
    /// (via [`validate_zone`](Self::validate_zone) or a cached result).
    /// This method performs the cryptographic check on the leaf.
    #[must_use]
    pub fn validate_leaf(
        &self,
        rrset: &[DnsRecord],
        rrsigs: &[DnsRecord],
        zone_dnskeys: &[DnskeyRdata],
    ) -> ValidationOutcome {
        validate_rrset(rrset, rrsigs, zone_dnskeys)
    }

    /// Validate the DNSKEY `RRset` of `zone` against its parent.
    ///
    /// * If `parent` is `Anchor`, the zone must match an anchor entry
    ///   directly.
    /// * If `parent` is `Ds`, at least one DNSKEY's hash must match a
    ///   DS record, and the DNSKEY `RRset` must carry a valid RRSIG from
    ///   that key.
    pub fn validate_zone(
        &self,
        zone: &str,
        dnskey_rrset: &[DnsRecord],
        rrsigs: &[DnsRecord],
        parent: &ParentMaterial,
    ) -> ChainOutcome {
        let zone_key = SmolStr::new(normalize_owner(zone));

        // Fast path: cached.
        if let Some(outcome) = self.cached(&zone_key) {
            return outcome;
        }

        let keys: Vec<DnskeyRdata> = dnskey_rrset
            .iter()
            .filter_map(|r| match &r.data {
                RecordData::Dnskey(k) => Some(k.clone()),
                _ => None,
            })
            .collect();
        if keys.is_empty() {
            return self.store(&zone_key, ChainOutcome::Bogus, Vec::new());
        }

        // Collect the indices of candidate KSKs so the borrow of
        // `keys` does not escape this block. Using indices (rather
        // than `&DnskeyRdata`) lets the success branch move `keys`
        // into the cache.
        let candidate_indices: Vec<usize> = match parent {
            ParentMaterial::Anchor => keys
                .iter()
                .enumerate()
                .filter(|(_, k)| self.anchor.matches(k, zone))
                .map(|(i, _)| i)
                .collect(),
            ParentMaterial::Ds(ds_records) => {
                let ds_list: Vec<&DsRdata> = ds_records
                    .iter()
                    .filter_map(|r| match &r.data {
                        RecordData::Ds(ds) => Some(ds),
                        _ => None,
                    })
                    .collect();

                // RFC 4035 §5.2: a DS RRset in which no record is
                // usable by this validator (unsupported algorithm or
                // digest type) makes the delegation *insecure*, not
                // bogus. An empty DS RRset also means insecure.
                let usable_ds: Vec<&DsRdata> = ds_list
                    .iter()
                    .copied()
                    .filter(|ds| is_usable_ds(ds))
                    .collect();
                if usable_ds.is_empty() {
                    let outcome = ChainOutcome::Insecure;
                    return self.store(&zone_key, outcome, Vec::new());
                }

                keys.iter()
                    .enumerate()
                    .filter(|(_, key)| {
                        usable_ds
                            .iter()
                            .any(|ds| ds_matches_key_in_zone(ds, key, zone))
                    })
                    .map(|(i, _)| i)
                    .collect()
            }
        };

        if candidate_indices.is_empty() {
            // We know at least one DS was usable, or the parent was
            // an anchor: no candidate KSK matched. That is a
            // signature/DS mismatch — bogus.
            return self.store(&zone_key, ChainOutcome::Bogus, Vec::new());
        }

        // Try each candidate KSK; any successful self-signature
        // establishes the trust chain.
        let mut any_secure = false;
        let mut any_insecure = false;
        for &idx in &candidate_indices {
            match validate_rrset_signed_by(dnskey_rrset, rrsigs, &keys[idx]) {
                ValidationOutcome::Secure { .. } => {
                    any_secure = true;
                    break;
                }
                ValidationOutcome::Insecure => any_insecure = true,
                ValidationOutcome::Bogus => {}
            }
        }

        if any_secure {
            // Cache the validated keys so children can chain from them.
            return self.store(&zone_key, ChainOutcome::Secure, keys);
        }

        let outcome = if any_insecure {
            ChainOutcome::Insecure
        } else {
            ChainOutcome::Bogus
        };
        self.store(&zone_key, outcome, Vec::new())
    }

    /// Return cached DNSKEYs for a zone, if the cache holds a `Secure`
    /// result that has not yet expired.
    ///
    /// Returns `None` for `Insecure` or `Bogus` cached entries: only a
    /// fully-validated chain yields keys a caller can trust.
    #[must_use]
    pub fn validated_keys(&self, zone: &str) -> Option<Vec<DnskeyRdata>> {
        let key = SmolStr::new(normalize_owner(zone));
        let cache = self.cache.read();
        let entry = cache.get(&key)?;
        if entry.validated_at.elapsed() >= self.ttl {
            return None;
        }
        if entry.outcome != ChainOutcome::Secure {
            return None;
        }
        Some(entry.keys.clone())
    }

    /// Drop expired cache entries.
    pub fn sweep(&self) {
        let ttl = self.ttl;
        let mut cache = self.cache.write();
        cache.retain(|_, entry| entry.validated_at.elapsed() < ttl);
    }

    /// Number of live cache entries (including expired ones not yet
    /// swept).
    #[must_use]
    pub fn cache_len(&self) -> usize {
        self.cache.read().len()
    }

    fn cached(&self, zone_key: &SmolStr) -> Option<ChainOutcome> {
        let cache = self.cache.read();
        let entry = cache.get(zone_key)?;
        // Negative cache for Bogus results: bound to 60s max to allow
        // fast recovery from transient errors.
        let effective_ttl = if entry.outcome == ChainOutcome::Bogus {
            Duration::from_secs(60).min(self.ttl)
        } else {
            self.ttl
        };
        if entry.validated_at.elapsed() < effective_ttl {
            Some(entry.outcome)
        } else {
            None
        }
    }

    fn store(&self, zone_key: &SmolStr, outcome: ChainOutcome, keys: Vec<DnskeyRdata>) -> ChainOutcome {
        let mut cache = self.cache.write();

        // Bound the cache. First drop anything expired; if the map is
        // still at capacity, drop the oldest half.
        if cache.len() >= self.max_entries {
            let ttl = self.ttl;
            let now = Instant::now();
            cache.retain(|_, e| now.duration_since(e.validated_at) < ttl);

            if cache.len() >= self.max_entries {
                let mut entries: Vec<(SmolStr, Instant)> = cache
                    .iter()
                    .map(|(k, v)| (k.clone(), v.validated_at))
                    .collect();
                entries.sort_by_key(|(_, t)| *t);
                let to_remove = entries.len() / 2;
                for (k, _) in entries.into_iter().take(to_remove) {
                    cache.remove(&k);
                }
            }
        }

        cache.insert(
            zone_key.clone(),
            CachedValidation {
                outcome,
                keys,
                validated_at: Instant::now(),
            },
        );
        outcome
    }
}

/// Whether a DS record uses an algorithm and digest type this build
/// can act on.
fn is_usable_ds(ds: &DsRdata) -> bool {
    ds.algorithm.is_supported() && digest_type_supported(ds.digest_type)
}

/// Whether this build supports the given DS digest type.
const fn digest_type_supported(digest_type: u8) -> bool {
    matches!(digest_type, 1 | 2 | 4)
}

/// Return `true` if `ds` is the digest of `key` under `zone`.
///
/// The DS digest is `H(owner | DNSKEY_RDATA)`, where `H` is SHA-1,
/// SHA-256, or SHA-384 depending on `digest_type` and the owner name is
/// the zone apex in canonical (lowercase) wire form. A match means the
/// KSK is vouched for by the parent.
fn ds_matches_key_in_zone(ds: &DsRdata, key: &DnskeyRdata, zone: &str) -> bool {
    if ds.key_tag != key.key_tag() || ds.algorithm != key.algorithm {
        return false;
    }
    let digest = compute_ds_digest_named(zone, key, ds.digest_type);
    digest.as_deref() == Some(ds.digest.as_slice())
}

/// Compute the DS digest with the owner name threaded through.
///
/// Per RFC 4034 §5.1.4: `digest = H(owner | DNSKEY_RDATA)` where
/// `DNSKEY_RDATA` is the wire encoding without the RR header.
#[must_use]
pub fn compute_ds_digest_named(
    owner: &str,
    key: &DnskeyRdata,
    digest_type: u8,
) -> Option<Vec<u8>> {
    use ring::digest;

    let algorithm: &'static digest::Algorithm = match digest_type {
        1 => &digest::SHA1_FOR_LEGACY_USE_ONLY,
        2 => &digest::SHA256,
        4 => &digest::SHA384,
        _ => return None,
    };

    let mut rdata = Vec::with_capacity(4 + key.public_key.len() + 64);
    rdata.extend_from_slice(&key.flags.to_be_bytes());
    rdata.push(key.protocol);
    rdata.push(key.algorithm.as_u8());
    rdata.extend_from_slice(&key.public_key);

    let mut ctx = digest::Context::new(algorithm);
    let mut owner_wire = Vec::with_capacity(64);
    crate::wire::encode_name(&normalize_owner(owner), &mut owner_wire).ok()?;
    ctx.update(&owner_wire);
    ctx.update(&rdata);

    Some(ctx.finish().as_ref().to_vec())
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::wire::record::DnssecAlgorithm;

    fn make_ed25519_key(seed: u8) -> DnskeyRdata {
        DnskeyRdata {
            flags: 257,
            protocol: 3,
            algorithm: DnssecAlgorithm::Ed25519,
            public_key: vec![seed; 32],
        }
    }

    #[test]
    fn empty_cache_returns_none() {
        let validator = ChainValidator::new(Arc::new(TrustAnchor::empty()));
        assert!(validator.validated_keys("example.com").is_none());
    }

    #[test]
    fn cached_secure_is_returned() {
        let validator = ChainValidator::new(Arc::new(TrustAnchor::empty()));
        let key = make_ed25519_key(0xAA);
        validator.store(
            &SmolStr::new("example.com"),
            ChainOutcome::Secure,
            vec![key.clone()],
        );
        let cached = validator.validated_keys("example.com");
        assert!(cached.is_some());
        assert_eq!(cached.unwrap()[0].public_key, key.public_key);
    }

    #[test]
    fn cache_key_is_case_and_dot_insensitive() {
        let validator = ChainValidator::new(Arc::new(TrustAnchor::empty()));
        validator.store(
            &SmolStr::new(normalize_owner("Example.COM.")),
            ChainOutcome::Secure,
            vec![make_ed25519_key(0x11)],
        );
        assert!(validator.validated_keys("example.com").is_some());
        assert!(validator.validated_keys("EXAMPLE.com.").is_some());
    }

    #[test]
    fn cache_is_bounded() {
        let validator = ChainValidator::new(Arc::new(TrustAnchor::empty())).with_capacity(4);
        for i in 0..100u16 {
            let name = format!("z{i}.example.com");
            validator.store(
                &SmolStr::new(normalize_owner(&name)),
                ChainOutcome::Secure,
                vec![make_ed25519_key(0)],
            );
        }
        assert!(validator.cache_len() <= 4);
    }

    #[test]
    fn ds_digest_sha256_roundtrip() {
        let key = make_ed25519_key(0x11);
        let digest = compute_ds_digest_named("example.com", &key, 2).unwrap();
        assert_eq!(digest.len(), 32);
    }

    #[test]
    fn unsupported_ds_makes_zone_insecure() {
        // A DS with an unsupported digest type should yield Insecure,
        // not Bogus.
        let key = make_ed25519_key(0x22);
        let dnskey = DnsRecord {
            name: SmolStr::new("example.com"),
            name_raw: "example.com".into(),
            rtype: crate::wire::TYPE_DNSKEY,
            rclass: crate::wire::CLASS_IN,
            ttl: 300,
            data: RecordData::Dnskey(key.clone()),
        };
        let ds = DnsRecord {
            name: SmolStr::new("example.com"),
            name_raw: "example.com".into(),
            rtype: crate::wire::TYPE_DS,
            rclass: crate::wire::CLASS_IN,
            ttl: 300,
            data: RecordData::Ds(DsRdata {
                key_tag: key.key_tag(),
                algorithm: key.algorithm,
                digest_type: 99, // unsupported
                digest: vec![0; 32],
            }),
        };
        let validator = ChainValidator::new(Arc::new(TrustAnchor::empty()));
        let outcome = validator.validate_zone(
            "example.com",
            &[dnskey],
            &[],
            &ParentMaterial::Ds(vec![ds]),
        );
        assert_eq!(outcome, ChainOutcome::Insecure);
    }
}