//! DNSSEC validation.
//!
//! # Scope
//!
//! This module verifies that an `RRset` is signed by a key that chains
//! to a configured trust anchor. It implements:
//!
//! * **Signature verification** ([`verify`]) — the cryptographic
//!   primitive, plus canonical form reconstruction per RFC 4034 §6.
//! * **Chain validation** ([`chain`]) — walking from an anchor down
//!   through DS records to the DNSKEY that signed the answer, with a
//!   memoizing cache.
//! * **Anchor management** ([`anchor`]) — loading trust anchors from
//!   base64 or from a zone file.
//!
//! It does **not** implement:
//!
//! * **Aggressive NSEC caching.** The intervals are parsed (see
//!   `cache::nsec`); using them to synthesize NXDOMAIN requires the
//!   validator to expose its chain result, which we do — but caching is
//!   the resolver's job.
//! * **Key rollover (RFC 5011).** Anchors are loaded once and not
//!   refreshed. This is a deployment concern, handled outside the crate.
//!
//! # The three outcomes
//!
//! Every validation returns one of three classifications, and the
//! distinctions matter:
//!
//! * **Secure** — a signature over the `RRset` verifies against a key
//!   that chains to a trust anchor.
//! * **Insecure** — no chain exists. Either the zone is unsigned, or
//!   the only signatures use algorithms we cannot verify. `Insecure`
//!   is a legitimate state: most of the DNS is unsigned.
//! * **Bogus** — a signature exists, the algorithm is supported, and
//!   verification fails. The data has been tampered with, or the
//!   signature is expired. This is a protocol violation.

mod algorithm;
mod anchor;
mod chain;
mod verify;

pub use anchor::{AnchorError, TrustAnchor};
pub use chain::{ChainOutcome, ChainValidator, ParentMaterial};
pub use verify::{validate_rrset, validate_rrset_signed_by, ValidatorError};

use std::sync::Arc;

use smol_str::SmolStr;

use crate::wire::record::{DnsRecord, DnskeyRdata, RecordData};

// ─────────────────────────────────────────────────────────────────────────────
// Validation outcome
// ─────────────────────────────────────────────────────────────────────────────

/// The result of validating an `RRset`.
///
/// `Insecure` is not a failure: most of the DNS is unsigned, and an
/// unsigned answer is exactly what a validating resolver should
/// return for such a zone.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ValidationOutcome {
    /// A signature verifies against a supported algorithm.
    Secure {
        /// Key tag of the signing DNSKEY.
        key_tag: u16,
        /// Signing algorithm used to produce the validated signature.
        algorithm: crate::wire::record::DnssecAlgorithm,
    },
    /// No chain of trust is available. The data is treated as ordinary
    /// unsigned DNS.
    Insecure,
    /// A signature exists but does not verify, or is expired.
    Bogus,
}

impl ValidationOutcome {
    /// Returns true if the validation outcome is secure.
    #[inline]
    #[must_use]
    pub const fn is_secure(self) -> bool {
        matches!(self, Self::Secure { .. })
    }

    /// Returns true if the validation outcome is bogus.
    #[inline]
    #[must_use]
    pub const fn is_bogus(self) -> bool {
        matches!(self, Self::Bogus)
    }

    /// Returns true if the validation outcome is insecure.
    #[inline]
    #[must_use]
    pub const fn is_insecure(self) -> bool {
        matches!(self, Self::Insecure)
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Validator
// ─────────────────────────────────────────────────────────────────────────────

/// The validator.
///
/// Cheap to share; wrap in `Arc` and clone the `Arc`.
///
/// The cryptographic primitive lives in [`verify::verify_rrset`]; the
/// methods here add the validity-window policy (clock skew) that the
/// free functions in [`verify`] fix at five minutes.
pub struct DnssecValidator {
    anchor: Arc<TrustAnchor>,
    /// Clock-skew tolerance. RFC 4035 §5.3.3 permits a verifier to
    /// accept signatures slightly outside their validity window; five
    /// minutes is the community default.
    clock_skew: u32,
}

impl DnssecValidator {
    /// Build a validator with the given trust anchor.
    #[must_use]
    pub const fn new(anchor: Arc<TrustAnchor>) -> Self {
        Self {
            anchor,
            clock_skew: 300,
        }
    }

    /// Override the default clock-skew tolerance.
    #[must_use]
    pub const fn with_clock_skew(mut self, seconds: u32) -> Self {
        self.clock_skew = seconds;
        self
    }

    /// Borrow the trust anchor. Useful for tests that want to inspect
    /// which keys the validator is configured to trust.
    #[must_use]
    pub fn anchor(&self) -> &TrustAnchor {
        &self.anchor
    }

    /// The effective clock-skew tolerance.
    #[must_use]
    pub const fn clock_skew(&self) -> u32 {
        self.clock_skew
    }

    /// Verify an `RRset` against the DNSKEYs supplied by the caller.
    ///
    /// The caller is responsible for ensuring the DNSKEYs themselves
    /// are trusted. This is the "leaf" half of validation; the chain
    /// walk lives in [`ChainValidator`].
    ///
    /// Applies this validator's clock-skew tolerance to the signature
    /// validity window.
    #[must_use]
    pub fn validate_rrset(
        &self,
        rrset: &[DnsRecord],
        rrsigs: &[DnsRecord],
        dnskeys: &[DnskeyRdata],
    ) -> ValidationOutcome {
        validate_rrset_with_skew(rrset, rrsigs, dnskeys, self.clock_skew)
    }

    /// Verify an `RRset` that is a DNSKEY `RRset` — the "zone" half
    /// of validation.
    ///
    /// `keys` are the DNSKEYs the zone advertises; `rrsigs` are the
    /// signatures on those keys; `trusted_key` is the key we already
    /// trust (from the anchor or a parent's DS).
    #[must_use]
    pub fn validate_dnskey_rrset(
        &self,
        keys: &[DnsRecord],
        rrsigs: &[DnsRecord],
        trusted_key: &DnskeyRdata,
    ) -> ValidationOutcome {
        let now = current_time_u32();

        for rrsig in rrsigs {
            let RecordData::Rrsig(sig) = &rrsig.data else {
                continue;
            };
            if sig.type_covered != crate::wire::TYPE_DNSKEY {
                continue;
            }
            if sig.key_tag != trusted_key.key_tag() || sig.algorithm != trusted_key.algorithm {
                continue;
            }
            if !sig.algorithm.is_supported() || !self.within_validity(sig, now) {
                continue;
            }
            if verify::verify_rrset(sig, keys, trusted_key).is_ok() {
                return ValidationOutcome::Secure {
                    key_tag: sig.key_tag,
                    algorithm: sig.algorithm,
                };
            }
        }

        ValidationOutcome::Bogus
    }

    /// Whether the signature's validity window (with skew) contains
    /// `now`.
    const fn within_validity(&self, sig: &RrsigRdata, now: u32) -> bool {
        let skew = self.clock_skew;
        // RFC 4034 §3.1.5 & RFC 1982: 32-bit serial number arithmetic.
        let lower = sig.signature_inception.wrapping_sub(skew);
        let upper = sig.signature_expiration.wrapping_add(skew);
        let valid_start = (now.wrapping_sub(lower) as i32) >= 0;
        let not_expired = (upper.wrapping_sub(now) as i32) >= 0;
        valid_start && not_expired
    }
}

/// `verify::validate_rrset` with a caller-supplied clock skew.
///
/// Factored out so the [`DnssecValidator`] method and the free
/// function in [`verify`] share one implementation.
fn validate_rrset_with_skew(
    rrset: &[DnsRecord],
    rrsigs: &[DnsRecord],
    dnskeys: &[DnskeyRdata],
    skew: u32,
) -> ValidationOutcome {
    let Some(covered) = rrset.first().map(|r| r.rtype) else {
        return ValidationOutcome::Insecure;
    };

    let sigs: Vec<&RrsigRdata> = rrsigs
        .iter()
        .filter_map(|r| match &r.data {
            RecordData::Rrsig(s) if s.type_covered == covered => Some(s),
            _ => None,
        })
        .collect();
    if sigs.is_empty() {
        return ValidationOutcome::Insecure;
    }

    let now = current_time_u32();
    let mut any_supported = false;

    for sig in &sigs {
        if !sig.algorithm.is_supported() {
            continue;
        }
        any_supported = true;
        if !within_validity_with_skew(sig, now, skew) {
            continue;
        }
        let Some(key) = dnskeys
            .iter()
            .find(|k| k.key_tag() == sig.key_tag && k.algorithm == sig.algorithm)
        else {
            continue;
        };
        if verify::verify_rrset(sig, rrset, key).is_ok() {
            return ValidationOutcome::Secure {
                key_tag: sig.key_tag,
                algorithm: sig.algorithm,
            };
        }
    }

    if any_supported {
        ValidationOutcome::Bogus
    } else {
        ValidationOutcome::Insecure
    }
}

/// Whether the signature's validity window (with the given skew)
/// contains `now`.
const fn within_validity_with_skew(sig: &RrsigRdata, now: u32, skew: u32) -> bool {
    let lower = sig.signature_inception.wrapping_sub(skew);
    let upper = sig.signature_expiration.wrapping_add(skew);
    let valid_start = (now.wrapping_sub(lower) as i32) >= 0;
    let not_expired = (upper.wrapping_sub(now) as i32) >= 0;
    valid_start && not_expired
}

/// Unix seconds, saturating at `u32::MAX`.
#[inline]
fn current_time_u32() -> u32 {
    use std::time::{SystemTime, UNIX_EPOCH};
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map_or(0, |d| d.as_secs().try_into().unwrap_or(u32::MAX))
}

/// The signing zone name of an RRSIG `RRset`, if any.
///
/// Returns the signer name from the first RRSIG in the slice; a set
/// with mixed signer names is itself a protocol error that callers
/// detect separately.
#[must_use]
pub fn signer_name(rrsigs: &[DnsRecord]) -> Option<SmolStr> {
    rrsigs.iter().find_map(|r| match &r.data {
        RecordData::Rrsig(sig) => Some(sig.signer_name.clone()),
        _ => None,
    })
}

// Re-exported for tests and external callers that want the raw
// RRSIG validity check without building a validator.
pub use verify::within_validity as within_validity_default_skew;

// ─────────────────────────────────────────────────────────────────────────────
// Tests
// ─────────────────────────────────────────────────────────────────────────────

#[cfg(test)]
mod tests {
    use super::*;
    use crate::wire::record::{DnssecAlgorithm, RrsigRdata};
    use std::time::{SystemTime, UNIX_EPOCH};

    fn a_record(name: &str) -> DnsRecord {
        DnsRecord {
            name: SmolStr::new(name),
            name_raw: name.into(),
            rtype: crate::wire::TYPE_A,
            rclass: crate::wire::CLASS_IN,
            ttl: 300,
            data: RecordData::A("192.0.2.1".parse().unwrap()),
        }
    }

    fn future_rrsig() -> DnsRecord {
        let now = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap()
            .as_secs() as u32;
        DnsRecord {
            name: SmolStr::new("example.com"),
            name_raw: "example.com".into(),
            rtype: crate::wire::TYPE_RRSIG,
            rclass: crate::wire::CLASS_IN,
            ttl: 300,
            data: RecordData::Rrsig(RrsigRdata {
                type_covered: crate::wire::TYPE_A,
                algorithm: DnssecAlgorithm::Ed25519,
                labels: 2,
                original_ttl: 300,
                signature_expiration: now + 3600,
                signature_inception: now - 3600,
                key_tag: 0,
                signer_name: SmolStr::new("example.com"),
                signature: vec![0u8; 64],
            }),
        }
    }

    #[test]
    fn unsigned_rrset_is_insecure() {
        let validator = DnssecValidator::new(Arc::new(TrustAnchor::empty()));
        let outcome = validator.validate_rrset(&[a_record("x.com")], &[], &[]);
        assert_eq!(outcome, ValidationOutcome::Insecure);
    }

    #[test]
    fn unsupported_algorithm_is_insecure() {
        let validator = DnssecValidator::new(Arc::new(TrustAnchor::empty()));
        let mut sig = future_rrsig();
        if let RecordData::Rrsig(r) = &mut sig.data {
            r.algorithm = DnssecAlgorithm::RsaSha1;
        }
        let keys = vec![DnskeyRdata {
            flags: 256,
            protocol: 3,
            algorithm: DnssecAlgorithm::RsaSha1,
            public_key: vec![0u8; 64],
        }];
        let outcome = validator.validate_rrset(&[a_record("x.com")], &[sig], &keys);
        assert_eq!(outcome, ValidationOutcome::Insecure);
    }

    #[test]
    fn expired_signature_is_bogus() {
        let validator = DnssecValidator::new(Arc::new(TrustAnchor::empty()));
        let mut sig = future_rrsig();
        if let RecordData::Rrsig(r) = &mut sig.data {
            r.signature_expiration = 100;
            r.signature_inception = 50;
        }
        let keys = vec![DnskeyRdata {
            flags: 256,
            protocol: 3,
            algorithm: DnssecAlgorithm::Ed25519,
            public_key: vec![0u8; 32],
        }];
        let outcome = validator.validate_rrset(&[a_record("x.com")], &[sig], &keys);
        assert_eq!(outcome, ValidationOutcome::Bogus);
    }

    #[test]
    fn custom_clock_skew_is_respected() {
        let validator =
            DnssecValidator::new(Arc::new(TrustAnchor::empty())).with_clock_skew(0);
        assert_eq!(validator.clock_skew(), 0);
    }
}