//! Trust anchors.
//!
//! A trust anchor is the set of keys the validator trusts without
//! further proof. In practice this is one or two root KSKs; the code
//! here supports the general case because operators may run a private
//! DNSSEC tree with its own anchor.
//!
//! # Loading formats
//!
//! Two formats are supported:
//!
//! * **Base64-encoded DNSKEY RDATA.** This is what `unbound`'s
//!   `root.key` file contains on a single line, and what most
//!   automation tools emit. See [`TrustAnchor::from_base64`].
//! * **A zone file with DNSKEY records.** The parser is minimal — one
//!   logical record per entry, `;` starts a comment, and parentheses
//!   continue a record across lines. This is sufficient for the files
//!   BIND and IANA publish. See [`TrustAnchor::from_file`].
//!
//! # Matching
//!
//! Anchors match by `(owner, algorithm, key tag)`. The tag is a
//! checksum of the DNSKEY's wire format; two keys with the same tag
//! and different material is a deliberate collision (the attacker
//! would need to grind ~2^16 candidates), and the code compares the
//! public key material as a second factor.
//!
//! # Name normalization
//!
//! Owner names are stored lowercased and **without** a trailing dot.
//! Callers may supply names in either form; `matches` normalizes the
//! query side to the stored form.

use std::collections::HashSet;
use std::path::Path;

use base64::Engine;
use smol_str::SmolStr;

use crate::wire::record::{DnskeyRdata, DnssecAlgorithm};

/// Errors from anchor loading.
#[derive(Debug, thiserror::Error)]
pub enum AnchorError {
    /// The underlying I/O operation failed.
    #[error("I/O error: {0}")]
    Io(#[from] std::io::Error),
    /// A line was not valid base64.
    #[error("invalid base64 on line {line}: {message}")]
    Base64 {
        /// One-based line number in the source.
        line: usize,
        /// The decoder's message.
        message: String,
    },
    /// A decoded record is shorter than the fixed DNSKEY header.
    #[error("DNSKEY RDATA too short on line {line}")]
    TooShort {
        /// One-based line number in the source.
        line: usize,
    },
    /// No parseable DNSKEY record was found.
    #[error("no anchors found in {source}")]
    Empty {
        /// Where the parser looked.
        source: String,
    },
}

/// One trusted key.
#[derive(Debug, Clone, PartialEq, Eq, Hash)]
struct AnchorKey {
    owner: SmolStr,
    algorithm: u8,
    key_tag: u16,
    public_key: Vec<u8>,
}

/// The trust anchor set.
#[derive(Debug)]
pub struct TrustAnchor {
    keys: HashSet<AnchorKey>,
}

impl TrustAnchor {
    /// An empty anchor. Every lookup returns `false`.
    ///
    /// Used in tests and in code paths that have no DNSSEC configured.
    #[must_use]
    pub fn empty() -> Self {
        Self {
            keys: HashSet::new(),
        }
    }

    /// Parse anchors from base64-encoded DNSKEY RDATA.
    ///
    /// `owner` is the owner name the anchors share; for the root this
    /// is `"."`. This is the format `unbound`'s `root.key` uses and the
    /// one most automation tools emit.
    ///
    /// # Errors
    ///
    /// Returns [`AnchorError::Empty`] when the input list is empty,
    /// [`AnchorError::Base64`] when a line is not valid base64, and
    /// [`AnchorError::TooShort`] when a decoded record is shorter than
    /// the fixed DNSKEY header plus at least one key byte.
    pub fn from_base64(owner: &str, encoded: &[String]) -> Result<Self, AnchorError> {
        if encoded.is_empty() {
            return Err(AnchorError::Empty {
                source: "from_base64 (empty list)".into(),
            });
        }
        let decoder = base64::engine::general_purpose::STANDARD;
        let owner = SmolStr::new(normalize_owner(owner));
        let mut keys = HashSet::with_capacity(encoded.len());

        for (idx, entry) in encoded.iter().enumerate() {
            let line = idx + 1;
            let raw_rdata = decoder.decode(entry.trim()).map_err(|e| AnchorError::Base64 {
                line,
                message: e.to_string(),
            })?;
            // The DNSKEY header is four bytes; a key with no public
            // material at all is rejected rather than silently stored
            // as an anchor that cannot match anything.
            if raw_rdata.len() <= 4 {
                return Err(AnchorError::TooShort { line });
            }
            keys.insert(anchor_key_from_rdata(&owner, &raw_rdata));
        }
        Ok(Self { keys })
    }

    /// Load anchors from a zone file with DNSKEY records.
    ///
    /// The parser is minimal: one logical record per entry, `;` starts
    /// a comment, and parentheses continue a record across lines. This
    /// is enough for the files IANA and BIND publish.
    ///
    /// # Errors
    ///
    /// Returns [`AnchorError::Io`] if the file cannot be read and
    /// [`AnchorError::Empty`] if no parseable DNSKEY line is found.
    pub fn from_file(path: &Path) -> Result<Self, AnchorError> {
        let content = std::fs::read_to_string(path)?;
        let mut keys = HashSet::new();

        for (line_no, line) in logical_lines(&content).into_iter().enumerate() {
            let tokens: Vec<&str> = line.split_whitespace().collect();
            let Some(keyword_pos) = tokens
                .iter()
                .position(|t| t.eq_ignore_ascii_case("DNSKEY"))
            else {
                continue;
            };
            // A bare `DNSKEY` at the start means the owner name is
            // missing; a malformed file. Skip it rather than guess.
            if keyword_pos == 0 {
                continue;
            }
            let after = &tokens[keyword_pos + 1..];
            if after.len() < 4 {
                continue;
            }

            let Ok(flags) = after[0].parse::<u16>() else {
                continue;
            };
            let Ok(protocol) = after[1].parse::<u8>() else {
                continue;
            };
            // RFC 4034 §2.1.2 pins the protocol field at 3.
            if protocol != 3 {
                continue;
            }
            let Ok(algorithm) = after[2].parse::<u8>() else {
                continue;
            };
            let b64: String = after[3..].join("");

            let decoder = base64::engine::general_purpose::STANDARD;
            let Ok(public_key) = decoder.decode(b64.trim()) else {
                continue;
            };
            if public_key.is_empty() {
                continue;
            }

            let algorithm = DnssecAlgorithm::from_u8(algorithm);
            let key_tag = compute_key_tag(flags, protocol, algorithm, &public_key);

            let owner = SmolStr::new(normalize_owner(tokens[0]));
            keys.insert(AnchorKey {
                owner,
                algorithm: algorithm.as_u8(),
                key_tag,
                public_key,
            });
            let _ = line_no; // retained for future diagnostics
        }

        if keys.is_empty() {
            return Err(AnchorError::Empty {
                source: path.display().to_string(),
            });
        }
        Ok(Self { keys })
    }

    /// Whether `key` is trusted under `owner`.
    ///
    /// Matching is by `(owner, algorithm, key tag, public key)`. The
    /// owner comparison is case-insensitive and trailing-dot-insensitive;
    /// the key tag narrows the search, and the public-key comparison
    /// guards against a deliberate tag collision.
    #[must_use]
    pub fn matches(&self, key: &DnskeyRdata, owner: &str) -> bool {
        let owner = normalize_owner(owner);
        let algorithm = key.algorithm.as_u8();
        let tag = key.key_tag();

        self.keys.iter().any(|anchor| {
            anchor.owner == owner
                && anchor.algorithm == algorithm
                && anchor.key_tag == tag
                && anchor.public_key == key.public_key
        })
    }

    /// Number of keys in the set.
    #[must_use]
    pub fn len(&self) -> usize {
        self.keys.len()
    }

    /// Whether no keys are trusted.
    #[must_use]
    pub fn is_empty(&self) -> bool {
        self.keys.is_empty()
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Helpers
// ─────────────────────────────────────────────────────────────────────────────

/// Lowercase and strip the trailing dot from a domain name.
///
/// The rest of the codebase treats `"example.com"` and `"example.com."`
/// as the same name; this helper makes that concrete.
#[inline]
pub(crate) fn normalize_owner(s: &str) -> String {
    s.trim_end_matches('.').to_ascii_lowercase()
}

/// Fold a zone file into one logical record per string.
///
/// Strips `;`-style comments, joins lines continued inside parentheses,
/// and collapses runs of whitespace so the caller can `split_whitespace`
/// directly. Blank entries are omitted.
fn logical_lines(content: &str) -> Vec<String> {
    let mut out = Vec::new();
    let mut buf = String::new();
    let mut paren_depth: i32 = 0;

    for raw in content.lines() {
        let line = raw.split(';').next().unwrap_or("");
        for ch in line.chars() {
            match ch {
                '(' => paren_depth += 1,
                ')' => paren_depth = (paren_depth - 1).max(0),
                c if c.is_whitespace() => buf.push(' '),
                c => buf.push(c),
            }
        }
        if paren_depth == 0 {
            let trimmed = buf.trim();
            if !trimmed.is_empty() {
                out.push(trimmed.to_owned());
            }
            buf.clear();
        } else {
            buf.push(' ');
        }
    }
    // Unterminated parenthesis: keep whatever was accumulated rather
    // than silently dropping it.
    let trimmed = buf.trim();
    if !trimmed.is_empty() {
        out.push(trimmed.to_owned());
    }
    out
}

/// Compute a DNSKEY key tag (RFC 4034 Appendix B).
///
/// Kept as a free function so callers that already have the four fields
/// in hand do not need to build a [`DnskeyRdata`] just to read its tag.
#[must_use]
pub(crate) fn compute_key_tag(
    flags: u16,
    protocol: u8,
    algorithm: DnssecAlgorithm,
    public_key: &[u8],
) -> u16 {
    // RFC 4034 Appendix B: sum the RDATA as 16-bit big-endian words,
    // add the carry, then fold into 16 bits.
    let mut rdata = Vec::with_capacity(4 + public_key.len());
    rdata.extend_from_slice(&flags.to_be_bytes());
    rdata.push(protocol);
    rdata.push(algorithm.as_u8());
    rdata.extend_from_slice(public_key);

    let mut acc: u32 = 0;
    for (i, byte) in rdata.iter().enumerate() {
        if i & 1 == 0 {
            acc += u32::from(*byte) << 8;
        } else {
            acc += u32::from(*byte);
        }
    }
    acc += (acc >> 16) & 0xFFFF;
    (acc & 0xFFFF) as u16
}

fn anchor_key_from_rdata(owner: &SmolStr, rdata: &[u8]) -> AnchorKey {
    debug_assert!(rdata.len() > 4, "caller must reject short RDATA");
    let flags = u16::from_be_bytes([rdata[0], rdata[1]]);
    let protocol = rdata[2];
    let algorithm = rdata[3];
    let public_key = &rdata[4..];

    AnchorKey {
        owner: owner.clone(),
        algorithm,
        key_tag: compute_key_tag(
            flags,
            protocol,
            DnssecAlgorithm::from_u8(algorithm),
            public_key,
        ),
        public_key: public_key.to_vec(),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn empty_anchor_matches_nothing() {
        let anchor = TrustAnchor::empty();
        let key = DnskeyRdata {
            flags: 257,
            protocol: 3,
            algorithm: DnssecAlgorithm::Ed25519,
            public_key: vec![0u8; 32],
        };
        assert!(!anchor.matches(&key, "."));
    }

    #[test]
    fn base64_roundtrip() {
        let mut rdata = Vec::new();
        rdata.extend_from_slice(&257u16.to_be_bytes());
        rdata.push(3);
        rdata.push(15);
        rdata.extend_from_slice(&[0xAA; 32]);
        let encoded = base64::engine::general_purpose::STANDARD.encode(&rdata);

        let anchor = TrustAnchor::from_base64(".", &[encoded]).unwrap();
        assert_eq!(anchor.len(), 1);

        let key = DnskeyRdata {
            flags: 257,
            protocol: 3,
            algorithm: DnssecAlgorithm::Ed25519,
            public_key: vec![0xAA; 32],
        };
        assert!(anchor.matches(&key, "."));
    }

    #[test]
    fn owner_must_match() {
        let mut rdata = Vec::new();
        rdata.extend_from_slice(&257u16.to_be_bytes());
        rdata.push(3);
        rdata.push(15);
        rdata.extend_from_slice(&[0xBB; 32]);
        let encoded = base64::engine::general_purpose::STANDARD.encode(&rdata);

        let anchor = TrustAnchor::from_base64("example.com", &[encoded]).unwrap();
        let key = DnskeyRdata {
            flags: 257,
            protocol: 3,
            algorithm: DnssecAlgorithm::Ed25519,
            public_key: vec![0xBB; 32],
        };
        assert!(anchor.matches(&key, "example.com"));
        // Trailing dot and case must be normalized away.
        assert!(anchor.matches(&key, "Example.COM."));
        assert!(!anchor.matches(&key, "other.com"));
    }

    #[test]
    fn empty_input_rejected() {
        assert!(matches!(
            TrustAnchor::from_base64(".", &[]),
            Err(AnchorError::Empty { .. })
        ));
    }

    #[test]
    fn too_short_rdata_rejected() {
        let encoded = base64::engine::general_purpose::STANDARD.encode(&[1, 2]);
        assert!(matches!(
            TrustAnchor::from_base64(".", &[encoded]),
            Err(AnchorError::TooShort { line: 1 })
        ));
        // Exactly four bytes: header only, no key material.
        let encoded = base64::engine::general_purpose::STANDARD.encode(&[0, 1, 3, 15]);
        assert!(matches!(
            TrustAnchor::from_base64(".", &[encoded]),
            Err(AnchorError::TooShort { line: 1 })
        ));
    }

    #[test]
    fn zone_file_multiline_dnskey_is_parsed() {
        // The canonical IANA `root.key` formatting: the record spans
        // three lines, joined by an opening and a closing parenthesis.
        let content = "\
            . IN DNSKEY 257 3 15 ( AAAA\n\
            BBBB\n\
            CCCC ) ; comment\n\
        ";
        // Build a well-formed base64 payload first so the parser sees
        // a real key, then reflow it across lines.
        let mut rdata = Vec::new();
        rdata.extend_from_slice(&257u16.to_be_bytes());
        rdata.push(3);
        rdata.push(15);
        rdata.extend_from_slice(&[0xCC; 32]);
        let b64 = base64::engine::general_purpose::STANDARD.encode(&rdata);
        // Split b64 into three chunks to force the multi-line path.
        let mid = b64.len() / 3;
        let tail = 2 * b64.len() / 3;
        let content = format!(
            ". IN DNSKEY 257 3 15 ( {} \n {} \n {} ) ; root KSK\n",
            &b64[..mid],
            &b64[mid..tail],
            &b64[tail..],
        );

        let tmp = std::env::temp_dir().join("caly-anchor-test.key");
        std::fs::write(&tmp, content.as_bytes()).unwrap();
        let anchor = TrustAnchor::from_file(&tmp).unwrap();
        std::fs::remove_file(&tmp).ok();

        assert_eq!(anchor.len(), 1);
        let key = DnskeyRdata {
            flags: 257,
            protocol: 3,
            algorithm: DnssecAlgorithm::Ed25519,
            public_key: vec![0xCC; 32],
        };
        assert!(anchor.matches(&key, "."));
    }
}