//! Algorithm support classification.
//!
//! This file exists to keep the mapping from [`DnssecAlgorithm`] to
//! `ring`'s signature verifiers in one place. When a new algorithm
//! becomes supported, exactly two functions change:
//!
//! * [`verifier_for`] — returns the `ring` verification algorithm.
//! * [`DnssecAlgorithm::is_supported`] in `wire/record.rs`.
//!
//! Everything else — the validator, the chain walker, the resolver —
//! reads through those two entry points and does not need to know what
//! is or is not supported.

use crate::wire::record::DnssecAlgorithm;

/// Return the `ring` verifier for an algorithm, or `None` if
/// unsupported.
///
/// This is the single source of truth for which algorithms the crate
/// can actually verify.
#[must_use]
#[allow(dead_code)]
pub fn verifier_for(
    algorithm: DnssecAlgorithm,
) -> Option<&'static dyn ring::signature::VerificationAlgorithm> {
    use ring::signature;
    match algorithm {
        DnssecAlgorithm::Ed25519 => Some(&signature::ED25519),
        DnssecAlgorithm::EcdsaP256Sha256 => Some(&signature::ECDSA_P256_SHA256_FIXED),
        DnssecAlgorithm::EcdsaP384Sha384 => Some(&signature::ECDSA_P384_SHA384_FIXED),
        DnssecAlgorithm::RsaSha256 => Some(&signature::RSA_PKCS1_2048_8192_SHA256),
        DnssecAlgorithm::RsaSha512 => Some(&signature::RSA_PKCS1_2048_8192_SHA512),
        _ => None,
    }
}

/// Whether an algorithm has a signature verifier in this build.
///
/// Thin wrapper over [`verifier_for`] so callers that only need a
/// boolean do not have to name `ring`'s trait.
#[must_use]
#[inline]
pub fn is_supported(algorithm: DnssecAlgorithm) -> bool {
    verifier_for(algorithm).is_some()
}

/// The number of bytes a public key should have for the given
/// algorithm.
///
/// For fixed-length algorithms this is the **exact** length. For RSA,
/// whose keys are variable-length, this returns the minimum length of
/// the compact DNSKEY encoding (RFC 3110): one byte for the exponent
/// length. Callers that need a validity check should use
/// [`key_len_matches`].
#[must_use]
#[allow(dead_code)]
pub const fn expected_public_key_len(algorithm: DnssecAlgorithm) -> Option<usize> {
    match algorithm {
        DnssecAlgorithm::Ed25519 => Some(32),
        // ECDSA keys are stored as raw x || y without the 0x04 prefix.
        DnssecAlgorithm::EcdsaP256Sha256 => Some(64),
        DnssecAlgorithm::EcdsaP384Sha384 => Some(96),
        // RSA keys are variable-length: at minimum a one-byte exponent
        // length plus one exponent byte plus one modulus byte.
        DnssecAlgorithm::RsaSha256 | DnssecAlgorithm::RsaSha512 => Some(3),
        _ => None,
    }
}

/// Whether `key_len` is plausible for `algorithm`.
///
/// Fixed-length algorithms require an exact match; RSA accepts any
/// length at or above the compact-header minimum.
#[must_use]
pub const fn key_len_matches(algorithm: DnssecAlgorithm, key_len: usize) -> bool {
    match algorithm {
        DnssecAlgorithm::Ed25519
        | DnssecAlgorithm::EcdsaP256Sha256
        | DnssecAlgorithm::EcdsaP384Sha384 => {
            matches!(expected_public_key_len(algorithm), Some(n) if n == key_len)
        }
        DnssecAlgorithm::RsaSha256 | DnssecAlgorithm::RsaSha512 => key_len >= 3,
        _ => false,
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn supported_algorithms_have_verifiers() {
        for algorithm in [
            DnssecAlgorithm::Ed25519,
            DnssecAlgorithm::EcdsaP256Sha256,
            DnssecAlgorithm::RsaSha256,
            DnssecAlgorithm::RsaSha512,
        ] {
            assert!(
                verifier_for(algorithm).is_some(),
                "no verifier for {algorithm:?}"
            );
            assert!(is_supported(algorithm));
        }
    }

    #[test]
    fn unsupported_algorithms_have_no_verifier() {
        for algorithm in [
            DnssecAlgorithm::RsaMd5,
            DnssecAlgorithm::RsaSha1,
            DnssecAlgorithm::Ed448,
        ] {
            assert!(verifier_for(algorithm).is_none());
            assert!(!is_supported(algorithm));
        }
    }

    #[test]
    fn key_lengths_are_sensible() {
        assert_eq!(expected_public_key_len(DnssecAlgorithm::Ed25519), Some(32));
        assert_eq!(
            expected_public_key_len(DnssecAlgorithm::EcdsaP256Sha256),
            Some(64)
        );
        assert!(key_len_matches(DnssecAlgorithm::Ed25519, 32));
        assert!(!key_len_matches(DnssecAlgorithm::Ed25519, 31));
        assert!(key_len_matches(DnssecAlgorithm::RsaSha256, 256));
    }
}