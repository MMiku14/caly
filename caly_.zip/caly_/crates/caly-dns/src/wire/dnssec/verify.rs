//! The signature verification primitive.
//!
//! # Canonical form (RFC 4034 §6)
//!
//! To verify an RRSIG, the signed data is reconstructed exactly as the
//! signer produced it:
//!
//! ```text
//!   RRSIG_RDATA_without_signature  ||  sorted canonical RRs
//! ```
//!
//! Each RR is rendered in canonical form:
//!
//! 1. Owner name lowercase, uncompressed wire format.
//! 2. Wildcard expansion per §6.2: if the RRSIG's `labels` field is
//!    smaller than the name's label count, the leftmost labels are
//!    replaced with `*`.
//! 3. TTL replaced by the RRSIG's `original_ttl`.
//! 4. RDATA in canonical form: names lowercased, no compression.
//! 5. Records sorted bytewise by RDATA.
//!
//! The result is deterministic and matches what every DNSSEC signer
//! produces.
//!
//! # Crypto
//!
//! `ring` does the actual verification. This module's job is to hand
//! `ring` the right bytes: DER-encode the RSA key, strip the ECDSA
//! prefix, prepare the message.

use crate::wire::name::encode_name;
use crate::wire::record::{
    DnsRecord, DnskeyRdata, DnssecAlgorithm, RecordData, RrsigRdata,
};
use crate::wire::dnssec::ValidationOutcome;

/// Errors from signature verification.
#[derive(Debug, thiserror::Error)]
pub enum ValidatorError {
    #[error("malformed signing input: {0}")]
    /// The signing input could not be assembled.
    Malformed(&'static str),
    #[error("signature verification failed")]
    /// The cryptographic verification rejected the signature.
    Signature,
    #[error("unsupported algorithm")]
    /// The signature uses an algorithm this build cannot verify.
    UnsupportedAlgorithm,
    /// Wire-format DNS encoding or decoding failure.
    #[error("wire encoding: {0}")]
    Wire(#[from] caly_common::dns::DnsError),
}

/// Verify one RRSIG against one DNSKEY over `rrset`.
///
/// `rrset` must contain only records of the type covered by `rrsig`.
pub fn verify_rrset(
    rrsig: &RrsigRdata,
    rrset: &[DnsRecord],
    dnskey: &DnskeyRdata,
) -> std::result::Result<(), ValidatorError> {
    if !rrset.iter().any(|r| r.rtype == rrsig.type_covered) {
        return Err(ValidatorError::Malformed("empty RRset for covered type"));
    }
    let message = build_signing_input(rrsig, rrset)?;
    verify_raw(
        rrsig.algorithm,
        &dnskey.public_key,
        &message,
        &rrsig.signature,
    )
}

// ─────────────────────────────────────────────────────────────────────────────
// Signing input
// ─────────────────────────────────────────────────────────────────────────────

/// Build the byte string the RRSIG was computed over.
///
/// The RRs are sorted bytewise by their canonical form, which makes
/// the result independent of the order the records appear on the wire.
fn build_signing_input(
    rrsig: &RrsigRdata,
    rrset: &[DnsRecord],
) -> std::result::Result<Vec<u8>, ValidatorError> {
    let mut out = Vec::with_capacity(256 + rrset.len() * 32);

    // RRSIG RDATA without the signature. Per RFC 4034 §6.2 every name
    // in the signing input is lowercased before encoding.
    out.extend_from_slice(&rrsig.type_covered.to_be_bytes());
    out.push(rrsig.algorithm.as_u8());
    out.push(rrsig.labels);
    out.extend_from_slice(&rrsig.original_ttl.to_be_bytes());
    out.extend_from_slice(&rrsig.signature_expiration.to_be_bytes());
    out.extend_from_slice(&rrsig.signature_inception.to_be_bytes());
    out.extend_from_slice(&rrsig.key_tag.to_be_bytes());
    encode_name(&rrsig.signer_name.to_ascii_lowercase(), &mut out)
        .map_err(ValidatorError::Wire)?;

    // Canonical RRs, sorted strictly by RDATA octets per RFC 4034 §6.3.
    let mut canonical: Vec<(Vec<u8>, Vec<u8>)> = Vec::with_capacity(rrset.len());
    for rr in rrset {
        // OPT pseudo-records are hop-by-hop and never participate in
        // DNSSEC signatures; including them would corrupt the input.
        if matches!(rr.data, RecordData::Opt(_)) {
            continue;
        }
        let rdata = canonical_rdata(rr)?;
        let owner = owner_for_signing(&rr.name, rrsig.labels);
        let mut full = Vec::with_capacity(64);
        encode_name(&owner.to_ascii_lowercase(), &mut full).map_err(ValidatorError::Wire)?;
        full.extend_from_slice(&rr.rtype.to_be_bytes());
        full.extend_from_slice(&rr.rclass.to_be_bytes());
        full.extend_from_slice(&rrsig.original_ttl.to_be_bytes());
        let len = u16::try_from(rdata.len())
            .map_err(|_| ValidatorError::Malformed("RDATA too large for RDLENGTH"))?;
        full.extend_from_slice(&len.to_be_bytes());
        full.extend_from_slice(&rdata);
        canonical.push((rdata, full));
    }
    canonical.sort_by(|a, b| a.0.cmp(&b.0));
    for (_, rr) in &canonical {
        out.extend_from_slice(rr);
    }

    Ok(out)
}

/// Apply wildcard expansion to the owner name (RFC 4034 §6.2).
///
/// If the RRSIG covers fewer labels than the owner name has, the
/// leftmost `(name_labels − sig_labels)` labels are replaced by `*`.
/// The result is borrowed when no wildcard expansion applies.
fn owner_for_signing(name: &str, rrsig_labels: u8) -> std::borrow::Cow<'_, str> {
    let labels: Vec<&str> = name.split('.').filter(|l| !l.is_empty()).collect();
    if labels.len() <= usize::from(rrsig_labels) {
        return std::borrow::Cow::Borrowed(name);
    }
    let keep_from = labels.len() - usize::from(rrsig_labels);
    let mut out = String::from("*");
    for label in labels.iter().skip(keep_from) {
        out.push('.');
        out.push_str(label);
    }
    std::borrow::Cow::Owned(out)
}

/// Canonicalize RDATA (RFC 4034 §6.2).
fn canonical_rdata(rr: &DnsRecord) -> std::result::Result<Vec<u8>, ValidatorError> {
    let mut out = Vec::with_capacity(32);
    match &rr.data {
        RecordData::A(v4) => out.extend_from_slice(&v4.octets()),
        RecordData::Aaaa(v6) => out.extend_from_slice(&v6.octets()),
        RecordData::Cname(name) | RecordData::Ptr(name) => {
            encode_name(&name.to_ascii_lowercase(), &mut out).map_err(ValidatorError::Wire)?;
        }
        RecordData::Txt(raw) => {
            // Wire format of TXT RDATA is already in canonical form per RFC 4034 §6.2.
            out.extend_from_slice(raw);
        }
        RecordData::Dnskey(key) => {
            out.extend_from_slice(&key.flags.to_be_bytes());
            out.push(key.protocol);
            out.push(key.algorithm.as_u8());
            out.extend_from_slice(&key.public_key);
        }
        RecordData::Ds(ds) => {
            out.extend_from_slice(&ds.key_tag.to_be_bytes());
            out.push(ds.algorithm.as_u8());
            out.push(ds.digest_type);
            out.extend_from_slice(&ds.digest);
        }
        RecordData::Nsec(nsec) => {
            encode_name(&nsec.next_domain_name.to_ascii_lowercase(), &mut out)
                .map_err(ValidatorError::Wire)?;
            encode_type_bitmap(&nsec.types, &mut out);
        }
        RecordData::Rrsig(r) => {
            out.extend_from_slice(&r.type_covered.to_be_bytes());
            out.push(r.algorithm.as_u8());
            out.push(r.labels);
            out.extend_from_slice(&r.original_ttl.to_be_bytes());
            out.extend_from_slice(&r.signature_expiration.to_be_bytes());
            out.extend_from_slice(&r.signature_inception.to_be_bytes());
            out.extend_from_slice(&r.key_tag.to_be_bytes());
            encode_name(&r.signer_name.to_ascii_lowercase(), &mut out)
                .map_err(ValidatorError::Wire)?;
            out.extend_from_slice(&r.signature);
        }
        RecordData::Unknown(bytes) => {
            // RFC 4034 §6.2: RDATA for a type the parser does not
            // interpret is signed verbatim as opaque bytes.
            out.extend_from_slice(bytes);
        }
        RecordData::Opt(_) => {
            // `build_signing_input` already filters these out; a
            // caller reaching this arm directly has a bug.
            debug_assert!(false, "OPT record reached canonical_rdata");
        }
    }
    Ok(out)
}

fn encode_type_bitmap(types: &[u16], out: &mut Vec<u8>) {
    use std::collections::BTreeMap;

    let mut windows: BTreeMap<u8, Vec<u8>> = BTreeMap::new();
    for &rtype in types {
        let window = (rtype >> 8) as u8;
        let offset = (rtype & 0xFF) as u8;
        let byte_index = offset / 8;
        let bit = offset % 8;
        let entry = windows.entry(window).or_default();
        if entry.len() <= byte_index as usize {
            entry.resize(byte_index as usize + 1, 0);
        }
        entry[byte_index as usize] |= 0x80 >> bit;
    }
    for (window, mut bitmap) in windows {
        while bitmap.last() == Some(&0) {
            bitmap.pop();
        }
        if bitmap.is_empty() {
            continue;
        }
        out.push(window);
        out.push(u8::try_from(bitmap.len()).unwrap_or(32));
        out.extend_from_slice(&bitmap);
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Crypto
// ─────────────────────────────────────────────────────────────────────────────

fn verify_raw(
    algorithm: DnssecAlgorithm,
    public_key: &[u8],
    message: &[u8],
    signature: &[u8],
) -> std::result::Result<(), ValidatorError> {
    use ring::signature;

    match algorithm {
        DnssecAlgorithm::Ed25519 => {
            if public_key.len() != 32 {
                return Err(ValidatorError::Malformed("Ed25519 key length"));
            }
            let key = signature::UnparsedPublicKey::new(&signature::ED25519, public_key);
            key.verify(message, signature)
                .map_err(|_| ValidatorError::Signature)
        }
        DnssecAlgorithm::EcdsaP256Sha256 => {
            if public_key.len() != 64 {
                return Err(ValidatorError::Malformed("P-256 key length"));
            }
            // RFC 5480 §2.2: prepend the 0x04 uncompressed-point tag
            // that DNSSEC omits from the DNSKEY RDATA.
            let mut formatted_key = Vec::with_capacity(65);
            formatted_key.push(0x04);
            formatted_key.extend_from_slice(public_key);
            let key = signature::UnparsedPublicKey::new(
                &signature::ECDSA_P256_SHA256_FIXED,
                &formatted_key,
            );
            key.verify(message, signature)
                .map_err(|_| ValidatorError::Signature)
        }
        DnssecAlgorithm::EcdsaP384Sha384 => {
            if public_key.len() != 96 {
                return Err(ValidatorError::Malformed("P-384 key length"));
            }
            let mut formatted_key = Vec::with_capacity(97);
            formatted_key.push(0x04);
            formatted_key.extend_from_slice(public_key);
            let key = signature::UnparsedPublicKey::new(
                &signature::ECDSA_P384_SHA384_FIXED,
                &formatted_key,
            );
            key.verify(message, signature)
                .map_err(|_| ValidatorError::Signature)
        }
        DnssecAlgorithm::RsaSha256 | DnssecAlgorithm::RsaSha512 => {
            let der = rsa_public_key_to_der(public_key)?;
            let alg: &dyn signature::VerificationAlgorithm = match algorithm {
                DnssecAlgorithm::RsaSha256 => &signature::RSA_PKCS1_2048_8192_SHA256,
                _ => &signature::RSA_PKCS1_2048_8192_SHA512,
            };
            let key = signature::UnparsedPublicKey::new(alg, &der);
            key.verify(message, signature)
                .map_err(|_| ValidatorError::Signature)
        }
        _ => Err(ValidatorError::UnsupportedAlgorithm),
    }
}

/// Convert a DNSSEC RSA public key into DER for `ring`.
///
/// DNSSEC stores RSA keys in a compact form: a length byte, the
/// exponent, then the modulus. RFC 3110 §2 allows the length byte to
/// be either a single byte or, when it is zero, a 16-bit big-endian
/// count. `ring` wants a DER-encoded `RSAPublicKey` wrapped in an
/// SPKI envelope.
fn rsa_public_key_to_der(key: &[u8]) -> std::result::Result<Vec<u8>, ValidatorError> {
    if key.is_empty() {
        return Err(ValidatorError::Malformed("empty RSA key"));
    }
    let (exp_len, header_len) = if key[0] == 0 {
        if key.len() < 3 {
            return Err(ValidatorError::Malformed("RSA 16-bit exponent header too short"));
        }
        (usize::from(u16::from_be_bytes([key[1], key[2]])), 3)
    } else {
        (usize::from(key[0]), 1)
    };
    if key.len() < header_len + exp_len {
        return Err(ValidatorError::Malformed("RSA exponent length overflow"));
    }
    let exponent = &key[header_len..header_len + exp_len];
    if exponent.is_empty() {
        return Err(ValidatorError::Malformed("RSA exponent empty"));
    }
    let modulus = &key[header_len + exp_len..];
    if modulus.is_empty() {
        return Err(ValidatorError::Malformed("RSA modulus empty"));
    }

    let modulus_der = der_integer(modulus);
    let exponent_der = der_integer(exponent);
    let body_len = modulus_der.len() + exponent_der.len();

    let mut pkcs1 = Vec::with_capacity(body_len + 8);
    pkcs1.push(0x30); // SEQUENCE
    der_length(&mut pkcs1, body_len);
    pkcs1.extend_from_slice(&modulus_der);
    pkcs1.extend_from_slice(&exponent_der);

    const RSA_ALGORITHM_IDENTIFIER: [u8; 15] = [
        0x30, 0x0D, 0x06, 0x09, 0x2A, 0x86, 0x48, 0x86, 0xF7, 0x0D, 0x01, 0x01, 0x01, 0x05, 0x00,
    ];
    let bit_string_len = 1 + pkcs1.len();
    let mut bit_string = Vec::with_capacity(bit_string_len + 4);
    bit_string.push(0x03); // BIT STRING
    der_length(&mut bit_string, bit_string_len);
    bit_string.push(0x00); // 0 unused bits
    bit_string.extend_from_slice(&pkcs1);

    let spki_len = RSA_ALGORITHM_IDENTIFIER.len() + bit_string.len();
    let mut spki = Vec::with_capacity(spki_len + 4);
    spki.push(0x30); // SEQUENCE
    der_length(&mut spki, spki_len);
    spki.extend_from_slice(&RSA_ALGORITHM_IDENTIFIER);
    spki.extend_from_slice(&bit_string);

    Ok(spki)
}

/// Encode one INTEGER in DER.
fn der_integer(bytes: &[u8]) -> Vec<u8> {
    let first_nonzero = bytes.iter().position(|&b| b != 0).unwrap_or(bytes.len());
    let trimmed = &bytes[first_nonzero..];

    if trimmed.is_empty() {
        return vec![0x02, 0x01, 0x00];
    }

    let needs_pad = trimmed.first().is_some_and(|&b| b & 0x80 != 0);
    let content_len = trimmed.len() + usize::from(needs_pad);

    let mut out = Vec::with_capacity(content_len + 4);
    out.push(0x02); // INTEGER
    der_length(&mut out, content_len);
    if needs_pad {
        out.push(0);
    }
    out.extend_from_slice(trimmed);
    out
}

/// Encode a DER length.
fn der_length(out: &mut Vec<u8>, len: usize) {
    if len < 0x80 {
        out.push(u8::try_from(len).unwrap_or(0x7F));
    } else if len < 0x100 {
        out.push(0x81);
        out.push(u8::try_from(len).unwrap_or(0xFF));
    } else if len < 0x10000 {
        out.push(0x82);
        out.extend_from_slice(&u16::try_from(len).unwrap_or(0xFFFF).to_be_bytes());
    } else {
        out.push(0x83);
        let bytes = u32::try_from(len).unwrap_or(u32::MAX).to_be_bytes();
        out.extend_from_slice(&bytes[1..]);
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Public helpers
// ─────────────────────────────────────────────────────────────────────────────

/// Whether the signature's validity window (with the standard
/// five-minute skew) contains `now`.
///
/// The wrapper in `mod.rs` and this helper apply the same rule; the
/// helper is `pub(crate)`-private and exists so the leaf verifier can
/// run without an `Arc<TrustAnchor>` in hand.
pub(crate) const fn within_validity(sig: &RrsigRdata, now: u32) -> bool {
    const SKEW: u32 = 300;
    // RFC 4034 §3.1.5 & RFC 1982: 32-bit serial number arithmetic.
    let lower = sig.signature_inception.wrapping_sub(SKEW);
    let upper = sig.signature_expiration.wrapping_add(SKEW);
    let valid_start = (now.wrapping_sub(lower) as i32) >= 0;
    let not_expired = (upper.wrapping_sub(now) as i32) >= 0;
    valid_start && not_expired
}

/// Validate an `RRset` against a set of DNSKEYs.
///
/// The caller vouches for the keys; this function only checks that a
/// signature verifies and that its validity window contains `now`.
///
/// Returns `Insecure` when no RRSIG covers the `RRset` or when every
/// covering RRSIG uses an algorithm this build cannot verify (per
/// RFC 4035 §5.2). Returns `Bogus` when at least one supported
/// algorithm was present but nothing verified.
#[must_use]
pub fn validate_rrset(
    rrset: &[DnsRecord],
    rrsigs: &[DnsRecord],
    dnskeys: &[DnskeyRdata],
) -> ValidationOutcome {
    let Some(covered) = rrset.first().map(|r| r.rtype) else {
        return ValidationOutcome::Insecure;
    };

    let sigs: Vec<&RrsigRdata> = rrsigs
        .iter()
        .filter_map(|r| match &r.data {
            RecordData::Rrsig(s) if s.type_covered == covered => Some(s),
            _ => None,
        })
        .collect();
    if sigs.is_empty() {
        return ValidationOutcome::Insecure;
    }

    let now = current_time();
    let mut any_supported = false;

    for sig in &sigs {
        if !sig.algorithm.is_supported() {
            continue;
        }
        any_supported = true;
        if !within_validity(sig, now) {
            continue;
        }
        let Some(key) = dnskeys
            .iter()
            .find(|k| k.key_tag() == sig.key_tag && k.algorithm == sig.algorithm)
        else {
            continue;
        };
        if verify_rrset(sig, rrset, key).is_ok() {
            return ValidationOutcome::Secure {
                key_tag: sig.key_tag,
                algorithm: sig.algorithm,
            };
        }
    }

    if any_supported {
        ValidationOutcome::Bogus
    } else {
        ValidationOutcome::Insecure
    }
}

/// Validate an `RRset` against one specific DNSKEY.
///
/// Returns `Insecure` when no RRSIG covering `rrset` uses `key`'s
/// algorithm with a supported signature scheme; returns `Bogus`
/// otherwise.
#[must_use]
pub fn validate_rrset_signed_by(
    rrset: &[DnsRecord],
    rrsigs: &[DnsRecord],
    key: &DnskeyRdata,
) -> ValidationOutcome {
    let Some(covered) = rrset.first().map(|r| r.rtype) else {
        return ValidationOutcome::Insecure;
    };

    let now = current_time();
    let key_tag = key.key_tag();
    let mut any_supported = false;

    for rrsig in rrsigs {
        let RecordData::Rrsig(sig) = &rrsig.data else {
            continue;
        };
        if sig.type_covered != covered {
            continue;
        }
        if sig.key_tag != key_tag || sig.algorithm != key.algorithm {
            continue;
        }
        if !sig.algorithm.is_supported() {
            continue;
        }
        any_supported = true;
        if !within_validity(sig, now) {
            continue;
        }
        if verify_rrset(sig, rrset, key).is_ok() {
            return ValidationOutcome::Secure {
                key_tag: sig.key_tag,
                algorithm: sig.algorithm,
            };
        }
    }

    if any_supported {
        ValidationOutcome::Bogus
    } else {
        ValidationOutcome::Insecure
    }
}

/// Unix seconds, saturating at `u32::MAX`.
#[inline]
fn current_time() -> u32 {
    use std::time::{SystemTime, UNIX_EPOCH};
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map_or(0, |d| d.as_secs().try_into().unwrap_or(u32::MAX))
}

// ─────────────────────────────────────────────────────────────────────────────
// Tests
// ─────────────────────────────────────────────────────────────────────────────

#[cfg(test)]
mod tests {
    use super::*;
    use crate::wire::record::DnssecAlgorithm;
    use smol_str::SmolStr;

    fn a_record(name: &str, ip: [u8; 4]) -> DnsRecord {
        DnsRecord {
            name: SmolStr::new(name),
            name_raw: name.into(),
            rtype: crate::wire::TYPE_A,
            rclass: crate::wire::CLASS_IN,
            ttl: 300,
            data: RecordData::A(std::net::Ipv4Addr::from(ip)),
        }
    }

    fn empty_sig() -> RrsigRdata {
        RrsigRdata {
            type_covered: crate::wire::TYPE_A,
            algorithm: DnssecAlgorithm::Ed25519,
            labels: 2,
            original_ttl: 300,
            signature_expiration: 2_000_000_000,
            signature_inception: 1_900_000_000,
            key_tag: 0x1234,
            signer_name: SmolStr::new("example.com"),
            signature: Vec::new(),
        }
    }

    #[test]
    fn signing_input_is_deterministic() {
        let rrset = vec![
            a_record("example.com", [192, 0, 2, 1]),
            a_record("example.com", [192, 0, 2, 2]),
        ];
        let sig = empty_sig();
        let a = build_signing_input(&sig, &rrset).unwrap();
        let b = build_signing_input(&sig, &rrset).unwrap();
        assert_eq!(a, b);
    }

    #[test]
    fn sorted_rdata_yields_same_input() {
        let sig = empty_sig();
        let rrset_a = vec![
            a_record("example.com", [192, 0, 2, 1]),
            a_record("example.com", [192, 0, 2, 2]),
        ];
        let rrset_b = vec![
            a_record("example.com", [192, 0, 2, 2]),
            a_record("example.com", [192, 0, 2, 1]),
        ];
        assert_eq!(
            build_signing_input(&sig, &rrset_a).unwrap(),
            build_signing_input(&sig, &rrset_b).unwrap(),
        );
    }

    #[test]
    fn uppercase_owner_is_normalized() {
        let sig = empty_sig();
        let lower = vec![a_record("example.com", [192, 0, 2, 1])];
        let upper = vec![a_record("EXAMPLE.COM", [192, 0, 2, 1])];
        assert_eq!(
            build_signing_input(&sig, &lower).unwrap(),
            build_signing_input(&sig, &upper).unwrap(),
        );
    }

    #[test]
    fn der_integer_strips_leading_zeros() {
        let bytes = &[0x00, 0x00, 0x80, 0x01];
        let der = der_integer(bytes);
        assert_eq!(der, vec![0x02, 0x03, 0x00, 0x80, 0x01]);
    }

    #[test]
    fn der_integer_preserves_normal_values() {
        let bytes = &[0x01, 0x02, 0x03];
        let der = der_integer(bytes);
        assert_eq!(der, vec![0x02, 0x03, 0x01, 0x02, 0x03]);
    }

    #[test]
    fn der_length_encodes_short_and_long() {
        let mut out = Vec::new();
        der_length(&mut out, 5);
        assert_eq!(out, vec![5]);

        out.clear();
        der_length(&mut out, 200);
        assert_eq!(out, vec![0x81, 200]);
    }

    #[test]
    fn wildcard_expansion_replaces_leftmost_labels() {
        let owner = owner_for_signing("www.example.com", 2);
        assert_eq!(owner.as_ref(), "*.example.com");

        let owner = owner_for_signing("example.com", 2);
        assert_eq!(owner.as_ref(), "example.com");

        let owner = owner_for_signing("a.b.c.example.com", 3);
        assert_eq!(owner.as_ref(), "*.c.example.com");
    }

    #[test]
    fn rsa_der_requires_exponent() {
        assert!(rsa_public_key_to_der(&[]).is_err());
        assert!(rsa_public_key_to_der(&[5, 1, 2]).is_err());
    }

    #[test]
    fn unsupported_algorithm_yields_insecure_not_bogus() {
        // Regression: `validate_rrset_signed_by` used to return Bogus
        // whenever the only covering RRSIG used an unsupported
        // algorithm. RFC 4035 §5.2 requires Insecure.
        let rrset = vec![a_record("x.com", [192, 0, 2, 1])];
        let mut sig = empty_sig();
        if let RecordData::Rrsig(r) = &mut sig.data {
            r.algorithm = DnssecAlgorithm::RsaSha1;
        }
        let key = DnskeyRdata {
            flags: 256,
            protocol: 3,
            algorithm: DnssecAlgorithm::RsaSha1,
            public_key: vec![0u8; 64],
        };
        assert_eq!(
            validate_rrset_signed_by(&rrset, &[sig], &key),
            ValidationOutcome::Insecure,
        );
    }
}