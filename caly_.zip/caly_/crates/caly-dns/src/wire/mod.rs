//! Wire format: names, records, messages, EDNS0, DNSSEC.
//!
//! # The boundary
//!
//! This module is where the crate stops being about software and starts
//! being about bytes. Everything above it — `upstream`, `cache`,
//! `resolver` — works with the Rust types defined here. Everything
//! below it is the wire.
//!
//! No module outside `wire` should accept a raw `&[u8]` message; if a
//! function requires byte-level deserialization, it belongs strictly in this module.
//!
//! # RFCs implemented
//!
//! * **RFC 1035** — message format, name encoding, the original RR types.
//! * **RFC 6891** — EDNS0: OPT pseudo-record, extended flags.
//! * **RFC 7871** — EDNS Client Subnet.
//! * **RFC 7873** — DNS Cookies.
//! * **RFC 7830** — EDNS Padding.
//! * **RFC 4034** — DNSSEC resource records (DNSKEY, DS, RRSIG, NSEC).
//! * **RFC 6052** — IPv4-embedded IPv6 address format.
//! * **RFC 6147** — DNS64 synthesis.
//!
//! # Structure
//!
//! ```text
//!   message.rs   — DnsMessage, DnsHeader, DnsQuestion
//!   record.rs    — DnsRecord, RecordData, DNSSEC RDATA types
//!   name.rs      — SIMD label scanning, encoding, 0x20
//!   edns.rs      — EdnsOption and its variants
//!   dnssec/      — cryptographic validation
//! ```

pub mod dnssec;
pub mod edns;
pub mod message;
pub mod name;
pub mod record;

pub use edns::{ClientSubnet, DnsCookie, EdnsOption, OptRecord};
pub use message::{DnsHeader, DnsMessage, DnsQuestion};
pub use name::{encode_name, resolve_pointers, scan, NameOffsets};
pub use record::{
    DnsRecord, DnskeyRdata, DnssecAlgorithm, DsRdata, NsecRdata, RecordData, RrsigRdata,
};

// ─────────────────────────────────────────────────────────────────────────────
// RR type codes (IANA registry)
// ─────────────────────────────────────────────────────────────────────────────

/// IPv4 host address (RFC 1035).
pub const TYPE_A: u16 = 1;
/// Authoritative name server (RFC 1035).
pub const TYPE_NS: u16 = 2;
/// Canonical name for an alias (RFC 1035).
pub const TYPE_CNAME: u16 = 5;
/// Start of a zone of authority (RFC 1035).
pub const TYPE_SOA: u16 = 6;
/// Domain name pointer (RFC 1035).
pub const TYPE_PTR: u16 = 12;
/// Mail exchange (RFC 1035).
pub const TYPE_MX: u16 = 15;
/// Text strings (RFC 1035).
pub const TYPE_TXT: u16 = 16;
/// IPv6 host address (RFC 3596).
pub const TYPE_AAAA: u16 = 28;
/// Service locator (RFC 2782).
pub const TYPE_SRV: u16 = 33;
/// EDNS0 pseudo-record (RFC 6891).
pub const TYPE_OPT: u16 = 41;
/// Delegation signer (RFC 4034).
pub const TYPE_DS: u16 = 43;
/// DNSSEC signature (RFC 4034).
pub const TYPE_RRSIG: u16 = 46;
/// Next secure record (RFC 4034).
pub const TYPE_NSEC: u16 = 47;
/// DNSSEC public key (RFC 4034).
pub const TYPE_DNSKEY: u16 = 48;
/// Service binding (RFC 9460).
pub const TYPE_SVCB: u16 = 64;
/// HTTPS binding (RFC 9460).
pub const TYPE_HTTPS: u16 = 65;

// Modern DNSSEC and WebPKI type identifiers.
/// Hashed next secure record (RFC 5155).
pub const TYPE_NSEC3: u16 = 50;
/// NSEC3 parameters (RFC 5155).
pub const TYPE_NSEC3PARAM: u16 = 51;
/// Certification Authority Authorization (RFC 8659).
pub const TYPE_CAA: u16 = 257;

/// Zone transfer query; not handled by the parser (RFC 1035).
pub const TYPE_AXFR: u16 = 252;
/// Wildcard query type; callers reject it by policy.
pub const TYPE_ANY: u16 = 255;

// ─────────────────────────────────────────────────────────────────────────────
// Class codes
// ─────────────────────────────────────────────────────────────────────────────

/// Internet class, the only class the crate interprets.
pub const CLASS_IN: u16 = 1;

// ─────────────────────────────────────────────────────────────────────────────
// RCODEs
// ─────────────────────────────────────────────────────────────────────────────

/// No error condition.
pub const RCODE_NOERROR: u8 = 0;
/// Format error: the server could not parse the query.
pub const RCODE_FORMERR: u8 = 1;
/// Server failure: the name server hit an internal error.
pub const RCODE_SERVFAIL: u8 = 2;
/// Name error: the queried name does not exist.
pub const RCODE_NXDOMAIN: u8 = 3;
/// Not implemented: the server does not support this opcode.
pub const RCODE_NOTIMP: u8 = 4;
/// Refused: the server refuses to answer for policy reasons.
pub const RCODE_REFUSED: u8 = 5;
/// Name exists when it should not.
pub const RCODE_YXDOMAIN: u8 = 6;
/// `RRset` exists when it should not.
pub const RCODE_YXRRSET: u8 = 7;
/// `RRset` that should exist does not.
pub const RCODE_NXRRSET: u8 = 8;
/// Server is not authoritative for the zone.
pub const RCODE_NOTAUTH: u8 = 9;
/// Name is outside the zone the server is authoritative for.
pub const RCODE_NOTZONE: u8 = 10;

// ─────────────────────────────────────────────────────────────────────────────
// Header flag bits
// ─────────────────────────────────────────────────────────────────────────────

/// Query/Response: set on responses.
pub const FLAG_QR: u16 = 1 << 15;
/// Authoritative Answer: set by the server for authoritative data.
pub const FLAG_AA: u16 = 1 << 10;
/// Truncation: the response did not fit and the client should retry over TCP.
pub const FLAG_TC: u16 = 1 << 9;
/// Recursion Desired: the client asks for a recursive resolution.
pub const FLAG_RD: u16 = 1 << 8;
/// Recursion Available: the server offers recursive resolution.
pub const FLAG_RA: u16 = 1 << 7;
/// Authentic Data: the response passed DNSSEC validation.
pub const FLAG_AD: u16 = 1 << 5;
/// Checking Disabled: the client asks the server to skip validation.
pub const FLAG_CD: u16 = 1 << 4;

// ─────────────────────────────────────────────────────────────────────────────
// DNSKEY Flags (RFC 4034 §2.1.1, RFC 3757)
//
// Defined here so the bit meanings live next to the constants rather than
// being duplicated (and drifting) inside `record.rs`.
// ─────────────────────────────────────────────────────────────────────────────

/// DNSKEY flag bit 0 (LSB): Secure Entry Point (RFC 3757).
pub const DNSKEY_FLAG_SEP: u16 = 0x0001;
/// DNSKEY flag bit 8: Zone Key (RFC 4034 §2.1.1). A key without this bit
/// set is not a zone key at all.
pub const DNSKEY_FLAG_ZONE: u16 = 0x0100;

/// EDNS0 UDP payload size advertised in every query.
///
/// 1232 bytes is the DNS Flag Day 2020 recommendation: the largest
/// message size that avoids IP fragmentation on common MTUs. Queries
/// that do not carry an OPT record therefore still fit in a single
/// datagram.
pub const EDNS0_UDP_PAYLOAD: u16 = 1232;
