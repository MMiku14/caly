//! Domain-name wire codec with SIMD-accelerated label scanning.
//!
//! # The problem
//!
//! A wire-format DNS name is a sequence of length-prefixed labels
//! terminated by a root label or a compression pointer:
//!
//! ```text
//!   [3] w w w  [7] e x a m p l e  [3] c o m  [0]
//!     ↑          ↑                 ↑
//!     label      label             label      root
//! ```
//!
//! The scalar decoder walks byte-by-byte: read a length, jump forward,
//! repeat. A 30-byte name costs 30 branches, most of which mispredict.
//!
//! # The approach
//!
//! Label-length bytes have the top two bits clear (`0x00..=0x3F`); the
//! root terminator is a zero byte; a compression pointer's first byte has
//! the top two bits set (`0xC0..=0xFF`). Bytes with the top two bits equal
//! to `0x40` or `0x80` are reserved label types. This partitions the byte
//! space, so a single SIMD comparison against `0xC0` splits the input into
//! "length bytes" and "payload bytes" with no per-byte branching.
//!
//! We use that to find label boundaries and never touch the payload.
//! Assembly then copies only the bytes it needs.
//!
//! # SIMD / scalar agreement
//!
//! The SIMD and scalar scanners MUST return identical results for every
//! input. Reserved label types (`0x40..=0xBF`) are *not* boundary
//! candidates, so the SIMD path inspects the current label-start byte
//! first and treats a reserved byte as end-of-name exactly as the scalar
//! scanner does — otherwise it would skip the reserved byte and could
//! mistake a `0xC0..` byte later in the payload for a pointer. A
//! differential test (see the `tests` module) enforces this equality.
//!
//! # What "SIMD" buys
//!
//! On `x86_64` the scan runs at 16 bytes per cycle. For typical names
//! (15–40 bytes) that means one or two iterations, versus the scalar
//! path's 15–40. Real-world speedup: 3–5×.

use caly_common::dns::DnsError;
use rand::Rng;
use smallvec::SmallVec;

/// Maximum number of labels in a name before we bail out. RFC 1035 §2.3.4
/// caps names at 255 wire bytes, which bounds the label count at 127;
/// 32 slots covers every real name without spilling.
const MAX_LABELS: usize = 32;

/// Maximum compression-pointer hops. A well-formed message needs fewer
/// than ten; 32 is generous.
const MAX_HOPS: usize = 32;

/// Offsets of a name's labels within its containing buffer.
///
/// `offsets[i]` points to the *length byte* of the `i`-th label.
/// `end` points one byte past the name's terminator in the original
/// buffer, even when compression pointers were followed.
///
/// The caller uses `end` as the cursor for the next record in the
/// message; when the name was compressed, `end` is the byte after the
/// pointer, not the byte after the target name.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct NameOffsets {
    offsets: SmallVec<[u32; MAX_LABELS]>,
    end: u32,
    pointer: Option<u16>,
}

impl NameOffsets {
    /// Number of labels the scanner recorded.
    #[inline]
    #[must_use]
    pub fn label_count(&self) -> usize {
        self.offsets.len()
    }

    /// Whether the name has no labels at all.
    #[inline]
    #[must_use]
    pub fn is_empty(&self) -> bool {
        self.offsets.is_empty()
    }

    /// Offset one byte past the name's terminator in the source buffer.
    #[inline]
    #[must_use]
    pub const fn end(&self) -> usize {
        self.end as usize
    }

    /// Target offset if the name was terminated by a compression pointer.
    #[inline]
    #[must_use]
    pub const fn pointer(&self) -> Option<u16> {
        self.pointer
    }
}

// ---------------------------------------------------------------------------
// Scanning
//
// The scalar scanner is the reference implementation; the SIMD variant
// is only chosen when the target and the runtime both agree. Both must
// produce identical output for identical input.
// ---------------------------------------------------------------------------

/// Scan `buf[offset..]` for a name.
///
/// Returns the label offsets plus the caller's cursor. Does not follow
/// compression pointers — the caller does that via [`resolve_pointers`]
/// when needed.
///
/// # Errors
///
/// Returns `DnsError::MalformedResponse` when `offset` is past the end
/// of the buffer.
pub fn scan(buf: &[u8], offset: usize) -> Result<NameOffsets, DnsError> {
    if offset >= buf.len() {
        return Err(DnsError::MalformedResponse("name offset past end".into()));
    }

    #[cfg(all(feature = "simd", target_arch = "x86_64"))]
    if is_x86_feature_detected!("sse2") {
        // SAFETY: guarded by the runtime feature check above.
        return Ok(unsafe { scan_sse2(buf, offset) });
    }

    Ok(scan_scalar(buf, offset))
}

/// Portable scalar scanner. Also used as the tail of the SIMD path.
///
/// Every offset it records is bounded by the message length, which
/// RFC 1035 caps at 65535 bytes; the truncating conversions to `u32`
/// below are therefore provably safe.
#[allow(clippy::cast_possible_truncation)]
fn scan_scalar(buf: &[u8], mut offset: usize) -> NameOffsets {
    let mut offsets: SmallVec<[u32; MAX_LABELS]> = SmallVec::new();
    while offset < buf.len() {
        let b = buf[offset];
        match b & 0xC0 {
            0x00 if b == 0 => {
                // Root label: end of name.
                return NameOffsets {
                    offsets,
                    end: (offset + 1) as u32,
                    pointer: None,
                };
            }
            0x00 => {
                // Length byte: record and jump past the label.
                offsets.push(offset as u32);
                let next = offset + 1 + usize::from(b);
                if next > buf.len() {
                    return NameOffsets {
                        offsets,
                        end: buf.len() as u32,
                        pointer: None,
                    };
                }
                offset = next;
            }
            0xC0 => {
                // Compression pointer: end of name, two bytes consumed.
                let pointer = if offset + 1 < buf.len() {
                    Some(((usize::from(b & 0x3F) << 8) | usize::from(buf[offset + 1])) as u16)
                } else {
                    None
                };
                return NameOffsets {
                    offsets,
                    end: (offset + 2).min(buf.len()) as u32,
                    pointer,
                };
            }
            _ => {
                // Reserved label type (0x40..=0xBF). Treat as end-of-name.
                return NameOffsets {
                    offsets,
                    end: (offset + 1).min(buf.len()) as u32,
                    pointer: None,
                };
            }
        }
    }
    NameOffsets {
        offsets,
        end: buf.len() as u32,
        pointer: None,
    }
}

#[cfg(all(feature = "simd", target_arch = "x86_64"))]
#[target_feature(enable = "sse2")]
unsafe fn scan_sse2(buf: &[u8], start: usize) -> NameOffsets {
    use std::arch::x86_64::*;

    let mut offsets: SmallVec<[u32; MAX_LABELS]> = SmallVec::new();
    let mut offset = start;
    let n = buf.len();

    // The scalar scanner walks one label at a time; the SIMD scanner
    // finds every length byte in a 16-byte window at once, then jumps
    // through them. When the input runs out of window, we hand off to
    // the scalar scanner for the tail.
    while offset + 16 <= n {
        // Classify the current *label-start* byte before scanning the
        // window. A reserved type (top two bits 0x40 or 0x80) is not a
        // boundary candidate, so the movemask below would skip past it and
        // could mistake a payload `0xC0..` byte for a pointer. Mirror the
        // scalar scanner exactly: stop here.
        let start_byte = buf[offset] & 0xC0;
        if start_byte == 0x40 || start_byte == 0x80 {
            return NameOffsets {
                offsets,
                end: (offset + 1).min(n) as u32,
                pointer: None,
            };
        }

        // SAFETY: `_mm_loadu_si128` is an unaligned load; the target
        // alignment is deliberately one byte.
        #[allow(clippy::cast_ptr_alignment)]
        let chunk = _mm_loadu_si128(buf.as_ptr().add(offset).cast::<__m128i>());

        // Mask the top two bits. A byte with (b & 0xC0) == 0 is a length
        // byte or root; (b & 0xC0) == 0xC0 is a compression pointer.
        // `as i8` / `as u32` casts (instead of the newer std cast helper
        // methods) keep this compiling on lower toolchains (MSRV-friendly).
        let c0 = _mm_set1_epi8(0xC0u8 as i8);
        let masked = _mm_and_si128(chunk, c0);
        let zero_mask = _mm_cmpeq_epi8(masked, _mm_setzero_si128());
        let ptr_mask = _mm_cmpeq_epi8(masked, c0);
        let boundary_mask = _mm_or_si128(zero_mask, ptr_mask);
        let candidates = _mm_movemask_epi8(boundary_mask) as u32;

        if candidates == 0 {
            offset += 16;
            continue;
        }

        // The current label-start byte is always a boundary candidate at
        // position 0 (a length/root/pointer byte), so `trailing_zeros`
        // yields it first. We process only that first candidate, then
        // re-load a fresh window from the new offset.
        let pos = candidates.trailing_zeros() as usize;
        let idx = offset + pos;
        let b = buf[idx];

        if b == 0 {
            return NameOffsets {
                offsets,
                end: (idx + 1) as u32,
                pointer: None,
            };
        }
        if b & 0xC0 == 0xC0 {
            let pointer = if idx + 1 < n {
                Some(((usize::from(b & 0x3F) << 8) | usize::from(buf[idx + 1])) as u16)
            } else {
                None
            };
            return NameOffsets {
                offsets,
                end: (idx + 2).min(n) as u32,
                pointer,
            };
        }

        offsets.push(idx as u32);
        let next = idx + 1 + usize::from(b);
        if next > n {
            return NameOffsets {
                offsets,
                end: n as u32,
                pointer: None,
            };
        }
        offset = next;
    }

    // Hand the tail (fewer than 16 bytes, or a position already advanced
    // past a window) to the reference scanner.
    let tail = scan_scalar(buf, offset);
    offsets.extend(tail.offsets.iter().copied());
    NameOffsets {
        offsets,
        end: tail.end,
        pointer: tail.pointer,
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Assembly
// ─────────────────────────────────────────────────────────────────────────────

/// Follow any compression pointers starting at `offset` and return the
/// full name, lowercased.
///
/// # Errors
///
/// Returns `DnsError::MalformedResponse` when a name extends past the
/// buffer, when a label is not valid UTF-8, or when a pointer target
/// falls outside the buffer. Returns `DnsError::CnameLoop` when the
/// pointer chain exceeds `MAX_HOPS` hops.
pub fn resolve_pointers(buf: &[u8], offset: usize) -> Result<(String, usize), DnsError> {
    let first = scan(buf, offset)?;
    let end = first.end();
    let mut out = String::with_capacity(64);
    let mut current = first;
    let mut hops = 0usize;

    loop {
        // Normalise a bare root label to `.` so callers do not have
        // to special-case the empty string.
        if current.offsets.is_empty() && out.is_empty() {
            out.push('.');
        }

        for &off_u32 in &current.offsets {
            let off = off_u32 as usize;
            let label_len = usize::from(buf[off]);
            let start = off + 1;
            let end_label = start + label_len;
            if end_label > buf.len() {
                return Err(DnsError::MalformedResponse("label extends past end".into()));
            }
            let label = std::str::from_utf8(&buf[start..end_label])
                .map_err(|_| DnsError::MalformedResponse("non-UTF-8 label".into()))?;
            if !out.is_empty() && out != "." {
                out.push('.');
            } else if out == "." {
                out.clear();
            }
            out.extend(label.chars().map(|c| c.to_ascii_lowercase()));
        }

        // Check for a trailing compression pointer.
        let Some(target) = current.pointer().map(usize::from) else {
            break;
        };
        if target >= buf.len() {
            return Err(DnsError::MalformedResponse("pointer past end".into()));
        }
        hops += 1;
        if hops > MAX_HOPS {
            return Err(DnsError::CnameLoop);
        }
        current = scan(buf, target)?;
    }

    Ok((out, end))
}

/// Same as [`resolve_pointers`] but preserves the original byte case.
///
/// The root name is returned as an empty string here, not as `.`; the
/// lower-casing variant normalises the root for cache keys.
///
/// Used by the 0x20 verifier, which must compare against the exact
/// sequence it sent, byte for byte.
///
/// # Errors
///
/// Same failure modes as [`resolve_pointers`].
pub fn resolve_pointers_preserving_case(
    buf: &[u8],
    offset: usize,
) -> Result<(String, usize), DnsError> {
    let first = scan(buf, offset)?;
    let end = first.end();
    let mut out = String::with_capacity(64);
    let mut current = first;
    let mut hops = 0usize;

    loop {
        for &off_u32 in &current.offsets {
            let off = off_u32 as usize;
            let label_len = usize::from(buf[off]);
            let start = off + 1;
            let label_end = start + label_len;
            if label_end > buf.len() {
                return Err(DnsError::MalformedResponse("label past end".into()));
            }
            if !out.is_empty() {
                out.push('.');
            }
            let label = std::str::from_utf8(&buf[start..label_end])
                .map_err(|_| DnsError::MalformedResponse("non-UTF-8 label".into()))?;
            out.push_str(label);
        }
        let Some(target) = current.pointer().map(usize::from) else {
            break;
        };
        if target >= buf.len() {
            return Err(DnsError::MalformedResponse("pointer past end".into()));
        }
        hops += 1;
        if hops > MAX_HOPS {
            return Err(DnsError::CnameLoop);
        }
        current = scan(buf, target)?;
    }

    Ok((out, end))
}

// ─────────────────────────────────────────────────────────────────────────────
// Encoding
// ─────────────────────────────────────────────────────────────────────────────

/// Encode a name in wire format. Never emits compression pointers.
///
/// Enforces the RFC 1035 §2.3.4 limits: each label is 1..=63 bytes and
/// the whole name is at most 253 bytes. A trailing dot is optional.
///
/// # Errors
///
/// Returns `DnsError::ParseError` when a label exceeds 63 bytes, when
/// the whole name exceeds 253 bytes, or when a label is empty.
///
/// The label-length push below is a `usize`-to-`u8` conversion; the
/// length check above bounds the value at 63.
#[allow(clippy::cast_possible_truncation)]
pub fn encode_name(name: &str, out: &mut Vec<u8>) -> Result<(), DnsError> {
    let trimmed = name.trim_end_matches('.');
    if trimmed.is_empty() {
        out.push(0);
        return Ok(());
    }
    if trimmed.len() > 253 {
        return Err(DnsError::ParseError("name exceeds 253 bytes".into()));
    }
    for label in trimmed.split('.') {
        if label.is_empty() || label.len() > 63 {
            return Err(DnsError::ParseError(
                "label must be 1..=63 bytes".into(),
            ));
        }
        out.push(label.len() as u8);
        out.extend_from_slice(label.as_bytes());
    }
    out.push(0);
    Ok(())
}

// ─────────────────────────────────────────────────────────────────────────────
// 0x20 case randomisation
// ─────────────────────────────────────────────────────────────────────────────

/// Randomise the ASCII case of every alphabetic byte.
///
/// A conformant resolver echoes the case it received; a spoofing
/// middlebox that canonicalises case cannot. With a 16-bit TXID, the
/// probability of an off-path attacker guessing both is
/// `1 / (65536 · 2^L)` where `L` is the alphabetic character count.
///
/// Consumes entropy one 64-bit word at a time, so the number of RNG
/// calls is proportional to `name.len() / 64`, not to the alphabetic
/// character count.
#[must_use]
pub fn randomize_case<R: Rng>(name: &str, rng: &mut R) -> String {
    let mut out = String::with_capacity(name.len());
    let mut entropy: u64 = rng.gen();
    let mut bits_remaining = 64;
    for ch in name.chars() {
        if ch.is_ascii_alphabetic() {
            if bits_remaining == 0 {
                entropy = rng.gen();
                bits_remaining = 64;
            }
            let flip = (entropy & 1) != 0;
            entropy >>= 1;
            bits_remaining -= 1;
            if flip {
                out.push(ch.to_ascii_uppercase());
            } else {
                out.push(ch.to_ascii_lowercase());
            }
        } else {
            out.push(ch);
        }
    }
    out
}

/// Return `true` iff `response` is byte-for-byte identical to `expected`.
///
/// This is the 0x20 (RFC 8467 / draft-vixie-dnsext-dns0x20) check: the
/// response MUST echo the exact case sequence that was sent. Any
/// deviation — a differing length, a differing non-alphabetic byte, or a
/// single re-cased letter — is rejected, because a middlebox that
/// canonicalises case is exactly the signal we are trying to catch.
///
/// The name is deliberately *not* `case_matches`: a case-*insensitive*
/// comparison here would defeat the anti-spoofing purpose of 0x20. Call
/// it what it does — the response "echoes exactly" what we sent.
#[must_use]
pub fn echoes_exactly(expected: &str, response: &str) -> bool {
    expected.len() == response.len()
        && expected.bytes().zip(response.bytes()).all(|(a, b)| a == b)
}

// ─────────────────────────────────────────────────────────────────────────────
// Tests
// ─────────────────────────────────────────────────────────────────────────────

#[cfg(test)]
mod tests {
    use super::*;
    use rand::SeedableRng;

    fn encoded(name: &str) -> Vec<u8> {
        let mut buf = Vec::new();
        encode_name(name, &mut buf).unwrap();
        buf
    }

    #[test]
    fn scan_simple_name() {
        let buf = encoded("www.example.com");
        let offsets = scan(&buf, 0).unwrap();
        assert_eq!(offsets.label_count(), 3);
        assert_eq!(offsets.end(), buf.len());
    }

    #[test]
    fn scan_root_only() {
        let buf = [0u8];
        let offsets = scan(&buf, 0).unwrap();
        assert!(offsets.is_empty());
        assert_eq!(offsets.end(), 1);
    }

    #[test]
    fn resolve_simple() {
        let buf = encoded("www.example.com");
        let (name, end) = resolve_pointers(&buf, 0).unwrap();
        assert_eq!(name, "www.example.com");
        assert_eq!(end, buf.len());
    }

    #[test]
    fn resolve_with_pointer() {
        // "example.com" at offset 0, then "www" + pointer to 0.
        let mut buf = encoded("example.com");
        let ptr_target = 0u16;
        buf.push(3);
        buf.extend_from_slice(b"www");
        buf.push(0xC0 | (ptr_target >> 8) as u8);
        buf.push(ptr_target as u8);
        let (name, _) = resolve_pointers(&buf, 13).unwrap();
        assert_eq!(name, "www.example.com");
    }

    #[test]
    fn pointer_loop_is_detected() {
        // Two pointers pointing at each other.
        let buf = [0xC0, 0x00, 0xC0, 0x00];
        let result = resolve_pointers(&buf, 0);
        assert!(result.is_err());
    }

    #[test]
    fn preserves_case_when_asked() {
        let buf = encoded("WWW.Example.COM");
        let (lower, _) = resolve_pointers(&buf, 0).unwrap();
        assert_eq!(lower, "www.example.com");
        let (preserved, _) = resolve_pointers_preserving_case(&buf, 0).unwrap();
        assert_eq!(preserved, "WWW.Example.COM");
    }

    #[test]
    fn long_name_does_not_spill() {
        // 30 labels, each 63 bytes — well past MAX_LABELS * 63.
        let labels: Vec<String> = (0..30).map(|_| "a".repeat(63)).collect();
        let name = labels.join(".");
        let buf = encoded(&name);
        let offsets = scan(&buf, 0).unwrap();
        assert_eq!(offsets.label_count(), 30);
        let (decoded, _) = resolve_pointers(&buf, 0).unwrap();
        assert_eq!(decoded, name.to_lowercase());
    }

    #[test]
    fn echo_check_is_byte_exact() {
        let mut rng = rand::rngs::StdRng::seed_from_u64(42);
        let original = "www.example.com";
        let randomised = randomize_case(original, &mut rng);
        assert_eq!(randomised.to_lowercase(), original);
        // A string echoes itself.
        assert!(echoes_exactly(&randomised, &randomised));
        // A differently-cased string is NOT an exact echo — this is the
        // whole point of the 0x20 check.
        assert!(!echoes_exactly(&randomised, original));
    }

    #[test]
    fn reserved_start_byte_is_end_of_name() {
        // 0x40 is a reserved label type; both scanners must stop here.
        let buf = [0x40u8, b'a', b'b', 0x00];
        let offsets = scan(&buf, 0).unwrap();
        assert!(offsets.is_empty());
        assert_eq!(offsets.end(), 1);
        assert_eq!(offsets.pointer(), None);
    }

    #[test]
    fn truncated_buffer_does_not_panic() {
        // A length byte that promises more bytes than the buffer holds.
        let buf = [5u8, b'a'];
        let _ = scan(&buf, 0);
        let _ = resolve_pointers(&buf, 0);
    }

    /// Differential test: the SIMD scanner must return exactly the same
    /// `NameOffsets` as the reference scalar scanner for every input.
    /// This is the guard that would have caught the reserved-label
    /// divergence called out in review.
    #[cfg(all(feature = "simd", target_arch = "x86_64"))]
    #[test]
    fn simd_matches_scalar() {
        if !is_x86_feature_detected!("sse2") {
            return;
        }
        let cases: Vec<Vec<u8>> = vec![
            encoded("www.example.com"),
            vec![0u8],
            vec![0x40, b'a', b'b', 0x00],          // reserved at start
            vec![0x80, 0x41, 0x42],                // other reserved class
            encoded("a")
                .into_iter()
                .chain([0x41u8, 0x42, 0x43])
                .collect(),                        // reserved mid-stream
            {
                let mut v = encoded("example.com");
                v.push(0xC0);
                v.push(0x00);                       // trailing pointer
                v
            },
            vec![0x05, b'w', b'w', b'w'],           // truncated length
            (0..40).map(|i| (i % 20) as u8).collect::<Vec<u8>>(), // filler
            encoded("a.very.long.name.that.spans.multiple.simd.windows.example"),
        ];
        for buf in &cases {
            let scalar = scan_scalar(buf, 0);
            // SAFETY: guarded by the is_x86_feature_detected! above.
            let simd = unsafe { scan_sse2(buf, 0) };
            assert_eq!(scalar, simd, "SIMD/scalar divergence on {buf:?}");
        }
    }

    proptest::proptest! {
        /// Whatever bytes we receive, parsing must not panic.
        #[test]
        fn scan_never_panics(data in proptest::collection::vec(proptest::num::u8::ANY, 0..512)) {
            let _ = scan(&data, 0);
            let _ = resolve_pointers(&data, 0);
        }

        /// Encoding then decoding a valid name round-trips.
        #[test]
        fn encode_decode_roundtrip(
            labels in proptest::collection::vec("[a-zA-Z0-9-]{1,30}", 1..10)
        ) {
            let name = labels.join(".");
            let mut buf = Vec::new();
            encode_name(&name, &mut buf).unwrap();
            let (decoded, _) = resolve_pointers(&buf, 0).unwrap();
            proptest::prop_assert_eq!(decoded, name.to_lowercase());
        }

        /// SIMD and scalar scanners must agree on every input.
        #[cfg(all(feature = "simd", target_arch = "x86_64"))]
        #[test]
        fn simd_scalar_agreement(data in proptest::collection::vec(proptest::num::u8::ANY, 0..512)) {
            if !is_x86_feature_detected!("sse2") {
                return Ok(());
            }
            let scalar = scan_scalar(&data, 0);
            // SAFETY: guarded by the runtime check above.
            let simd = unsafe { scan_sse2(&data, 0) };
            proptest::prop_assert_eq!(scalar, simd);
            Ok(())
        }
    }
}
