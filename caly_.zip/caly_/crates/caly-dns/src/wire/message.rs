//! DNS message codec (RFC 1035 §4).
//!
//! # Shape
//!
//! A DNS message is a header, then four sections in fixed order:
//!
//! ```text
//!   ┌─────────┬────────────┬───────────┬──────────────┬────────────┐
//!   │ Header  │ Questions  │ Answers   │ Authorities  │ Additional │
//!   │ 12 B    │ qdcount    │ ancount   │ nscount      │ arcount    │
//!   └─────────┴────────────┴───────────┴──────────────┴────────────┘
//! ```
//!
//! The header is fixed-length. Each subsequent section is a sequence of
//! records whose count the header declares.
//!
//! # Lenient additional section
//!
//! The question, answer, and authority sections are parsed strictly: a
//! malformed record is a protocol error. The additional section is not.
//! Some servers pad it with records we do not care about, and refusing
//! the whole message because of an OPT record with a malformed option
//! would turn a working query into a failure. The parser stops at the
//! first malformed additional record and returns what it has.
//!
//! # Two serializers
//!
//! [`DnsMessage::serialize_query`] writes only what a query needs —
//! question and EDNS0 OPT. [`DnsMessage::serialize`] writes a full
//! message, used when the resolver synthesizes a response.

use std::net::{Ipv4Addr, Ipv6Addr};
use smallvec::SmallVec;
use smol_str::SmolStr;

use crate::error::{Error, Result};
use crate::wire::edns::{EdnsOption, OptRecord};
use crate::wire::name::{encode_name, resolve_pointers_preserving_case};
use crate::wire::record::{DnsRecord, RecordData};
use crate::wire::{CLASS_IN, EDNS0_UDP_PAYLOAD, FLAG_QR, FLAG_RD, TYPE_OPT};

// ─────────────────────────────────────────────────────────────────────────────
// Header
// ─────────────────────────────────────────────────────────────────────────────

/// The 12-byte DNS header.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub struct DnsHeader {
    /// Transaction identifier.
    pub id: u16,
    /// Flags: QR, OPCODE, AA, TC, RD, RA, Z, RCODE.
    pub flags: u16,
    /// Question count.
    pub qdcount: u16,
    /// Answer count.
    pub ancount: u16,
    /// Authority count.
    pub nscount: u16,
    /// Additional count.
    pub arcount: u16,
}

impl DnsHeader {
    /// Whether this message is a response. Equivalent to the QR bit
    /// being set.
    ///
    /// # Returns
    /// True for any message with the QR bit set.
    #[inline]
    #[must_use]
    pub const fn is_response(&self) -> bool {
        self.flags & FLAG_QR != 0
    }

    /// Whether the message was truncated.
    #[inline]
    #[must_use]
    pub const fn is_truncated(&self) -> bool {
        self.flags & crate::wire::FLAG_TC != 0
    }

    /// The response code (low 4 bits of flags).
    #[inline]
    #[must_use]
    pub const fn rcode(&self) -> u8 {
        (self.flags & 0x000F) as u8
    }

    /// Encode the header into `out`.
    #[inline]
    pub fn encode(&self, out: &mut Vec<u8>) {
        out.extend_from_slice(&self.id.to_be_bytes());
        out.extend_from_slice(&self.flags.to_be_bytes());
        out.extend_from_slice(&self.qdcount.to_be_bytes());
        out.extend_from_slice(&self.ancount.to_be_bytes());
        out.extend_from_slice(&self.nscount.to_be_bytes());
        out.extend_from_slice(&self.arcount.to_be_bytes());
    }

    /// Parse the header from `buf`.
    ///
    /// Returns the header and the offset of the byte after it (always
    /// 12 on success).
    ///
    /// # Errors
    ///
    /// Returns `Error::Malformed` when `buf` is shorter than the
    /// twelve-byte DNS header.
    pub const fn decode(buf: &[u8]) -> Result<(Self, usize)> {
        if buf.len() < 12 {
            return Err(Error::Malformed("header shorter than 12 bytes"));
        }
        Ok((
            Self {
                id: u16::from_be_bytes([buf[0], buf[1]]),
                flags: u16::from_be_bytes([buf[2], buf[3]]),
                qdcount: u16::from_be_bytes([buf[4], buf[5]]),
                ancount: u16::from_be_bytes([buf[6], buf[7]]),
                nscount: u16::from_be_bytes([buf[8], buf[9]]),
                arcount: u16::from_be_bytes([buf[10], buf[11]]),
            },
            12,
        ))
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Question
// ─────────────────────────────────────────────────────────────────────────────

/// A question entry.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct DnsQuestion {
    /// Owner name, lowercased.
    pub name: SmolStr,
    /// The name as it appeared on the wire, preserving case. Required
    /// by the 0x20 verifier.
    pub name_raw: String,
    /// Query type.
    pub qtype: u16,
    /// Query class.
    pub qclass: u16,
}

impl DnsQuestion {
    /// Encode the question into `out`.
    ///
    /// # Errors
    ///
    /// Returns an error when the owner name fails to encode.
    pub fn encode(&self, out: &mut Vec<u8>) -> Result<()> {
        encode_name(&self.name, out)?;
        out.extend_from_slice(&self.qtype.to_be_bytes());
        out.extend_from_slice(&self.qclass.to_be_bytes());
        Ok(())
    }

    /// Encode using the exact case of `name_raw`.
    ///
    /// Used by the local server to echo the client's question
    /// byte-for-byte; the 0x20 case check depends on this.
    ///
    /// # Errors
    ///
    /// Returns an error when the raw owner name fails to encode.
    pub fn encode_raw(&self, out: &mut Vec<u8>) -> Result<()> {
        encode_name(&self.name_raw, out)?;
        out.extend_from_slice(&self.qtype.to_be_bytes());
        out.extend_from_slice(&self.qclass.to_be_bytes());
        Ok(())
    }

    /// Parse a question from `buf[offset..]`.
    ///
    /// # Errors
    ///
    /// Returns `Error::Malformed` when the question extends past the
    /// end of the buffer.
    pub fn decode(buf: &[u8], offset: usize) -> Result<(Self, usize)> {
        let (raw_name, next) = resolve_pointers_preserving_case(buf, offset)?;
        if next + 4 > buf.len() {
            return Err(Error::Malformed("truncated question"));
        }
        Ok((
            Self {
                name: SmolStr::new(raw_name.to_ascii_lowercase()),
                name_raw: raw_name,
                qtype: u16::from_be_bytes([buf[next], buf[next + 1]]),
                qclass: u16::from_be_bytes([buf[next + 2], buf[next + 3]]),
            },
            next + 4,
        ))
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Message
// ─────────────────────────────────────────────────────────────────────────────

/// A complete DNS message.
#[derive(Debug, Clone, PartialEq, Eq, Default)]
pub struct DnsMessage {
    /// The twelve-byte header.
    pub header: DnsHeader,
    /// The question section.
    pub questions: Vec<DnsQuestion>,
    /// The answer section.
    pub answers: Vec<DnsRecord>,
    /// The authority section.
    pub authorities: Vec<DnsRecord>,
    /// The additional section.
    pub additionals: Vec<DnsRecord>,
}

impl DnsMessage {
    /// Build a recursive query with an EDNS0 OPT advertising 1232 bytes.
    #[must_use]
    pub fn new_query(id: u16, name: &str, qtype: u16) -> Self {
        Self::new_query_with_options(id, name, qtype, SmallVec::new())
    }

    /// Build a recursive query with EDNS0 options.
    ///
    /// The query name is stored as given. Case randomisation, when
    /// enabled, is the caller's job: they must apply it before calling
    /// this method, and retain the randomised string for verification.
    #[must_use]
    pub fn new_query_with_options(
        id: u16,
        name: &str,
        qtype: u16,
        options: SmallVec<[EdnsOption; 2]>,
    ) -> Self {
        // RFC 3225: the DO bit is bit 15 of the extended RCODE/flags
        // word, which the OPT record's TTL field carries.
        const EDNS_DO_BIT: u32 = 0x0000_8000;

        let trimmed = name.trim_end_matches('.');
        let question = DnsQuestion {
            name: SmolStr::new(trimmed.to_ascii_lowercase()),
            name_raw: trimmed.to_owned(),
            qtype,
            qclass: CLASS_IN,
        };
        let opt = DnsRecord {
            name: SmolStr::default(),
            name_raw: String::new(),
            rtype: TYPE_OPT,
            rclass: EDNS0_UDP_PAYLOAD,
            ttl: EDNS_DO_BIT,
            data: RecordData::Opt(OptRecord { options }),
        };
        Self {
            header: DnsHeader {
                id,
                flags: FLAG_RD,
                qdcount: 1,
                ancount: 0,
                nscount: 0,
                arcount: 1,
            },
            questions: vec![question],
            answers: Vec::new(),
            authorities: Vec::new(),
            additionals: vec![opt],
        }
    }

    /// The first OPT record, if any. A well-formed message carries at
    /// most one; additional OPT records are ignored.
    #[must_use]
    pub fn opt(&self) -> Option<&OptRecord> {
        self.additionals.iter().find_map(|record| match &record.data {
            RecordData::Opt(opt) => Some(opt),
            _ => None,
        })
    }

    // ─────────────────────────────────────────────────────────────────────
    // Serialization
    // ─────────────────────────────────────────────────────────────────────

    /// Serialize a query.
    ///
    /// Only the question and any OPT record are written. This is the
    /// shape we send upstream.
    ///
    /// # Errors
    ///
    /// Returns an error when a question or an OPT record fails to
    /// encode.
    pub fn serialize_query(&self) -> Result<Vec<u8>> {
        let mut out = Vec::with_capacity(64);
        self.header.encode(&mut out);
        for question in &self.questions {
            if question.name_raw.is_empty() {
                question.encode(&mut out)?;
            } else {
                question.encode_raw(&mut out)?;
            }
        }
        for record in &self.additionals {
            if record.rtype == TYPE_OPT {
                record.encode(&mut out)?;
            }
        }
        Ok(out)
    }

    /// Serialize a full message.
    ///
    /// The header counts are recalculated from the section lengths, so
    /// a caller that populated the vectors directly without updating
    /// the header still produces a valid message.
    ///
    /// Question names are written using their case-preserved form so a
    /// response echoes the client's exact bytes.
    ///
    /// # Errors
    ///
    /// Returns an error when any section fails to encode, or when a
    /// section's record count exceeds the 16-bit field. Exceeding the
    /// field is reported as an error rather than silently truncated, so
    /// the caller cannot emit a header whose counts disagree with the
    /// records actually written.
    pub fn serialize(&self) -> Result<Vec<u8>> {
        let mut out = Vec::with_capacity(256);
        let mut header = self.header;
        header.qdcount = u16::try_from(self.questions.len())
            .map_err(|_| Error::Malformed("question count exceeds 16 bits"))?;
        header.ancount = u16::try_from(self.answers.len())
            .map_err(|_| Error::Malformed("answer count exceeds 16 bits"))?;
        header.nscount = u16::try_from(self.authorities.len())
            .map_err(|_| Error::Malformed("authority count exceeds 16 bits"))?;
        header.arcount = u16::try_from(self.additionals.len())
            .map_err(|_| Error::Malformed("additional count exceeds 16 bits"))?;
        header.encode(&mut out);

        for question in &self.questions {
            if question.name_raw.is_empty() {
                question.encode(&mut out)?;
            } else {
                question.encode_raw(&mut out)?;
            }
        }
        for record in &self.answers {
            record.encode(&mut out)?;
        }
        for record in &self.authorities {
            record.encode(&mut out)?;
        }
        for record in &self.additionals {
            record.encode(&mut out)?;
        }
        Ok(out)
    }

    // ─────────────────────────────────────────────────────────────────────
    // Parsing
    // ─────────────────────────────────────────────────────────────────────

    /// Parse a wire-format message.
    ///
    /// Strict on question / answer / authority sections; lenient on
    /// additional, per the module documentation. A malformed record in
    /// the additional section stops that section, not the parse.
    ///
    /// # Errors
    ///
    /// Returns `Error::Malformed` when a strict section cannot be
    /// parsed, or when a section ends before its declared count.
    pub fn parse(buf: &[u8]) -> Result<Self> {
        let (header, mut offset) = DnsHeader::decode(buf)?;

        let questions = parse_section_questions(buf, &mut offset, header.qdcount)?;

        let answers = parse_section(
            buf,
            &mut offset,
            header.ancount,
            SectionKind::Record,
        )?;
        let authorities = parse_section(
            buf,
            &mut offset,
            header.nscount,
            SectionKind::Record,
        )?;
        // The additional section is parsed leniently: an OPT record
        // with an unfamiliar option must not invalidate the answer.
        let additionals = parse_section(
            buf,
            &mut offset,
            header.arcount,
            SectionKind::RecordLenient,
        )?;

        Ok(Self {
            header,
            questions,
            answers,
            authorities,
            additionals,
        })
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Section parsing
// ─────────────────────────────────────────────────────────────────────────────

/// Which kind of record section is being parsed, and how strictly.
#[derive(Debug, Clone, Copy)]
enum SectionKind {
    Record,
    RecordLenient,
}

/// Parse `count` records from `buf` starting at `offset`.
///
/// `RecordLenient` sections stop at the first malformed record and
/// return what they have; `Record` sections propagate the error.
fn parse_section(
    buf: &[u8],
    offset: &mut usize,
    count: u16,
    kind: SectionKind,
) -> Result<Vec<DnsRecord>> {
    // Bound the pre-allocation by the number of minimum-size records
    // the remaining buffer could possibly hold.
    let max_possible_records = (buf.len().saturating_sub(*offset) / 11).max(1);
    let safe_capacity = (count as usize).min(max_possible_records);
    let mut records = Vec::with_capacity(safe_capacity);
    for _ in 0..count {
        if *offset >= buf.len() {
            return match kind {
                SectionKind::RecordLenient => Ok(records),
                SectionKind::Record => Err(Error::Malformed(
                    "section ends before declared record count",
                )),
            };
        }
        match DnsRecord::parse(buf, *offset) {
            Ok((record, next)) => {
                records.push(record);
                *offset = next;
            }
            Err(e) => match kind {
                SectionKind::RecordLenient => return Ok(records),
                SectionKind::Record => return Err(e),
            },
        }
    }
    Ok(records)
}

/// Parse a question section.
///
/// This is the single source of truth for question parsing — the main
/// [`DnsMessage::parse`] routes through it rather than inlining a second
/// copy of the loop, so the two paths cannot drift.
fn parse_section_questions(
    buf: &[u8],
    offset: &mut usize,
    count: u16,
) -> Result<Vec<DnsQuestion>> {
    // Bound pre-allocation by what the remaining buffer can hold (a
    // minimum question is a root label + 4 bytes).
    let max_possible = (buf.len().saturating_sub(*offset) / 5).max(1);
    let safe_capacity = (count as usize).min(max_possible);
    let mut questions = Vec::with_capacity(safe_capacity);
    for _ in 0..count {
        if *offset >= buf.len() {
            return Err(Error::Malformed(
                "question section ends before declared count",
            ));
        }
        let (question, next) = DnsQuestion::decode(buf, *offset)?;
        questions.push(question);
        *offset = next;
    }
    Ok(questions)
}

impl DnsMessage {
    /// Parse a wire message, preserving question case.
    ///
    /// The name is retained for callers that predate the plain `parse`;
    /// both entry points share the same implementation.
    ///
    /// # Errors
    ///
    /// Identical to [`DnsMessage::parse`].
    #[inline]
    pub fn parse_with_questions(buf: &[u8]) -> Result<Self> {
        Self::parse(buf)
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Query / response helpers
// ─────────────────────────────────────────────────────────────────────────────

/// Build a minimal query for a name and type, using the given id.
///
/// This is a thin wrapper over [`DnsMessage::new_query`] for callers
/// that do not need EDNS options.
#[must_use]
#[inline]
pub fn make_query(id: u16, name: &str, qtype: u16) -> DnsMessage {
    DnsMessage::new_query(id, name, qtype)
}

/// Build a response echoing `query`'s question, with the given rcode and
/// answers. No OPT record is added; callers that need one add it.
///
/// The response copies the query's RD bit and sets QR and RA, matching
/// the behaviour of a standard recursive resolver.
#[must_use]
pub fn make_response(
    query: &DnsMessage,
    rcode: u8,
    answers: Vec<DnsRecord>,
) -> DnsMessage {
    let rd = query.header.flags & FLAG_RD;
    let header = DnsHeader {
        id: query.header.id,
        // QR=1, RD copied, RA=1.
        flags: FLAG_QR | rd | crate::wire::FLAG_RA | u16::from(rcode & 0x0F),
        qdcount: 1,
        ancount: u16::try_from(answers.len()).unwrap_or(u16::MAX),
        nscount: 0,
        arcount: 0,
    };
    DnsMessage {
        header,
        questions: query.questions.clone(),
        answers,
        authorities: Vec::new(),
        additionals: Vec::new(),
    }
}

/// Build an A-record answer.
#[must_use]
pub fn a_record(name: &str, address: Ipv4Addr, ttl: u32) -> DnsRecord {
    DnsRecord {
        name: SmolStr::new(name.to_ascii_lowercase()),
        name_raw: name.to_owned(),
        rtype: crate::wire::TYPE_A,
        rclass: CLASS_IN,
        ttl,
        data: RecordData::A(address),
    }
}

/// Build an AAAA-record answer.
#[must_use]
pub fn aaaa_record(name: &str, address: Ipv6Addr, ttl: u32) -> DnsRecord {
    DnsRecord {
        name: SmolStr::new(name.to_ascii_lowercase()),
        name_raw: name.to_owned(),
        rtype: crate::wire::TYPE_AAAA,
        rclass: CLASS_IN,
        ttl,
        data: RecordData::Aaaa(address),
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Tests
// ─────────────────────────────────────────────────────────────────────────────

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn header_roundtrip() {
        let header = DnsHeader {
            id: 0xABCD,
            flags: FLAG_RD,
            qdcount: 1,
            ancount: 2,
            nscount: 0,
            arcount: 1,
        };
        let mut buf = Vec::new();
        header.encode(&mut buf);
        assert_eq!(buf.len(), 12);
        let (decoded, offset) = DnsHeader::decode(&buf).unwrap();
        assert_eq!(decoded, header);
        assert_eq!(offset, 12);
    }

    #[test]
    fn header_short_input_rejected() {
        assert!(DnsHeader::decode(&[0u8; 5]).is_err());
    }

    #[test]
    fn query_roundtrip() {
        let query = DnsMessage::new_query(0x1234, "www.example.com", 1);
        let wire = query.serialize_query().unwrap();
        let parsed = DnsMessage::parse_with_questions(&wire).unwrap();
        assert_eq!(parsed.header.id, 0x1234);
        assert!(parsed.header.flags & FLAG_RD != 0);
        assert_eq!(parsed.questions.len(), 1);
        assert_eq!(parsed.questions[0].name.as_str(), "www.example.com");
        assert_eq!(parsed.questions[0].qtype, 1);
    }

    #[test]
    fn query_with_edns_options_roundtrip() {
        use crate::wire::edns::{ClientSubnet, EdnsOption};
        let options: SmallVec<[EdnsOption; 2]> = smallvec::smallvec![
            EdnsOption::ClientSubnet(ClientSubnet::new(
                "192.168.1.42".parse().unwrap(),
                24
            )),
        ];
        let query = DnsMessage::new_query_with_options(1, "example.com", 1, options);
        let wire = query.serialize_query().unwrap();
        let parsed = DnsMessage::parse_with_questions(&wire).unwrap();
        let opt = parsed.opt().expect("OPT record present");
        assert_eq!(opt.options.len(), 1);
    }

    #[test]
    fn response_with_a_record_roundtrip() {
        let query = DnsMessage::new_query(7, "example.com", 1);
        let answer = a_record("example.com", "192.0.2.1".parse().unwrap(), 300);
        let response = make_response(&query, 0, vec![answer.clone()]);
        let wire = response.serialize().unwrap();
        let parsed = DnsMessage::parse_with_questions(&wire).unwrap();
        assert!(parsed.header.is_response());
        assert_eq!(parsed.header.id, 7);
        assert_eq!(parsed.answers.len(), 1);
        assert_eq!(parsed.answers[0].name.as_str(), "example.com");
        match &parsed.answers[0].data {
            RecordData::A(addr) => assert_eq!(addr.to_string(), "192.0.2.1"),
            other => panic!("expected A record, got {other:?}"),
        }
    }

    #[test]
    fn response_preserves_question_case() {
        // Send a query with mixed case; the response must echo it.
        let query = DnsMessage::new_query_with_options(
            1,
            "WWW.Example.COM",
            1,
            SmallVec::new(),
        );
        // The `new_query_with_options` lowercases the internal `name`
        // but preserves the raw form.
        assert_eq!(query.questions[0].name.as_str(), "www.example.com");
        assert_eq!(query.questions[0].name_raw, "WWW.Example.COM");
        let wire = query.serialize_query().unwrap();
        let parsed = DnsMessage::parse_with_questions(&wire).unwrap();
        assert_eq!(parsed.questions[0].name_raw, "WWW.Example.COM");
        assert_eq!(parsed.questions[0].name.as_str(), "www.example.com");
    }

    #[test]
    fn multiple_questions_roundtrip() {
        // Though rare, DNS allows more than one question.
        let mut message = DnsMessage::new_query(1, "a.example", 1);
        message.questions.push(DnsQuestion {
            name: SmolStr::new("b.example"),
            name_raw: "b.example".into(),
            qtype: 28,
            qclass: CLASS_IN,
        });
        message.header.qdcount = 2;
        let wire = message.serialize_query().unwrap();
        let parsed = DnsMessage::parse_with_questions(&wire).unwrap();
        assert_eq!(parsed.questions.len(), 2);
        assert_eq!(parsed.questions[1].qtype, 28);
    }

    #[test]
    fn truncated_response_is_rejected() {
        let query = DnsMessage::new_query(1, "example.com", 1);
        let wire = query.serialize_query().unwrap();
        // Cut the buffer in half; parse must fail, not panic.
        assert!(DnsMessage::parse_with_questions(&wire[..wire.len() / 2]).is_err());
    }

    #[test]
    fn empty_buffer_does_not_panic() {
        assert!(DnsMessage::parse_with_questions(&[]).is_err());
    }

    #[test]
    fn serialize_rejects_oversized_section_count() {
        // A section with more records than a 16-bit count can express
        // must be reported, not silently truncated (the previous `as u16`
        // behaviour emitted a header whose count disagreed with the body).
        let mut message = DnsMessage::new_query(1, "example.com", 1);
        // Fabricate 65_536 answers — one more than u16::MAX.
        message.answers = (0..=u16::MAX)
            .map(|_| a_record("example.com", "192.0.2.1".parse().unwrap(), 300))
            .collect();
        assert!(message.serialize().is_err());
    }

    #[test]
    fn rcode_extraction() {
        let mut header = DnsHeader::default();
        header.flags = 0x8183; // QR=1, RD=1, RA=1, RCODE=3
        assert!(header.is_response());
        assert_eq!(header.rcode(), 3);
    }

    #[test]
    fn truncation_flag() {
        let mut header = DnsHeader::default();
        header.flags = 0x0200;
        assert!(header.is_truncated());
    }

    proptest::proptest! {
        /// Parsing arbitrary bytes must not panic.
        #[test]
        fn parse_never_panics(data in proptest::collection::vec(
            proptest::num::u8::ANY, 0..2048
        )) {
            let _ = DnsMessage::parse_with_questions(&data);
        }

        /// A query roundtrips through serialize / parse.
        #[test]
        fn query_roundtrip_prop(
            id in proptest::num::u16::ANY,
            labels in proptest::collection::vec("[a-z0-9-]{1,20}", 1..6),
            qtype in proptest::num::u16::ANY,
        ) {
            let name = labels.join(".");
            let query = DnsMessage::new_query(id, &name, qtype);
            let wire = query.serialize_query().unwrap();
            let parsed = DnsMessage::parse_with_questions(&wire).unwrap();
            proptest::prop_assert_eq!(parsed.header.id, id);
            proptest::prop_assert_eq!(parsed.questions.len(), 1);
            proptest::prop_assert_eq!(
                parsed.questions[0].name.as_str(),
                name.as_str(),
            );
            proptest::prop_assert_eq!(parsed.questions[0].qtype, qtype);
        }
    }
}
