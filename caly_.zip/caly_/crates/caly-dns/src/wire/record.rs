//! Resource records.
//!
//! # The shape of a record
//!
//! On the wire, every record has the same outer form:
//!
//! ```text
//!   NAME  TYPE  CLASS  TTL  RDLENGTH  RDATA
//! ```
//!
//! The first five fields are mechanical. `RDATA` is where the type
//! shows through: an A record's RDATA is 4 bytes, an MX record's is a
//! preference plus a name, an RRSIG's is a structured blob.
//!
//! [`RecordData`] is that distinction made explicit. Its variants
//! correspond to the RDATA shapes we understand; anything else falls
//! into [`RecordData::Unknown`] as an opaque byte slice.
//!
//! # Why DNSSEC types live here
//!
//! `DNSKEY`, `DS`, `RRSIG`, and `NSEC` are RDATA shapes. They belong
//! with the other shapes, not with the validation logic that consumes
//! them. Keeping them here means `wire::dnssec` can depend on them
//! without `record.rs` depending on `wire::dnssec`.

use std::net::{Ipv4Addr, Ipv6Addr};
use smallvec::SmallVec;
use smol_str::SmolStr;

use crate::error::{Error, Result};
use crate::wire::name::{encode_name, resolve_pointers};
use crate::wire::{
    TYPE_A, TYPE_AAAA, TYPE_CNAME, TYPE_DNSKEY, TYPE_DS, TYPE_NSEC, TYPE_OPT, TYPE_PTR, TYPE_RRSIG,
    TYPE_TXT,
};

// ─────────────────────────────────────────────────────────────────────────────
// Algorithm identifier
// ─────────────────────────────────────────────────────────────────────────────

/// DNSSEC signing algorithm (RFC 4034 Appendix A.1).
///
/// The enum is `#[non_exhaustive]` because the registry grows: new
/// algorithms are added every few years, and a verifier that hits an
/// unrecognised algorithm must not crash. `Unknown` carries the raw
/// byte so the caller can log it without losing information.
///
/// The supported set is checked by
/// [`DnssecAlgorithm::is_supported`]; anything outside that set is
/// parsed but not verified.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum DnssecAlgorithm {
    // Historical, kept so we can parse old signatures.
    /// RSA/MD5. Historical; parse-only.
    RsaMd5,
    /// DSA/SHA-1. Historical; parse-only.
    Dsa,
    /// RSA/SHA-1. Historical; parse-only.
    RsaSha1,
    /// DSA-NSEC3-SHA1. Historical; parse-only.
    DsaNsec3Sha1,
    /// RSA/SHA-1 with NSEC3. Historical; parse-only.
    RsaSha1Nsec3Sha1,
    // Modern.
    /// RSA/SHA-256. Supported.
    RsaSha256,
    /// RSA/SHA-512. Supported.
    RsaSha512,
    /// GOST R 34.10-2001. Parse-only.
    EccGost,
    /// ECDSA P-256 / SHA-256. Supported.
    EcdsaP256Sha256,
    /// ECDSA P-384 / SHA-384. Supported.
    EcdsaP384Sha384,
    /// Ed25519. Supported.
    Ed25519,
    /// Ed448. Parse-only.
    Ed448,
    /// Any algorithm this build does not know.
    Unknown(u8),
}

impl DnssecAlgorithm {
    /// Decode an algorithm byte.
    #[must_use]
    pub const fn from_u8(value: u8) -> Self {
        match value {
            1 => Self::RsaMd5,
            3 => Self::Dsa,
            5 => Self::RsaSha1,
            6 => Self::DsaNsec3Sha1,
            7 => Self::RsaSha1Nsec3Sha1,
            8 => Self::RsaSha256,
            10 => Self::RsaSha512,
            12 => Self::EccGost,
            13 => Self::EcdsaP256Sha256,
            14 => Self::EcdsaP384Sha384,
            15 => Self::Ed25519,
            16 => Self::Ed448,
            other => Self::Unknown(other),
        }
    }

    /// The wire-format byte.
    #[must_use]
    pub const fn as_u8(self) -> u8 {
        match self {
            Self::RsaMd5 => 1,
            Self::Dsa => 3,
            Self::RsaSha1 => 5,
            Self::DsaNsec3Sha1 => 6,
            Self::RsaSha1Nsec3Sha1 => 7,
            Self::RsaSha256 => 8,
            Self::RsaSha512 => 10,
            Self::EccGost => 12,
            Self::EcdsaP256Sha256 => 13,
            Self::EcdsaP384Sha384 => 14,
            Self::Ed25519 => 15,
            Self::Ed448 => 16,
            Self::Unknown(v) => v,
        }
    }

    /// Whether this build can verify signatures made with this algorithm.
    ///
    /// The supported set is RSA/SHA-256, RSA/SHA-512, ECDSA P-256,
    /// ECDSA P-384, and Ed25519. Together they cover the entire public
    /// DNSSEC deployment as of 2024.
    #[must_use]
    pub const fn is_supported(self) -> bool {
        matches!(
            self,
            Self::RsaSha256 | Self::RsaSha512 | Self::EcdsaP256Sha256 | Self::EcdsaP384Sha384 | Self::Ed25519
        )
    }
}

impl std::fmt::Display for DnssecAlgorithm {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        let name = match self {
            Self::RsaMd5 => "RSAMD5",
            Self::Dsa => "DSA",
            Self::RsaSha1 => "RSASHA1",
            Self::DsaNsec3Sha1 => "DSA-NSEC3-SHA1",
            Self::RsaSha1Nsec3Sha1 => "RSASHA1-NSEC3-SHA1",
            Self::RsaSha256 => "RSASHA256",
            Self::RsaSha512 => "RSASHA512",
            Self::EccGost => "ECC-GOST",
            Self::EcdsaP256Sha256 => "ECDSAP256SHA256",
            Self::EcdsaP384Sha384 => "ECDSAP384SHA384",
            Self::Ed25519 => "ED25519",
            Self::Ed448 => "ED448",
            Self::Unknown(v) => return write!(f, "UNKNOWN({v})"),
        };
        f.write_str(name)
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// DNSSEC RDATA
// ─────────────────────────────────────────────────────────────────────────────

/// DNSKEY RDATA (RFC 4034 §2.1).
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct DnskeyRdata {
    /// DNSKEY Flags. Authoritative bit meanings:
    ///
    /// * bit 8 (`0x0100`) = Zone Key (RFC 4034 §2.1.1). Without it the
    ///   key is not a zone key.
    /// * bit 0 (`0x0001`) = Secure Entry Point / SEP (RFC 3757).
    ///
    /// See [`crate::wire::DNSKEY_FLAG_ZONE`] and
    /// [`crate::wire::DNSKEY_FLAG_SEP`].
    pub flags: u16,
    /// Protocol. RFC 4034 §2.1.2 mandates 3.
    pub protocol: u8,
    /// Public-key algorithm.
    pub algorithm: DnssecAlgorithm,
    /// Algorithm-specific public-key bytes.
    pub public_key: Vec<u8>,
}

impl DnskeyRdata {
    /// Whether the Zone Key bit is set (RFC 4034 §2.1.1, `0x0100`).
    ///
    /// This is the authoritative, RFC-backed predicate. Everything the
    /// resolver needs to distinguish "is this even a zone key" is here.
    #[must_use]
    pub const fn is_zone_key(&self) -> bool {
        self.flags & crate::wire::DNSKEY_FLAG_ZONE != 0
    }

    /// Whether this is a Secure Entry Point (RFC 4034 §2.1.1 / RFC 3757,
    /// flag bit 0 = `0x0001`).
    #[must_use]
    pub const fn is_sep(&self) -> bool {
        self.flags & crate::wire::DNSKEY_FLAG_SEP != 0
    }

    /// Heuristic: whether this looks like a Key Signing Key.
    ///
    /// NOTE: KSK vs ZSK is *not* defined by the flags — RFC 4034 leaves
    /// both bits shared, and the authoritative test is whether the key
    /// is referenced by a DS record (the "zone-anchor" check). Flags
    /// alone cannot decide it. The overwhelmingly common deployment
    /// convention, however, is that a KSK carries the SEP bit alongside
    /// the Zone Key bit (`flags = 0x0101`) while a ZSK carries only the
    /// Zone Key bit (`flags = 0x0100`). This method encodes that
    /// convention and MUST NOT be relied on for security decisions —
    /// treat it as an ordering hint; resolve the real answer via DS
    /// coverage in `wire::dnssec`.
    #[must_use]
    pub const fn is_ksk(&self) -> bool {
        self.is_zone_key() && self.is_sep()
    }

    /// Heuristic: whether this looks like a Zone Signing Key.
    ///
    /// See [`DnskeyRdata::is_ksk`] for the caveat: this is a flag-based
    /// convention, not the authoritative KSK/ZSK test. A key that is not
    /// a zone key at all is neither KSK nor ZSK.
    #[must_use]
    pub const fn is_zsk(&self) -> bool {
        self.is_zone_key() && !self.is_sep()
    }

    /// Compute the key tag as defined in RFC 4034 Appendix B.
    ///
    /// The tag is a 16-bit checksum over the wire-format RDATA. Two
    /// keys with the same tag and different key material are a
    /// deliberate-collision risk; the check exists to let resolvers
    /// select the right key quickly, not to be collision resistant.
    #[must_use]
    pub fn key_tag(&self) -> u16 {
        // Reuse a stack buffer: the header is four bytes and the public
        // key is bounded by the DNSKEY RDATA size.
        let mut rdata = Vec::with_capacity(4 + self.public_key.len());
        rdata.extend_from_slice(&self.flags.to_be_bytes());
        rdata.push(self.protocol);
        rdata.push(self.algorithm.as_u8());
        rdata.extend_from_slice(&self.public_key);

        let mut accumulator: u32 = 0;
        #[allow(clippy::chunks_exact_to_as_chunks)]
        let mut chunks = rdata.chunks_exact(2);
        for pair in &mut chunks {
            accumulator += u32::from(u16::from_be_bytes([pair[0], pair[1]]));
        }
        if let Some(&last) = chunks.remainder().first() {
            accumulator += u32::from(last) << 8;
        }
        // RFC 4034 Appendix B folds the high 16 bits in *exactly once*.
        // A loop here diverges from the RFC when the fold itself
        // carries (e.g. acc = 0x1FFFF: the RFC returns 0x0000, a loop
        // returns 0x0001), and a mismatch silently breaks anchor
        // matching for the affected keys.
        accumulator += (accumulator >> 16) & 0xFFFF;
        (accumulator & 0xFFFF) as u16
    }
}

/// DS RDATA (RFC 4034 §5.1).
///
/// The digest algorithm field selects the hash used over the child's
/// DNSKEY; the key tag and algorithm together identify the key the
/// digest was computed from.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct DsRdata {
    /// Key tag of the DNSKEY this DS refers to.
    pub key_tag: u16,
    /// Algorithm of that DNSKEY.
    pub algorithm: DnssecAlgorithm,
    /// Digest algorithm: 1 = SHA-1, 2 = SHA-256, 4 = SHA-384.
    pub digest_type: u8,
    /// The digest bytes.
    pub digest: Vec<u8>,
}

/// RRSIG RDATA (RFC 4034 §3.1).
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct RrsigRdata {
    /// The RR type this signature covers.
    pub type_covered: u16,
    /// Signing algorithm.
    pub algorithm: DnssecAlgorithm,
    /// Number of labels in the original owner name.
    pub labels: u8,
    /// The TTL the `RRset` had when it was signed.
    pub original_ttl: u32,
    /// Signature expiry, seconds since Unix epoch.
    pub signature_expiration: u32,
    /// Signature inception, seconds since Unix epoch.
    pub signature_inception: u32,
    /// Key tag of the DNSKEY that produced this signature.
    pub key_tag: u16,
    /// Owner name of the signing zone, lowercased.
    pub signer_name: SmolStr,
    /// Raw signature bytes.
    pub signature: Vec<u8>,
}

/// NSEC RDATA (RFC 4034 §4.1).
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct NsecRdata {
    /// Next owner name in canonical order.
    pub next_domain_name: SmolStr,
    /// RR types present at this name. Sorted ascending.
    pub types: SmallVec<[u16; 8]>,
}

// ─────────────────────────────────────────────────────────────────────────────
// RecordData
// ─────────────────────────────────────────────────────────────────────────────

/// A record's RDATA.
///
/// Variants exist only for the types this crate interprets. Everything
/// else goes into `Unknown` and is preserved byte-for-byte so that
/// re-serialization is lossless.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum RecordData {
    /// An IPv4 host address.
    A(Ipv4Addr),
    /// An IPv6 host address.
    Aaaa(Ipv6Addr),
    /// A canonical-name alias.
    Cname(SmolStr),
    /// A reverse-mapping pointer.
    Ptr(SmolStr),
    /// A text record, stored as the concatenated strings.
    Txt(Vec<u8>),
    /// An EDNS0 OPT pseudo-record.
    Opt(crate::wire::edns::OptRecord),
    /// A DNSSEC signature.
    Rrsig(RrsigRdata),
    /// A DNSSEC public key.
    Dnskey(DnskeyRdata),
    /// A delegation signer.
    Ds(DsRdata),
    /// A next-secure-record.
    Nsec(NsecRdata),
    /// A type this build does not interpret. The bytes are kept
    /// verbatim so a round trip through the parser is lossless.
    Unknown(Vec<u8>),
}

impl RecordData {
    /// The wire-format type code.
    ///
    /// For `Unknown`, this returns 0; the true type is carried by the
    /// enclosing [`DnsRecord::rtype`].
    #[must_use]
    pub const fn rtype(&self) -> u16 {
        match self {
            Self::A(_) => TYPE_A,
            Self::Aaaa(_) => TYPE_AAAA,
            Self::Cname(_) => TYPE_CNAME,
            Self::Ptr(_) => TYPE_PTR,
            Self::Txt(_) => TYPE_TXT,
            Self::Opt(_) => TYPE_OPT,
            Self::Rrsig(_) => TYPE_RRSIG,
            Self::Dnskey(_) => TYPE_DNSKEY,
            Self::Ds(_) => TYPE_DS,
            Self::Nsec(_) => TYPE_NSEC,
            Self::Unknown(_) => 0,
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// DnsRecord
// ─────────────────────────────────────────────────────────────────────────────

/// A resource record.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct DnsRecord {
    /// Owner name, lowercased.
    pub name: SmolStr,
    /// The name as it appeared on the wire, preserving case. Used by
    /// the 0x20 verifier, which must compare byte-for-byte.
    pub name_raw: String,
    /// RR type code.
    pub rtype: u16,
    /// Class code. Always `CLASS_IN` for the records we handle.
    pub rclass: u16,
    /// Time-to-live in seconds.
    pub ttl: u32,
    /// The record's payload.
    pub data: RecordData,
}

impl DnsRecord {
    /// Parse a record from `buf` starting at `offset`.
    ///
    /// Returns the record and the offset one past its last byte. The
    /// owner name is lowercased for the cache key while `name_raw`
    /// preserves the wire bytes for the 0x20 verifier.
    ///
    /// # Errors
    ///
    /// Returns `Error::Malformed` when the buffer ends mid-record,
    /// when `RDLENGTH` runs past the buffer, or when an RDATA field
    /// fails its type-specific validity check.
    pub fn parse(buf: &[u8], offset: usize) -> Result<(Self, usize)> {
        let (raw_name, after_name) = resolve_pointers(buf, offset)?;
        let name = SmolStr::new(raw_name.to_ascii_lowercase());
        if after_name + 10 > buf.len() {
            return Err(Error::Malformed("truncated RR header"));
        }
        let rtype = u16::from_be_bytes([buf[after_name], buf[after_name + 1]]);
        let rclass = u16::from_be_bytes([buf[after_name + 2], buf[after_name + 3]]);
        let ttl = u32::from_be_bytes([
            buf[after_name + 4],
            buf[after_name + 5],
            buf[after_name + 6],
            buf[after_name + 7],
        ]);
        let rdlength = usize::from(u16::from_be_bytes([
            buf[after_name + 8],
            buf[after_name + 9],
        ]));
        let rdata_start = after_name + 10;
        let rdata_end = rdata_start + rdlength;
        if rdata_end > buf.len() {
            return Err(Error::Malformed("RDLENGTH past message end"));
        }
        let data = parse_rdata(buf, rdata_start, rdlength, rtype, rclass)?;
        Ok((
            Self {
                name,
                name_raw: raw_name,
                rtype,
                rclass,
                ttl,
                data,
            },
            rdata_end,
        ))
    }

    /// Serialize the record without compression.
    ///
    /// The RDATA length is computed after the body has been written,
    /// so the caller does not have to know it in advance.
    ///
    /// # Errors
    ///
    /// Returns an error when the owner name or an embedded name fails
    /// to encode, or when the RDATA exceeds the 65535-byte limit the
    /// `RDLENGTH` field can represent.
    pub fn encode(&self, out: &mut Vec<u8>) -> Result<()> {
        // Preserve the wire case when the caller supplied one.
        if self.name_raw.is_empty() {
            encode_name(&self.name, out)?;
        } else {
            encode_name(&self.name_raw, out)?;
        }
        out.extend_from_slice(&self.rtype.to_be_bytes());
        out.extend_from_slice(&self.rclass.to_be_bytes());
        out.extend_from_slice(&self.ttl.to_be_bytes());
        let len_pos = out.len();
        out.extend_from_slice(&0u16.to_be_bytes());
        let rdata_start = out.len();
        encode_rdata(&self.data, out)?;
        // The documented contract is to fail rather than emit a
        // truncated RDLENGTH: a downstream parser that trusts the
        // field would desynchronise on the next record.
        let rdlength = u16::try_from(out.len() - rdata_start)
            .map_err(|_| Error::Malformed("RDATA exceeds 65535 bytes"))?;
        out[len_pos..len_pos + 2].copy_from_slice(&rdlength.to_be_bytes());
        Ok(())
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// RDATA parsing
// ─────────────────────────────────────────────────────────────────────────────

fn parse_rdata(
    buf: &[u8],
    start: usize,
    length: usize,
    rtype: u16,
    _rclass: u16,
) -> Result<RecordData> {
    let rdata = &buf[start..start + length];
    Ok(match rtype {
        TYPE_A => {
            if length != 4 {
                return Err(Error::Malformed("invalid A record length"));
            }
            RecordData::A(Ipv4Addr::new(rdata[0], rdata[1], rdata[2], rdata[3]))
        }
        TYPE_AAAA => {
            if length != 16 {
                return Err(Error::Malformed("invalid AAAA record length"));
            }
            let mut octets = [0u8; 16];
            octets.copy_from_slice(rdata);
            RecordData::Aaaa(Ipv6Addr::from(octets))
        }
        TYPE_CNAME => {
            let (target, end) = resolve_pointers(buf, start)?;
            if end != start + length {
                return Err(Error::Malformed("CNAME RDATA length mismatch"));
            }
            RecordData::Cname(SmolStr::new(target))
        }
        TYPE_PTR => {
            let (target, _) = resolve_pointers(buf, start)?;
            RecordData::Ptr(SmolStr::new(target))
        }
        TYPE_TXT => {
            // Validate character-string framing per RFC 1035 §3.3.14 while keeping
            // exact wire format to preserve multi-string chunk boundaries and DNSSEC fidelity.
            let mut cur = rdata;
            while !cur.is_empty() {
                let slen = cur[0] as usize;
                if cur.len() < 1 + slen {
                    return Err(Error::Malformed("truncated TXT character-string"));
                }
                cur = &cur[1 + slen..];
            }
            RecordData::Txt(rdata.to_vec())
        }
        TYPE_OPT => RecordData::Opt(crate::wire::edns::OptRecord::parse(rdata)),
        TYPE_RRSIG => RecordData::Rrsig(parse_rrsig(buf, start, length)?),
        TYPE_DNSKEY => RecordData::Dnskey(parse_dnskey(rdata)?),
        TYPE_DS => RecordData::Ds(parse_ds(rdata)?),
        TYPE_NSEC => RecordData::Nsec(parse_nsec(buf, start, length)?),
        _ => RecordData::Unknown(rdata.to_vec()),
    })
}

fn parse_rrsig(buf: &[u8], start: usize, length: usize) -> Result<RrsigRdata> {
    // RFC 4034 §3.1: the fixed portion of RRSIG RDATA is 18 bytes,
    // followed by the signer name (which may be compressed), followed
    // by the signature.
    const FIXED_LEN: usize = 18;
    if length < FIXED_LEN {
        return Err(Error::Malformed("RRSIG shorter than fixed portion"));
    }
    let r = &buf[start..start + length];
    let type_covered = u16::from_be_bytes([r[0], r[1]]);
    let algorithm = DnssecAlgorithm::from_u8(r[2]);
    let labels = r[3];
    let original_ttl = u32::from_be_bytes([r[4], r[5], r[6], r[7]]);
    let signature_expiration = u32::from_be_bytes([r[8], r[9], r[10], r[11]]);
    let signature_inception = u32::from_be_bytes([r[12], r[13], r[14], r[15]]);
    let key_tag = u16::from_be_bytes([r[16], r[17]]);

    let (signer_name, name_end) = resolve_pointers(buf, start + FIXED_LEN)?;
    // RRSIG signer names are zone names, never the root.
    if signer_name.is_empty() {
        return Err(Error::Malformed("RRSIG has empty signer name"));
    }
    // `resolve_pointers` lowercases; signer names must be canonical.
    // A future switch to `resolve_pointers_preserving_case` here would
    // silently break signature verification.
    debug_assert!(signer_name.chars().all(|c| !c.is_ascii_uppercase()));

    let rdata_end = start + length;
    if name_end > rdata_end {
        return Err(Error::Malformed("RRSIG signer overruns RDATA"));
    }
    // Everything from the end of the signer name to the end of the
    // RDATA is the raw signature.
    let signature = buf[name_end..rdata_end].to_vec();

    Ok(RrsigRdata {
        type_covered,
        algorithm,
        labels,
        original_ttl,
        signature_expiration,
        signature_inception,
        key_tag,
        signer_name: SmolStr::new(signer_name),
        signature,
    })
}

fn parse_dnskey(rdata: &[u8]) -> Result<DnskeyRdata> {
    if rdata.len() < 4 {
        return Err(Error::Malformed("DNSKEY shorter than fixed portion"));
    }
    // RFC 4034 §2.1.2: a DNSKEY whose protocol field is not 3 is
    // "invalid during signature verification", not malformed. Parse
    // it here and let `DnssecValidator` reject it when it verifies.
    // Rejecting at parse time would break mixed-protocol rollover
    // zones.
    Ok(DnskeyRdata {
        flags: u16::from_be_bytes([rdata[0], rdata[1]]),
        protocol: rdata[2],
        algorithm: DnssecAlgorithm::from_u8(rdata[3]),
        public_key: rdata[4..].to_vec(),
    })
}

fn parse_ds(rdata: &[u8]) -> Result<DsRdata> {
    if rdata.len() < 4 {
        return Err(Error::Malformed("DS shorter than fixed portion"));
    }
    Ok(DsRdata {
        key_tag: u16::from_be_bytes([rdata[0], rdata[1]]),
        algorithm: DnssecAlgorithm::from_u8(rdata[2]),
        digest_type: rdata[3],
        digest: rdata[4..].to_vec(),
    })
}

fn parse_nsec(buf: &[u8], start: usize, length: usize) -> Result<NsecRdata> {
    let (next, name_end) = resolve_pointers(buf, start)?;
    let rdata_end = start + length;
    if name_end > rdata_end {
        return Err(Error::Malformed("NSEC next-name overruns RDATA"));
    }
    let types = decode_type_bitmap(&buf[name_end..rdata_end])?;
    Ok(NsecRdata {
        next_domain_name: SmolStr::new(next),
        types,
    })
}

// ─────────────────────────────────────────────────────────────────────────────
// Type bitmap (RFC 4034 §4.1.2)
// ─────────────────────────────────────────────────────────────────────────────

/// Decode a type bitmap into a sorted list of type codes.
///
/// Each window is `(window_number, bitmap_length, bitmap_bytes)`; the
/// window numbers must be strictly increasing, and `bitmap_bytes` must
/// not end in a zero byte.
fn decode_type_bitmap(mut rdata: &[u8]) -> Result<SmallVec<[u16; 8]>> {
    let mut types = SmallVec::new();
    let mut last_window: Option<u8> = None;
    while !rdata.is_empty() {
        if rdata.len() < 2 {
            return Err(Error::Malformed("truncated NSEC type bitmap"));
        }
        let window = rdata[0];
        // RFC 4034 §4.1.2 requires window numbers to be strictly
        // increasing across a single bitmap.
        if let Some(prev) = last_window {
            if window <= prev {
                return Err(Error::Malformed("NSEC windows out of order or duplicate"));
            }
        }
        last_window = Some(window);
        let len = usize::from(rdata[1]);
        if len == 0 || len > 32 || rdata.len() < 2 + len {
            return Err(Error::Malformed("bad NSEC bitmap length"));
        }
        let bitmap = &rdata[2..2 + len];
        // RFC 4034 §4.1.2 forbids a trailing zero byte: the bitmap must
        // be trimmed to its significant length.
        if bitmap.last() == Some(&0) {
            return Err(Error::Malformed("NSEC bitmap has trailing zero byte"));
        }
        for (byte_index, &byte) in bitmap.iter().enumerate() {
            if byte == 0 {
                continue;
            }
            for bit in 0..8u16 {
                if byte & (0x80 >> bit) != 0 {
                    // `byte_index < 32` and `bit < 8`, so both casts are
                    // lossless.
                    let rtype = (u16::from(window) << 8)
                        | (u16::try_from(byte_index).unwrap_or(0) * 8 + bit);
                    types.push(rtype);
                }
            }
        }
        rdata = &rdata[2 + len..];
    }
    Ok(types)
}

/// Encode a sorted type list as a bitmap.
///
/// Windows are emitted in ascending order; trailing zero bytes are
/// stripped from each window so the encoding is canonical.
fn encode_type_bitmap(types: &[u16], out: &mut Vec<u8>) {
    use std::collections::BTreeMap;
    // Group by window (high byte). Within each window, emit the smallest
    // bitmap that covers every type — trailing zero bytes are forbidden.
    let mut windows: BTreeMap<u8, Vec<u8>> = BTreeMap::new();
    for &rtype in types {
        let window = (rtype >> 8) as u8;
        let offset = (rtype & 0xFF) as u8;
        let byte_index = offset / 8;
        let bit = offset % 8;
        let entry = windows.entry(window).or_default();
        if entry.len() <= byte_index as usize {
            entry.resize(byte_index as usize + 1, 0);
        }
        entry[byte_index as usize] |= 0x80 >> bit;
    }
    for (window, mut bitmap) in windows {
        while bitmap.last() == Some(&0) {
            bitmap.pop();
        }
        if bitmap.is_empty() {
            continue;
        }
        out.push(window);
        // The bitmap length is bounded by 32 by construction.
        out.push(u8::try_from(bitmap.len()).unwrap_or(32));
        out.extend_from_slice(&bitmap);
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// RDATA encoding
// ─────────────────────────────────────────────────────────────────────────────

fn encode_rdata(data: &RecordData, out: &mut Vec<u8>) -> Result<()> {
    match data {
        RecordData::A(addr) => out.extend_from_slice(&addr.octets()),
        RecordData::Aaaa(addr) => out.extend_from_slice(&addr.octets()),
        RecordData::Cname(name) | RecordData::Ptr(name) => {
            encode_name(name, out)?;
        }
        RecordData::Txt(raw) => out.extend_from_slice(raw),
        RecordData::Opt(opt) => opt.encode(out)?,
        RecordData::Rrsig(rrsig) => {
            out.extend_from_slice(&rrsig.type_covered.to_be_bytes());
            out.push(rrsig.algorithm.as_u8());
            out.push(rrsig.labels);
            out.extend_from_slice(&rrsig.original_ttl.to_be_bytes());
            out.extend_from_slice(&rrsig.signature_expiration.to_be_bytes());
            out.extend_from_slice(&rrsig.signature_inception.to_be_bytes());
            out.extend_from_slice(&rrsig.key_tag.to_be_bytes());
            encode_name(&rrsig.signer_name, out)?;
            out.extend_from_slice(&rrsig.signature);
        }
        RecordData::Dnskey(key) => {
            out.extend_from_slice(&key.flags.to_be_bytes());
            out.push(key.protocol);
            out.push(key.algorithm.as_u8());
            out.extend_from_slice(&key.public_key);
        }
        RecordData::Ds(ds) => {
            out.extend_from_slice(&ds.key_tag.to_be_bytes());
            out.push(ds.algorithm.as_u8());
            out.push(ds.digest_type);
            out.extend_from_slice(&ds.digest);
        }
        RecordData::Nsec(nsec) => {
            encode_name(&nsec.next_domain_name, out)?;
            encode_type_bitmap(&nsec.types, out);
        }
        RecordData::Unknown(bytes) => out.extend_from_slice(bytes),
    }
    Ok(())
}

// ─────────────────────────────────────────────────────────────────────────────
// Tests
// ─────────────────────────────────────────────────────────────────────────────

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn key_tag_matches_hand_computed_example() {
        // RFC 4034 Appendix B folding, verified by hand rather than by
        // the previous self-referential `key_tag() == key_tag()` no-op.
        //
        // Wire RDATA bytes: flags 0x0102, protocol 0x03, algorithm 0
        // (Unknown), public_key [0x04] =>
        //   [0x01,0x02, 0x03,0x00, 0x04]
        // Pair sum: 0x0102 + 0x0300 = 0x0402; odd remainder byte 0x04
        // contributes 0x04 << 8 = 0x0400. Total = 0x0802. Fold once
        // (no carry). Expected key tag = 0x0802 == 2050.
        let key = DnskeyRdata {
            flags: 0x0102,
            protocol: 3,
            algorithm: DnssecAlgorithm::Unknown(0),
            public_key: vec![0x04],
        };
        assert_eq!(key.key_tag(), 2050);

        // Even-length input, no remainder byte: flags 0x0001, protocol 0,
        // algorithm 0, empty key => [0x00,0x01,0x00,0x00] => 1 + 0 = 1.
        let key2 = DnskeyRdata {
            flags: 0x0001,
            protocol: 0,
            algorithm: DnssecAlgorithm::Unknown(0),
            public_key: vec![],
        };
        assert_eq!(key2.key_tag(), 1);
    }

    #[test]
    fn algorithm_roundtrip() {
        for byte in 0u8..=20 {
            let alg = DnssecAlgorithm::from_u8(byte);
            assert_eq!(alg.as_u8(), byte);
        }
    }

    #[test]
    fn type_bitmap_roundtrip() {
        let types: SmallVec<[u16; 8]> = smallvec::smallvec![1, 5, 28, 46, 47, 48];
        let mut buf = Vec::new();
        encode_type_bitmap(&types, &mut buf);
        let decoded = decode_type_bitmap(&buf).unwrap();
        assert_eq!(decoded.as_slice(), types.as_slice());
    }

    #[test]
    fn type_bitmap_crosses_windows() {
        let types: SmallVec<[u16; 8]> = smallvec::smallvec![1, 256];
        let mut buf = Vec::new();
        encode_type_bitmap(&types, &mut buf);
        let decoded = decode_type_bitmap(&buf).unwrap();
        assert_eq!(decoded.as_slice(), types.as_slice());
    }

    #[test]
    fn dnskey_flag_classification() {
        // These cases are chosen so the SEP bit (0x0001) and the Zone
        // Key bit (0x0100) can be distinguished — the old tests used
        // flags 257/256 where the buggy code happened to agree, masking
        // the bit-position error.

        // SEP only, NOT a zone key. A non-zone key is never KSK or ZSK.
        let sep_only = DnskeyRdata {
            flags: 0x0001,
            protocol: 3,
            algorithm: DnssecAlgorithm::Ed25519,
            public_key: vec![],
        };
        assert!(sep_only.is_sep());
        assert!(!sep_only.is_zone_key());
        assert!(!sep_only.is_ksk());
        assert!(!sep_only.is_zsk());

        // Zone Key only: conventionally a ZSK.
        let zsk = DnskeyRdata {
            flags: 0x0100,
            protocol: 3,
            algorithm: DnssecAlgorithm::Ed25519,
            public_key: vec![],
        };
        assert!(zsk.is_zone_key());
        assert!(!zsk.is_sep());
        assert!(!zsk.is_ksk());
        assert!(zsk.is_zsk());

        // Zone Key + SEP: conventionally a KSK.
        let ksk = DnskeyRdata {
            flags: 0x0101,
            protocol: 3,
            algorithm: DnssecAlgorithm::Ed25519,
            public_key: vec![],
        };
        assert!(ksk.is_zone_key());
        assert!(ksk.is_sep());
        assert!(ksk.is_ksk());
        assert!(!ksk.is_zsk());

        // Neither bit set: a revoked/zone key that is neither.
        let neither = DnskeyRdata {
            flags: 0x0000,
            protocol: 3,
            algorithm: DnssecAlgorithm::Ed25519,
            public_key: vec![],
        };
        assert!(!neither.is_sep());
        assert!(!neither.is_zone_key());
    }
}
