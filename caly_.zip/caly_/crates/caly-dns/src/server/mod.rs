//! Local DNS server.
//!
//! # What this module is
//!
//! The resolver answers questions. This module *receives* them. It
//! binds UDP and TCP sockets, runs the accept loops, and forwards each
//! query to a [`QueryHandler`].
//!
//! # The `QueryHandler` boundary
//!
//! The handler is the only interface between the network layer and the
//! resolver. Everything upstream of this module — resolver, cache,
//! rules — is visible only through that trait. This keeps the server
//! code independent of the DNS logic: a test harness can supply a mock
//! handler that returns canned responses, and the transport layer will
//! not notice.
//!
//! # Structure
//!
//! ```text
//!   udp.rs       — recvmmsg-batched UDP
//!   tcp.rs       — length-prefixed TCP
//!   rrl_hook.rs  — a QueryHandler that wraps another with RRL
//! ```

mod rrl_hook;
mod tcp;
mod udp;

pub use rrl_hook::RrlHandler;
pub use tcp::TcpServer;
pub use udp::UdpServer;

use std::net::SocketAddr;

use crate::error::Result;

/// A query handler.
///
/// The server calls this for every query. Returning `None` means the
/// response should be dropped — for example, because RRL decided to
/// drop it. Returning `Some(bytes)` sends those bytes back to the
/// client.
///
/// The handler is the only interface between the network layer and the
/// resolver; everything above it is invisible to this trait.
#[async_trait::async_trait]
pub trait QueryHandler: Send + Sync {
    /// Process a wire-format query.
    async fn handle(&self, request: &[u8], peer: SocketAddr) -> Option<Vec<u8>>;
}

/// Wrap a handler in an `Arc` for sharing with the server.
///
/// The wrapper exists so call sites do not have to spell out the trait
/// object type; callers with an existing `Arc` can pass it through
/// unchanged.
#[must_use]
pub fn shared<H: QueryHandler + 'static>(handler: H) -> std::sync::Arc<dyn QueryHandler> {
    std::sync::Arc::new(handler)
}

// Silence unused-import warnings under feature combinations.
#[allow(unused_imports)]
use Result as _;
