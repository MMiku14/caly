//! TCP server.
//!
//! # Framing
//!
//! RFC 7766 §8 specifies a two-byte length prefix on every message.
//! The server reads the prefix, then reads exactly that many bytes.
//! A message that announces fewer than 12 bytes (the DNS header) is a
//! protocol violation and the connection is closed.
//!
//! # Connection reuse
//!
//! The server supports multiple queries per connection. A client that
//! sends two queries back to back receives two responses in order.
//! Pipelining (sending query B before A's response has arrived) is not
//! supported: the server reads one query, handles it, writes the
//! response, then reads the next. RFC 7766 permits both modes; the
//! sequential one is simpler and adequate.

use std::net::SocketAddr;
use std::sync::Arc;
use std::time::Duration;

use tokio::io::{AsyncReadExt, AsyncWriteExt};
use tokio::net::TcpListener;
use tokio::sync::watch;
use tokio::time::timeout;

use crate::error::Result;
use crate::server::QueryHandler;
use crate::wire::message::DnsMessage;

/// Two bytes cap the length field at 65535, which is also the DNS
/// message size limit, so no additional bound is needed.
const MAX_MESSAGE_LEN: usize = u16::MAX as usize;

/// How long a connection may sit idle before the server closes it.
///
/// RFC 7766 §6.2.3 recommends two to five minutes. The local resolver
/// mostly speaks to loopback clients that rarely idle, so a shorter
/// timeout keeps file-descriptor pressure low without dropping useful
/// sessions.
const IDLE_TIMEOUT: Duration = Duration::from_secs(30);

/// A TCP server bound to one address.
pub struct TcpServer {
    handler: Arc<dyn QueryHandler>,
}

impl TcpServer {
    /// Bind a TCP server that dispatches every connection to `handler`.
    #[must_use]
    pub fn new(handler: Arc<dyn QueryHandler>) -> Self {
        Self { handler }
    }

    /// Run the accept loop until `shutdown` fires.
    /// # Errors
    ///
    /// Returns an error if TCP socket binding or stream processing fails fatally.
    pub async fn run(
        self: Arc<Self>,
        listener: TcpListener,
        mut shutdown: watch::Receiver<()>,
    ) -> Result<()> {
        loop {
            tokio::select! {
                biased;

                _ = shutdown.changed() => {
                    tracing::debug!("tcp server shutting down");
                    return Ok(());
                }

                accepted = listener.accept() => {
                    let (stream, peer) = accepted?;
                    let handler = Arc::clone(&self.handler);
                    tokio::spawn(async move {
                        if let Err(e) = serve_connection(stream, peer, handler).await {
                            tracing::debug!(
                                peer = %peer,
                                error = %e,
                                "tcp connection ended"
                            );
                        }
                    });
                }
            }
        }
    }
}

/// Serve one client connection until it closes or times out.
async fn serve_connection(
    mut stream: tokio::net::TcpStream,
    peer: SocketAddr,
    handler: Arc<dyn QueryHandler>,
) -> std::io::Result<()> {
    let _ = stream.set_nodelay(true);

    loop {
        // Read the 2-byte length prefix.
        let mut len_buf = [0u8; 2];
        match timeout(IDLE_TIMEOUT, stream.read_exact(&mut len_buf)).await {
            Err(_) => return Ok(()),            // idle timeout
            Ok(Err(e)) if e.kind() == std::io::ErrorKind::UnexpectedEof => {
                return Ok(());                   // client closed
            }
            Ok(Err(e)) => return Err(e),
            Ok(Ok(_)) => {}
        }

        let len = usize::from(u16::from_be_bytes(len_buf));
        if !(12..=MAX_MESSAGE_LEN).contains(&len) {
            return Err(std::io::Error::new(
                std::io::ErrorKind::InvalidData,
                format!("invalid DNS message length: {len}"),
            ));
        }

        // Read the message body.
        let mut body = vec![0u8; len];
        timeout(IDLE_TIMEOUT, stream.read_exact(&mut body)).await??;

        // Parse before dispatching so a malformed frame never reaches
        // the resolver. The handler parses again; the duplicated work is
        // small relative to the round trip it guards.
        if DnsMessage::parse(&body).is_err() {
            return Err(std::io::Error::new(
                std::io::ErrorKind::InvalidData,
                "malformed DNS query",
            ));
        }

        // Dispatch.
        let Some(response) = handler.handle(&body, peer).await else {
            // Handler chose to drop (RRL, for instance). Close the
            // connection: TCP has no "drop silently" semantics, and
            // leaving the client waiting would be worse.
            return Ok(());
        };

        // Write the response with its length prefix.
        let response_len = u16::try_from(response.len()).map_err(|_| {
            std::io::Error::new(
                std::io::ErrorKind::InvalidData,
                "response too large for TCP framing",
            )
        })?;
        stream.write_all(&response_len.to_be_bytes()).await?;
        stream.write_all(&response).await?;
        stream.flush().await?;
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn constants_are_sensible() {
        assert!(MAX_MESSAGE_LEN >= 1232);
        assert!(IDLE_TIMEOUT.as_secs() > 0);
    }
}
