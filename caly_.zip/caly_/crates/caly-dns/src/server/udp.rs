//! Local UDP server with `recvmmsg` batching.
//!
//! # The problem
//!
//! A naive UDP server does one `recv_from` per datagram. Each call is a
//! syscall (~200 ns), plus the per-datagram allocation of a receive
//! buffer. At 100k QPS that is 100k syscalls per second per core, and
//! malloc/free churn that dominates the throughput ceiling.
//!
//! # The approach
//!
//! Linux's `recvmmsg(2)` reads up to 32 datagrams in a single syscall.
//! The caller pre-allocates the buffers and the `mmsghdr` array; the
//! kernel fills them in. After the call, each slot carries a datagram
//! and its source address.
//!
//! We combine that with `SO_REUSEPORT` so each worker thread owns its
//! own socket, and the kernel load-balances incoming packets across
//! them. There is no shared state between workers.
//!
//! # Safety
//!
//! `recvmmsg` is a raw FFI call. The buffers we hand it must:
//!
//! 1. Outlive the call. Enforced by keeping the buffer arena in this
//!    struct, not on the stack.
//! 2. Not be aliased. Each slot has exclusive access during the call.
//! 3. Be fully initialized. `memset` before the call zeroes them.
//!
//! All three hold in the code below; the raw pointers are constructed
//! fresh for every batch and never stored.

use std::io;
use std::net::SocketAddr;
use std::os::fd::{AsRawFd, RawFd};
use std::sync::Arc;

use tokio::net::UdpSocket;
use tokio::sync::mpsc;

use crate::server::QueryHandler;

/// Number of datagrams read per `recvmmsg` call.
///
/// Larger values amortize syscall cost further but increase latency for
/// the last packet in the batch. 32 keeps the whole arena inside L1
/// (32 × 1500 B = 48 KiB) and tail latency under ~50 µs on typical
/// hardware.
const BATCH_SIZE: usize = 32;

/// Per-datagram buffer size. The EDNS0 ceiling is 1232 bytes, but the
/// arena is sized so a client that ignores the advertised payload
/// still has its datagram delivered rather than truncated.
const BUF_SIZE: usize = 1500;

/// A UDP server bound to one address.
pub struct UdpServer {
    handler: Arc<dyn QueryHandler>,
    /// Datagram buffer arena. Reused across batches; never reallocated
    /// after construction. Each slot is written by the kernel before the
    /// corresponding `msg_len` is read.
    buffers: Box<[[u8; BUF_SIZE]; BATCH_SIZE]>,
    /// Scratch storage for the source addresses. Entries below
    /// `msg_len > 0` are initialised by the kernel.
    sources: Box<[std::mem::MaybeUninit<libc::sockaddr_storage>; BATCH_SIZE]>,
    /// Scratch storage for the per-datagram iovecs.
    iovecs: Box<[libc::iovec; BATCH_SIZE]>,
    /// Scratch storage for the mmsghdrs handed to the kernel.
    msgs: Box<[libc::mmsghdr; BATCH_SIZE]>,
}

// SAFETY: `UdpServer` holds raw pointer buffers for `recvmmsg` that point exclusively
// to heap memory owned by `self`. It is never concurrently accessed and is safe to send.
#[allow(clippy::non_send_fields_in_send_ty)]
unsafe impl Send for UdpServer {}

impl UdpServer {
    /// Create a server. The `handler` is called for every datagram; it
    /// returns the response bytes (if any) which are sent back to the
    /// source address.
    /// # Panics
    ///
    /// Panics if heap buffer allocation cannot be converted to a fixed-size array.
    pub fn new(handler: Arc<dyn QueryHandler>) -> Self {
        Self {
            handler,
            buffers: vec![[0u8; BUF_SIZE]; BATCH_SIZE].into_boxed_slice().try_into().unwrap(),
            // SAFETY: MaybeUninit is initialized to uninit, which is
            // valid for the type.
            sources: Box::new([const { std::mem::MaybeUninit::uninit() }; BATCH_SIZE]),
            iovecs: Box::new(
                [const { libc::iovec {
                    iov_base: std::ptr::null_mut(),
                    iov_len: 0,
                } }; BATCH_SIZE],
            ),
            msgs: Box::new(
                [const { libc::mmsghdr {
                    // SAFETY: `msghdr` is an all-primitive C struct where all-zero bit pattern is valid representation.
                    msg_hdr: unsafe { std::mem::zeroed() },
                    msg_len: 0,
                } }; BATCH_SIZE],
            ),
        }
    }

    /// Run the receive loop on `socket` until `shutdown` fires.
    ///
    /// Each datagram is dispatched to a task through `handler`. The
    /// responses are sent back on the same socket; because UDP is
    /// connectionless this requires no per-client state.
    /// # Errors
    ///
    /// Returns an [`io::Error`] if reading from or polling the socket encounters a fatal I/O failure.
    pub async fn run(
        mut self,
        socket: Arc<UdpSocket>,
        mut shutdown: mpsc::Receiver<()>,
    ) -> io::Result<()> {
        // `recvmmsg` is a blocking-style syscall. We use a raw
        // non-blocking fd and drive readiness through the tokio reactor.
        socket.readable().await?;
        let fd = socket.as_raw_fd();

        loop {
            tokio::select! {
                biased;

                _ = shutdown.recv() => {
                    tracing::debug!("udp server shutting down");
                    return Ok(());
                }

                readable = socket.readable() => {
                    readable?;
                    self.drain_batch(&socket, fd);
                }
            }
        }
    }

    /// Read one batch and process every datagram.
    ///
    /// The function itself performs no asynchronous work: `recvmmsg`
    /// is a synchronous syscall and the response dispatch is handed to
    /// `tokio::spawn`. Only the await inside that spawned task is
    /// asynchronous.
    fn drain_batch(&mut self, socket: &Arc<UdpSocket>, fd: RawFd) {
        // SAFETY: `socket` is a valid file descriptor and `msgs` points to initialized `mmsghdr` buffers.
        let received = match unsafe { recvmmsg(
            fd,
            &mut self.msgs[..],
            &mut self.iovecs[..],
            &mut self.buffers[..],
            &mut self.sources[..],
        ) } {
            Ok(n) => n,
            Err(e) if e.kind() == io::ErrorKind::WouldBlock => return,
            Err(e) => {
                tracing::warn!(error = %e, "recvmmsg failed");
                return;
            }
        };

        for slot in 0..received {
            let len = self.msgs[slot].msg_len as usize;
            if len == 0 {
                continue;
            }
            let source = parse_sockaddr(&self.sources[slot]);
            let data = self.buffers[slot][..len].to_vec();

            let handler = Arc::clone(&self.handler);
            let socket = Arc::clone(socket);

            tokio::spawn(async move {
                if let Some(response) = handler.handle(&data, source).await {
                    let _ = socket.send_to(&response, source).await;
                }
            });
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// FFI plumbing
// ─────────────────────────────────────────────────────────────────────────────

/// One `recvmmsg(2)` call.
///
/// # Safety
///
/// The caller must ensure `msgs`, `iovecs`, `buffers`, and `sources`
/// are all length `BATCH_SIZE`, and that they all outlive the call. The
/// function re-initializes `msgs` and `iovecs` on every invocation, so
/// they may be reused.
unsafe fn recvmmsg(
    fd: RawFd,
    msgs: &mut [libc::mmsghdr],
    iovecs: &mut [libc::iovec],
    buffers: &mut [[u8; BUF_SIZE]],
    sources: &mut [std::mem::MaybeUninit<libc::sockaddr_storage>],
) -> io::Result<usize> {
    debug_assert_eq!(msgs.len(), iovecs.len());
    debug_assert_eq!(msgs.len(), buffers.len());
    debug_assert_eq!(msgs.len(), sources.len());

    let count = msgs.len();

    // Prepare iovecs and mmsghdrs fresh on every call: the kernel may
    // mutate them, so any state left over from the previous batch is
    // stale.
    for i in 0..count {
        iovecs[i] = libc::iovec {
            iov_base: buffers[i].as_mut_ptr().cast(),
            iov_len: buffers[i].len(),
        };

        // Zero the msg_hdr. We could use MaybeUninit, but the cost of a
        // 56-byte memset is negligible compared to the syscall and the
        // remaining code is clearer without it.
        msgs[i].msg_hdr = std::mem::zeroed();
        msgs[i].msg_hdr.msg_name = sources[i].as_mut_ptr().cast();
        msgs[i].msg_hdr.msg_namelen =
            libc::socklen_t::try_from(std::mem::size_of::<libc::sockaddr_storage>()).unwrap_or(0);
        msgs[i].msg_hdr.msg_iov = &raw mut iovecs[i];
        msgs[i].msg_hdr.msg_iovlen = 1;
        msgs[i].msg_len = 0;
    }

    let ret = libc::recvmmsg(
        fd,
        msgs.as_mut_ptr(),
        libc::c_uint::try_from(count).unwrap_or(0),
        libc::MSG_DONTWAIT,
        std::ptr::null_mut(),
    );

    if ret < 0 {
        return Err(io::Error::last_os_error());
    }
    Ok(usize::try_from(ret).unwrap_or(0))
}

/// Decode a `sockaddr_storage` into a `SocketAddr`.
fn parse_sockaddr(storage: &std::mem::MaybeUninit<libc::sockaddr_storage>) -> SocketAddr {
    // SAFETY: `recvmmsg` initialized this slot on success. The caller
    // only invokes this function for slots < `received`.
    let storage = unsafe { storage.assume_init_ref() };

    match libc::c_int::from(storage.ss_family) {
        libc::AF_INET => {
            // SAFETY: the family field says this is a v4 address.
            let sin = unsafe { &*std::ptr::from_ref(storage).cast::<libc::sockaddr_in>() };
            let ip = std::net::Ipv4Addr::from(u32::from_be(sin.sin_addr.s_addr));
            SocketAddr::new(std::net::IpAddr::V4(ip), u16::from_be(sin.sin_port))
        }
        libc::AF_INET6 => {
            // SAFETY: the family field says this is a v6 address.
            let sin6 = unsafe { &*std::ptr::from_ref(storage).cast::<libc::sockaddr_in6>() };
            let ip = std::net::Ipv6Addr::from(sin6.sin6_addr.s6_addr);
            SocketAddr::new(std::net::IpAddr::V6(ip), u16::from_be(sin6.sin6_port))
        }
        // Unknown family: the caller logs and drops the datagram.
        _ => SocketAddr::from(([0u8; 4], 0)),
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Tests
// ─────────────────────────────────────────────────────────────────────────────

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn buffer_sizes_are_sensible() {
        assert!(BUF_SIZE >= 1232, "must hold a max-size EDNS0 query");
        assert!(BATCH_SIZE > 1, "batching only helps above 1");
        assert!(
            std::mem::size_of::<[u8; BUF_SIZE]>() * BATCH_SIZE < 128 * 1024,
            "batch arena must fit in L1"
        );
    }

    #[test]
    fn parse_sockaddr_v4() {
        let mut storage: std::mem::MaybeUninit<libc::sockaddr_storage> =
            std::mem::MaybeUninit::zeroed();
        // Fill in an AF_INET sockaddr for 127.0.0.1:5353.
        unsafe {
            let s = storage.as_mut_ptr();
            (*s).ss_family = libc::AF_INET as libc::sa_family_t;
            let sin = s as *mut libc::sockaddr_in;
            (*sin).sin_addr.s_addr = u32::to_be(u32::from(std::net::Ipv4Addr::LOCALHOST));
            (*sin).sin_port = u16::to_be(5353);
        }
        let addr = parse_sockaddr(&storage);
        assert_eq!(addr.port(), 5353);
        assert!(addr.ip().is_loopback());
    }
}
