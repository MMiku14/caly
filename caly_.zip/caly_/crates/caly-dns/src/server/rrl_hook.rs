//! RRL applied as a `QueryHandler` wrapper.
//!
//! # Composition over intrusion
//!
//! RRL could be built into the resolver: it would check every response
//! before returning it. But that would mean the resolver knows about
//! rate limiting, and the rate limiter knows about resolution. They are
//! orthogonal concerns.
//!
//! This module composes them. [`RrlHandler`] wraps an inner handler; on
//! every call, it checks the rate limiter, then either forwards to the
//! inner handler or drops/truncates.
//!
//! # The truncated path
//!
//! When RRL says "truncate", we send a DNS response with the TC bit set
//! and no answers. A conformant client retries over TCP. Over TCP, the
//! client's source address cannot be spoofed, so the retry is not a
//! threat and passes the limiter.

use std::net::SocketAddr;
use std::sync::Arc;

use crate::rrl::{Rrl, RrlVerdict};
use crate::server::QueryHandler;
use crate::wire::message::DnsMessage;

/// A handler that applies RRL before delegating.
pub struct RrlHandler {
    inner: Arc<dyn QueryHandler>,
    rrl: Arc<Rrl>,
}

impl RrlHandler {
    /// Wrap `inner` so every response passes through `rrl` first.
    #[must_use]
    pub fn new(inner: Arc<dyn QueryHandler>, rrl: Arc<Rrl>) -> Self {
        Self { inner, rrl }
    }
}

#[async_trait::async_trait]
impl QueryHandler for RrlHandler {
    async fn handle(&self, request: &[u8], peer: SocketAddr) -> Option<Vec<u8>> {
        // Peek at the question to build the RRL key. A malformed query
        // has no question to key on; forwarding to the inner handler
        // will produce a FORMERR, which is fine.
        let verdict = match DnsMessage::parse(request) {
            Ok(query) => query.questions.first().map_or(RrlVerdict::Pass, |question| {
                self.rrl
                    .check(peer.ip(), question.name.as_str(), question.qtype)
            }),
            Err(_) => RrlVerdict::Pass,
        };

        match verdict {
            RrlVerdict::Pass => self.inner.handle(request, peer).await,
            RrlVerdict::Drop => {
                tracing::debug!(peer = %peer, "RRL dropped response");
                None
            }
            RrlVerdict::Truncate => {
                tracing::debug!(peer = %peer, "RRL slipping truncated response");
                Some(build_truncated_response(request))
            }
        }
    }
}

/// Build a `TC=1` response that echoes the question.
///
/// A truncated error is still a valid DNS response, and a conformant
/// client will retry over TCP where the source address cannot be
/// spoofed.
fn build_truncated_response(request: &[u8]) -> Vec<u8> {
    match DnsMessage::parse(request) {
        Ok(query) => {
            let response = DnsMessage {
                header: crate::wire::message::DnsHeader {
                    id: query.header.id,
                    // QR=1, RD copied, RA=1, TC=1.
                    flags: crate::wire::FLAG_QR
                        | (query.header.flags & crate::wire::FLAG_RD)
                        | crate::wire::FLAG_RA
                        | crate::wire::FLAG_TC,
                    qdcount: 1,
                    ancount: 0,
                    nscount: 0,
                    arcount: 0,
                },
                questions: query.questions,
                answers: Vec::new(),
                authorities: Vec::new(),
                additionals: Vec::new(),
            };
            response.serialize().unwrap_or_default()
        }
        Err(_) => Vec::new(),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn truncated_response_echoes_id() {
        let request = DnsMessage::new_query(0x1234, "example.com", 1);
        let wire = request.serialize_query().unwrap();
        let response = build_truncated_response(&wire);
        let parsed = DnsMessage::parse(&response).unwrap();
        assert_eq!(parsed.header.id, 0x1234);
        assert!(parsed.header.is_truncated());
        assert_eq!(parsed.questions.len(), 1);
        assert_eq!(parsed.answers.len(), 0);
    }
}
