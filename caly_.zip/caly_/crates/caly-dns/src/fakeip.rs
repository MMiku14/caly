//! `FakeIP` address pool.
//!
//! # Why `FakeIPs`
//!
//! A transparent proxy needs the client's traffic to reach the proxy,
//! not the real server. For IPv4 the OS gives us one knob: the routing
//! table. For IPv6 the story is the same. `FakeIP` intercepts the *DNS*
//! answer: instead of returning the real address of `api.example.com`,
//! the Client Plane returns a virtual one. When the client connects to
//! the virtual address, the kernel routes it to the proxy, and the
//! proxy looks up which name it stands for.
//!
//! # Deterministic allocation
//!
//! The mapping from name to virtual address is derived from an FNV hash
//! of the name. Same name, same virtual address — across restarts, and
//! across every Caly process pointed at the same pool. This matters
//! because the client caches the address: if we hand out a different
//! virtual address after a restart, in-flight connections break.
//!
//! # Linear probing on collision
//!
//! A hash-derived slot may already be occupied. The pool probes
//! forward, up to `MAX_PROBE` steps, then falls back to a cursor-based
//! scan for the common case of a nearly-full pool.
//!
//! # TTL, not refcounts
//!
//! Liveness is expressed by re-allocation: a name that is queried again
//! refreshes its deadline. There is no reference count to leak. The
//! cost is that an idle name is freed after the TTL even if some client
//! still holds a reference — which is correct, because the client will
//! re-query when it needs the address again.

use std::collections::HashMap;
use std::net::{IpAddr, Ipv4Addr, Ipv6Addr};
use std::sync::atomic::{AtomicU64, AtomicUsize, Ordering};
use std::time::{Duration, Instant};

use parking_lot::RwLock;
use smol_str::SmolStr;

use crate::error::{Error, Result};
use crate::util::{fnv1a, normalize_domain};

/// Maximum probe steps before falling back to a full scan.
const MAX_PROBE: usize = 32;

/// Capacity of the domain→ip accelerator.
const ACCELERATOR_CAPACITY: usize = 8192;

// ─────────────────────────────────────────────────────────────────────────────
// CIDR ranges
// ─────────────────────────────────────────────────────────────────────────────

/// A parsed IPv4 CIDR block.
#[derive(Debug, Clone, Copy)]
pub struct IpRange4 {
        /// First address of the range, as a host-order u32.
pub base: u32,
    /// Total number of assignable addresses in the IPv4 range.
    pub capacity: u32,
}

impl IpRange4 {
    /// Parse `"A.B.C.D/prefix"`.
    /// # Errors
    ///
    /// Returns an error string if `spec` is not a valid IPv4 CIDR string.
    pub fn parse(spec: &str) -> std::result::Result<Self, String> {
        let (addr, prefix) = spec
            .split_once('/')
            .ok_or_else(|| format!("invalid IPv4 CIDR: {spec}"))?;
        let ip: Ipv4Addr = addr
            .trim()
            .parse()
            .map_err(|e| format!("invalid IPv4 in '{spec}': {e}"))?;
        let prefix: u32 = prefix
            .trim()
            .parse()
            .map_err(|e| format!("invalid IPv4 prefix in '{spec}': {e}"))?;
        if prefix > 32 {
            return Err(format!("IPv4 prefix out of range: {prefix}"));
        }
        let host_bits = 32 - prefix;
        // Build the mask without ever shifting by 32 bits. `prefix` is
        // already validated to be <= 32, so the `prefix == 0` branch
        // covers the only case where the shift would be out of range.
        let mask = match prefix {
            0 => 0,
            32 => u32::MAX,
            _ => !((1u32 << host_bits) - 1),
        };
        let base = u32::from(ip) & mask;
        // Cap at 2^18 entries (262,144) to prevent massive memory footprint in Bitmap.
        let capacity = if host_bits >= 18 {
            1u32 << 18
        } else {
            1u32.checked_shl(host_bits).unwrap_or(u32::MAX)
        };
        Ok(Self { base, capacity })
    }

    #[inline]
    fn to_ip(self, index: usize) -> IpAddr {
        let offset = u32::try_from(index).unwrap_or(u32::MAX);
        IpAddr::V4(Ipv4Addr::from(self.base + offset))
    }

    #[inline]
    fn offset_of(self, ip: IpAddr) -> Option<usize> {
        let IpAddr::V4(v4) = ip else { return None };
        let value = u32::from(v4);
        if value < self.base {
            return None;
        }
        let offset = value - self.base;
        (offset < self.capacity).then_some(offset as usize)
    }
}

/// A parsed IPv6 CIDR block. Capacity is clamped to `u32::MAX`.
#[derive(Debug, Clone, Copy)]
pub struct IpRange6 {
        /// First address of the range, as a host-order u128.
pub base: u128,
    /// Total number of assignable addresses in the IPv6 range.
    pub capacity: u32,
}

impl IpRange6 {
    /// Parse `"2001:db8::/prefix"`.
    ///
    /// # Errors
    ///
    /// Returns an error string if `spec` is not a valid IPv6 CIDR string.
    pub fn parse(spec: &str) -> std::result::Result<Self, String> {
        let (addr, prefix) = spec
            .split_once('/')
            .ok_or_else(|| format!("invalid IPv6 CIDR: {spec}"))?;
        let ip: Ipv6Addr = addr
            .trim()
            .parse()
            .map_err(|e| format!("invalid IPv6 in '{spec}': {e}"))?;
        let prefix: u32 = prefix
            .trim()
            .parse()
            .map_err(|e| format!("invalid IPv6 prefix in '{spec}': {e}"))?;
        if prefix > 128 {
            return Err(format!("IPv6 prefix out of range: {prefix}"));
        }
        let host_bits = 128 - prefix;
        // `/0` keeps no bits; anything wider than `/128` is rejected
        // above, so the only out-of-range shift is `prefix == 0`.
        let mask = if prefix == 0 {
            0
        } else {
            u128::MAX.checked_shl(host_bits).unwrap_or(0)
        };
        let base = u128::from(ip) & mask;
        // Cap at 2^18 entries: the bitmap alone is 32 KiB at that size,
        // which keeps the pool footprint bounded.
        let capacity = if host_bits >= 18 {
            1u32 << 18
        } else {
            1u32 << host_bits
        };
        Ok(Self { base, capacity })
    }

    #[inline]
    fn to_ip(self, index: usize) -> IpAddr {
        IpAddr::V6(Ipv6Addr::from(self.base + index as u128))
    }

    #[inline]
    fn offset_of(self, ip: IpAddr) -> Option<usize> {
        let IpAddr::V6(v6) = ip else { return None };
        let value = u128::from(v6);
        if value < self.base {
            return None;
        }
        let offset = value - self.base;
        (offset < u128::from(self.capacity)).then_some(offset as usize)
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Bitmap
// ─────────────────────────────────────────────────────────────────────────────

struct Bitmap {
    words: Box<[AtomicU64]>,
}

impl Bitmap {
    fn new(capacity: u32) -> Self {
        let word_count = (capacity as usize).div_ceil(64);
        let words = (0..word_count)
            .map(|_| AtomicU64::new(0))
            .collect::<Vec<_>>()
            .into_boxed_slice();
        Self { words }
    }

    #[inline]
    fn try_claim(&self, index: usize) -> bool {
        let word = index / 64;
        if word >= self.words.len() {
            return false;
        }
        let bit = index % 64;
        let mask = 1u64 << bit;
        // Optimistic probe: quickly bail out if already taken to avoid cache line bouncing.
        if (self.words[word].load(Ordering::Relaxed) & mask) != 0 {
            return false;
        }
        self.words[word].fetch_or(mask, Ordering::AcqRel) & mask == 0
    }

    #[inline]
    fn release(&self, index: usize) {
        let word = index / 64;
        // Bounds-check the word index so a stale ip cannot panic the
        // release path.
        if word >= self.words.len() {
            return;
        }
        let bit = index % 64;
        let mask = !(1u64 << bit);
        self.words[word].fetch_and(mask, Ordering::AcqRel);
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Pool
// ─────────────────────────────────────────────────────────────────────────────

struct Entry {
    domain: SmolStr,
    expires_at: Instant,
}

/// The `FakeIP` pool.
pub struct FakeIpPool {
    v4_range: IpRange4,
    v4_bits: Bitmap,
    v4_cursor: AtomicUsize,

    v6_range: IpRange6,
    v6_bits: Bitmap,
    v6_cursor: AtomicUsize,

    /// Authoritative: ip → entry.
    reverse: RwLock<HashMap<IpAddr, Entry>>,
    /// Non-authoritative accelerator: domain → ip. May be evicted.
    forward: RwLock<HashMap<SmolStr, IpAddr>>,

    ttl: Duration,

    allocated: AtomicU64,
    released: AtomicU64,
    exhausted: AtomicU64,
}

impl FakeIpPool {
    /// Construct a pool from two ranges and a TTL.
    #[must_use]
    pub fn new(v4: IpRange4, v6: IpRange6, ttl: Duration) -> Self {
        Self {
            v4_range: v4,
            v4_bits: Bitmap::new(v4.capacity),
            v4_cursor: AtomicUsize::new(0),
            v6_range: v6,
            v6_bits: Bitmap::new(v6.capacity),
            v6_cursor: AtomicUsize::new(0),
            reverse: RwLock::new(HashMap::with_capacity(4096)),
            forward: RwLock::new(HashMap::with_capacity(ACCELERATOR_CAPACITY)),
            ttl,
            allocated: AtomicU64::new(0),
            released: AtomicU64::new(0),
            exhausted: AtomicU64::new(0),
        }
    }

    /// Build a pool from a config block.
    ///
    /// # Errors
    ///
    /// Returns [`Error::Config`] if CIDR blocks cannot be parsed.
    pub fn from_config(cfg: &crate::config::FakeIpConfig) -> Result<Self> {
        let v4 = IpRange4::parse(&cfg.inet4_range)
            .map_err(Error::config)?;
        let v6 = IpRange6::parse(&cfg.inet6_range)
            .map_err(Error::config)?;
        Ok(Self::new(v4, v6, Duration::from_secs(cfg.global_ttl)))
    }

    /// Allocate a virtual address for `name`.
    ///
    /// Idempotent within the TTL: successive calls with the same name
    /// return the same address and refresh its deadline.
    /// # Errors
    ///
    /// Returns [`Error::FakeIpExhausted`] if the allocation pool is full.
    pub fn allocate(&self, name: &str, prefer_v6: bool) -> Result<IpAddr> {
        let norm = normalize_domain(name);
        let key = SmolStr::new(norm.as_ref());

        // Fast path: accelerator hit with ghost entry detection
        let cached_ip = self.forward.read().get(&key).copied();
        if let Some(ip) = cached_ip {
            if self.touch(&ip) {
                return Ok(ip);
            }
            // Evicted from reverse mapping; purge dirty entry from forward table immediately.
            self.forward.write().remove(&key);
        }

        // Slow path: allocate under the write lock.
        let hash = fnv1a(key.as_bytes());

        let candidates: [(Family, u64); 2] = if prefer_v6 {
            [(Family::V6, hash), (Family::V4, hash)]
        } else {
            [(Family::V4, hash), (Family::V6, hash)]
        };

        for (family, hash) in candidates {
            if let Some(index) = self.try_claim(family, hash) {
                let ip = match family {
                    Family::V4 => self.v4_range.to_ip(index),
                    Family::V6 => self.v6_range.to_ip(index),
                };
                let final_ip = self.commit(&key, ip);
                return Ok(final_ip);
            }
        }

        self.exhausted.fetch_add(1, Ordering::Relaxed);
        Err(Error::FakeIpExhausted)
    }

    /// Reverse lookup: virtual address → name.
    #[must_use]
    pub fn lookup(&self, ip: IpAddr) -> Option<SmolStr> {
        self.reverse.read().get(&ip).map(|e| e.domain.clone())
    }

    /// Drop expired entries. Returns the number removed.
    ///
    /// Takes a read lock first so a sweep on a cold pool costs nothing
    /// beyond a shared borrow; only when an expired entry is observed
    /// does the function escalate to the write lock.
    pub fn sweep_expired(&self) -> usize {
        let now = Instant::now();
        // Fast path: if nothing is expired, return without touching
        // the write lock.
        {
            let reverse_guard = self.reverse.read();
            if !reverse_guard.values().any(|e| now >= e.expires_at) {
                return 0;
            }
        }
        let mut reverse = self.reverse.write();
        let mut forward = self.forward.write();

        let mut expired = Vec::new();
        for (&ip, entry) in reverse.iter() {
            if now >= entry.expires_at {
                expired.push((ip, entry.domain.clone()));
            }
        }

        let count = expired.len();
        for (ip, domain) in expired {
            self.release_bit(ip);
            reverse.remove(&ip);
            forward.remove(&domain);
            self.released.fetch_add(1, Ordering::Relaxed);
        }
        drop(reverse);
        drop(forward);
        count
    }

    /// Total successful allocations since construction.
    #[must_use]
    pub fn allocated_count(&self) -> u64 {
        self.allocated.load(Ordering::Relaxed)
    }

    /// Total slots released by `sweep_expired`.
    #[must_use]
    pub fn released_count(&self) -> u64 {
        self.released.load(Ordering::Relaxed)
    }

    /// Total allocation attempts that found the pool empty.
    #[must_use]
    pub fn exhausted_count(&self) -> u64 {
        self.exhausted.load(Ordering::Relaxed)
    }

    /// Total number of distinct slots across both families.
    #[must_use]
    pub fn capacity(&self) -> u64 {
        u64::from(self.v4_range.capacity) + u64::from(self.v6_range.capacity)
    }

    /// Number of names currently holding a slot.
    #[must_use]
    pub fn live_count(&self) -> usize {
        self.reverse.read().len()
    }

    // ── Internals ─────────────────────────────────────────────────────

    fn touch(&self, ip: &IpAddr) -> bool {
        let now = Instant::now();
        {
            let reverse = self.reverse.read();
            if let Some(entry) = reverse.get(ip) {
                if now >= entry.expires_at {
                    return false;
                }
                // Avoid acquiring exclusive write lock if plenty of TTL remains.
                // checked_duration_since guards the non-monotonic-clock case.
                if entry
                    .expires_at
                    .checked_duration_since(now)
                    .is_some_and(|d| d > self.ttl / 2)
                {
                    return true;
                }
            } else {
                return false;
            }
        }
        let mut reverse = self.reverse.write();
        if let Some(entry) = reverse.get_mut(ip) {
            if now < entry.expires_at {
                entry.expires_at = now + self.ttl;
                true
            } else {
                false
            }
        } else {
            false
        }
    }

    fn commit(&self, name: &SmolStr, ip: IpAddr) -> IpAddr {
        let now = Instant::now();
        // Acquire locks in uniform hierarchical order (reverse -> forward) to eliminate ABBA deadlock
        let mut reverse = self.reverse.write();
        let mut forward = self.forward.write();
        if let Some(&existing_ip) = forward.get(name) {
            // A live forward entry whose reverse slot is still valid: reuse it.
            if matches!(reverse.get(&existing_ip), Some(e) if now < e.expires_at) {
                // Safe: the match above proved the entry exists and is live.
                if let Some(entry) = reverse.get_mut(&existing_ip) {
                    entry.expires_at = now + self.ttl;
                }
                drop(forward);
                drop(reverse);
                self.release_bit(ip);
                return existing_ip;
            }
            // The forward pointer is stale: its reverse entry already expired
            // or was swept. The old address is still claimed in the bitmap, so
            // release it before handing the name a fresh slot — otherwise every
            // re-allocation after a sweep leaks one bit and the pool slowly
            // degrades toward permanent FakeIpExhausted.
            self.release_bit(existing_ip);
            reverse.remove(&existing_ip);
        }
        reverse.insert(
            ip,
            Entry {
                domain: name.clone(),
                expires_at: now + self.ttl,
            },
        );
        if forward.len() >= ACCELERATOR_CAPACITY && !forward.contains_key(name) {
            if let Some(k) = forward.keys().next().cloned() {
                forward.remove(&k);
            }
        }
        forward.insert(name.clone(), ip);
        drop(forward);
        drop(reverse);
        self.allocated.fetch_add(1, Ordering::Relaxed);
        ip
    }

    #[allow(clippy::cast_possible_truncation)]
    fn try_claim(&self, family: Family, hash: u64) -> Option<usize> {
        let (bitmap, capacity, cursor) = match family {
            Family::V4 => (
                &self.v4_bits,
                self.v4_range.capacity as usize,
                &self.v4_cursor,
            ),
            Family::V6 => (
                &self.v6_bits,
                self.v6_range.capacity as usize,
                &self.v6_cursor,
            ),
        };
        if capacity == 0 {
            return None;
        }

        let start = (hash as usize) % capacity;
        let probe_bound = MAX_PROBE.min(capacity);
        for step in 0..probe_bound {
            let index = (start + step) % capacity;
            if bitmap.try_claim(index) {
                return Some(index);
            }
        }

        // Fall back to cursor scan.
        let scan_start = cursor.load(Ordering::Relaxed) % capacity;
        for step in 0..capacity {
            let index = (scan_start + step) % capacity;
            if bitmap.try_claim(index) {
                cursor.store((index + 1) % capacity, Ordering::Relaxed);
                return Some(index);
            }
        }
        None
    }

    fn release_bit(&self, ip: IpAddr) {
        if let Some(index) = self.v4_range.offset_of(ip) {
            self.v4_bits.release(index);
        } else if let Some(index) = self.v6_range.offset_of(ip) {
            self.v6_bits.release(index);
        }
    }
}

#[derive(Debug, Clone, Copy)]
enum Family {
    V4,
    V6,
}

#[cfg(test)]
mod tests {
    use super::*;

    fn small_pool(ttl: Duration) -> FakeIpPool {
        FakeIpPool::new(
            IpRange4::parse("198.18.0.0/24").unwrap(),
            IpRange6::parse("fc00::/120").unwrap(),
            ttl,
        )
    }

    #[test]
    fn idempotent_within_ttl() {
        let pool = small_pool(Duration::from_secs(300));
        let a = pool.allocate("example.com", false).unwrap();
        let b = pool.allocate("EXAMPLE.COM.", false).unwrap();
        assert_eq!(a, b);
    }

    #[test]
    fn deterministic_across_instances() {
        let a = small_pool(Duration::from_secs(300));
        let b = small_pool(Duration::from_secs(300));
        assert_eq!(
            a.allocate("example.com", false).unwrap(),
            b.allocate("example.com", false).unwrap(),
        );
    }

    #[test]
    fn reverse_lookup_works() {
        let pool = small_pool(Duration::from_secs(300));
        let ip = pool.allocate("example.com", false).unwrap();
        assert_eq!(pool.lookup(ip).as_deref(), Some("example.com"));
    }

    #[test]
    fn exhaustion_and_release() {
        // /30 v4 → 4 slots; /126 v6 → 4 slots. Total 8.
        let pool = FakeIpPool::new(
            IpRange4::parse("198.18.0.0/30").unwrap(),
            IpRange6::parse("fc00::/126").unwrap(),
            Duration::ZERO,
        );
        for i in 0..8 {
            pool.allocate(&format!("d{i}.example"), false).unwrap();
        }
        assert!(pool.allocate("overflow.example", false).is_err());

        std::thread::sleep(Duration::from_millis(2));
        pool.sweep_expired();
        pool.allocate("reuse.example", false).unwrap();
    }

    #[test]
    fn v6_preference_respected() {
        let pool = small_pool(Duration::from_secs(300));
        let ip = pool.allocate("example.com", true).unwrap();
        assert!(ip.is_ipv6());
    }

    #[test]
    fn range_parsing() {
        assert_eq!(IpRange4::parse("198.18.0.0/15").unwrap().capacity, 131_072);
        // IPv6 capacity is also derived from host_bits, capped at 2^18.
        // /114 -> 14 host bits -> 1<<14; /18 -> 110 host bits -> clamped to 1<<18.
        assert_eq!(IpRange6::parse("fc00::/114").unwrap().capacity, 1 << 14);
        assert_eq!(IpRange6::parse("fc00::/18").unwrap().capacity, 1 << 18);
        assert!(IpRange4::parse("1.2.3.4/33").is_err());
        assert!(IpRange6::parse("::/129").is_err());
    }
}
