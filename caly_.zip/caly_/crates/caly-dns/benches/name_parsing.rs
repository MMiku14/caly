//! Benchmarks for the SIMD-accelerated name codec.
//!
//! # What we measure
//!
//! * Short names (15–25 bytes): the common case for `api.example.com`-style
//!   endpoints.
//! * Long names (200+ bytes): stress the SIMD path's chunk handling.
//! * Compressed names: the pointer-following path.
//!
//! # Why these benchmarks
//!
//! The SIMD code path in `wire::name` claims a 3–5× speedup over the
//! scalar fallback. This benchmark measures whether that claim holds
//! for realistic inputs. When the SIMD feature is disabled, the same
//! benchmark measures the fallback, so a comparison is a Cargo feature
//! flag away.

use std::hint::black_box;

use caly_dns::wire::name::{encode_name, resolve_pointers, scan};
use criterion::{criterion_group, criterion_main, Criterion, Throughput};

fn bench_short_name(c: &mut Criterion) {
    let mut buf = Vec::new();
    encode_name("www.example.com", &mut buf).unwrap();

    let mut group = c.benchmark_group("name/short");
    group.throughput(Throughput::Bytes(buf.len() as u64));

    group.bench_function("scan", |b| {
        b.iter(|| {
            let offsets = scan(black_box(&buf), 0).unwrap();
            black_box(offsets.label_count())
        })
    });

    group.bench_function("resolve", |b| {
        b.iter(|| {
            let (name, end) = resolve_pointers(black_box(&buf), 0).unwrap();
            black_box((name, end))
        })
    });

    group.finish();
}

fn bench_long_name(c: &mut Criterion) {
    // 30 labels, each 30 chars — a pathological but legal name.
    let labels: Vec<String> = (0..30).map(|_| "a".repeat(30)).collect();
    let name = labels.join(".");
    let mut buf = Vec::new();
    encode_name(&name, &mut buf).unwrap();

    let mut group = c.benchmark_group("name/long");
    group.throughput(Throughput::Bytes(buf.len() as u64));

    group.bench_function("scan", |b| {
        b.iter(|| {
            let offsets = scan(black_box(&buf), 0).unwrap();
            black_box(offsets.label_count())
        })
    });

    group.bench_function("resolve", |b| {
        b.iter(|| {
            let (name, _) = resolve_pointers(black_box(&buf), 0).unwrap();
            black_box(name)
        })
    });

    group.finish();
}

fn bench_compressed_name(c: &mut Criterion) {
    // The pointer target is 0, so the encoding must stay in sync with
    // the encoder in `wire::name`.
    // "example.com" at 0, then "www" + pointer to 0 at offset 13.
    let mut buf = Vec::new();
    encode_name("example.com", &mut buf).unwrap();
    let pointer_offset = buf.len() as u16;
    buf.push(3);
    buf.extend_from_slice(b"www");
    buf.push(0xC0 | (pointer_offset >> 8) as u8);
    buf.push((pointer_offset & 0xFF) as u8);

    c.bench_function("name/compressed/resolve", |b| {
        b.iter(|| {
            let (name, _) = resolve_pointers(black_box(&buf), 13).unwrap();
            black_box(name)
        })
    });
}

fn bench_encoding(c: &mut Criterion) {
    let names = [
        "a.example",
        "www.example.com",
        "api.prod.us-east-1.example-corp.internal",
    ];

    let mut group = c.benchmark_group("name/encode");
    for name in names {
        group.bench_function(name, |b| {
            b.iter(|| {
                let mut out = Vec::with_capacity(128);
                encode_name(black_box(name), &mut out).unwrap();
                black_box(out)
            })
        });
    }
    group.finish();
}

criterion_group!(
    benches,
    bench_short_name,
    bench_long_name,
    bench_compressed_name,
    bench_encoding,
);
criterion_main!(benches);
