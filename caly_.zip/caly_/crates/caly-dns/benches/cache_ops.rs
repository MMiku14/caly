//! Benchmarks for the cache.
//!
//! # What we measure
//!
//! * `get` on a fresh entry (the hot path).
//! * `put` for a single record and for a CNAME chain.
//! * `snapshot` — the persistence export path.
//!
//! # Why
//!
//! The cache is on every query. A regression here is a regression
//! everywhere. These benchmarks establish a baseline; a change that
//! triples `get` latency will show up immediately.

use std::hint::black_box;
use std::net::{IpAddr, Ipv4Addr};
use std::time::Duration;

use caly_dns::cache::{CachedAnswer, DnsCache, SecurityStatus};
use criterion::{criterion_group, criterion_main, Criterion};

fn populated_cache(entries: usize) -> DnsCache {
    let cache = DnsCache::new(entries * 2, Duration::from_secs(60));
    // Pre-size the names so the loop measures cache behaviour, not
    // the allocator.
    for i in 0..entries {
        let name = format!("host{i}.example.com");
        let ip = IpAddr::V4(Ipv4Addr::new(
            10,
            (i >> 16) as u8,
            ((i >> 8) & 0xFF) as u8,
            (i & 0xFF) as u8,
        ));
        let ips = smallvec::smallvec![ip];
        cache.put(
            &name,
            &[],
            CachedAnswer::Resolved(ips),
            Duration::from_secs(300),
            None,
            SecurityStatus::Insecure,
        );
    }
    cache
}

fn bench_cache_get_hit(c: &mut Criterion) {
    let cache = populated_cache(1024);

    c.bench_function("cache/get_hit", |b| {
        b.iter(|| {
            let hit = cache.get(black_box("host42.example.com"), None);
            black_box(hit.is_some())
        })
    });
}

fn bench_cache_get_miss(c: &mut Criterion) {
    let cache = populated_cache(1024);

    c.bench_function("cache/get_miss", |b| {
        b.iter(|| {
            let hit = cache.get(black_box("nonexistent.example"), None);
            black_box(hit.is_some())
        })
    });
}

fn bench_cache_put_simple(c: &mut Criterion) {
    let cache = DnsCache::new(2048, Duration::from_secs(60));
    let ips = smallvec::smallvec![IpAddr::V4(Ipv4Addr::new(192, 0, 2, 1))];

    c.bench_function("cache/put_simple", |b| {
        b.iter(|| {
            cache.put(
                black_box("host.example.com"),
                &[],
                CachedAnswer::Resolved(ips.clone()),
                Duration::from_secs(300),
                None,
                SecurityStatus::Insecure,
            )
        })
    });
}

fn bench_cache_put_with_chain(c: &mut Criterion) {
    let cache = DnsCache::new(2048, Duration::from_secs(60));
    let ips = smallvec::smallvec![IpAddr::V4(Ipv4Addr::new(192, 0, 2, 1))];
    let chain: smallvec::SmallVec<[smol_str::SmolStr; 2]> = smallvec::smallvec![
        smol_str::SmolStr::new("b.example.com"),
        smol_str::SmolStr::new("c.example.com"),
        smol_str::SmolStr::new("d.example.com"),
    ];

    c.bench_function("cache/put_with_chain", |b| {
        b.iter(|| {
            cache.put(
                black_box("a.example.com"),
                &chain,
                CachedAnswer::Resolved(ips.clone()),
                Duration::from_secs(300),
                None,
                SecurityStatus::Insecure,
            )
        })
    });
}

fn bench_cache_nxdomain_cut(c: &mut Criterion) {
    let cache = DnsCache::new(2048, Duration::from_secs(60));

    c.bench_function("cache/put_nxdomain_with_cut", |b| {
        b.iter(|| {
            cache.put(
                black_box("missing.deep.sub.example.com"),
                &[],
                CachedAnswer::NxDomain,
                Duration::from_secs(30),
                None,
                SecurityStatus::Insecure,
            )
        })
    });
}

fn bench_cache_snapshot(c: &mut Criterion) {
    let cache = populated_cache(1024);

    c.bench_function("cache/snapshot_1024", |b| {
        b.iter(|| {
            let snapshot = cache.snapshot();
            black_box(snapshot.len())
        })
    });
}

fn bench_cache_prefetch_candidates(c: &mut Criterion) {
    let cache = populated_cache(1024);
    // Touch half of the entries so they become "hot".
    for i in 0..512 {
        let _ = cache.get(&format!("host{i}.example.com"), None);
    }

    c.bench_function("cache/prefetch_candidates", |b| {
        b.iter(|| {
            let candidates =
                cache.prefetch_candidates(Duration::from_secs(120), Duration::from_secs(300));
            black_box(candidates.len())
        })
    });
}

criterion_group!(
    benches,
    bench_cache_get_hit,
    bench_cache_get_miss,
    bench_cache_put_simple,
    bench_cache_put_with_chain,
    bench_cache_nxdomain_cut,
    bench_cache_snapshot,
    bench_cache_prefetch_candidates,
);
criterion_main!(benches);
